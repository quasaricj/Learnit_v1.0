# Learning Approach: Active Recall

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Active Recall as a learning technique.
- **Differentiate** between active recall and passive review.
- **Explain** why active recall is a more effective learning strategy than re-reading.
- **Apply** active recall techniques to your study of software engineering concepts.
- **Understand** the "testing effect" and its role in strengthening memory.

---

## 2. Introduction: How We Learn

Many of us learn by **passive review**. We read a textbook, highlight the important parts, and then re-read our highlights. We watch a tutorial video. We look at a completed example.

While this feels productive, cognitive science has shown that it is a very inefficient way to learn. Passive review creates an **"illusion of competence"**. You recognize the material when you see it, and you think you know it. But you can't actually *recall* it from memory when you need it.

**Active Recall** (also known as "retrieval practice") is a much more effective learning strategy. It is the act of actively retrieving information from your own memory, rather than passively consuming it.

---

## 3. The Science: Why Active Recall Works

Every time you pull a piece of information out of your memory, you are not just remembering it; you are **strengthening the neural pathways** that lead to it, making it easier to recall in the future. The act of "testing" yourself is a powerful learning event in itself. This is known as the **testing effect**.

Struggling to recall a piece of information is not a sign of failure; **the struggle itself is what builds the memory.**

### Passive vs. Active

- **Passive**: "Let me read the chapter on the Circuit Breaker pattern again."
- **Active**: Close the book and ask yourself: "What are the three states of a Circuit Breaker? Can I draw a diagram of how it works?"

---

## 4. How to Apply Active Recall to Software Development

This entire course has been designed with active recall in mind.

### 1. Use the "Active Recall Questions"

- At the end of each topic, there is a list of "Active Recall Questions".
- **Do not** just read them and think "yeah, I know that."
- **Actively** try to answer them out loud, write down the answers, or explain them to a friend, all without looking at the material.
- Only after you have tried to retrieve the information from your own memory should you go back and check if you were right.

### 2. The Feynman Technique

- This is a powerful active recall method for deeply understanding a concept.
  1.  Choose a concept you want to learn (e.g., the CAP Theorem).
  2.  **Teach it to a child** (or pretend to). Explain it in the simplest possible terms. Use analogies.
  3.  When you get stuck or use complex jargon, you have identified a gap in your own understanding.
  4.  Go back to the source material to fill in the gap, and then repeat the process until you can explain the concept clearly and simply.

### 3. Flashcards (for facts and definitions)

- Use a flashcard app (like Anki) to create digital flashcards for definitions, concepts, and syntax.
- **The question goes on one side, the answer goes on the other.**
- The act of trying to remember the answer before you flip the card is active recall.

### 4. Solve Problems from Scratch

- When you are practicing a coding problem, do not have the solution open in another window.
- Write the code from a blank slate. Try to recall the algorithm and the syntax from your own memory.
- This is the most important form of active recall for a developer.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that **Active Recall** is the act of retrieving information from memory.
-   [ ] I know that active recall is a much more effective learning strategy than passive re-reading.
-   [ ] I understand that the **struggle** to remember is what strengthens the memory.
-   [ ] I will use the "Active Recall Questions" at the end of each topic to test myself.
-   [ ] I can use the **Feynman Technique** to test my deep understanding of a concept by trying to explain it simply.

---

## 6. Research and References

-   **"Make It Stick: The Science of Successful Learning" by Peter C. Brown, Henry L. Roediger III, and Mark A. McDaniel**: The definitive, research-backed book on effective learning strategies. Active recall is a central theme.
-   **"A Mind for Numbers: How to Excel at Math and Science" by Barbara Oakley**: A very practical guide to learning difficult, technical subjects.
-   **Ali Abdaal's YouTube Channel**: A popular productivity YouTuber who has many excellent videos that explain the science of active recall and how to apply it.
-   **Anki**: A popular, free, open-source flashcard app that uses spaced repetition. [Link](https://apps.ankiweb.net/)
