# Learning Approach: Spaced Repetition

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Spaced Repetition as a learning technique.
- **Explain** the "Forgetting Curve" and how spaced repetition helps to combat it.
- **Understand** how to combine spaced repetition with active recall for maximum effect.
- **Apply** a spaced repetition schedule to your own learning.
- **Recognize** that spaced repetition is a long-term strategy for building durable knowledge.

---

## 2. Introduction: The Problem of Forgetting

You've just spent a week doing a deep dive on Kubernetes. You feel like you have a good grasp of the concepts. But what happens two weeks from now? Or two months from now?

In the late 19th century, psychologist Hermann Ebbinghaus discovered the **"Forgetting Curve"**. It describes how our memory of new information decays over time. We forget things exponentially. You might forget 50% of what you learned within a day, and 90% within a week.

**Spaced Repetition** is a learning technique that is designed to combat the forgetting curve. It is an evidence-based technique that involves reviewing information at increasing intervals of time.

---

## 3. How Spaced Repetition Works

The core idea is simple:
- When you first learn a new piece of information, you should review it again very soon (e.g., the next day).
- Each time you successfully recall the information, you **increase the interval** before the next review.
- The intervals might look something like this: 1 day, 3 days, 1 week, 2 weeks, 1 month, 3 months, etc.

By reviewing the information at the point when you are *just about to forget it*, you are telling your brain that this information is important, and it strengthens the memory in a very durable way.

### Spaced Repetition + Active Recall

Spaced repetition is most powerful when it is combined with **active recall**. The "review" should not be a passive re-reading. It should be an active test of your memory.

This is the foundation of flashcard systems like **Anki** or **SuperMemo**.
1.  You create a flashcard for a concept.
2.  The app shows you the "question" side of the card.
3.  You try to **actively recall** the answer.
4.  You then rate how difficult it was for you to recall the answer.
5.  Based on your rating, the app's algorithm will automatically schedule the next time you will see that card. If it was easy, you won't see it for a long time. If you struggled, you will see it again very soon.

---

## 4. How to Apply Spaced Repetition

### 1. Use a Flashcard System (for facts and concepts)

- **What to put on flashcards**:
  - Definitions (e.g., "What is a CDN?").
  - Concepts (e.g., "What is the difference between IaaS, PaaS, and SaaS?").
  - The names of design patterns and their purpose.
  - The names of popular tools for a given job.
- **Make it a Daily Habit**: Spend 10-15 minutes every day reviewing your flashcards. The key is consistency.

### 2. Schedule Your Practice (for skills)

- Spaced repetition doesn't just apply to facts; it applies to skills as well.
- **Example**:
  - You learn how to implement a Binary Search.
  - You should try to solve another binary search problem the next day.
  - Then, try another one 3 days later.
  - Then, try another one a week after that.
- This is how you build a deep and intuitive understanding of an algorithmic pattern.

### 3. Review Previous Modules

- As you are working through this course, don't just focus on the current module.
- At the end of each week, go back and spend a short amount of time reviewing the "Summary and Mastery Checklist" and the "Active Recall Questions" from a previous module. This will help to keep the information fresh and to build connections between the different topics.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define **Spaced Repetition** as the technique of reviewing information at increasing intervals.
-   [ ] I can explain that the goal of this technique is to combat the **Forgetting Curve**.
-   [ ] I know that spaced repetition is most effective when the "review" is done using **active recall**.
-   [ ] I can use a flashcard app like **Anki** to apply spaced repetition to facts and concepts.
-   [ ] I understand that I should also apply this principle to my skills practice, by revisiting old problem types at regular intervals.

---

## 6. Research and References

-   **"Make It Stick: The Science of Successful Learning"**: A must-read book that explains the research behind spaced repetition and other effective learning strategies.
-   **Anki**: The most popular open-source spaced repetition flashcard system. [Link](https://apps.ankiweb.net/)
-   **"Spaced Repetition: A Guide for Students"**: A common topic for blogs on learning and productivity.
-   **The Ebbinghaus Forgetting Curve**: The original research that underpins the theory.
