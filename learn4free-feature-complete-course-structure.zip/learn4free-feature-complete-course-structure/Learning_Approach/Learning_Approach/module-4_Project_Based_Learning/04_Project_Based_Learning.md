# Learning Approach: Project-Based Learning

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Project-Based Learning (PBL).
- **Explain** why PBL is a particularly effective strategy for learning software development.
- **Understand** the difference between a small practice exercise and a larger, integrated project.
- **Apply** the principles of PBL by building a capstone project.
- **Recognize** that building projects is the best way to create a strong portfolio and to prepare for real-world work.

---

## 2. Introduction: "Learning by Doing"

**Project-Based Learning (PBL)** is a learning method in which you gain knowledge and skills by working for an extended period of time to investigate and respond to an authentic, engaging, and complex question, problem, or challenge.

In software development, this means **building real, working applications**.

While exercises, tutorials, and flashcards are great for learning the individual "bricks" (the concepts, the syntax, the algorithms), a project is where you learn how to put all the bricks together to build a "house". It is the process of **synthesis**.

---

## 3. Why Project-Based Learning is So Effective

1.  **It's Active, Not Passive**:
    - You cannot build a project by passively watching a video. You have to actively write the code, solve the problems, and make the decisions. This is a form of **active recall** on a macro scale.

2.  **It's Integrated**:
    - A real project forces you to integrate all the different concepts you have learned. You can't just think about the database in isolation; you have to think about how the backend will talk to the database, how the frontend will talk to the backend, and how it will all be deployed.

3.  **It Teaches You How to "Learn How to Learn"**:
    - No course can teach you everything. When you are building a project, you will inevitably run into a problem that you don't know the answer to.
    - You will have to learn how to read documentation, how to search for answers on Stack Overflow, and how to debug a problem. These are the most critical skills for a real-world software engineer.

4.  **It's Motivating**:
    - Working on a project that you are genuinely interested in is much more motivating than just doing abstract exercises.

5.  **It Creates a Portfolio**:
    - A collection of well-built projects on your GitHub profile is the single most powerful tool you have for proving your skills to a potential employer. It is a concrete demonstration that you can not only *know* the concepts, but that you can *apply* them to create a working product.

---

## 4. The Structure of a Good Learning Project

- **Start Small**: Your first project should be small and achievable. The "Task Management CLI Application" from Phase 1 is a good example.
- **Increase Complexity**: As you learn more, your projects should become more complex and should integrate more parts of the stack.
- **The Capstone Project**: The final project in this course is a "capstone". It is designed to be a comprehensive project where you apply everything you have learned, from system design to CI/CD and cloud deployment.

### A Good Project is a "T-shaped" Project

- It should have a reasonable **breadth** (it touches all the parts of the stack: frontend, backend, database, deployment).
- It should also have **depth** in one or two specific areas that you are particularly interested in. For example, if you are interested in distributed systems, you might build a simple chat application, as this will force you to learn about WebSockets and real-time communication.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define **Project-Based Learning** as the process of learning by building real-world applications.
-   [ ] I understand that projects are about **synthesis**—putting all the individual concepts together.
-   [ ] I know that building projects is the best way to learn how to **debug** and to **read documentation**.
-   [ ] I understand that a strong **portfolio of projects** is essential for a successful job search.
-   [ ] I am committed to building the **Capstone Project** as a way to demonstrate and solidify my skills.

---

## 6. Research and References

-   **"The Pragmatic Programmer" by David Thomas and Andrew Hunt**: Encourages a hands-on, project-based approach to learning and skill development.
-   **"Portfolio Projects for Software Developers"**: A common topic for blog posts and YouTube videos that provide great ideas and inspiration.
-   **"How to Build a Portfolio that Will Get You a Job"**: Another common topic with practical advice.
-   **GitHub**: Explore popular open-source projects to see how large, real-world applications are built and structured.
