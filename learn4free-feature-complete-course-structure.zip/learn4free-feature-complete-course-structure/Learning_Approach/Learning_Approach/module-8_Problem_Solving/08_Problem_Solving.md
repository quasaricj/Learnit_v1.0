# Learning Approach: Systematic Problem-Solving

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Recognize** that problem-solving is a skill that can be learned and improved.
- **Apply** a systematic, structured approach to solving a problem.
- **Describe** Polya's four-step problem-solving process.
- **Understand** the importance of clearly defining the problem before trying to solve it.
- **Use** techniques like breaking a problem down and solving a simpler version first.
- **Develop** the habit of verifying your solution.

---

## 2. Introduction: "Thinking Like a Programmer"

At its heart, software engineering is not about writing code. It is about **solving problems**. The code is just the tool you use to express the solution. "Thinking like a programmer" means having a systematic and logical approach to breaking down and solving complex problems.

This is a skill, and like any other skill, it can be improved with deliberate practice. Having a structured process is far more effective than just "diving in" and hoping for the best.

---

## 3. Polya's Four-Step Problem-Solving Process

George Polya was a mathematician who wrote a famous book called "How to Solve It" in 1945. His four-step process is a simple, powerful, and universal framework for problem-solving that is highly applicable to software development.

### Step 1: Understand the Problem

- This is the most important step, and the one that is most often skipped. You must understand the problem before you can solve it.
- **Questions to ask yourself**:
  - Can I restate the problem in my own words?
  - What are the inputs? What are the outputs?
  - What are the constraints or the rules?
  - Can I work through a few small, concrete examples by hand?
- **In programming terms**: This is about clarifying the requirements. What are the function's arguments? What should it return? What are the edge cases?

### Step 2: Devise a Plan

- Find a connection between the data you have (the inputs) and the unknown (the output). You may be obliged to consider auxiliary problems if an immediate connection cannot be found.
- **Strategies to try**:
  - **Look for a pattern**: Do your concrete examples have a pattern?
  - **Solve a simpler problem**: Can you solve a simplified version of the problem first? (e.g., "What if the input array was already sorted?").
  - **Break it down**: Can you break the problem down into smaller, independent subproblems? (This is the core of **problem decomposition**).
  - **Work backward**: Start from the output and try to work your way back to the inputs.
  - **Draw a picture or a diagram**.
- **In programming terms**: This is the **algorithmic thinking** and **system design** phase. You are choosing your data structures and algorithms and sketching out the high-level logic before you write any code.

### Step 3: Carry out the Plan

- Implement your plan.
- **In programming terms**: This is the part where you actually **write the code**.
- **Best Practices**:
  - As you are implementing, check each step.
  - Write your code in a clean, readable way.
  - Add comments where the logic is complex.

### Step 4: Look Back (and Verify)

- Examine the solution you have obtained.
- **Questions to ask yourself**:
  - Does my solution work for my small, concrete examples?
  - Does it handle the edge cases?
  - Can I verify the result? (e.g., by writing an automated test).
  - Can I derive the result differently?
  - Can I improve the solution? Is it efficient? Can it be made more readable?
- **In programming terms**: This is the **testing, debugging, and refactoring** phase. You must verify that your code is not just "done," but that it is correct and well-written.

---

## 4. Applying the Process to a Coding Challenge

**Problem**: "Given a sorted array of integers, return the index of a given target value, or -1 if it is not present."

1.  **Understand**:
    - **Inputs**: A sorted array of integers, and a target integer.
    - **Output**: The index of the target, or -1.
    - **Constraint**: The array is sorted. This is a huge clue.
    - **Example**: `arr = [2, 5, 8, 12, 16]`, `target = 12` -> `output = 3`.
    - **Example**: `arr = [2, 5, 8, 12, 16]`, `target = 7` -> `output = -1`.

2.  **Plan**:
    - My first thought is a linear search (loop through the array). But the array is sorted. This suggests a more efficient algorithm is possible.
    - I can use **Binary Search**.
    - My plan is to have two pointers, `left` and `right`. I will look at the middle element. If it's the target, I'm done. If it's too big, I'll move the `right` pointer. If it's too small, I'll move the `left` pointer. I will repeat this until the pointers cross.

3.  **Carry out**:
    - Write the code for the binary search algorithm.

4.  **Look Back**:
    - Does it work for my examples? Yes.
    - What are the edge cases?
      - An empty array.
      - An array with one element.
      - The target is the first or the last element.
    - I will write **unit tests** for all these cases to verify my solution is correct.
    - The solution is `O(log n)`, which is very efficient. The code is clean. I am confident in this solution.

---

## 5. Summary and Mastery Checklist

-   [ ] I know that problem-solving is a structured skill, not a random act of genius.
-   [ ] I can name Polya's four steps: **Understand, Plan, Do, Look Back**.
-   [ ] I will always take the time to **fully understand the problem** and work through small examples before I start to code.
-   [ ] I will try to **break down** a complex problem into smaller, simpler subproblems.
-   [ ] I will always **verify** my solution, preferably by writing automated tests.

---

## 6. Research and References

-   **"How to Solve It" by George Polya**: The classic book on the topic.
-   **"The Pragmatic Programmer" by David Thomas and Andrew Hunt**: Has great advice on the mindset of a successful problem-solver.
-   **"Cracking the Coding Interview" by Gayle Laakmann McDowell**: This book is not just a collection of problems; it is a masterclass in applying a systematic approach to solving them.
-   **LeetCode / HackerRank**: These sites provide a massive number of problems for you to practice this skill on.
