# Variables, Data Types, Expressions, and Operators

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** what a variable is and its role in programming.
- **Declare and initialize** variables.
- **Identify and differentiate** between various data types (integers, strings, booleans, etc.).
- **Define** what an expression is and its role in programming.
- **Identify and use** arithmetic, assignment, comparison, and logical operators.
- **Understand** operator precedence and associativity.
- **Construct** complex expressions to solve problems.
- **Apply** boolean logic to control program flow.

---

## 2. Introduction

At the heart of any programming language lies the ability to store and manipulate data. **Variables** are the fundamental containers for storing this data, while **data types** are the classifications that tell the computer how to interpret that data. **Expressions** and **operators** are the building blocks that allow you to process that data and make decisions. Mastering these concepts is the first and most critical step in your journey to becoming a proficient software developer.

---

## 3. Core Concepts

### Variables and Data Types

A **variable** is a named storage location in a computer's memory that holds a value. A **data type** specifies the type of data that a variable can hold.

- **Primitive Data Types**:
  - **Integer (`int`)**: Whole numbers.
  - **Floating-Point (`float`, `double`)**: Numbers with a decimal point.
  - **Boolean (`bool`)**: `true` or `false`.
  - **Character (`char`)**: A single character.
- **Composite Data Types**:
  - **String (`str`)**: A sequence of characters.

### Expressions and Operators

An **expression** is a combination of values, variables, and operators that evaluates to a single value. **Operators** are special symbols that perform operations.

- **Arithmetic Operators**: `+`, `-`, `*`, `/`, `%`
- **Assignment Operators**: `=`, `+=`, `-=`
- **Comparison Operators**: `==`, `!=`, `<`, `>`, `<=`, `>=`
- **Logical Operators**: `&&` (AND), `||` (OR), `!` (NOT)

### Operator Precedence

This is the order in which operators are evaluated. Multiplication has a higher precedence than addition. Use parentheses `()` to control the order.

---

## 4. Deliberate Practice

1.  **Declare and Initialize**: Declare variables for your name and age.
2.  **Simple Calculations**: Create two integer variables and perform addition, subtraction, multiplication, and division.
3.  **Temperature Converter**: Write an expression to convert a temperature from Celsius to Fahrenheit.
4.  **Logical Puzzle**: Write an expression that evaluates to `true` if a number is between 10 and 20 (inclusive).

---

## 5. Active Recall Questions

- What is the difference between declaring and initializing a variable?
- Explain the difference between `=` and `==`.
- What is operator precedence?
- Name three primitive data types and give an example of each.
- When would you use the logical AND operator?

---

## 6. Tools, Frameworks, and Platforms

- **IDE (Integrated Development Environment)**: VS Code, IntelliJ IDEA, or PyCharm.
- **Debugger**: Step through your code to see how expressions are evaluated.
- **Linters**: Tools like ESLint or Pylint help enforce coding standards.

---

## 7. Summary and Mastery Checklist

- [ ] I can explain what a variable is.
- [ ] I can list and describe the most common primitive data types.
- [ ] I can use arithmetic operators to perform calculations.
- [ ] I can use comparison and logical operators to make decisions.
- [ ] I understand operator precedence.

---

## 8. Research and References

- **MDN Web Docs - Expressions and operators**: [Link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Expressions_and_Operators)
- **"Clean Code" by Robert C. Martin**
