# Control Structures: Conditionals and Loops

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** the concept of control flow in programming.
- **Implement** conditional logic using `if`, `else if`, and `else` statements.
- **Utilize** `switch` statements for multi-branch decision-making.
- **Write** `for`, `while`, and `do-while` loops to repeat actions.
- **Control** loop execution with the `break` and `continue` keywords.
- **Choose** the appropriate control structure for a given problem.

---

## 2. Introduction to Control Structures

So far, you've learned how to write code that executes line-by-line, from top to bottom. But what if you want your program to make decisions or repeat actions? **Control structures** are the answer. They allow you to alter the default sequential flow of execution, enabling your programs to handle complex logic and respond to different inputs.

---

## 3. Core Concepts

### Conditionals

Conditionals allow your program to execute different blocks of code based on whether a certain condition is true or false.

-   **`if` Statement**: Executes a block of code if a condition is true.
-   **`else if` Statement**: Checks for another condition if the first `if` was false.
-   **`else` Statement**: Executes a block of code if all preceding conditions were false.
-   **Ternary Operator**: A shorthand for a simple `if-else` statement. Example: `result = (condition) ? value_if_true : value_if_false;`
-   **`switch` Statement**: Efficiently handles multiple possible values for a single variable.

### Loops

Loops are used to execute a block of code repeatedly as long as a certain condition is met.

-   **`for` Loop**: The most common type of loop. It consists of an initializer, a condition, and an incrementor. Ideal for when you know how many times you want to loop.
-   **`while` Loop**: Executes a block of code as long as a condition is true. The condition is checked *before* each iteration.
-   **`do-while` Loop**: Similar to a `while` loop, but the condition is checked *after* each iteration, meaning the code block will always execute at least once.
-   **`break`**: Immediately exits the current loop.
-   **`continue`**: Skips the rest of the current iteration and proceeds to the next one.

---

## 4. Deliberate Practice

1.  **Grade Calculator**: Write a program that takes a numerical score and prints the corresponding letter grade (A, B, C, D, or F).
2.  **FizzBuzz**: Write a program that prints the numbers from 1 to 100. For multiples of three, print "Fizz" instead of the number. For multiples of five, print "Buzz". For numbers which are multiples of both three and five, print "FizzBuzz".
3.  **Sum of an Array**: Write a function that calculates the sum of all numbers in an array/list using a `for` loop.
4.  **Guessing Game**: Create a simple game where the computer picks a random number and the user has to guess it. Use a `while` loop to keep the game going until the user guesses correctly.

---

## 5. Active Recall Questions

-   What is the main difference between a `while` loop and a `do-while` loop?
-   In a `for` loop, what are the three parts inside the parentheses?
-   When is it more appropriate to use a `switch` statement instead of a series of `if-else` statements?
-   What does the `continue` keyword do?
-   How can you create an infinite loop, and why is it usually a bad thing?

---

## 6. Tools, Frameworks, and Platforms

-   **Debugger**: An invaluable tool for visualizing control flow. You can set breakpoints and step through your code line-by-line to see how decisions are made and how loops execute.
-   **Flowchart Tools**: Websites like [draw.io](https://draw.io) (now diagrams.net) can help you map out your logic visually before you start coding.

---

## 7. Feedback and Self-Assessment

-   **Unit Testing**: Write tests for different branches of your conditional logic. For example, in the grade calculator, have a test for each letter grade.
-   **Peer Code Review**: Ask a colleague to review your use of control structures. Is there a more efficient or readable way to write your logic?
-   **Trace Tables**: For a given loop, create a table to track the values of your variables through each iteration. This helps you understand exactly what the loop is doing.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Imagine you are implementing the logic for a login form. The system should check the following:
1.  Is the username field empty?
2.  If not, does the username exist in the database?
3.  Is the password field empty?
4.  If not, does the password match the one for the given username?

Map out this logic using nested `if-else` statements. This exercise demonstrates how control structures are used to handle real-world validation scenarios.

---

## 9. Collaborative Activities

-   **Pair Programming**: Work with a partner on the "Guessing Game" practice exercise. One person can write the logic for the loop, while the other handles the conditional checks.
-   **Logic Puzzles**: As a group, try to solve logic puzzles using pseudocode on a whiteboard. This helps you focus on the control flow without getting bogged down in syntax.

---

## 10. Domain-Specific Mastery Strategies

-   **Web Development**: Control structures are used to render lists of items, show or hide UI elements based on user authentication, and handle user input.
-   **Data Science**: You'll use loops and conditionals to iterate over large datasets, filter out irrelevant data, and perform calculations on specific subsets of your data.
-   **Embedded Systems**: Control flow is critical for reading sensor data, controlling motors, and responding to external events in real-time.

---

## 11. Psychological and Cognitive Principles

-   **Decomposition**: Break down complex problems into smaller, more manageable logical checks. A series of simple `if` statements is often better than one highly complex one.
-   **Mental Models**: Before you write a loop, have a clear mental model of what will happen in the first iteration, a middle iteration, and the last iteration.

---

## 12. Summary and Mastery Checklist

-   [ ] I can use `if`, `else if`, and `else` to create conditional logic.
-   [ ] I can use a `for` loop to iterate a specific number of times.
-   [ ] I can use a `while` loop to iterate as long as a condition is true.
-   [ ] I can differentiate between `break` and `continue`.
-   [ ] I can analyze a problem and choose the best control structure to solve it.

---

## 13. Research and References

-   **MDN Web Docs - Control flow and error handling**: [Link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling)
-   **"Eloquent JavaScript" by Marijn Haverbeke, Chapter 2: Program Structure**: A great introduction to control flow.
