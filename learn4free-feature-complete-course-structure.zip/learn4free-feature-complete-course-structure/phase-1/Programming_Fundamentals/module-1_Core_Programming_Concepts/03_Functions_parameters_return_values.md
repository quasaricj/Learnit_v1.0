# Functions, Parameters, and Return Values

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** what a function is and explain its purpose in programming.
-   **Declare and call** functions in your chosen programming language.
-   **Pass arguments** to functions through parameters.
-   **Return values** from functions to be used in other parts of the code.
-   **Understand** the concept of function scope.
-   **Write modular and reusable** code by encapsulating logic within functions.

---

## 2. Introduction to Functions

As programs grow in complexity, it becomes crucial to organize your code in a clean and manageable way. **Functions** are the primary tool for achieving this. They are self-contained blocks of code that perform a specific task. By encapsulating logic within functions, you can make your code more reusable, readable, and easier to debug, following the **DRY (Don't Repeat Yourself)** principle.

---

## 3. Core Concepts

### What is a Function?

A function is a reusable block of code that performs a specific action. Functions can be "called" or "invoked" from other parts of the code.

-   **Function Declaration**: The process of defining the function's name, parameters, and the code it will execute.
-   **Function Call**: The act of executing a function.

### Parameters and Arguments

-   **Parameters**: The variables listed in a function's definition. They act as placeholders for the values that will be passed to the function.
-   **Arguments**: The actual values that are passed to the function when it is called.

### Return Values

Functions can send a value back to the code that called them using a **return statement**. This is useful for functions that perform calculations or retrieve data. If a function does not have a return statement, it implicitly returns a default value (e.g., `undefined` in JavaScript, `None` in Python).

### Scope

**Scope** determines the accessibility of variables. Variables declared inside a function are in the **local scope** of that function and cannot be accessed from outside. This is a crucial concept for preventing naming conflicts and unintended side effects.

---

## 4. Deliberate Practice

1.  **Greeting Function**: Write a function that takes a person's name as a parameter and prints a personalized greeting.
2.  **Area of a Rectangle**: Write a function that takes the width and height of a rectangle as parameters and returns its area.
3.  **isEven Function**: Write a function that takes a number as a parameter and returns `true` if the number is even, and `false` otherwise.
4.  **Combine Functions**: Use the `isEven` function you just wrote inside another function that prints a message indicating whether a number is even or odd.

---

## 5. Active Recall Questions

-   What is the difference between a parameter and an argument?
-   What is the purpose of the `return` keyword?
-   Can a function be called before it is declared? (This depends on the language, a good research question!)
-   What happens if you call a function with more or fewer arguments than it has parameters?
-   Explain the concept of "local scope".

---

## 6. Tools, Frameworks, and Platforms

-   **Debugger**: Step into and out of functions to trace the flow of execution and inspect the values of local variables.
-   **Linters**: Can be configured to enforce function naming conventions and parameter limits.
-   **Documentation Generators**: Tools like JSDoc or Sphinx can automatically generate documentation for your functions based on comments in your code.

---

## 7. Feedback and Self-Assessment

-   **Unit Tests**: Write tests for your functions that cover different inputs and edge cases. For the `isEven` function, test it with positive numbers, negative numbers, and zero.
-   **Code Review**: Ask a peer to review your functions. Are the names clear? Is the logic easy to follow? Are they too long? (A good rule of thumb is that a function should do one thing and do it well).
-   **Refactoring**: Look for repeated code in your projects and refactor it into a reusable function.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: You are building a simple e-commerce application. You need to calculate the total price of an item, including tax.
1.  Write a function `calculate_tax` that takes a price and a tax rate as parameters and returns the amount of tax.
2.  Write another function `calculate_total` that takes a price and a tax rate, calls `calculate_tax` to get the tax amount, and then returns the original price plus the tax.

This exercise demonstrates how functions can be composed together to build more complex logic from simpler, reusable pieces.

---

## 9. Collaborative Activities

-   **"Black Box" Exercise**: One person writes a function and gives only the function name and a description of what it does to a partner. The partner then has to write code that uses the function, without seeing the implementation.
-   **API Design**: As a group, design the functions that would be needed for a simple application (e.g., a to-do list). What would the function names be? What parameters would they take? What would they return?

---

## 10. Domain-Specific Mastery Strategies

-   **Frontend Development**: Functions are used extensively as event handlers (e.g., what happens when a button is clicked). Reusable functions are also used to create UI components.
-   **Backend Development**: Functions are used to create API endpoints, interact with databases, and encapsulate business logic.
-   **Data Science**: Functions are used to create reusable data cleaning and transformation pipelines.

---

## 11. Psychological and Cognitive Principles

-   **Abstraction**: Functions are a form of abstraction. They allow you to use a piece of code without needing to know the details of its implementation. This reduces cognitive load.
-   **Single Responsibility Principle**: A function should be responsible for only one thing. This makes it easier to reason about, test, and reuse.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the purpose of functions in programming.
-   [ ] I can declare a function that accepts parameters.
-   [ ] I can call a function and pass it arguments.
-   [ ] I can use the `return` keyword to get a value from a function.
-   [ ] I understand that variables declared inside a function are local to that function.

---

## 13. Research and References

-   **MDN Web Docs - Functions**: [Link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions)
-   **"Clean Code" by Robert C. Martin, Chapter 3: Functions**: A highly recommended read on how to write effective functions.
