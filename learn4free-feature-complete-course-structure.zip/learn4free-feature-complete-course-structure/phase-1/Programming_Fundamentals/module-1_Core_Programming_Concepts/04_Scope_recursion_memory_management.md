# Scope, Recursion, and Memory Management

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Differentiate** between global, local, and block scope.
-   **Understand** the concept of the call stack and how it relates to function calls.
-   **Define** recursion and identify the necessary components of a recursive function (base case, recursive step).
-   **Solve** problems using recursion (e.g., factorial, Fibonacci).
-   **Explain** the difference between the stack and the heap in memory management.
-   **Recognize** potential issues like stack overflow and memory leaks.

---

## 2. Introduction to Advanced Concepts

This module dives into some of the more abstract but critically important concepts in programming. **Scope** rules how variables are accessed, **recursion** provides a powerful alternative to iteration for solving certain problems, and **memory management** is the foundation upon which your entire program runs. Understanding these topics will elevate your coding from simply "working" to being efficient and robust.

---

## 3. Core Concepts

### Scope

Scope defines the context in which variables are declared and can be accessed.

-   **Global Scope**: Variables declared outside of any function are in the global scope and can be accessed from anywhere in the code.
-   **Local/Function Scope**: Variables declared inside a function are local to that function and cannot be accessed from the outside.
-   **Block Scope**: In many modern languages (like JavaScript with `let`/`const`), variables can be scoped to a block of code (e.g., inside an `if` statement or a `for` loop).

### Recursion

Recursion is a technique where a function calls itself to solve a problem. A recursive function must have:

-   **Base Case**: A condition that stops the recursion. Without a base case, the function would call itself indefinitely, leading to a "stack overflow".
-   **Recursive Step**: The part of the function that calls itself, usually with a modified argument that moves it closer to the base case.

*Example: Factorial*
`factorial(n)` is `n * factorial(n-1)`, with the base case being `factorial(0) = 1`.

### Memory Management

Your program uses two main areas of memory:

-   **The Stack**: An area of memory that stores information about function calls. When a function is called, a "stack frame" is added to the top of the stack, containing its local variables and parameters. When the function returns, its frame is popped off the stack. The stack is fast but limited in size.
-   **The Heap**: A large pool of memory used for dynamic allocation of objects and data that needs to persist beyond a single function call. Memory management on the heap is more complex and can be a source of bugs (e.g., memory leaks) in languages without automatic garbage collection.

---

## 4. Deliberate Practice

1.  **Scope Practice**: Create a global variable and a local variable with the same name. Print the value of the variable from inside and outside the function to observe how scope works.
2.  **Factorial Function**: Write a recursive function to calculate the factorial of a number.
3.  **Fibonacci Sequence**: Write a recursive function to calculate the nth number in the Fibonacci sequence.
4.  **Visualize the Call Stack**: On paper or a whiteboard, trace the execution of your recursive factorial function for `n=3`. Draw the stack frames for each function call.

---

## 5. Active Recall Questions

-   What is the main difference between the stack and the heap?
-   What is a "stack overflow"?
-   Every recursive function must have what two components?
-   Why is it generally a bad idea to use too many global variables?
-   Explain the call stack in your own words.

---

## 6. Tools, Frameworks, and Platforms

-   **Debugger**: The ultimate tool for understanding these concepts. You can view the call stack in real-time, see how local variables are scoped to each function, and step through recursive calls.
-   **Memory Profilers**: Tools included in browser developer tools or IDEs that allow you to inspect memory usage, detect memory leaks, and understand how your program is using the heap.

---

## 7. Feedback and Self-Assessment

-   **Test with Edge Cases**: Test your recursive functions with a base case (e.g., `factorial(0)`), a small number, and a larger number.
-   **Add Logging**: Add `print` statements to the beginning and end of your recursive function to see the flow of execution and the values of variables at each step.
-   **Compare with Iteration**: For a problem you solved with recursion, try solving it with a loop instead. What are the pros and cons of each approach?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Consider a file system, which is a tree-like structure of folders and files. You want to write a function that finds a file by its name. A recursive approach is very natural here:
1.  The function takes a directory and a filename as input.
2.  It checks all files in the current directory. If it finds a match, it returns the file path.
3.  If it finds a subdirectory, it *recursively calls itself* on that subdirectory.
4.  The base case is an empty directory or a directory with no subdirectories.

This demonstrates how recursion is perfectly suited for problems that can be broken down into smaller, self-similar subproblems.

---

## 9. Collaborative Activities

-   **Peer Explanations**: One person explains the call stack, and the other explains the difference between the stack and the heap. Teaching a concept is one of the best ways to solidify your own understanding.
-   **Recursive Problem Solving**: As a group, brainstorm problems that could be solved recursively (e.g., traversing a maze, calculating the power of a number).

---

## 10. Domain-Specific Mastery Strategies

-   **UI Development**: Component trees in frameworks like React are often traversed using recursive-like algorithms. Understanding recursion helps in understanding how data flows through the application.
-   **Backend Development**: Asynchronous programming often involves a deep chain of function calls (the call stack). Understanding the stack is crucial for debugging asynchronous code.
-   **Compiler Design**: Compilers and interpreters rely heavily on tree structures (Abstract Syntax Trees) and recursive algorithms to parse and evaluate code.

---

## 11. Psychological and Cognitive Principles

-   **Recursive Leap of Faith**: When writing a recursive function, you have to trust that the function will work correctly for the smaller subproblem. Don't try to trace the entire call stack in your head once the logic is sound.
-   **Visualization**: Use diagrams and visual aids to understand the call stack and tree-like data structures. Our brains are much better at processing visual information.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the difference between global and local scope.
-   [ ] I can define the "call stack" and its role in function calls.
-   [ ] I can identify the base case and recursive step in a recursive function.
-   [ ] I can write a simple recursive function to solve a problem.
-   [ ] I can explain the difference between stack and heap memory.

---

## 13. Research and References

-   **MDN Web Docs - Scope**: [Link](https://developer.mozilla.org/en-US/docs/Glossary/Scope)
-   **"Grokking Algorithms" by Aditya Bhargava, Chapter 3: Recursion**: A very visual and intuitive explanation of recursion and the call stack.
-   **Computerphile YouTube Channel - Stack vs Heap**: [Link](https://www.youtube.com/watch?v=1p_aG5L42_c)
