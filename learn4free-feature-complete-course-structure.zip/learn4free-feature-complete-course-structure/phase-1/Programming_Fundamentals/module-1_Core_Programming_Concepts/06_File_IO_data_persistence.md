# File I/O and Data Persistence

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** the concept of data persistence and its importance.
-   **Read data** from and **write data** to text files.
-   **Differentiate** between various file modes (read, write, append).
-   **Handle** common errors that can occur during file operations.
-   **Understand** the basics of structured data formats like CSV and JSON.
-   **Manage** file resources properly, ensuring files are closed after use.

---

## 2. Introduction to File I/O and Data Persistence

So far, all the data your programs have worked with has been **transient**, meaning it disappears the moment the program stops running. To build truly useful applications, you need a way to save data permanently. This is known as **data persistence**. The most fundamental way to persist data is by reading from and writing to **files** on a computer's storage system. This process is called **File I/O (Input/Output)**.

---

## 3. Core Concepts

### What is File I/O?

File I/O is the process of exchanging data between your program and a file on a disk.
-   **Input**: Reading data from a file into your program's memory.
-   **Output**: Writing data from your program's memory to a file.

### The File I/O Process

1.  **Open**: You open a file and specify the mode you want to use (e.g., read, write). This creates a "file handle" or "stream" that your program uses to interact with the file.
2.  **Read/Write**: You perform the desired operations, either reading the file's contents into variables or writing the contents of your variables to the file.
3.  **Close**: You close the file. This is a critical step that finalizes the writing process and releases the file resource, allowing other programs to use it.

### File Modes

-   **`r` (Read)**: Opens a file for reading. An error occurs if the file does not exist.
-   **`w` (Write)**: Opens a file for writing. Creates the file if it does not exist, or **overwrites** the entire file if it does.
-   **`a` (Append)**: Opens a file for appending. Creates the file if it does not exist, and adds new data to the end of the file without overwriting existing content.

### Data Formats

While you can write plain text to files, it's often useful to structure the data.
-   **CSV (Comma-Separated Values)**: A simple format for storing tabular data. Each line is a row, and values in the row are separated by commas.
-   **JSON (JavaScript Object Notation)**: A popular, human-readable format for storing nested data using key-value pairs. It's widely used in web development and APIs.

---

## 4. Deliberate Practice

1.  **Write a User Log**: Create a program that prompts the user for their name and then appends the name and the current timestamp to a file called `log.txt`.
2.  **Read a Story**: Find a short story online and save it as a `.txt` file. Write a program that reads the file and prints its contents to the console.
3.  **Simple To-Do List**: Write a program that stores a list of tasks in a file. The program should be able to:
    -   Add a new task to the file.
    -   Display all tasks from the file.
4.  **CSV Data**: Create a simple `data.csv` file with a few rows of data (e.g., `name,age`). Write a program to read this file and print each row.

---

## 5. Active Recall Questions

-   What does "I/O" stand for?
-   What are the three main steps in the File I/O process?
-   What is the difference between "write" mode (`w`) and "append" mode (`a`)?
-   Why is it important to close a file after you are done with it?
-   What is JSON and why is it a popular data format?

---

## 6. Tools, Frameworks, and Platforms

-   **Standard Libraries**: Most programming languages have built-in libraries for file I/O that are sufficient for most basic tasks.
-   **Text Editors**: A good text editor like VS Code, Sublime Text, or Notepad++ is essential for viewing and editing the files your program creates.
-   **CSV Libraries**: Libraries like `csv` in Python or `PapaParse` in JavaScript make it much easier to work with CSV files.

---

## 7. Feedback and Self-Assessment

-   **Error Handling**: Wrap your file I/O code in `try...catch...finally` blocks. What happens if you try to read a file that doesn't exist? Your program should handle this gracefully.
-   **Check File Contents**: After running your program, manually open the file it was supposed to write to. Is the content what you expected? Is the formatting correct?
-   **Resource Management**: Ensure that you are always closing your files. Modern languages have constructs like `try-with-resources` (Java) or the `with` statement (Python) that handle this automatically.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: You are building a settings feature for a desktop application. The user can choose a theme (e.g., "dark" or "light") and a font size. How would you persist these settings so they are remembered the next time the user opens the application?
-   What would you name the settings file?
-   What data format would you use (plain text, JSON, something else)? Why?
-   When would your program read this file? When would it write to it?

This exercise connects the abstract concept of persistence to a tangible feature in a real application.

---

## 9. Collaborative Activities

-   **Configuration Manager**: Work with a partner to create a simple configuration manager. One person writes the function to save settings to a JSON file, and the other writes the function to load the settings.
-   **Code Review**: Review each other's solutions to the "Simple To-Do List" practice exercise. Pay close attention to error handling and resource management.

---

## 10. Domain-Specific Mastery Strategies

-   **Web Development**: On the server-side, file I/O is used for logging, serving static assets, and managing user uploads.
-   **Data Science**: Data scientists spend a significant amount of their time reading data from various file formats (CSV, Excel, Parquet) and writing out processed data and models.
-   **Game Development**: Game assets like images, sounds, and 3D models are all loaded from files. Player progress is also saved to files.

---

## 11. Psychological and Cognitive Principles

-   **Tangibility**: File I/O makes the results of your code tangible. You can see the files being created and modified. Use this to your advantage to build a stronger mental model of how your program works.
-   **Destructive Actions**: Be very careful with the `w` (write) mode, as it can overwrite your files. It's often a good idea to make a backup of a file before writing to it programmatically.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain why data persistence is necessary.
-   [ ] I can open a file in read, write, or append mode.
-   [ ] I can read the contents of a text file.
-   [ ] I can write new content to a text file.
-   [ ] I understand the importance of closing files and how to do it.

---

## 13. Research and References

-   **Python Documentation - Reading and Writing Files**: [Link](https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files)
-   **Node.js Documentation - File System**: [Link](https://nodejs.org/api/fs.html)
-   **Working with JSON - MDN**: [Link](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/JSON)
