# Arrays, Lists, Stacks, and Queues

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define and differentiate** between arrays, lists, stacks, and queues.
-   **Perform common operations** on arrays/lists (access, insertion, deletion, searching).
-   **Understand** the time complexity of array/list operations.
-   **Implement** the LIFO (Last-In, First-Out) principle using a stack.
-   **Implement** the FIFO (First-In, First-Out) principle using a queue.
-   **Choose** the appropriate linear data structure for a given problem.

---

## 2. Introduction to Linear Data Structures

Data structures are specialized formats for organizing, processing, retrieving, and storing data. **Linear data structures** are the simplest form, where elements are arranged in a sequential or linear order. This module covers the most fundamental linear data structures: arrays, lists, stacks, and queues. Mastering them is essential for building efficient and scalable software.

---

## 3. Core Concepts

### Arrays

An **array** is a collection of items stored at contiguous memory locations.
-   **Key Feature**: Elements are accessed via an **index** (usually zero-based).
-   **Strengths**: Fast, constant-time access to any element (`O(1)`).
-   **Weaknesses**: Fixed size in many languages. Inserting or deleting an element in the middle can be slow (`O(n)`) because it may require shifting other elements.

### Lists (Dynamic Arrays)

A **list** (often called a "dynamic array" or `ArrayList`) is a more flexible version of an array that can grow and shrink in size.
-   **Key Feature**: Manages its own memory, resizing automatically when needed.
-   **Trade-off**: While offering flexibility, resizing can sometimes be a slow operation. However, access is still typically `O(1)`. Most modern high-level languages use lists by default.

### Stacks

A **stack** is a data structure that follows the **LIFO (Last-In, First-Out)** principle. Think of it like a stack of plates: you can only add a new plate to the top, and you can only remove the top plate.
-   **`push`**: Adds an element to the top of the stack.
-   **`pop`**: Removes and returns the element from the top of the stack.
-   **`peek` or `top`**: Looks at the top element without removing it.

### Queues

A **queue** is a data structure that follows the **FIFO (First-In, First-Out)** principle. Think of it like a line at a store: the first person to get in line is the first person to be served.
-   **`enqueue`**: Adds an element to the back (tail) of the queue.
-   **`dequeue`**: Removes and returns the element from the front (head) of the queue.
-   **`front` or `peek`**: Looks at the front element without removing it.

---

## 4. Deliberate Practice

1.  **Array Operations**: Create an array of your favorite book titles.
    -   Access and print the first and last elements.
    -   Add a new book to the end of the list.
    -   Remove a book from the beginning of the list.
2.  **Reverse a String**: Write a function that takes a string and uses a stack to reverse it. (Push each character onto the stack, then pop them off to build the reversed string).
3.  **Printer Queue Simulation**: Create a simple simulation of a printer queue. Write a program that can `enqueue` print jobs (represented by strings) and `dequeue` them one by one to "print".
4.  **Balanced Parentheses**: Write a function that uses a stack to check if a string of parentheses (`()`, `{}`, `[]`) is balanced.

---

## 5. Active Recall Questions

-   What is the main difference between an array and a list?
-   What does FIFO stand for, and which data structure uses it?
-   What are the two primary operations of a stack?
-   Explain the time complexity of accessing an element in an array by its index.
-   Give a real-world example of a queue.

---

## 6. Tools, Frameworks, and Platforms

-   **Debugger**: Step through your code to visualize how elements are added and removed from these data structures.
-   **Visualizers**: Websites like [VisuAlgo](https://visualgo.net/en) provide interactive animations of data structures, which can greatly aid understanding.
-   **Built-in Libraries**: All major languages have built-in implementations of these data structures in their standard libraries.

---

## 7. Feedback and Self-Assessment

-   **Complexity Analysis**: For each operation you perform in the practice exercises, analyze its time complexity. Could you have used a different data structure to make it more efficient?
-   **Implement from Scratch**: As a challenge, try to implement a basic stack or queue using only an array/list. This will deepen your understanding of how they work under the hood.
-   **Unit Tests**: Write tests for your "Balanced Parentheses" function. Include cases that should pass and cases that should fail.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: The "Undo" feature in a text editor.
-   What data structure would be most appropriate to store the history of user actions?
-   When the user performs an action (e.g., typing text, deleting text), what operation would you perform on the data structure?
-   When the user hits "Undo", what operation would you perform?
-   What about a "Redo" feature? (This is a trickier extension).

The answer is a **stack**. Each action is `pushed` onto the stack. "Undo" `pops` the most recent action off the stack.

---

## 9. Collaborative Activities

-   **Data Structure Debate**: As a group, discuss a problem and debate which of these four data structures would be the best fit and why. For example: "Managing the history of visited pages in a web browser".
-   **Pair Implementation**: Work with a partner to implement a queue using two stacks. This is a classic interview problem that requires a deep understanding of both data structures.

---

## 10. Domain-Specific Mastery Strategies

-   **Operating Systems**: Queues are used to manage processes waiting for the CPU. Stacks are used to manage function calls (the call stack).
-   **Web Development**: The event loop in JavaScript uses a queue to process asynchronous events.
-   **Compilers**: Stacks are used to parse expressions and manage scope.

---

## 11. Psychological and Cognitive Principles

-   **Analogies**: Use the physical analogies (stack of plates, line at a store) to build a strong mental model before diving into the code.
-   **Chunking**: Don't try to learn all four at once. Focus on arrays/lists first, as they are the building blocks for the others. Then move on to stacks, and finally queues.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the characteristics of an array.
-   [ ] I can describe the LIFO principle and its implementation with a stack.
-   [ ] I can describe the FIFO principle and its implementation with a queue.
-   [ ] I can perform basic operations like insertion, deletion, and access on these structures.
-   [ ] I can analyze a problem and decide if a stack or a queue is a suitable data structure.

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Chapters on arrays and lists provide excellent, easy-to-understand illustrations.
-   **GeeksforGeeks - Data Structures**: A comprehensive resource with explanations and code examples for all these data structures. [Link](https://www.geeksforgeeks.org/data-structures/)
-   **CS50 - Harvard's Introduction to Computer Science**: The lectures on data structures are available online and are highly recommended.
