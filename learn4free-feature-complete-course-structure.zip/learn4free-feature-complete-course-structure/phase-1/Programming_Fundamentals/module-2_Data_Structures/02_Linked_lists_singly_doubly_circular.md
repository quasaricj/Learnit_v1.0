# Linked Lists: Singly, Doubly, and Circular

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** what a linked list is and how it differs from an array.
-   **Describe** the structure of a `Node` (data and pointer).
-   **Differentiate** between singly, doubly, and circular linked lists.
-   **Implement** common operations: traversal, insertion, and deletion.
-   **Analyze** the time complexity of linked list operations.
-   **Identify** use cases where a linked list is a more suitable data structure than an array.

---

## 2. Introduction to Linked Lists

Unlike arrays that store elements in contiguous memory locations, a **linked list** is a linear data structure where elements are not stored at a single place. Instead, elements are linked using pointers. Each element, called a **`Node`**, consists of two parts: the actual data and a pointer (or reference) to the next node in the sequence. This structure provides more flexibility for dynamic data, especially for insertions and deletions.

---

## 3. Core Concepts

### The `Node`

The fundamental building block of any linked list is the `Node`.
-   **Singly Linked List Node**: Contains `data` and a `next` pointer.
-   **Doubly Linked List Node**: Contains `data`, a `next` pointer, and a `previous` pointer.

### Types of Linked Lists

#### 1. Singly Linked List

This is the simplest type of linked list where navigation is **forward-only**.
-   Each node has a pointer to the `next` node in the list.
-   The last node's `next` pointer points to `null`, indicating the end of the list.
-   The list is accessed through a pointer to the first node, called the `head`.

#### 2. Doubly Linked List

This list allows for **bidirectional (forward and backward) traversal**.
-   Each node has a `next` pointer and a `previous` pointer.
-   The `previous` pointer of the `head` is `null`, and the `next` pointer of the `tail` (the last node) is `null`.
-   This makes operations like deleting a node or inserting a node before another one more efficient.

#### 3. Circular Linked List

In this type of list, the `next` pointer of the last node points back to the `head` of the list instead of `null`, forming a circle.
-   This can be useful for applications where you want to cycle through a list of items, like a slideshow or a round-robin scheduler.
-   A circular list can be singly or doubly linked.

### Common Operations

-   **Traversal**: Iterating through the list from the `head` to the `tail`.
-   **Insertion**: Adding a new node at the beginning, end, or middle of the list.
-   **Deletion**: Removing a node from the list.

---

## 4. Deliberate Practice

1.  **Implement a Singly Linked List**: From scratch, create a `Node` class and a `LinkedList` class with methods for `insertAtHead`, `insertAtTail`, and `printList`.
2.  **Delete a Node**: Add a `delete` method to your `LinkedList` class that removes a node with a given value.
3.  **Reverse a Linked List**: Write a function that reverses a singly linked list. This is a classic interview problem.
4.  **Implement a Doubly Linked List**: Create a `DoublyLinkedList` class and implement the insertion and deletion methods. Note how the `previous` pointers need to be managed.

---

## 5. Active Recall Questions

-   What are the two main components of a `Node`?
-   What is the primary advantage of a linked list over an array? What is the primary disadvantage?
-   What is the time complexity of accessing the 100th element in a linked list?
-   What is the key difference between a singly and a doubly linked list?
-   In a circular linked list, where does the last node's `next` pointer point?

---

## 6. Tools, Frameworks, and Platforms

-   **Debugger**: Indispensable for understanding linked lists. Step through your code and watch how the `next` and `previous` pointers change during insertion and deletion operations.
-   **Whiteboard/Paper**: Drawing the boxes and arrows for a linked list is the best way to visualize its structure and plan your operations before you write any code.
-   **Visualizers**: Websites like [VisuAlgo](https://visualgo.net/en/list) can help you visualize the operations in an animated way.

---

## 7. Feedback and Self-Assessment

-   **Handle Edge Cases**: When implementing your linked list, did you consider edge cases like an empty list, inserting into an empty list, deleting the head, or deleting the tail? Write unit tests for these cases.
-   **Time Complexity Analysis**: What is the time complexity of inserting a node at the head of a singly linked list? What about at the tail? Why are they different?
-   **Memory Management**: In languages without automatic garbage collection (like C++), you are responsible for freeing the memory of deleted nodes. This is a common source of memory leaks.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A music player application.
-   You want to build a playlist feature where users can play the next song and the *previous* song.
-   Which type of linked list would be most suitable for this feature and why?
-   When a user adds a new song to the end of the playlist, what linked list operation is that?
-   When a user removes a song from the middle of the playlist, what operations are needed to update the list?

A **doubly linked list** is the perfect data structure here, as the `next` and `previous` pointers map directly to the "next" and "previous song" buttons.

---

## 9. Collaborative Activities

-   **Pair Programming**: Work with a partner to implement the "Reverse a Linked List" problem. One person can write the code while the other navigates and keeps track of the pointers on a whiteboard.
-   **Code Review**: Swap your linked list implementations with a peer and review each other's code, specifically looking for edge case handling and correct pointer manipulation.

---

## 10. Domain-Specific Mastery Strategies

-   **Operating Systems**: Linked lists are used to manage lists of processes, free memory blocks, and device drivers.
-   **Web Browsers**: The "back" and "forward" buttons in a web browser can be implemented using a doubly linked list.
-   **Blockchain**: A blockchain is essentially a linked list where each "block" (node) contains a cryptographic hash of the previous one, ensuring data integrity.

---

## 11. Psychological and Cognitive Principles

-   **Visualization is Key**: Do not try to manipulate linked lists in your head. Always draw the nodes and pointers on a piece of paper or a whiteboard. This offloads the cognitive load and makes it much easier to reason about the problem.
-   **Pointer Management**: The most common source of bugs in linked list implementations is incorrect pointer management. Be methodical and trace the effect of every pointer change.

---

## 12. Summary and Mastery Checklist

-   [ ] I can draw the structure of a singly, doubly, and circular linked list.
-   [ ] I can explain the trade-offs between a linked list and an array.
-   [ ] I can write code to insert a node into a linked list.
-   [ ] I can write code to delete a node from a linked list.
-   [ ] I understand why a doubly linked list is useful for implementing features like "previous" and "next".

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Chapter 5 provides a very beginner-friendly, illustrated guide to linked lists.
-   **GeeksforGeeks - Linked List Data Structure**: [Link](https://www.geeksforgeeks.org/data-structures/linked-list/)
-   **YouTube - CS Dojo - Linked Lists for Technical Interviews**: A clear and concise video explanation.
