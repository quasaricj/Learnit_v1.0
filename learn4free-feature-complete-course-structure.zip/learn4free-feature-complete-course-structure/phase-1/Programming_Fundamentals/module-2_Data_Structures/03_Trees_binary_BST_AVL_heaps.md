# Trees: Binary, BST, AVL, and Heaps

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a tree as a non-linear data structure and its related terminology (root, node, parent, child, leaf).
-   **Differentiate** between a general tree and a binary tree.
-   **Explain** the ordering property of a Binary Search Tree (BST).
-   **Perform** insertion, search, and deletion operations on a BST.
-   **Describe** the concept of a self-balancing tree and the purpose of an AVL tree.
-   **Define** a heap and differentiate between a min-heap and a max-heap.
-   **Analyze** the time complexity of common tree operations.

---

## 2. Introduction to Trees

So far, we have only looked at linear data structures where elements are arranged sequentially. **Trees** are **hierarchical** or **non-linear** data structures that are incredibly powerful for representing data that has a parent-child relationship. Think of a file system, an organization chart, or even the DOM (Document Object Model) of a webpage.

---

## 3. Core Concepts

### Basic Tree Terminology

-   **Node**: The fundamental part of a tree that contains data and pointers to other nodes.
-   **Root**: The topmost node in a tree.
-   **Edge**: The link between two nodes.
-   **Parent**: A node that has child nodes.
-   **Child**: A node that extends from a parent node.
-   **Leaf**: A node with no children.
-   **Height**: The length of the longest path from the root to a leaf.

### Binary Tree

A **Binary Tree** is a tree data structure in which each node has at most **two children**, which are referred to as the `left` child and the `right` child.

### Binary Search Tree (BST)

A **BST** is a special type of binary tree that adheres to a specific ordering property:
1.  The `left` child of a node must contain a value that is **less than** the parent's value.
2.  The `right` child of a node must contain a value that is **greater than** the parent's value.
3.  Both the left and right subtrees must also be binary search trees.

This property makes searching for an element very efficient, typically `O(log n)` time if the tree is balanced.

### AVL Tree (Self-Balancing BST)

A potential problem with a BST is that it can become **unbalanced**. If you insert elements in sorted order, the tree will essentially become a linked list, and search performance degrades to `O(n)`.

An **AVL Tree** is a self-balancing BST. It automatically performs operations called **rotations** to ensure that the height difference between the left and right subtrees of any node is at most 1. This guarantees that the tree remains balanced and that search operations remain `O(log n)`.

### Heaps

A **Heap** is a specialized tree-based data structure that satisfies the "heap property". It is typically implemented as a binary tree.
-   **Min-Heap**: The value of each node is *less than or equal to* the value of its children. This means the smallest element is always at the root.
-   **Max-Heap**: The value of each node is *greater than or equal to* the value of its children. This means the largest element is always at the root.

Heaps are commonly used to implement **Priority Queues**.

---

## 4. Deliberate Practice

1.  **Build a BST**: Write a `Node` class and a `BST` class. Implement a method to `insert` new values into the tree, maintaining the BST property.
2.  **Search a BST**: Implement a `search` method that takes a value and returns `true` if it's in the BST and `false` otherwise.
3.  **Tree Traversal**: Implement three traversal methods for your BST: `in-order`, `pre-order`, and `post-order`. What do you notice about the output of an `in-order` traversal?
4.  **Heap Operations**: Using a library implementation of a heap/priority queue, add a series of numbers and then remove them one by one. Observe the order in which they are removed.

---

## 5. Active Recall Questions

-   What is the maximum number of children a node can have in a binary tree?
-   What is the key property of a Binary Search Tree?
-   What problem do self-balancing trees like AVL trees solve?
-   What is the main difference between a min-heap and a max-heap?
-   In a balanced BST, what is the time complexity for a search operation?

---

## 6. Tools, Frameworks, and Platforms

-   **Visualizers**: [VisuAlgo](https://visualgo.net/en/bst) and [USFCA Data Structure Visualizations](https://www.cs.usfca.edu/~galles/visualization/Algorithms.html) are absolutely essential for understanding how trees are constructed and manipulated.
-   **Whiteboard**: Like linked lists, trees are best understood by drawing them.

---

## 7. Feedback and Self-Assessment

-   **Test your BST**: Insert a series of numbers into your BST and then perform an in-order traversal. The output should be a sorted list of the numbers. If it's not, there's a bug in your insertion logic.
-   **Complexity Analysis**: What is the worst-case time complexity for insertion into a BST? When does this worst case occur?
-   **Recursive vs. Iterative**: Try implementing the `search` function both recursively and iteratively. Which do you find more intuitive?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Autocomplete in a search engine.
-   When you start typing a word, the search engine suggests a list of possible completions. A specialized tree called a **Trie** (or Prefix Tree) is often used for this.
-   How would you structure a tree to store a dictionary of words in a way that makes it fast to find all words with a given prefix?
-   Each node could represent a character, and a path from the root to a node would represent a prefix.

This exercise shows how tree structures can be adapted to solve complex, real-world problems.

---

## 9. Collaborative Activities

-   **Build a BST on a Whiteboard**: As a group, take a list of numbers and construct a BST on a whiteboard. One person inserts a number, and the others verify that it's in the correct place.
-   **Traversal Race**: One person implements a pre-order traversal, another implements in-order, and a third implements post-order. Compare your results for the same tree.

---

## 10. Domain-Specific Mastery Strategies

-   **Databases**: Indexes in databases are often implemented using a type of tree called a B-Tree, which is optimized for reading and writing large blocks of data from a disk.
-   **UI Frameworks**: The component structure of a web application in a framework like React forms a tree.
-   **Networking**: Routers use tree-like structures (routing tables) to efficiently find the shortest path to a destination.
-   **Game Development**: AI for games often uses decision trees to determine an NPC's behavior.

---

## 11. Psychological and Cognitive Principles

-   **Recursion is Natural**: Many tree operations are most elegantly expressed using recursion. Once you have a solid mental model of the tree structure, the recursive "leap of faith" becomes easier.
-   **Divide and Conquer**: Trees naturally lend themselves to divide-and-conquer algorithms. Operations can often be performed on the left subtree and the right subtree independently.

---

## 12. Summary and Mastery Checklist

-   [ ] I can identify the root, parent, child, and leaf nodes in a diagram of a tree.
-   [ ] I can explain the ordering property of a BST.
-   [ ] I can manually trace the insertion of a new node into a BST.
-   [ ] I understand why a balanced tree is important for performance.
-   [ ] I can explain the purpose of a heap and its primary use case (priority queues).

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Provides a very accessible introduction to binary search trees.
-   **GeeksforGeeks - Tree Data Structure**: [Link](https://www.geeksforgeeks.org/binary-tree-data-structure/)
-   **YouTube - Gayle Laakmann McDowell - Heaps**: A clear explanation of heaps from the author of "Cracking the Coding Interview".
