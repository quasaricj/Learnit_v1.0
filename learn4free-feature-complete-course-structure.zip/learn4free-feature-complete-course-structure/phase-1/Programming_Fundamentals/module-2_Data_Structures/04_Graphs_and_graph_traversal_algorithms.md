# Graphs and Graph Traversal Algorithms

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a graph data structure and its related terminology (vertex, edge, directed, undirected).
-   **Represent** a graph using an adjacency list and an adjacency matrix.
-   **Explain** the difference between a directed and an undirected graph.
-   **Implement** the Breadth-First Search (BFS) traversal algorithm.
-   **Implement** the Depth-First Search (DFS) traversal algorithm.
-   **Analyze** the time and space complexity of BFS and DFS.
-   **Identify** real-world problems that can be modeled with graphs.

---

## 2. Introduction to Graphs

Graphs are the most general and powerful of all data structures. A graph is a collection of **vertices** (or nodes) and **edges** that connect these vertices. Unlike trees, graphs can have cycles, and the connections between nodes can be much more complex. They are used to model networks of all kinds, from social networks to road maps to the internet itself.

---

## 3. Core Concepts

### Graph Terminology

-   **Vertex**: A node in the graph.
-   **Edge**: A connection between two vertices.
-   **Undirected Graph**: Edges have no orientation. The connection between A and B is the same as B to A.
-   **Directed Graph**: Edges have a direction. An edge from A to B is not the same as an edge from B to A.
-   **Weighted Graph**: Each edge has a numerical "weight" or "cost" associated with it.

### Graph Representations

There are two common ways to represent a graph in code:

1.  **Adjacency Matrix**: A 2D array where `matrix[i][j] = 1` if there is an edge between vertex `i` and vertex `j`, and `0` otherwise.
    -   *Pros*: Fast to check if an edge exists between two vertices.
    -   *Cons*: Uses a lot of memory for sparse graphs (graphs with few edges).
2.  **Adjacency List**: An array of lists, where `adj[i]` is a list of all vertices connected to vertex `i`.
    -   *Pros*: Memory-efficient for sparse graphs.
    -   *Cons*: Slower to check if an edge exists between two specific vertices.

### Graph Traversal Algorithms

Traversal means visiting every vertex in the graph once.

#### Breadth-First Search (BFS)

BFS explores the graph "layer by layer". It starts at a given vertex, explores all of its immediate neighbors, then the neighbors of those neighbors, and so on.
-   **Key Data Structure**: A **queue** is used to keep track of the next vertex to visit.
-   **Use Case**: Finding the shortest path between two vertices in an unweighted graph.

#### Depth-First Search (DFS)

DFS explores the graph by going as deep as possible down one path before backtracking. It starts at a given vertex, explores as far as it can along each branch before backing up.
-   **Key Data Structure**: A **stack** (often the call stack, via recursion) is used.
-   **Use Case**: Detecting cycles in a graph, "topological sorting", or solving maze-like problems.

---

## 4. Deliberate Practice

1.  **Represent a Graph**: Choose a small, real-world network (like your immediate family or a local subway map) and represent it as both an adjacency matrix and an adjacency list on paper.
2.  **Implement BFS**: Using an adjacency list representation, implement a BFS function that takes a starting vertex and prints the vertices in the order they are visited.
3.  **Implement DFS**: Implement a DFS function (either iteratively with a stack or recursively) and print the vertices in the order they are visited.
4.  **Path Finding**: Modify your BFS code to find if a path exists between two given vertices.

---

## 5. Active Recall Questions

-   What is the difference between a vertex and an edge?
-   When would you use an adjacency list over an adjacency matrix?
-   What data structure does BFS use? What about DFS?
-   Explain the main difference in the exploration strategy between BFS and DFS.
-   Can a graph have a cycle? Can a tree?

---

## 6. Tools, Frameworks, and Platforms

-   **Whiteboard**: Essential for drawing graphs and tracing traversal algorithms. It's nearly impossible to get them right by just thinking about them.
-   **Visualizers**: Tools like [VisuAlgo](https://visualgo.net/en/graphds) are excellent for visualizing graph structures and how BFS/DFS work.

---

## 7. Feedback and Self-Assessment

-   **Trace your traversals**: For a given graph, manually trace the output of your BFS and DFS algorithms. Does your code produce the same result?
-   **Handle disconnected graphs**: What happens if your graph is not fully connected (i.e., it has separate components)? Does your traversal code visit all vertices?
-   **Complexity Analysis**: What is the time complexity of BFS and DFS? (It depends on the representation: `O(V+E)` for adjacency list, `O(V^2)` for adjacency matrix, where V is vertices and E is edges).

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Social Network.
-   Imagine a social network like Facebook or LinkedIn. How can this be modeled as a graph?
-   What do the vertices represent? What do the edges represent?
-   What traversal algorithm would you use to find the shortest chain of connections between you and another person ("friend of a friend")?
-   How could you find all people within a certain "degree" of connection from you?

The answer is that this is a classic application for **Breadth-First Search (BFS)**, which naturally finds the shortest path in terms of the number of edges.

---

## 9. Collaborative Activities

-   **Graph Modeling**: As a group, pick a complex system (e.g., an airport system, the internet, a project dependency chart) and model it as a graph on a whiteboard. Decide if it should be directed, undirected, weighted, etc.
-   **Traversal Walkthrough**: One person "executes" the BFS algorithm on a whiteboard graph, while another person manages the queue. This makes the mechanics of the algorithm very clear.

---

## 10. Domain-Specific Mastery Strategies

-   **Mapping/GIS**: Services like Google Maps use graph algorithms (like Dijkstra's and A*) to find the shortest driving directions.
-   **AI/Machine Learning**: Neural networks are a type of graph. Graph databases are also becoming increasingly popular for storing and querying highly connected data.
-   **Recommendation Engines**: To recommend a product, a system might look at a graph of users and products, finding products that are "close" to the user or things the user has liked.

---

## 11. Psychological and Cognitive Principles

-   **Start with the Drawing**: The abstract nature of graphs can be confusing. Always start by drawing the graph and the connections. This provides a concrete foundation for your reasoning.
-   **Systematic Traversal**: The key to both BFS and DFS is being systematic. You need a way to keep track of which vertices you've already visited to avoid getting stuck in infinite loops.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define a graph using the terms "vertex" and "edge".
-   [ ] I can represent a simple graph using both an adjacency list and an adjacency matrix.
-   [ ] I can explain the difference between BFS and DFS.
-   [ ] I know that BFS uses a queue and is good for finding shortest paths.
-   [ ] I know that DFS uses a stack (or recursion) and is good for exploring paths to their conclusion.

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Chapters 6 and 7 provide a fantastic, illustrated introduction to graphs and BFS/DFS.
-   **GeeksforGeeks - Graph Data Structure and Algorithms**: [Link](https://www.geeksforgeeks.org/graph-data-structure-and-algorithms/)
-   **YouTube - MIT OpenCourseWare - Introduction to Algorithms**: The lectures on graphs are a gold standard for a deep, theoretical understanding.
