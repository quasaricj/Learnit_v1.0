# Hash Tables and Dictionaries

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a hash table and explain its purpose.
-   **Describe** the key-value pair structure used in dictionaries/maps.
-   **Explain** the role of a hash function in mapping keys to indices.
-   **Understand** the concept of a hash collision and common collision resolution strategies (chaining, open addressing).
-   **Analyze** the time complexity for insertion, deletion, and search operations in a hash table.
-   **Utilize** built-in dictionary/map/object data structures in your chosen programming language.

---

## 2. Introduction to Hash Tables

Hash tables are one of the most widely used and important data structures in computer science. They are the underlying implementation for `Dictionary` in C#, `HashMap` in Java, `dict` in Python, and plain `Objects` in JavaScript. A hash table is a data structure that allows for incredibly fast **key-based lookups**, with an average time complexity of `O(1)` (constant time).

---

## 3. Core Concepts

### Key-Value Pairs

Unlike arrays or lists which store single elements in a sequence, hash tables store data in **key-value pairs**.
-   **Key**: A unique identifier for a piece of data.
-   **Value**: The data associated with that key.

You use the `key` to store and retrieve the `value`.

### The Hash Function

The magic of a hash table comes from its **hash function**. A hash function is a special function that takes a `key` as input and produces an `index` (an integer) as output. This index determines where in the underlying array the `value` should be stored.

`hash_function(key) -> index`

A good hash function should:
1.  Be **fast** to compute.
2.  Be **deterministic**: The same key should always produce the same index.
3.  Provide a **uniform distribution** of indices to minimize collisions.

### Collisions

A **collision** occurs when two different keys produce the same index after being run through the hash function. Since two values cannot be stored in the same slot in the array, this must be handled.

### Collision Resolution Strategies

1.  **Separate Chaining (or Chaining)**: This is the most common strategy. Instead of storing the value directly in the array, each array slot points to a **linked list** (or other data structure). If a collision occurs, the new key-value pair is simply added to the linked list at that index.
2.  **Open Addressing (or Probing)**: In this strategy, if the calculated index is already occupied, the hash table probes for the *next available slot* in the array and stores the value there. Common probing methods include linear probing, quadratic probing, and double hashing.

---

## 4. Deliberate Practice

1.  **Use a Dictionary**: In your chosen language, create a dictionary/map to store the prices of items in a grocery store. The keys should be the item names (strings) and the values should be their prices (floats).
2.  **Word Counter**: Write a function that takes a sentence as input and returns a dictionary where the keys are the words in the sentence and the values are the number of times each word appeared.
3.  **Check for Duplicates**: Write a function that takes an array of numbers and uses a hash set (a hash table that only stores keys) to efficiently determine if the array contains any duplicate values.
4.  **Two Sum Problem**: Given an array of numbers and a target number, find two numbers in the array that add up to the target. A hash table can solve this in `O(n)` time.

---

## 5. Active Recall Questions

-   What is the average time complexity for a lookup in a hash table?
-   What are the two components of a hash table entry?
-   What is the purpose of a hash function?
-   What is a hash collision?
-   Name one common strategy for resolving collisions.

---

## 6. Tools, Frameworks, and Platforms

-   **Built-in Dictionaries**: The most important tool is the built-in hash table implementation in your language of choice. Familiarize yourself with its API (`get`, `set`, `delete`, `has_key`, etc.).
-   **Visualizers**: [VisuAlgo](https://visualgo.net/en/hashtable) has an excellent interactive visualization of how hash tables work, including chaining and open addressing.

---

## 7. Feedback and Self-Assessment

-   **"What if" analysis**: What happens to the performance of a hash table if you have a very bad hash function that maps every key to the same index? (It degrades to `O(n)`, the performance of a linked list).
-   **Library Exploration**: Look at the documentation for your language's dictionary/map. Does it provide any details about its underlying implementation? Is it chaining or open addressing?
-   **Implement a Simple Hash Table**: As a major challenge, try to implement a basic hash table from scratch using an array and a linked list for chaining. You will also need to write a simple hash function for strings.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Caching
-   A cache is a high-speed data storage layer that stores a subset of data, typically transient in nature, so that future requests for that data are served up faster than is possible by accessing the data's primary storage location.
-   What data structure would be perfect for implementing a simple in-memory cache?
-   If you want to cache the result of a database query, what would be the `key` and what would be the `value`?

A **hash table** is the ideal data structure for a cache. The `key` could be the database query string, and the `value` would be the result of that query. This allows the application to check the cache in `O(1)` time before making an expensive database call.

---

## 9. Collaborative Activities

-   **Hash Function Brainstorm**: As a group, try to design a hash function for a given data type (e.g., a string or a custom `User` object). What properties of the data would you use to generate the hash?
-   **Two Sum in Pairs**: Work with a partner to solve the "Two Sum" problem on a whiteboard. One person can manage the hash table while the other iterates through the array.

---

## 10. Domain-Specific Mastery Strategies

-   **Databases**: Hash tables are used in many parts of a database, including hash joins (a fast way to join two tables) and in-memory caches.
-   **Compilers/Interpreters**: When you write `my_variable = 10`, the language's interpreter stores this information in a hash table (called a symbol table) where the key is "my_variable" and the value is 10.
-   **Web Servers**: Servers use hash tables to cache frequently requested files or API responses in memory, dramatically improving performance.

---

## 11. Psychological and Cognitive Principles

-   **Abstraction**: Modern languages provide highly optimized, built-in hash table implementations. You can and should treat them as a "black box" that provides `O(1)` lookups. While it's important to understand how they work, you rarely need to implement them yourself.
-   **Mental Model**: The "filing cabinet" is a good analogy. The hash function tells you which drawer (index) to look in, and chaining is like having a folder of items within that drawer.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that a hash table stores data as key-value pairs.
-   [ ] I can describe the role of the hash function.
-   [ ] I understand what a hash collision is and why it needs to be handled.
-   [ ] I can achieve `O(1)` average time complexity for search, insertion, and deletion.
-   [ ] I can use the dictionary/map/object in my language to solve problems.

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Chapter 5 has a great, simple explanation of hash tables.
-   **GeeksforGeeks - Hashing Data Structure**: [Link](https://www.geeksforgeeks.org/hashing-data-structure/)
-   **YouTube - CS Dojo - Hash Tables Explained**: A clear video that covers the core concepts.
