# Sets and Their Operations

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a set as a data structure.
-   **Explain** the two key properties of a set: uniqueness of elements and lack of order.
-   **Perform** basic set operations: add, remove, and check for membership.
-   **Describe and implement** the main mathematical set operations: union, intersection, and difference.
-   **Analyze** the time complexity of set operations (which are typically `O(1)`).
-   **Identify** problems where using a set is more efficient than using a list or array.

---

## 2. Introduction to Sets

A **set** is a data structure that stores a collection of **unique** elements. Unlike arrays or lists, sets are **unordered**, meaning the elements are not stored in any particular sequence. The primary strength of a set is its highly optimized ability to check whether a specific element is contained within it.

Sets are often implemented using a **hash table** internally (a "hash set"), which is what gives them their `O(1)` average time complexity for add, remove, and contains operations.

---

## 3. Core Concepts

### Key Properties

1.  **Uniqueness**: A set cannot contain duplicate elements. If you try to add an element that is already in the set, the operation is simply ignored.
2.  **Unordered**: The elements in a set are not stored in a specific order. You cannot access elements by an index.

### Basic Operations

-   **`add(element)`**: Adds an element to the set.
-   **`remove(element)`**: Removes an element from the set.
-   **`contains(element)`** (or `has`): Returns `true` if the element is in the set, `false` otherwise. This is the most important and powerful operation.
-   **`size`**: Returns the number of elements in the set.

### Mathematical Operations

Sets are powerful because they can perform mathematical operations efficiently.

-   **Union**: Given two sets A and B, the union is a new set that contains all elements that are in A, B, or both.
-   **Intersection**: The intersection of sets A and B is a new set that contains only the elements that are in *both* A and B.
-   **Difference**: The difference of A and B (A - B) is a new set that contains elements from A that are *not* in B.

---

## 4. Deliberate Practice

1.  **Basic Set Usage**: Create a set and add the numbers 10, 20, 30.
    -   Try to add 20 again. What is the size of the set?
    -   Check if the set contains 10.
    -   Remove 30 from the set.
2.  **Find Unique Elements**: Write a function that takes a list of numbers (with duplicates) and returns a list of the unique numbers. Using a set makes this trivial.
3.  **Set Operations**: Create two sets: `setA = {1, 2, 3, 4}` and `setB = {3, 4, 5, 6}`.
    -   Calculate their union.
    -   Calculate their intersection.
    -   Calculate the difference `setA - setB`.
4.  **Find Missing Number**: You are given a list of `n-1` integers and these integers are in the range of `1` to `n`. There are no duplicates in the list. One of the integers is missing. Write an efficient function to find the missing integer. A set can be a useful tool here.

---

## 5. Active Recall Questions

-   What are the two defining properties of a set?
-   What data structure is often used to implement a set under the hood?
-   What is the time complexity of checking for membership in a hash set?
-   What does the "union" of two sets represent?
-   How is a set different from a list/array?

---

## 6. Tools, Frameworks, and Platforms

-   **Built-in Set Libraries**: All modern programming languages (Python, Java, JavaScript, C++) have a built-in `Set` data structure. Learn its API.
-   **Whiteboard**: Use Venn diagrams to visualize the mathematical set operations (union, intersection, difference).

---

## 7. Feedback and Self-Assessment

-   **Compare with Array**: For the "Find Unique Elements" practice problem, try to solve it using only an array. How does the time complexity of your array-based solution compare to the set-based solution?
-   **API Exploration**: Look at the documentation for your language's `Set` class. Are there other useful methods available, like `isSubset` or `isSuperset`?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: User Permissions in a web application.
-   Imagine you have a list of permissions a user has, for example `['can_edit_document', 'can_view_dashboard', 'can_delete_user']`.
-   The application needs to constantly check if a user has a specific permission before allowing them to perform an action.
-   If you store the permissions in a list, checking for a permission is an `O(n)` operation.
-   If you store the permissions in a **set**, checking for a permission becomes an `O(1)` operation.

This is a common use case where a set provides a significant performance advantage for frequent membership checks.

---

## 9. Collaborative Activities

-   **Venn Diagram Challenge**: On a whiteboard, draw two overlapping circles for a Venn diagram. Have your partner name two sets of items, and work together to place them in the correct sections of the diagram (A only, B only, or both). This directly maps to the set operations.
-   **Code Review**: Compare your solutions for the practice problems. Did you use the set's methods in the most efficient way?

---

## 10. Domain-Specific Mastery Strategies

-   **Databases**: The `UNIQUE` constraint on a database column is essentially enforcing the uniqueness property of a set. SQL also has `UNION` and `INTERSECT` operators.
-   **Data Analysis**: Sets are frequently used to find the unique values in a dataset or to compare the elements in two different datasets.
-   **Web Development**: A set can be used to track which items a user has "liked" or "favorited" to ensure they can't like the same item twice.

---

## 11. Psychological and Cognitive Principles

-   **Leverage Existing Knowledge**: The concept of sets is borrowed directly from mathematics. If you are familiar with mathematical sets, you can leverage that knowledge here.
-   **Focus on the "What", not the "How"**: Because sets are usually built-in, you can focus on *what* they do (provide fast membership testing) rather than *how* they are implemented. This is a form of abstraction.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that a set stores unique, unordered elements.
-   [ ] I can add, remove, and check for the existence of an element in a set.
-   [ ] I understand the concepts of union, intersection, and difference.
-   [ ] I know that set operations are typically very fast (`O(1)`).
-   [ ] I can identify problems where a set is a more efficient choice than a list.

---

## 13. Research and References

-   **MDN Web Docs - Set**: [Link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set) (for JavaScript)
-   **Python Documentation - Sets**: [Link](https://docs.python.org/3/tutorial/datastructures.html#sets)
-   **GeeksforGeeks - Set Data Structure**: [Link](https://www.geeksforgeeks.org/set-in-python/)
