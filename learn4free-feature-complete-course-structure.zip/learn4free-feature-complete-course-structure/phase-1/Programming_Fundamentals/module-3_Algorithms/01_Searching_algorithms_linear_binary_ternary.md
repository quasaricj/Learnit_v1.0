# Searching Algorithms: Linear, Binary, and Ternary

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** searching as a fundamental algorithmic problem.
-   **Implement** a linear search algorithm.
-   **Implement** a binary search algorithm for sorted arrays.
-   **Understand** the preconditions required for binary search to work.
-   **Describe** the logic behind ternary search.
-   **Analyze and compare** the time complexity of linear, binary, and ternary search.

---

## 2. Introduction to Searching Algorithms

Searching is the process of finding a particular item in a collection of items. It is one of the most fundamental and frequently performed operations in computer science. The efficiency of a searching algorithm can have a massive impact on the performance of a system. This module covers the foundational searching algorithms that every developer should know.

---

## 3. Core Concepts

### Linear Search

**Linear search** is the simplest searching algorithm. It sequentially checks each element of a list until a match is found or the whole list has been searched.

-   **How it works**: Start from the first element and compare it with the target value. If they are not equal, move to the next element. Repeat until the value is found or the end of the list is reached.
-   **Precondition**: None. The list does not need to be sorted.
-   **Time Complexity**: `O(n)`. In the worst case, you have to look at every single element.

### Binary Search

**Binary search** is a much more efficient algorithm, but it has a critical prerequisite: the list must be **sorted**.

-   **How it works**:
    1.  Compare the target value to the middle element of the sorted array.
    2.  If they are equal, the search is complete.
    3.  If the target is less than the middle element, it must be in the *left half* of the array. Discard the right half.
    4.  If the target is greater than the middle element, it must be in the *right half*. Discard the left half.
    5.  Repeat this process on the remaining half until the value is found or the subarray is empty.
-   **Precondition**: The list **must be sorted**.
-   **Time Complexity**: `O(log n)`. With each comparison, you eliminate half of the remaining search space.

### Ternary Search

**Ternary search** is an extension of binary search. Instead of dividing the array into two parts, it divides it into three.

-   **How it works**:
    1.  Compare the target value with the elements at two dividing points, `mid1` and `mid2`, which separate the array into three parts.
    2.  If the target is at `mid1` or `mid2`, the search is done.
    3.  If the target is less than `mid1`, recur for the first part.
    4.  If the target is greater than `mid2`, recur for the third part.
    5.  Otherwise, recur for the middle part.
-   **Precondition**: The list **must be sorted**.
-   **Time Complexity**: `O(log3 n)`. While this is technically faster than binary search (`O(log2 n)`), the difference is negligible in practice due to the increased number of comparisons in each step. Binary search is almost always preferred.

---

## 4. Deliberate Practice

1.  **Implement Linear Search**: Write a function that takes a list and a target value, and returns the index of the target if found, otherwise -1.
2.  **Implement Binary Search**: Write a function that performs binary search on a sorted list. Implement it both iteratively (with a `while` loop) and recursively.
3.  **Find First Occurrence**: Modify your binary search algorithm to find the *first* occurrence of a number in a sorted array that contains duplicates.
4.  **Analyze Performance**: Create a large sorted list of numbers. Search for an element using both your linear search and binary search functions. Time how long each one takes.

---

## 5. Active Recall Questions

-   What is the worst-case time complexity of a linear search?
-   What is the single most important precondition for using binary search?
-   Explain in your own words how binary search works.
-   Why is binary search so much faster than linear search for large datasets?
-   Why is binary search generally preferred over ternary search?

---

## 6. Tools, Frameworks, and Platforms

-   **Debugger**: Step through your binary search implementation to see how the `left` and `right` pointers converge on the target value.
-   **Built-in Functions**: Most languages have a built-in binary search function in their standard library. It's good to know it exists, but you should still learn how to implement it yourself.

---

## 7. Feedback and Self-Assessment

-   **Off-by-One Errors**: Binary search is notoriously tricky to implement perfectly because of "off-by-one" errors. Does your loop condition (`while left <= right` or `while left < right`) handle all cases correctly?
-   **Integer Overflow**: When calculating the middle index, `mid = (left + right) / 2`, the `left + right` part can potentially cause an integer overflow if the numbers are very large. A safer way to write this is `mid = left + (right - left) / 2`.
-   **Test Edge Cases**: Test your search functions with an empty list, a list with one element, and a target that is smaller or larger than any element in the list.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Searching for a word in a dictionary.
-   A physical dictionary is a perfect analogy for a sorted list.
-   You would never use linear search (reading from the first page until you find your word).
-   Instead, you instinctively use binary search: you open the dictionary to the middle, see if your word comes before or after that page, and then repeat the process on the smaller section.

This demonstrates how logarithmic time complexity (`O(log n)`) maps to our intuitive and efficient real-world search strategies.

---

## 9. Collaborative Activities

-   **Guess the Number Game**: One person thinks of a number between 1 and 100. The other person has to guess it. After each guess, the first person says "higher" or "lower". The guesser is performing a binary search.
-   **Pair Implementation**: Work with a partner to implement binary search. One person writes the recursive version, the other writes the iterative version. Compare your solutions.

---

## 10. Domain-Specific Mastery Strategies

-   **Databases**: When you query a database on an indexed column, the database can use an algorithm similar to binary search (often on a B-Tree) to find the data much faster than scanning the entire table.
-   **Version Control**: Git uses binary search in the `git bisect` command to efficiently find the commit that introduced a bug.
-   **Computer Graphics**: Searching for objects in a sorted list of coordinates is a common operation that can be sped up with binary search.

---

## 11. Psychological and Cognitive Principles

-   **Divide and Conquer**: Binary search is the quintessential "divide and conquer" algorithm. By breaking the problem in half at each step, you can solve a massive problem with a surprisingly small number of steps.
-   **Logarithmic Thinking**: Developing an intuition for logarithmic growth is a key milestone for a software engineer. An algorithm that is `O(log n)` can handle enormous inputs with ease.

---

## 12. Summary and Mastery Checklist

-   [ ] I can implement a linear search on an unsorted list.
-   [ ] I know that binary search requires a sorted list.
-   [ ] I can explain how binary search reduces the search space by half in each step.
-   [ ] I can implement binary search to find a value in a sorted list.
-   [ ] I can compare the time complexities of linear and binary search and explain why one is faster.

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Chapter 1 is one of the best and most intuitive explanations of binary search available.
-   **Wikipedia - Binary Search Algorithm**: [Link](https://en.wikipedia.org/wiki/Binary_search_algorithm)
-   **YouTube - CS50 - Binary Search**: A fantastic and energetic lecture explaining binary search.
