# Sorting Algorithms: Bubble, Merge, Quick, and Heap

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** sorting and explain its importance in computer science.
-   **Implement and explain** bubble sort.
-   **Implement and explain** merge sort, a "divide and conquer" algorithm.
-   **Implement and explain** quick sort, another "divide and conquer" algorithm.
-   **Explain** how a heap can be used to sort data (heap sort).
-   **Compare and contrast** the time complexity (best, average, worst) and space complexity of these algorithms.

---

## 2. Introduction to Sorting Algorithms

Sorting is the process of arranging a collection of items into a particular order (e.g., numerical or lexicographical). It is a fundamental algorithmic concept that is not only used to present data to users in a readable format, but also as a building block for many other more complex algorithms (like binary search). Understanding the trade-offs between different sorting algorithms is a hallmark of a proficient software engineer.

---

## 3. Core Concepts

### Bubble Sort

Bubble sort is a simple, comparison-based sorting algorithm. It repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order. The pass through the list is repeated until the list is sorted.
-   **Time Complexity**: `O(n^2)` in all cases (best, average, worst). It is inefficient for large lists and is primarily used for educational purposes.
-   **Space Complexity**: `O(1)` (in-place).

### Merge Sort

Merge sort is a highly efficient, "divide and conquer" sorting algorithm.
-   **How it works**:
    1.  **Divide**: Recursively divide the unsorted list into `n` sublists, each containing one element (a list of one element is considered sorted).
    2.  **Conquer**: Repeatedly merge sublists to produce new, sorted sublists until there is only one sublist remaining. This will be the sorted list.
-   **Time Complexity**: `O(n log n)` in all cases. It is very predictable and efficient.
-   **Space Complexity**: `O(n)`. It requires extra space to store the merged sublists.

### Quick Sort

Quick sort is another, often faster, "divide and conquer" algorithm.
-   **How it works**:
    1.  **Pivot**: Pick an element from the array (the "pivot").
    2.  **Partition**: Reorder the array so that all elements with values less than the pivot come before it, while all elements with values greater than the pivot come after it.
    3.  **Recurse**: Recursively apply the above steps to the sub-arrays of elements with smaller and greater values.
-   **Time Complexity**:
    -   *Best/Average*: `O(n log n)`.
    -   *Worst*: `O(n^2)`. This occurs if the pivot is consistently the smallest or largest element, which can happen with already-sorted data.
-   **Space Complexity**: `O(log n)` (due to recursion stack).

### Heap Sort

Heap sort is a comparison-based sorting technique based on a Binary Heap data structure.
-   **How it works**:
    1.  **Build Heap**: First, build a max-heap from the input data. The largest element is now at the root.
    2.  **Sort**: Swap the root element with the last element in the heap. "Remove" the last element from the heap (it's now in its sorted position).
    3.  **Heapify**: The root element may now violate the heap property. "Heapify" the root to restore the max-heap property.
    4.  Repeat steps 2-3 until the heap is empty.
-   **Time Complexity**: `O(n log n)` in all cases.
-   **Space Complexity**: `O(1)` (in-place).

---

## 4. Deliberate Practice

1.  **Implement Bubble Sort**: Write a function that sorts a list of numbers using bubble sort.
2.  **Implement Merge Sort**: Implement the `mergeSort` and `merge` functions to sort a list. This is a great exercise in recursion.
3.  **Implement Quick Sort**: Implement the `quickSort` and `partition` functions. Pay close attention to the logic of the partition step.
4.  **Visualize**: Use an online visualizer to watch these algorithms in action on the same dataset. Notice the differences in how they move the data.

---

## 5. Active Recall Questions

-   What is the time complexity of bubble sort? Why is it considered inefficient?
-   What is the main difference in space complexity between merge sort and quick sort?
-   What is a "pivot" in the context of quick sort?
-   What is the worst-case scenario for quick sort and how can it be mitigated? (Random pivot selection).
-   Which two of these algorithms have a guaranteed `O(n log n)` time complexity?

---

## 6. Tools, Frameworks, and Platforms

-   **Visualizers**: [VisuAlgo](https://visualgo.net/en/sorting) and [Toptal Sorting Algorithms](https://www.toptal.com/developers/sorting-algorithms) are fantastic for comparing the performance and mechanics of these algorithms side-by-side.
-   **Built-in Sort Functions**: Every language has a highly optimized, built-in sort function. It's important to know what algorithm it uses under the hood (often an introspective sort, a hybrid of quick sort, heap sort, and insertion sort).

---

## 7. Feedback and Self-Assessment

-   **Test with Sorted Data**: Run your quick sort implementation on an already sorted list. Does it exhibit worst-case `O(n^2)` performance?
-   **Stability**: Is the sorting algorithm "stable"? (A stable sort maintains the relative order of equal elements). Bubble sort and merge sort are stable. Quick sort and heap sort are not.
-   **Code Walkthrough**: Explain your implementation of merge sort or quick sort to a peer. This will force you to solidify your understanding of the recursive steps.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Sorting a massive log file.
-   You have a 10 GB log file that does not fit into your computer's RAM.
-   Which sorting algorithm would be suitable for this task?
-   **Merge sort** is the answer. Because it works by dividing the file into smaller, manageable chunks, sorting them individually, and then merging them back together, it's perfect for external sorting (sorting data that doesn't fit in memory).

This demonstrates that the choice of algorithm depends not just on time complexity, but also on the constraints of the system, like memory.

---

## 9. Collaborative Activities

-   **Human Sort**: Get a group of people and a deck of numbered cards. Physically act out the steps of bubble sort and then merge sort. This makes the logic very tangible.
-   **Partition Strategy**: As a group, discuss different strategies for choosing a pivot in quick sort (first element, last element, middle element, random element).

---

## 10. Domain-Specific Mastery Strategies

-   **Operating Systems**: The scheduler might use a sorting algorithm to decide which process to run next based on priority.
-   **Data Visualization**: Data almost always needs to be sorted before it can be effectively visualized in a chart or graph.
-   **Search Engines**: Search results are sorted by a relevance score, which is the output of a very complex sorting algorithm.

---

## 11. Psychological and Cognitive Principles

-   **Recursive Thinking**: Merge sort and quick sort are fantastic ways to practice recursive thinking. Trust that the recursive call on a smaller subarray will work, and focus only on the logic of the current step (the merge or the partition).
-   **Trade-offs**: There is no single "best" sorting algorithm. This is a key lesson in engineering: every choice has trade-offs (time vs. space, performance vs. predictability).

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the basic idea behind bubble sort and its `O(n^2)` complexity.
-   [ ] I can describe the "divide and conquer" strategy used by merge sort and quick sort.
-   [ ] I can explain what a pivot is and how the partition step in quick sort works.
-   [ ] I know that merge sort and heap sort are reliably `O(n log n)`.
-   [ ] I understand the space complexity trade-offs, particularly the `O(n)` space required by merge sort.

---

## 13. Research and References

-   **"Algorithms" by Robert Sedgewick and Kevin Wayne**: A classic textbook with detailed explanations and implementations.
-   **YouTube - AlgoRythmics**: A channel that visualizes sorting algorithms with folk dances. It's fun and surprisingly effective.
-   **Wikipedia - Sorting algorithm**: [Link](https://en.wikipedia.org/wiki/Sorting_algorithm) for a comprehensive overview and comparison.
