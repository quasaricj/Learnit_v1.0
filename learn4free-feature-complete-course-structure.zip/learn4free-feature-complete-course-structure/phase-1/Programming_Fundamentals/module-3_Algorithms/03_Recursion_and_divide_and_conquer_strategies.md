# Recursion and Divide-and-Conquer Strategies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** recursion as an algorithmic technique.
-   **Identify** the base case and the recursive step in a recursive solution.
-   **Explain** the divide-and-conquer paradigm.
-   **List** the three main steps of a divide-and-conquer algorithm.
-   **Analyze** problems to determine if they can be solved effectively with recursion or divide-and-conquer.
-   **Trace** the execution of a recursive algorithm using the call stack.

---

## 2. Introduction to Algorithmic Strategies

Beyond specific algorithms for searching or sorting, there are broader **algorithmic strategies** or **paradigms** that provide a framework for solving entire classes of problems. **Recursion** is a fundamental programming technique where a function calls itself, while **Divide and Conquer** is a powerful strategy that uses recursion to break down complex problems into more manageable pieces.

---

## 3. Core Concepts

### Recursion (as a strategy)

We've seen recursion as a programming feature, but it's also a way of thinking about problems. A problem might be a good candidate for a recursive solution if it can be defined in terms of a smaller version of itself.

-   **Base Case**: The simplest possible version of the problem, which can be solved directly without further recursion. This is what stops the chain of function calls.
-   **Recursive Step**: The part of the solution where the problem is broken down into a smaller version of itself, and the function calls itself to solve that smaller piece. The solution to the smaller piece is then used to solve the original problem.

**Example**: Calculating `power(x, n)` (x raised to the power of n).
-   **Recursive Definition**: `power(x, n) = x * power(x, n-1)`
-   **Base Case**: `power(x, 0) = 1`

### Divide and Conquer

This is a powerful algorithmic paradigm that closely relates to recursion. It involves three steps:

1.  **Divide**: Break the given problem into subproblems of the same type, but smaller in size.
2.  **Conquer**: Solve the subproblems recursively. If the subproblems are small enough, solve them directly (this is the base case).
3.  **Combine**: Combine the solutions of the subproblems to create the solution for the original problem.

**Classic Examples**:
-   **Merge Sort**:
    -   *Divide*: Split the array in half.
    -   *Conquer*: Recursively sort each half.
    -   *Combine*: Merge the two sorted halves.
-   **Binary Search**:
    -   *Divide*: Compare the target to the middle element, effectively dividing the problem into one of two smaller search spaces.
    -   *Conquer*: Recursively search the appropriate half.
    -   *Combine*: No combination step is needed; the result of the recursive call is the final result.

---

## 4. Deliberate Practice

1.  **Greatest Common Divisor (GCD)**: The Euclidean algorithm for finding the GCD of two numbers can be expressed recursively. Implement it.
2.  **Tower of Hanoi**: This is a classic puzzle that has a famously elegant recursive solution. Try to implement it.
3.  **Merge Sort Analysis**: Look back at your merge sort implementation. Clearly identify the "Divide", "Conquer", and "Combine" steps in your code.
4.  **Closest Pair of Points**: This is a more advanced problem. Given a set of points on a 2D plane, find the pair of points with the smallest distance between them. This has a clever divide-and-conquer solution that is much faster than the brute-force `O(n^2)` approach.

---

## 5. Active Recall Questions

-   What are the two essential components of a recursive function?
-   What are the three steps of the divide-and-conquer strategy?
-   Is recursion always the most efficient way to solve a problem? (No, an iterative solution can sometimes be faster and use less memory).
-   Name two algorithms we've already studied that use the divide-and-conquer strategy.
-   What is the role of the call stack in recursion?

---

## 6. Tools, Frameworks, and Platforms

-   **Debugger**: The debugger's call stack window is your best friend for understanding recursion. It visually shows you the chain of function calls and how the program returns back up the chain.
-   **Whiteboard**: Draw the recursion tree for a problem. This shows how the main problem branches out into smaller subproblems.

---

## 7. Feedback and Self-Assessment

-   **Trace the Stack**: For a recursive function like `factorial(3)`, manually write down the state of the call stack at each step of the execution.
-   **Identify the Pattern**: Look at the problems that are good for divide-and-conquer. What do they have in common? (The ability to be broken down into independent subproblems).
-   **Think about the "Combine" Step**: The "Combine" step is often the most complex part of a divide-and-conquer algorithm. For merge sort, the `merge` function is where the core logic lies.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Counting Inversions
-   An "inversion" in an array is a pair of indices `(i, j)` such that `i < j` and `array[i] > array[j]`. It's a measure of how "unsorted" an array is.
-   The brute-force approach is `O(n^2)`.
-   This problem can be solved in `O(n log n)` time using a divide-and-conquer approach that is a clever modification of merge sort. As you merge the two sorted halves, you can also count the inversions between them.

This shows that the divide-and-conquer paradigm can be adapted to solve problems that are not just about sorting or searching.

---

## 9. Collaborative Activities

-   **Recursive Brainstorming**: As a group, pick a problem and try to define it recursively. Can you find a base case and a recursive step?
-   **Whiteboard a Recursion Tree**: For an algorithm like merge sort on an array of 8 elements, draw the full recursion tree on a whiteboard to see how the problem is divided and then the results are combined.

---

## 10. Domain-Specific Mastery Strategies

-   **Functional Programming**: Languages like Lisp, Haskell, and F# use recursion as the primary way to iterate and process data.
-   **Computer Graphics**: Fractals, which are complex, self-similar patterns, are generated using recursive algorithms.
-   **Parsing**: Compilers often use recursive descent parsers to analyze the structure of the code you write, which is itself a recursive structure.

---

## 11. Psychological and Cognitive Principles

-   **The Recursive Leap of Faith**: This is the most crucial mental trick for mastering recursion. When you are writing the recursive step, you must *assume* that your function already works for the smaller subproblem. Trust the "magic" of the recursive call and focus only on the logic for the current step.
-   **Problem Decomposition**: The ability to break a large problem down into smaller, identical subproblems is a skill that extends far beyond just programming.

---

## 12. Summary and Mastery Checklist

-   [ ] I can identify the base case and recursive step in a recursive algorithm.
-   [ ] I can explain the three steps of the divide-and-conquer paradigm.
-   [ ] I can name at least two well-known divide-and-conquer algorithms.
-   [ ] I understand that recursion uses the call stack and can lead to a stack overflow if the base case is not reached.
-   [ ] I can analyze a problem and consider whether a recursive or divide-and-conquer approach would be suitable.

---

## 13. Research and References

-   **"Structure and Interpretation of Computer Programs" (SICP)**: A classic CS text that teaches programming with recursion as the foundational concept.
-   **"The Algorithm Design Manual" by Steven S. Skiena**: Provides a great overview of various algorithmic paradigms, including divide-and-conquer.
-   **YouTube - Abdul Bari - Divide and Conquer Introduction**: A clear and detailed lecture on the topic.
