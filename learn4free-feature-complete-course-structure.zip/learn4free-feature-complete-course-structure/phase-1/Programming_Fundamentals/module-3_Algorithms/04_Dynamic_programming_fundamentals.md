# Dynamic Programming Fundamentals

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** dynamic programming (DP) as an algorithmic technique.
-   **Identify** the two key properties of a problem that indicate it can be solved with DP: optimal substructure and overlapping subproblems.
-   **Differentiate** between the two main DP approaches: memoization (top-down) and tabulation (bottom-up).
-   **Implement** a memoized solution for a recursive problem like Fibonacci.
-   **Implement** a tabulated solution for a simple problem.
-   **Recognize** classic DP problems like the knapsack problem or coin change problem.

---

## 2. Introduction to Dynamic Programming

Dynamic Programming is a powerful technique for solving optimization problems by breaking them down into simpler subproblems. It is particularly effective for problems where a naive recursive solution would be too slow because it re-computes the same subproblems over and over again. DP solves each subproblem only once and stores its result, avoiding redundant calculations.

---

## 3. Core Concepts

### Conditions for Dynamic Programming

For a problem to be solvable with DP, it must have two properties:

1.  **Optimal Substructure**: The optimal solution to the overall problem can be constructed from the optimal solutions of its subproblems. (e.g., the shortest path to a destination is an extension of the shortest path to an intermediate stop).
2.  **Overlapping Subproblems**: A recursive solution to the problem involves solving the same subproblems multiple times. DP works by storing the results of these subproblems to avoid re-computation.

**Example**: The Fibonacci sequence. `fib(n) = fib(n-1) + fib(n-2)`. A naive recursive solution for `fib(5)` will call `fib(3)` twice, `fib(2)` three times, etc. This is a classic example of overlapping subproblems.

### DP Approaches

1.  **Memoization (Top-Down)**: This is a "lazy" approach that starts with the original problem and uses recursion. Before computing the solution to a subproblem, it checks if the solution is already stored in a cache (e.g., a hash map or an array).
    -   If the solution is in the cache, it's returned immediately.
    -   If not, the solution is computed, stored in the cache, and then returned.
    This is essentially "smart" recursion.

2.  **Tabulation (Bottom-Up)**: This is an "eager" approach that solves the problem "bottom-up". It starts by solving the smallest possible subproblems and gradually builds up to the solution of the original problem. The results are stored in a table (e.g., a 1D or 2D array).
    -   There is usually no recursion involved; the solution is iterative.
    -   This approach can be more space-efficient and avoid recursion depth limits.

---

## 4. Deliberate Practice

1.  **Naive Fibonacci**: Write the simple, naive recursive function for the Fibonacci sequence.
2.  **Memoized Fibonacci**: Take your naive Fibonacci function and add a cache (a dictionary or map) to implement memoization. Notice the dramatic speed improvement for larger numbers.
3.  **Tabulated Fibonacci**: Write a function to calculate the Fibonacci sequence using a bottom-up, iterative approach with an array.
4.  **Climbing Stairs Problem**: You are climbing a staircase. It takes `n` steps to reach the top. Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top? This is a classic DP problem.

---

## 5. Active Recall Questions

-   What are the two required properties for a problem to be solvable with DP?
-   What is the main difference between memoization and tabulation?
-   Why is the naive recursive solution for Fibonacci so slow?
-   Which DP approach is typically recursive? Which is iterative?
-   What is the purpose of the "cache" or "table" in DP?

---

## 6. Tools, Frameworks, and Platforms

-   **Whiteboard**: Essential for working out the recurrence relation and the structure of the DP table.
-   **Debugger**: Step through a memoized recursive solution to see how the cache is populated and how subsequent calls for the same subproblem return instantly.

---

## 7. Feedback and Self-Assessment

-   **Analyze the Subproblems**: For a given problem, draw the recursion tree. Do you see the same subproblems appearing in multiple branches? This is the key indicator for DP.
-   **Define the State**: The "state" of a DP problem is the set of parameters that uniquely identify a subproblem. For Fibonacci, the state is just the number `n`. For more complex problems, the state might be a pair of indices `(i, j)`. Defining the state is often the hardest part of solving a DP problem.
-   **Find the Recurrence Relation**: The recurrence relation is the formula that relates the solution of a problem to the solutions of its subproblems (e.g., `fib(n) = fib(n-1) + fib(n-2)`).

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: The Coin Change Problem
-   Given a set of coin denominations (e.g., {1, 5, 10}) and a total amount, find the *minimum number* of coins required to make that amount.
-   This problem has optimal substructure: the minimum number of coins for amount `A` is `1 + min(coins_for(A - coin_value))` over all coin values.
-   It also has overlapping subproblems: the number of coins needed for amount 10 will be calculated multiple times on the way to calculating the amount for 20.
-   This is a classic DP problem that can be solved with either memoization or tabulation.

---

## 9. Collaborative Activities

-   **DP War Stories**: Many experienced developers find DP challenging. As a group, discuss why it's considered a difficult topic. What are the common pitfalls?
-   **Tabulation Walkthrough**: On a whiteboard, manually fill out the DP table for a problem like "Climbing Stairs" or "Coin Change". This makes the bottom-up process very clear.

---

## 10. Domain-Specific Mastery Strategies

-   **Bioinformatics**: DP is used for sequence alignment, such as finding the similarity between two DNA or protein sequences.
-   **Financial Modeling**: DP can be used to optimize investment strategies over time.
-   **Competitive Programming**: A huge percentage of problems in competitive programming contests are DP problems.

---

## 11. Psychological and Cognitive Principles

-   **Recognizing the Pattern**: The key to getting good at DP is not about being a genius, but about recognizing patterns. The more classic DP problems you solve, the more you will start to recognize the underlying patterns in new problems.
-   **Patience and Persistence**: DP is a topic that takes time and practice to master. Don't be discouraged if it doesn't click immediately. Work through the fundamentals (memoizing simple recursion) before tackling more complex problems.

---

## 12. Summary and Mastery Checklist

-   [ ] I can identify optimal substructure and overlapping subproblems.
-   [ ] I can explain the difference between a top-down (memoization) and bottom-up (tabulation) approach.
-   [ ] I can take a slow recursive function and speed it up with memoization.
-   [ ] I can solve a simple problem using a bottom-up, tabulated approach.
-   [ ] I understand that DP is about storing the results of subproblems to avoid re-computation.

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Chapter 9 provides a gentle and visual introduction to dynamic programming.
-   **GeeksforGeeks - Dynamic Programming**: [Link](https://www.geeksforgeeks.org/dynamic-programming/)
-   **YouTube - Tushar Roy - Dynamic Programming**: A series of videos that work through many classic DP problems.
-   **TopCoder - A tutorial on Dynamic Programming**: A classic, in-depth article.
