# Time and Space Complexity Analysis (Big O Notation)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** algorithm complexity and explain its importance.
-   **Differentiate** between time complexity and space complexity.
-   **Explain** what Big O notation is and what it represents (the upper bound on the growth rate).
-   **Identify** and **rank** the most common complexity classes: `O(1)`, `O(log n)`, `O(n)`, `O(n log n)`, `O(n^2)`, `O(2^n)`.
-   **Analyze** a simple piece of code and determine its time and space complexity.
-   **Understand** the difference between best-case, average-case, and worst-case complexity.

---

## 2. Introduction to Complexity Analysis

Why is an algorithm like binary search considered "better" than linear search? How do we measure the efficiency of an algorithm? Complexity analysis is the formal method we use to answer these questions. It's not about measuring the exact time an algorithm takes to run (which depends on the computer's speed), but rather about measuring how the number of operations and memory usage **grow** as the input size (`n`) increases. **Big O notation** is the mathematical language we use to describe this growth rate.

---

## 3. Core Concepts

### What is Complexity?

-   **Time Complexity**: Measures how the number of operations an algorithm performs grows with the input size `n`.
-   **Space Complexity**: Measures how the amount of memory an algorithm uses grows with the input size `n`.

### Big O Notation

Big O notation describes the **worst-case** scenario. It provides an **upper bound** on the growth rate of a function. When we say an algorithm is `O(n)`, we mean that its execution time grows, at most, linearly with the input size `n`.

### Common Complexity Classes (from fastest to slowest)

1.  **`O(1)` — Constant Time**: The algorithm takes the same amount of time regardless of the input size.
    -   *Example*: Accessing an element in an array by its index.

2.  **`O(log n)` — Logarithmic Time**: The time it takes grows logarithmically with the input size. These algorithms are incredibly scalable.
    -   *Example*: Binary search.

3.  **`O(n)` — Linear Time**: The time it takes grows linearly with the input size.
    -   *Example*: Linear search, iterating through a list.

4.  **`O(n log n)` — Log-Linear Time**: A very efficient complexity for sorting algorithms.
    -   *Example*: Merge sort, quick sort (average case).

5.  **`O(n^2)` — Quadratic Time**: The time it takes grows quadratically. Often involves nested loops.
    -   *Example*: Bubble sort, comparing every element in a list to every other element.

6.  **`O(2^n)` — Exponential Time**: The time it takes doubles with each addition to the input size. These algorithms are not scalable for even moderately sized inputs.
    -   *Example*: Naive recursive Fibonacci, solving the traveling salesman problem with brute force.

### Best, Average, and Worst Case

-   **Worst-Case (Big O)**: The maximum number of operations for a given input size. This is the most important measure.
-   **Average-Case (Big Theta)**: The expected number of operations for a "typical" input.
-   **Best-Case (Big Omega)**: The minimum number of operations for a given input size.

---

## 4. Deliberate Practice

Analyze the time and space complexity of the following code snippets:

1.  **Find an element in a list**:
    ```python
    def find_element(arr, target):
        for item in arr:
            if item == target:
                return True
        return False
    ```

2.  **Find duplicates**:
    ```python
    def has_duplicates(arr):
        for i in range(len(arr)):
            for j in range(i + 1, len(arr)):
                if arr[i] == arr[j]:
                    return True
        return False
    ```

3.  **Create a list of pairs**:
    ```python
    def create_pairs(arr):
        pairs = []
        for item1 in arr:
            for item2 in arr:
                pairs.append((item1, item2))
        return pairs
    ```

4.  **Binary search (from the previous module)**. Why is it `O(log n)`?

---

## 5. Active Recall Questions

-   What does `n` represent in Big O notation?
-   What is the difference between time and space complexity?
-   Which is faster, `O(n)` or `O(log n)`?
-   What is the time complexity of a nested loop that iterates through the same list?
-   Why do we usually focus on the worst-case complexity?

---

## 6. Tools, Frameworks, and Platforms

-   **Big O Cheat Sheet**: A great website that provides a quick reference for the complexity of common data structure operations and sorting algorithms. [Link](https://www.bigocheatsheet.com/)
-   **Performance Profilers**: Tools built into IDEs or browsers that can measure the actual execution time and memory usage of your code. This is useful for verifying your theoretical analysis.

---

## 7. Feedback and Self-Assessment

-   **Drop the Constants**: In Big O notation, we ignore constants. `O(2n)` is the same as `O(n)`. Why do we do this? (Because as `n` gets very large, the constant factor becomes insignificant).
-   **Drop Non-Dominant Terms**: `O(n^2 + n)` simplifies to `O(n^2)`. Why? (Because the `n^2` term grows so much faster that it dominates the `n` term for large `n`).
-   **Analyze Your Own Code**: Go back to the code you wrote for the previous modules. Try to determine the Big O complexity for each function you wrote.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Choosing the right data structure.
-   You need to store a list of 1 million usernames and frequently check if a new username has already been taken.
-   **Option 1: Use a list/array.** Storing the usernames takes `O(n)` space. Checking if a username exists requires a linear search, which is `O(n)`.
-   **Option 2: Use a hash set.** Storing the usernames takes `O(n)` space. Checking if a username exists is, on average, `O(1)`.

By understanding the time complexity of the "contains" operation for these two data structures, you can make an informed decision. For this use case, the hash set is vastly superior. This is one of the most important practical applications of Big O analysis.

---

## 9. Collaborative Activities

-   **Complexity Smackdown**: As a group, analyze several different pieces of code. Have each person determine the Big O complexity, and then compare and defend your answers.
-   **Code Optimization**: Take a piece of `O(n^2)` code (like the "find duplicates" example) and work together to optimize it to `O(n)` using a hash set.

---

## 10. Domain-Specific Mastery Strategies

-   **Backend Development**: When designing an API, you need to be very aware of the complexity of your database queries. An `O(n)` query might be fine for a small table, but it could bring down your entire system on a table with millions of rows.
-   **Frontend Development**: Inefficient rendering logic (e.g., `O(n^2)` algorithms in the UI thread) can lead to a slow, unresponsive user interface.
-   **Data Science**: The choice of algorithm for processing a large dataset is completely dictated by its time and space complexity. An `O(n^2)` algorithm is often not even a possibility.

---

## 11. Psychological and Cognitive Principles

-   **Asymptotic Thinking**: Big O is about the "long game". It describes how an algorithm behaves as the input size approaches infinity. This kind of asymptotic thinking is a core component of mathematical and engineering reasoning.
-   **It's a "Language"**: Think of Big O as the language you use to communicate with other developers about the efficiency of code. When someone says "this is an O(n log n) solution," it conveys a huge amount of information in a very concise way.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that Big O describes the growth rate of an algorithm as the input `n` gets large.
-   [ ] I can name and rank the common complexity classes like `O(1)`, `O(n)`, and `O(n^2)`.
-   [ ] I can determine the time complexity of simple loops and nested loops.
-   [ ] I understand that `O(1)` is constant time, which is the ideal.
-   [ ] I can explain why choosing the right data structure is critical for performance, using Big O as my reasoning.

---

## 13. Research and References

-   **"Grokking Algorithms" by Aditya Bhargava**: Provides very clear, illustrated explanations of Big O for beginners.
-   **"Introduction to Algorithms" (CLRS)**: The standard academic text for a deep, formal understanding of complexity analysis.
-   **YouTube - HackerRank - Big O Notation**: A good video introduction to the topic.
