# Classes, Objects, and Instantiation

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** the difference between a class and an object.
-   **Explain** that a class is a blueprint and an object is an instance.
-   **Declare** a simple class in your chosen programming language.
-   **Instantiate** multiple objects from the same class.
-   **Define** and use attributes (properties) and methods (behaviors) for a class.
-   **Understand** the purpose of a constructor method.
-   **Explain** the role of the `this` or `self` keyword.

---

## 2. Introduction to Object-Oriented Programming (OOP)

Object-Oriented Programming is a programming paradigm based on the concept of "objects", which can contain data and code. OOP is designed to group data (attributes) and the code that operates on that data (methods) into a single, self-contained unit. This approach helps to manage complexity, improve reusability, and create more organized and maintainable code. The foundational concepts of OOP are **classes** and **objects**.

---

## 3. Core Concepts

### Class

A **class** is a **blueprint** or a template for creating objects. It defines a set of attributes and methods that the objects of that class will have. For example, you could have a `Car` class that defines that all cars will have a `color` and a `maxSpeed` (attributes), and that they can `startEngine()` and `drive()` (methods). The class itself is not an object; it's the recipe for making objects.

### Object

An **object** is an **instance** of a class. It is a concrete entity created from the class blueprint, and it resides in the computer's memory. Using our `Car` blueprint, you could create multiple car objects: a `blueCar` object, a `redCar` object, and so on. Each object has its own set of attribute values (e.g., `blueCar.color = "blue"`, `redCar.color = "red"`).

### Instantiation

**Instantiation** is the process of creating an object from a class. When you instantiate a class, you are creating a new instance (an object) in memory. This is typically done using the `new` keyword in many languages.

`myBlueCar = new Car("blue", 200);`

### Constructor

A **constructor** is a special method within a class that is automatically called when a new object is instantiated. Its purpose is to initialize the attributes of the object. In the example above, the constructor would take `"blue"` and `200` and assign them to the new object's `color` and `maxSpeed` attributes.

### `this` or `self`

Inside a class's methods, you often need to refer to the *specific object* that the method is being called on. The `this` (in languages like Java, C++, JavaScript) or `self` (in Python) keyword is a reference to the current instance of the class. For example, `this.color = "blue"` assigns the value `"blue"` to the `color` attribute of the *current* object being created.

---

## 4. Deliberate Practice

1.  **Create a `Dog` Class**:
    -   Define a `Dog` class.
    -   Give it attributes for `name` and `breed`.
    -   Write a constructor that initializes these attributes.
    -   Add a method called `bark()` that prints a string like "Woof! My name is [name]".
2.  **Instantiate Objects**:
    -   Create two different `Dog` objects from your class, for example, `fido` and `lucy`.
    -   Give them different names and breeds.
3.  **Call Methods**:
    -   Call the `bark()` method on both of your `Dog` objects and observe the different outputs.

---

## 5. Active Recall Questions

-   What is the relationship between a class and an object? Use an analogy.
-   What is the name of the special method that is called when you create a new object?
-   What is the purpose of the `this` (or `self`) keyword?
-   Can you create multiple objects from the same class?
-   What are the two main things a class defines? (Attributes and methods).

---

## 6. Tools, Frameworks, and Platforms

-   **IDE (Integrated Development Environment)**: An IDE with features like code completion and IntelliSense is extremely helpful for OOP. It can show you the available attributes and methods for an object as you type.
-   **Debugger**: A debugger is invaluable for inspecting the state of an object at runtime. You can set a breakpoint and see the specific values of an object's attributes.

---

## 7. Feedback and Self-Assessment

-   **Object State**: Create a `BankAccount` class with a `balance` attribute and `deposit()` and `withdraw()` methods. Instantiate an object, call the methods, and print the balance after each call to ensure the object's state is being updated correctly.
-   **Code Review**: Ask a peer to look at your `Dog` class. Is it well-named? Are the attribute and method names clear?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Modeling a User
-   Imagine you are building a social media application. You need to represent a user in your system.
-   What attributes would a `User` class have? (`username`, `email`, `password_hash`, `profile_picture_url`, `friends_list`).
-   What methods would it have? (`postMessage()`, `addFriend()`, `changePassword()`).
-   Thinking in terms of classes and objects allows you to model real-world entities and their interactions in a very clean and organized way.

---

## 9. Collaborative Activities

-   **Class Design**: As a group, design a class for a more complex entity, like a `BlogPost` or an `EcommerceProduct`, on a whiteboard. Decide on the necessary attributes and methods together.
-   **Pair Programming**: Work with a partner to implement the `BankAccount` class. One person can write the `deposit` method, and the other can write the `withdraw` method, including a check to prevent overdrawing.

---

## 10. Domain-Specific Mastery Strategies

-   **Game Development**: Everything in a game is an object: the player, enemies, items, bullets. OOP is the dominant paradigm in game development.
-   **UI Development**: Modern UI frameworks (like React, Angular, Vue) are based on the concept of "components", which are essentially classes that encapsulate a piece of the user interface's state (attributes) and behavior (methods).
-   **Backend Development**: In large-scale backend systems, OOP is used to model business entities (like `User`, `Order`, `Product`) and the logic that governs them.

---

## 11. Psychological and Cognitive Principles

-   **Abstraction**: OOP is a powerful form of abstraction. It allows you to package complex data and logic into a simple, easy-to-use object. You can `drive()` a `Car` object without needing to know the complex details of how the engine works.
-   **Mental Models**: OOP allows you to create mental models of your program that map more closely to the real world, making the code easier to reason about.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that a class is a blueprint and an object is an instance.
-   [ ] I can create a simple class with attributes and methods.
-   [ ] I can use a constructor to initialize an object's attributes.
-   [ ] I can instantiate one or more objects from a class.
-   [ ] I understand that `this`/`self` refers to the specific object a method is called on.

---

## 13. Research and References

-   **MDN Web Docs - Object-oriented JavaScript for beginners**: [Link](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/Object-oriented_JS)
-   **Python Documentation - Classes**: [Link](https://docs.python.org/3/tutorial/classes.html)
-   **"Head First Design Patterns" by Eric Freeman & Elisabeth Robson**: A classic book that introduces OOP concepts in a very visual and engaging way.
