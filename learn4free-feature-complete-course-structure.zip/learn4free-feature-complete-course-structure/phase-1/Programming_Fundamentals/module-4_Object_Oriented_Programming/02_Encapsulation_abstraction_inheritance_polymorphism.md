# The Four Pillars of OOP: Encapsulation, Abstraction, Inheritance, and Polymorphism

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define and explain** the four main principles of Object-Oriented Programming.
-   **Describe** how encapsulation bundles data and methods together.
-   **Explain** how abstraction hides complex implementation details.
-   **Implement** inheritance to create a subclass that inherits from a parent class.
-   **Define** polymorphism and provide an example of how it allows objects of different classes to be treated as objects of a common superclass.
-   **Relate** these principles to real-world analogies.

---

## 2. Introduction to the Pillars of OOP

While classes and objects provide the basic structure for OOP, the true power of the paradigm comes from four core principles: Encapsulation, Abstraction, Inheritance, and Polymorphism. These concepts work together to help you build software that is robust, flexible, and easy to maintain. Mastering them is essential for becoming a proficient object-oriented developer.

---

## 3. Core Concepts

### 1. Encapsulation

**Encapsulation** is the bundling of data (attributes) and the methods that operate on that data into a single unit (a class). It also involves restricting direct access to an object's internal state. This is often achieved by making attributes `private` and providing `public` methods (getters and setters) to access and modify them.

-   **Analogy**: A capsule pill. The plastic casing (the class) encloses the medicine (the data). You don't interact with the raw chemical powders directly; you use the interface the capsule provides.
-   **Benefit**: Protects data from unintended modification and makes the class a self-contained, predictable unit.

### 2. Abstraction

**Abstraction** is the concept of hiding complex implementation details and showing only the essential features of the object. It's about simplifying a complex system by modeling classes appropriate to the problem.

-   **Analogy**: A car's dashboard. You can use the steering wheel, pedals, and gearstick to drive the car. You don't need to know the complex mechanical and electrical details happening under the hood. The dashboard is the abstraction.
-   **Benefit**: Reduces complexity, isolates the impact of changes, and makes the system easier to use.

### 3. Inheritance

**Inheritance** is a mechanism that allows a new class (a `subclass` or `child class`) to inherit the attributes and methods of an existing class (a `superclass` or `parent class`). This promotes code reuse and establishes a clear "is-a" relationship between classes.

-   **Analogy**: A `GoldenRetriever` is a type of `Dog`. It inherits all the general properties of a dog (four legs, a tail, the ability to bark), but it might have its own specific attributes (e.g., golden fur) or methods.
-   **Benefit**: Promotes code reusability and creates a logical hierarchy.

### 4. Polymorphism

**Polymorphism** (from Greek, meaning "many forms") is the ability of an object to take on many forms. In practice, it means that a parent class reference can be used to refer to a child class object. It allows you to write code that can work with objects of different classes in a uniform way.

-   **Analogy**: The "start" button on a DVD player, a video game console, and a laptop. They are all different objects, but you can interact with them through a common interface (the `start` button), and they each respond in their own specific way.
-   **Benefit**: Provides flexibility and allows for code that is more generic and extensible.

---

## 4. Deliberate Practice

1.  **Encapsulation**: Modify your `BankAccount` class from the previous module. Make the `balance` attribute `private`. Create a `getBalance()` method (a getter) and modify the `deposit` and `withdraw` methods (setters) to control access to the balance.
2.  **Inheritance**:
    -   Create a general `Animal` class with a method `makeSound()`.
    -   Create `Dog` and `Cat` classes that **inherit** from `Animal`.
    -   **Override** the `makeSound()` method in both `Dog` and `Cat` to print "Woof" and "Meow" respectively.
3.  **Polymorphism**:
    -   Create a list of `Animal` objects that contains both `Dog` and `Cat` instances.
    -   Iterate through the list and call the `makeSound()` method on each object. Notice how the correct method is called for each object, even though you are treating them all as `Animal`s.

---

## 5. Active Recall Questions

-   What is the main goal of encapsulation?
-   How does abstraction simplify complex systems?
-   What kind of relationship does inheritance model? ("is-a").
-   Explain polymorphism using the `Animal` and `Dog`/`Cat` example.
-   Which two principles are most concerned with "hiding" information? (Encapsulation and Abstraction).

---

## 6. Tools, Frameworks, and Platforms

-   **UML (Unified Modeling Language) Class Diagrams**: A standard way to visually represent the classes in a system, including their attributes, methods, and the relationships (like inheritance) between them. Tools like `draw.io` or Lucidchart are great for this.

---

## 7. Feedback and Self-Assessment

-   **Identify the Principles**: Look at a well-written library or framework in your language. Can you identify examples of encapsulation, abstraction, inheritance, and polymorphism?
-   **"Is-a" vs. "Has-a"**: A `Car` *is a* `Vehicle` (inheritance). A `Car` *has a* `Engine` (composition, not inheritance). Understanding this distinction is key to good object-oriented design.
-   **Code Review**: Ask a peer to review your inheritance hierarchy. Is it logical? Does it make sense for the subclass to inherit from the superclass?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A UI Framework
-   A UI framework might have a base `UIComponent` class.
-   `Button`, `TextBox`, and `Image` classes would **inherit** from `UIComponent`.
-   The `UIComponent` class might define a `draw()` method, which is an example of **abstraction**.
-   Each subclass would implement its own specific version of `draw()` (**polymorphism**).
-   The internal state of each component (like its position and size) would be hidden from the outside world (**encapsulation**).

This shows how all four principles work together to create a flexible and powerful system.

---

## 9. Collaborative Activities

-   **OOP Roleplay**: Assign each person in a group a different class from an inheritance hierarchy (e.g., `Animal`, `Dog`, `Cat`). Act out how a method call would work, demonstrating polymorphism.
-   **Design Discussion**: As a group, debate the best way to model a complex system using these principles. For example, a university (with `Person`, `Student`, `Professor`, `Course` classes).

---

## 10. Domain-Specific Mastery Strategies

-   **Everywhere!**: These four principles are the bedrock of most large, modern software systems, regardless of the specific domain. They are fundamental to building scalable and maintainable software in any field.

---

## 11. Psychological and Cognitive Principles

-   **Categorization**: Humans naturally categorize the world into hierarchies (an apple is a fruit, a fruit is a food). Inheritance allows you to model these natural categories in your code.
-   **Black Box Thinking**: Abstraction and encapsulation encourage "black box" thinking. You can use an object without needing to understand its internal wiring, which dramatically reduces cognitive load.

---

## 12. Summary and Mastery Checklist

-   [ ] **Encapsulation**: I can explain that this is about bundling data and methods, and controlling access to the data.
-   [ ] **Abstraction**: I can explain that this is about hiding complexity and showing only what is necessary.
-   [ ] **Inheritance**: I can create a subclass that extends a superclass, reusing its code.
-   [ ] **Polymorphism**: I can explain that this allows objects of different child classes to be treated as if they were objects of the parent class.
-   [ ] I can see how these four principles work together to create well-designed object-oriented systems.

---

## 13. Research and References

-   **"Design Patterns: Elements of Reusable Object-Oriented Software" by the "Gang of Four"**: The definitive, classic book on OOP design.
-   **"Head First Design Patterns"**: A much more accessible and visual introduction to the same concepts.
-   **Refactoring Guru - The Pillars of OOP**: [Link](https://refactoring.guru/design-patterns/book) (The book's intro covers the pillars well).
