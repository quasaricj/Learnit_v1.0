# Access Specifiers and Modifiers

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** access specifiers and their role in enforcing encapsulation.
-   **Differentiate** between `public`, `private`, and `protected` access levels.
-   **Apply** the appropriate access specifier to class members (attributes and methods).
-   **Understand** how different languages handle access control (e.g., Python's name mangling vs. Java's keywords).
-   **Explain** the purpose of other modifiers like `static`, `final`, and `const`.

---

## 2. Introduction to Access Control

In the previous module, we discussed **encapsulation** as the principle of bundling data and methods, and restricting direct access to an object's internal state. **Access specifiers** (also called access modifiers) are the keywords that provide the mechanism to enforce this principle. They define the visibility of a class and its members, controlling which parts of your code can access them.

---

## 3. Core Concepts

### Access Specifiers

These keywords are most prominent in statically-typed languages like Java, C++, and C#.

1.  **`public`**:
    -   **Visibility**: Members declared as `public` are accessible from anywhere: from within the same class, from subclasses, and from any other class in any package.
    -   **Use Case**: This is for the "public interface" of your class. Methods that other parts of your application need to call should be `public`.

2.  **`private`**:
    -   **Visibility**: Members declared as `private` are only accessible from **within the same class**. They cannot be seen or used by subclasses or any other external code.
    -   **Use Case**: This is the default for attributes. It's the primary tool for encapsulation, hiding the internal state of an object and forcing access through public methods (getters/setters).

3.  **`protected`**:
    -   **Visibility**: Members declared as `protected` are accessible within the same class, by subclasses (even if they are in different packages), and by classes in the same package.
    -   **Use Case**: This is useful when you are designing a class specifically to be inherited. It allows a subclass to directly access and modify its parent's data, which can be more efficient than using public methods, but it also creates a tighter coupling between the classes.

**Language-Specific Notes**:
-   **Python**: Python doesn't have strict `private` keywords. Instead, it uses a convention: a member name prefixed with a single underscore (e.g., `_balance`) is treated as `protected`. A name prefixed with a double underscore (e.g., `__balance`) is "name-mangled," making it harder to access from outside, effectively acting as `private`.
-   **JavaScript**: Historically, JavaScript didn't have private members. The common convention was to use an underscore prefix. Modern JavaScript now has a `#` prefix for true private fields.

### Other Common Modifiers

-   **`static`**:
    -   A `static` member belongs to the **class itself**, not to any specific instance of the class. This means you can call a `static` method or access a `static` attribute without creating an object of the class.
    -   *Example*: `Math.PI`. You don't create a `new Math()` object to access `PI`.
-   **`final` (or `const` or `readonly`)**:
    -   A `final` variable is a constant; its value cannot be changed after it is initialized.
    -   A `final` method cannot be overridden by a subclass.
    -   A `final` class cannot be inherited from.

---

## 4. Deliberate Practice

1.  **Refactor `BankAccount`**:
    -   Take your `BankAccount` class.
    -   Declare the `balance` attribute as `private`.
    -   If your language supports it, declare the `accountNumber` as `final` or `readonly` after it's set in the constructor.
    -   Ensure your `deposit`, `withdraw`, and `getBalance` methods are `public`.
2.  **`protected` Members**:
    -   Create a `SavingsAccount` class that inherits from `BankAccount`.
    -   Change the `balance` in `BankAccount` to `protected`.
    -   Add an `addInterest()` method to `SavingsAccount` that directly accesses and modifies the `balance`.
3.  **Static Members**:
    -   Add a `static` attribute to your `BankAccount` class called `numberOfAccounts`.
    -   Increment this `static` variable inside the constructor.
    -   Create a `static` method `getNumberOfAccounts()` that returns its value.
    -   Create a few `BankAccount` objects and then call `BankAccount.getNumberOfAccounts()` to see the total.

---

## 5. Active Recall Questions

-   What is the difference between `public` and `private`?
-   Which access specifier is most directly related to inheritance?
-   What does the `static` keyword signify?
-   Can you change the value of a `final` variable?
-   How does Python indicate that a member should be treated as private?

---

## 6. Tools, Frameworks, and Platforms

-   **Compiler/Linter**: The compiler (in languages like Java/C#) or a linter will be your primary tool for enforcing access rules. It will give you an error if you try to access a `private` member from outside the class.
-   **IDE**: Your IDE's code completion will often hide private members from the suggestion list when you are working outside the class, reinforcing the concept of a public interface.

---

## 7. Feedback and Self-Assessment

-   **Principle of Least Privilege**: When designing a class, always start by making members as private as possible. Only make them more accessible (`protected` or `public`) if there is a clear and justified reason.
-   **API Design**: The `public` members of your classes form an "Application Programming Interface" (API) for other parts of your code. Think carefully about this API. Is it easy to use? Does it hide the internal complexity?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Designing a `Car` class
-   `public` methods: `startEngine()`, `stopEngine()`, `accelerate()`. These are the public interface for "driving" the car.
-   `private` attributes: `_currentSpeed`, `_rpm`, `_engineTemperature`. The outside world should not be able to arbitrarily change these values. They are side effects of the public methods.
-   `protected` method: `_igniteSparkPlugs()`. This is an internal detail that the `startEngine()` method uses. You might make it `protected` if you anticipate a `SportsCar` subclass needing to override it with a more advanced ignition sequence.
-   `static final` attribute: `WHEELS = 4`. This is a constant that is true for all instances of the `Car` class.

---

## 9. Collaborative Activities

-   **API Design Review**: As a group, look at a class one of you has written. Review the access specifiers. Are they appropriate? Is the public API clean and minimal?
-   **Modifier Debate**: Discuss the pros and cons of using `protected`. When is it a good idea, and when does it break encapsulation?

---

## 10. Domain-Specific Mastery Strategies

-   **Library Design**: If you are writing a library for other developers to use, the distinction between `public`, `protected`, and `private` is absolutely critical. The `public` members form your contract with your users.
-   **Framework Development**: Frameworks often use `protected` methods to allow developers to "hook into" the framework's lifecycle by subclassing and overriding specific behaviors.

---

## 11. Psychological and Cognitive Principles

-   **Information Hiding**: Access specifiers are the primary tool for information hiding. By hiding irrelevant details, you reduce the cognitive load on the developers who use your class. They only need to understand the public API, not the entire implementation.
-   **Reducing Errors**: By making data `private`, you prevent other parts of the code from putting the object into an invalid state, which makes the entire system more robust.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the purpose of `public`, `private`, and `protected`.
-   [ ] I use `private` for internal state to enforce encapsulation.
-   [ ] I use `public` for the methods that form the class's interface.
-   [ ] I understand that `protected` is for allowing access to subclasses.
-   [ ] I can explain that `static` members belong to the class, not the instance.
-   [ ] I can explain that `final`/`const` members cannot be changed.

---

## 13. Research and References

-   **Java Documentation - Controlling Access to Members of a Class**: [Link](https://docs.oracle.com/javase/tutorial/java/javaOO/accesscontrol.html)
-   **C# Documentation - Access Modifiers**: [Link](https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/access-modifiers)
-   **"Effective Java" by Joshua Bloch**: A book with excellent advice on API design and the proper use of access modifiers.
