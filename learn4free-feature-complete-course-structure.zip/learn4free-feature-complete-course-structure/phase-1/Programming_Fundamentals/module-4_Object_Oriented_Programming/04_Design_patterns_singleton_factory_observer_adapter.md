# Design Patterns (Singleton, Factory, Observer, Adapter)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** what a design pattern is and explain its purpose.
-   **Describe** the problem that the Singleton pattern solves and how it works.
-   **Describe** the problem that the Factory pattern solves and how it works.
-   **Describe** the problem that the Observer pattern solves and how it works.
-   **Describe** the problem that the Adapter pattern solves and how it works.
-   **Recognize** scenarios where these basic design patterns could be applied.

---

## 2. Introduction to Design Patterns

Design Patterns are reusable, well-documented solutions to commonly occurring problems within a given context in software design. They are not specific algorithms or pieces of code, but rather general concepts and templates that you can apply to your own applications. Learning design patterns helps you build on the collective experience of the software development community, leading to more flexible, maintainable, and robust code.

This module introduces four foundational patterns from the original "Gang of Four" (GoF) book on design patterns.

---

## 3. Core Concepts

### 1. Singleton Pattern

-   **Type**: Creational
-   **Problem**: You need to ensure that a class has **only one instance** and provide a single, global point of access to it.
-   **Solution**: The Singleton pattern makes the class itself responsible for managing its sole instance. The class has a private constructor to prevent direct instantiation and a static public method (e.g., `getInstance()`) that returns the single instance.
-   **Analogy**: A country's government. There can only be one official government.
-   **Use Case**: Logging objects, database connection pools, configuration managers.

### 2. Factory Pattern (Simple Factory)

-   **Type**: Creational
-   **Problem**: You need to create objects of different types, but you want to decouple the client code from the specific classes being instantiated. The client knows *when* it needs an object, but not *which* specific class to create.
-   **Solution**: The Factory pattern encapsulates the object creation logic in a separate "factory" class or method. The client calls the factory method with some parameters (e.g., a string), and the factory returns the appropriate object.
-   **Analogy**: A pizza restaurant. You (the client) tell the cashier (the factory) you want a "pepperoni" pizza. You don't need to know how to make it; the factory handles the creation and gives you back a pizza object.
-   **Use Case**: Creating different types of UI components, game characters, or documents.

### 3. Observer Pattern

-   **Type**: Behavioral
-   **Problem**: You have a "one-to-many" dependency between objects. When the state of one object (the "Subject" or "Observable") changes, all of its dependents (the "Observers") need to be notified and updated automatically.
-   **Solution**: The Subject object maintains a list of its Observers. When its state changes, it calls a specific method (e.g., `update()`) on each Observer in the list.
-   **Analogy**: A magazine subscription. The publisher (the Subject) doesn't need to know who its subscribers (the Observers) are. It just sends out a new magazine, and the postal service delivers it to everyone who is subscribed.
-   **Use Case**: Implementing event-driven systems. For example, in a Model-View-Controller (MVC) architecture, the View is an Observer of the Model. When the Model's data changes, the View is notified and updates itself.

### 4. Adapter Pattern

-   **Type**: Structural
-   **Problem**: You want to make two incompatible interfaces work together. You have a class that provides the functionality you need, but its interface doesn't match the one your client code expects.
-   **Solution**: The Adapter pattern acts as a bridge. You create an "adapter" class that wraps the original class (the "adaptee") and exposes an interface that the client can understand. The adapter translates calls from the client's interface into calls on the original adaptee's interface.
-   **Analogy**: A power plug adapter. Your European laptop plug doesn't fit into an American wall socket. The adapter sits in between, allowing them to work together.
-   **Use Case**: Making a third-party library work with your application's existing interface.

---

## 4. Deliberate Practice

1.  **Singleton**: Implement a simple `Logger` class as a Singleton.
2.  **Factory**: Create a `ShapeFactory` that can create `Circle`, `Square`, and `Rectangle` objects based on a string input.
3.  **Observer**:
    -   Create a `WeatherStation` (Subject) and a `PhoneDisplay` (Observer).
    -   When the `WeatherStation`'s temperature changes, the `PhoneDisplay` should be notified and print the new temperature.
4.  **Adapter**: Imagine you have a `NewFancyLibrary` with a method `makeRequest()`. Your existing application expects a class with a `send()` method. Write an `Adapter` class that wraps the new library.

---

## 5. Active Recall Questions

-   What is the main purpose of the Singleton pattern?
-   How does the Factory pattern promote loose coupling?
-   In the Observer pattern, which object holds the list of dependents: the Subject or the Observer?
-   What is the primary goal of the Adapter pattern?
-   Which pattern would you use to manage a single database connection for an entire application?

---

## 6. Tools, Frameworks, and Platforms

-   **Frameworks**: Most modern application frameworks are built on design patterns. For example, many UI frameworks (like the browser's DOM) use the Observer pattern extensively for event handling (`addEventListener`). Dependency Injection frameworks are a sophisticated form of the Factory pattern.

---

## 7. Feedback and Self-Assessment

-   **Identify Patterns in the Wild**: Look at the source code of a popular open-source library. Can you spot any of these design patterns being used?
-   **Problem First, Pattern Second**: Don't start with the goal of using a design pattern. Start with the problem you are trying to solve. A design pattern is a tool, not a goal in itself. "Pattern-itis" (overusing patterns) can lead to overly complex code.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A Document Editor
-   You have one `Document` object that multiple parts of the application need to access and modify. This is a good candidate for a **Singleton**.
-   The user can insert different types of objects (images, tables, charts) into the document. A **Factory** can be used to create these objects.
-   When the document is changed, the main window, the toolbar, and the spell checker all need to be notified to update themselves. This is a perfect use case for the **Observer** pattern.
-   The editor needs to import a document from an old, legacy format. You can write an **Adapter** that converts the old format into the one your editor understands.

---

## 9. Collaborative Activities

-   **Pattern Brainstorming**: As a group, pick a real-world software application (like a music player or a social media app) and brainstorm where these four patterns could be used in its design.
-   **Code Review for Patterns**: Review each other's practice implementations. Does the Singleton really prevent multiple instances? Does the Factory correctly hide the creation logic?

---

## 10. Domain-Specific Mastery Strategies

-   Design patterns are domain-agnostic. They are high-level solutions to common software engineering problems and are applicable in virtually every domain, from web development to embedded systems.

---

## 11. Psychological and Cognitive Principles

-   **Shared Vocabulary**: The most significant benefit of design patterns is that they provide a shared vocabulary for developers. When you say, "I'm using an Observer here," another developer who knows the pattern immediately understands the structure and intent of your code without needing to read every line.
-   **Chunking**: Patterns allow you to "chunk" a complex design into a single, well-understood concept, which makes it easier to reason about.

---

## 12. Summary and Mastery Checklist

-   [ ] **Singleton**: I can explain that this pattern ensures a class has only one instance.
-   [ ] **Factory**: I can explain that this pattern encapsulates object creation logic.
-   [ ] **Observer**: I can explain that this pattern is for notifying dependents when a state changes.
-   [ ] **Adapter**: I can explain that this pattern helps incompatible interfaces work together.
-   [ ] I understand that design patterns are general, reusable solutions to common problems.

---

## 13. Research and References

-   **"Design Patterns: Elements of Reusable Object-Oriented Software" by the "Gang of Four" (GoF)**: The original, canonical book on the topic. It is dense but foundational.
-   **"Head First Design Patterns" by Eric Freeman & Elisabeth Robson**: Widely considered the most accessible and fun introduction to design patterns.
-   **Refactoring Guru**: An excellent website with clear explanations, analogies, and code examples for a wide range of design patterns. [Link](https://refactoring.guru/design-patterns)
