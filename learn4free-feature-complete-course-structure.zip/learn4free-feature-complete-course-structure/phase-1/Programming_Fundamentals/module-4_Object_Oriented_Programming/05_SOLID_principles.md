# SOLID Principles

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** SOLID as a mnemonic acronym for five design principles.
-   **Explain** the Single Responsibility Principle (SRP).
-   **Explain** the Open/Closed Principle (OCP).
-   **Explain** the Liskov Substitution Principle (LSP).
-   **Explain** the Interface Segregation Principle (ISP).
-   **Explain** the Dependency Inversion Principle (DIP).
-   **Recognize** violations of these principles in code and suggest improvements.

---

## 2. Introduction to SOLID Principles

SOLID is an acronym that represents five fundamental principles of object-oriented design, introduced by Robert C. Martin ("Uncle Bob"). These principles, when applied together, make it more likely that a developer will create a system that is easy to maintain and extend over time. They are not laws, but rather guidelines that help you avoid common pitfalls and build more robust, scalable software. Adhering to SOLID principles is a key differentiator between a junior and a senior software engineer.

---

## 3. The Five Principles

### 1. S — Single Responsibility Principle (SRP)

-   **Principle**: A class should have only **one reason to change**.
-   **Explanation**: This means a class should have only one job or responsibility. If a class has more than one responsibility, the responsibilities become coupled. A change to one responsibility might force a change in the other.
-   **Example Violation**: A `User` class that not only stores user data but also handles database persistence and email notifications. This class has three reasons to change.
-   **Solution**: Separate these concerns into three different classes: a `User` class for data, a `UserRepository` for persistence, and an `EmailService` for notifications.

### 2. O — Open/Closed Principle (OCP)

-   **Principle**: Software entities (classes, modules, functions) should be **open for extension, but closed for modification**.
-   **Explanation**: You should be able to add new functionality to a system without changing existing, working code.
-   **Example Violation**: A function that calculates the total area of a list of shapes, using a giant `if/else if` block to check the type of each shape. To add a new shape, you have to modify this function.
-   **Solution**: Use polymorphism. Have a base `Shape` class with an `area()` method. Each specific shape (`Circle`, `Square`) inherits from `Shape` and implements its own `area()` method. The calculation function can then just call `shape.area()` on any shape, new or old.

### 3. L — Liskov Substitution Principle (LSP)

-   **Principle**: Subtypes must be **substitutable** for their base types.
-   **Explanation**: This means that if you have a piece of code that works with a base class, it should also work with any of its subclasses without any unexpected behavior. A subclass should not break the functionality of its parent class.
-   **Example Violation**: A classic (though debated) example is a `Rectangle` class with `setWidth` and `setHeight` methods. A `Square` class inherits from `Rectangle`. If you set the width of a `Square` to 5, it must also set its height to 5 to maintain its "squareness". This can lead to unexpected behavior in code that assumes setting the width doesn't change the height.
-   **Solution**: Ensure that subclasses only extend, and do not remove or fundamentally alter, the behavior of their parent classes.

### 4. I — Interface Segregation Principle (ISP)

-   **Principle**: Clients should not be forced to depend on interfaces they do not use.
-   **Explanation**: It's better to have many small, specific interfaces than one large, general-purpose interface.
-   **Example Violation**: A single `IWorker` interface with methods `work()` and `eat()`. A `HumanWorker` class can implement both. But a `RobotWorker` class is forced to implement the `eat()` method, which it doesn't need.
-   **Solution**: Split the large interface into two smaller ones: `IWorkable` and `IEatable`. Classes can then implement only the interfaces they need.

### 5. D — Dependency Inversion Principle (DIP)

-   **Principle**:
    1.  High-level modules should not depend on low-level modules. Both should depend on abstractions.
    2.  Abstractions should not depend on details. Details should depend on abstractions.
-   **Explanation**: This principle is about decoupling. Instead of `ClassA` directly creating and using `ClassB`, `ClassA` should depend on an `InterfaceB`, which `ClassB` then implements. This allows you to easily swap out `ClassB` for another implementation of `InterfaceB` without changing `ClassA`.
-   **Example Violation**: A `PasswordReminder` class that directly creates an instance of a `MySQLDatabase` class. The high-level `PasswordReminder` is directly dependent on the low-level `MySQLDatabase`.
-   **Solution**: The `PasswordReminder` should depend on a `IDatabaseConnection` interface. The `MySQLDatabase` class can then be one implementation of this interface, and it can be "injected" into the `PasswordReminder`. This is the core idea behind **Dependency Injection**.

---

## 4. Deliberate Practice

1.  **SRP**: Look at a class you've written previously. Does it have more than one responsibility? Refactor it into smaller, more focused classes.
2.  **OCP**: Refactor the `if/else if` shape example from the explanation into a solution that uses inheritance and polymorphism and is "open" to new shapes.
3.  **ISP**: Imagine you are designing interfaces for a document system. Would you have one giant `IDocument` interface, or smaller ones like `IPrintable`, `ISavable`, `ISpellCheckable`? Discuss the pros and cons.
4.  **DIP**: Take a class that creates its own dependency (e.g., `new MySQLDatabase()`). Refactor it to accept that dependency as an interface in its constructor (Dependency Injection).

---

## 5. Active Recall Questions

-   What does the "S" in SOLID stand for, and what does it mean?
-   How does the Open/Closed Principle relate to polymorphism?
-   The Liskov Substitution Principle is about the relationship between which types of classes?
-   What is the problem with "fat" interfaces? Which SOLID principle addresses this?
-   What is the main goal of the Dependency Inversion Principle?

---

## 6. Tools, Frameworks, and Platforms

-   **Linters and Static Analysis Tools**: Some static analysis tools can detect potential SOLID violations, such as overly complex classes (SRP violation) or unused interface methods (ISP violation).
-   **Dependency Injection Frameworks**: Frameworks like Spring (Java), NestJS (TypeScript), and ASP.NET Core are built around the Dependency Inversion Principle.

---

## 7. Feedback and Self-Assessment

-   **Code Reviews**: SOLID principles are a major focus of professional code reviews. When reviewing code, consciously ask: "Does this class have a single responsibility?", "Is this system open to extension?".
-   **"Why?" Analysis**: When a change to one part of your code forces you to make changes in many other, seemingly unrelated parts, it's often a sign of a SOLID principle violation. Ask "why" this ripple effect is happening.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: The evolution of a software system.
-   **Initial Version**: A simple system might violate many SOLID principles for the sake of speed and simplicity. This is often acceptable.
-   **Growth**: As the system grows, these violations start to cause problems. Changing one feature breaks another. Adding a new feature requires modifying many existing files. This is called "technical debt".
-   **Refactoring**: The process of refactoring the code to adhere more closely to SOLID principles can pay down this technical debt, making the system more stable and easier to work on in the long term.

This shows that SOLID principles are not just academic concepts; they are practical tools for managing the long-term health of a software project.

---

## 9. Collaborative Activities

-   **SOLID Scavenger Hunt**: As a group, look through a codebase and try to find one example that violates each of the five SOLID principles.
-   **Refactoring Session**: Pick one of the violations you found and work together to refactor the code to fix it.

---

## 10. Psychological and Cognitive Principles

-   **Future-Proofing**: The SOLID principles are a form of "future-proofing". They are based on the idea that the one constant in software is **change**. These principles help you write code that is more resilient to change.
-   **Decoupling**: A recurring theme in all of SOLID is **decoupling**—reducing the dependencies between different parts of a system. Decoupled systems are easier to understand, test, and maintain because you can reason about each part in isolation.

---

## 11. Summary and Mastery Checklist

-   [ ] **S**: I can explain that a class should have one reason to change.
-   [ ] **O**: I can explain that code should be open for extension, closed for modification.
-   [ ] **L**: I can explain that a subclass must be substitutable for its parent class.
-   [ ] **I**: I can explain that it's better to have many small interfaces than one large one.
-   [ ] **D**: I can explain that code should depend on abstractions, not concrete implementations.

---

## 13. Research and References

-   **"Clean Architecture" by Robert C. Martin**: A book that expands on these principles and shows how to apply them to build robust, application-level architectures.
-   **YouTube - "SOLID Principles" by Uncle Bob**: The original author has many talks available online that are highly insightful.
-   **DigitalOcean - The SOLID Principles of OOD**: [Link](https://www.digitalocean.com/community/conceptual_articles/s-o-l-i-d-the-first-5-principles-of-object-oriented-design)
