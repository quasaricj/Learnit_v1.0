# Constructor Overloading and Method Overriding

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** method overloading and provide an example.
-   **Implement** constructor overloading to provide multiple ways to instantiate an object.
-   **Define** method overriding as it relates to inheritance.
-   **Implement** method overriding to change the behavior of a subclass.
-   **Differentiate** clearly between overloading and overriding.
-   **Understand** the use of keywords like `super` or `base` to call a parent class's method.

---

## 2. Introduction to Advanced OOP Techniques

Overloading and overriding are two important concepts in object-oriented programming that, despite their similar names, refer to very different things. Both are forms of polymorphism. **Overloading** allows a class to have multiple methods with the same name but different parameters, providing flexibility in how an object is created or used. **Overriding** allows a subclass to provide its own specific implementation of a method that is already defined in its superclass, allowing for more specialized behavior.

---

## 3. Core Concepts

### Method Overloading (Compile-Time Polymorphism)

**Overloading** is the ability to define multiple methods in the same class with the **same name** but with **different signatures**. The signature of a method includes the number, type, and order of its parameters. The return type is *not* part of the signature.

-   **Why it's useful**: It provides convenience and improves code readability. You can call the same method name with different types of arguments, and the correct implementation will be chosen by the compiler.
-   **Constructor Overloading**: This is a very common use case. A class can have multiple constructors to provide different ways of creating an object. One constructor might take no arguments and set default values, while another might take several arguments to initialize the object with specific data.

**Example (Java/C#)**:
```java
class Pizza {
    Pizza() { // Default constructor
        // ... create a plain cheese pizza
    }
    Pizza(String topping1) { // Overloaded constructor
        // ... create a pizza with one topping
    }
    Pizza(String topping1, String topping2) { // Overloaded constructor
        // ... create a pizza with two toppings
    }
}
```

### Method Overriding (Run-Time Polymorphism)

**Overriding** is a feature of inheritance. When a subclass provides its own implementation for a method that is already defined in its parent class, it is called method overriding. The method in the subclass must have the **exact same name, return type, and parameters** as the one in the parent class.

-   **Why it's useful**: It allows a subclass to provide a more specific or specialized behavior for a method that it inherits. This is a key part of polymorphism.
-   **`super` or `base` keyword**: Inside an overridden method, you can (and often should) call the parent class's version of the method using the `super` (in Java/Python) or `base` (in C#) keyword. This is useful for extending, rather than completely replacing, the parent's behavior.

**Example (Java/Python)**:
```python
class Animal:
    def make_sound(self):
        print("Some generic animal sound")

class Dog(Animal):
    def make_sound(self):  # Overriding the parent method
        print("Woof")

class Cat(Animal):
    def make_sound(self):  # Overriding the parent method
        super().make_sound() # Calling the parent's method first
        print("Meow")
```

### Overloading vs. Overriding

| Feature           | Overloading                               | Overriding                                  |
| ----------------- | ----------------------------------------- | ------------------------------------------- |
| **Purpose**       | Provide multiple ways to call a method    | Provide a specific implementation in a subclass |
| **Scope**         | Within the same class                     | In two classes with an inheritance relationship |
| **Method Name**   | Must be the same                          | Must be the same                            |
| **Parameters**    | Must be **different**                     | Must be the **same**                        |
| **Relationship**  | Not related to inheritance                | Is a core feature of inheritance            |
| **Polymorphism**  | Compile-Time (Static)                     | Run-Time (Dynamic)                          |

---

## 4. Deliberate Practice

1.  **Overloaded Calculator**: Create a `Calculator` class with an `add` method that is overloaded to work with two integers, three integers, and two doubles.
2.  **Overloaded Constructors**: Create a `User` class.
    -   A default constructor that creates a "guest" user.
    -   A constructor that takes a `username`.
    -   A constructor that takes a `username` and an `email`.
3.  **Overriding `toString()`**: Most base `Object` classes have a `toString()` (or `__str__` in Python) method. In a class you've created (like `Dog` or `User`), override this method to return a custom, formatted string that describes the object.
4.  **`super` in Action**: Create a `Manager` class that inherits from an `Employee` class. Override the `calculatePay()` method in `Manager` to first call the `super.calculatePay()` method and then add a bonus to the result.

---

## 5. Active Recall Questions

-   What is the key difference in the method signatures between an overloaded method and an overridden one?
-   Which concept, overloading or overriding, is related to inheritance?
-   What is the purpose of constructor overloading?
-   What does the `super` keyword do?
-   Is it possible to overload a method based on a different return type? (No).

---

## 6. Tools, Frameworks, and Platforms

-   **IDE**: A good IDE will help you with overriding. It can automatically generate the method stub for you when you ask to override a parent class method, and it will often place an annotation (like `@Override` in Java) to make it clear.
-   **Compiler**: The compiler is what resolves overloaded method calls (compile-time polymorphism). It will give you an error if you try to override a method with a different signature.

---

## 7. Feedback and Self-Assessment

-   **Intent**: When you are writing a method, ask yourself: "Am I trying to provide a different way to call this method (overloading), or am I trying to change its behavior in a subclass (overriding)?".
-   **Liskov Substitution Principle**: Proper method overriding is essential for adhering to the Liskov Substitution Principle. The overridden method in the subclass should be compatible with the parent method's contract.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A GUI Framework
-   A base `Button` class has a `draw()` method that draws a simple gray rectangle.
-   An `ImageButton` subclass inherits from `Button`. It **overrides** the `draw()` method to draw an image instead of a gray box.
-   An `IconButton` subclass also inherits from `Button`. It **overrides** `draw()` to first call `super.draw()` to draw the gray box, and then draws an icon on top of it.
-   The `Button` class might have **overloaded** constructors: one that takes just text, and another that takes text and an icon.

This shows how both concepts work together in a real-world scenario to create a flexible and extensible system.

---

## 9. Collaborative Activities

-   **Code Puzzle**: Create a small piece of code with a superclass and a subclass, and then call an overridden method. Have your peers predict the exact output.
-   **Design Discussion**: Discuss when you would choose to overload a constructor versus using a separate "builder" or "factory" pattern.

---

## 11. Psychological and Cognitive Principles

-   **Don't Confuse Them**: The similar names are a common source of confusion for beginners. It's helpful to create a mnemonic or a strong mental anchor. For example: "Over**R**iding is **R**eplacing in a subclass. Over**L**oading is just a **L**onger parameter list."
-   **Context is Key**: Understanding these concepts depends on understanding the context. Overloading happens in one class. Overriding happens across a parent-child class relationship.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that **overloading** is multiple methods with the same name but different parameters in the **same class**.
-   [ ] I can explain that **overriding** is a subclass providing its own version of a method from its **parent class**.
-   [ ] I can use constructor overloading to create objects in multiple ways.
-   [ ] I can override a method to provide specialized behavior in a subclass.
-   [ ] I know how to use `super` or `base` to call the parent's implementation of a method.

---

## 13. Research and References

-   **GeeksforGeeks - Overloading and Overriding**: [Link](https://www.geeksforgeeks.org/overloading-and-overriding-in-java/) (Examples are in Java, but the concepts are universal).
-   **"Head First Java" by Kathy Sierra & Bert Bates**: Has excellent, visual explanations of these concepts.
