# Practical Project: Task Management CLI Application

## 1. Project Goal

To build a command-line interface (CLI) application for managing a to-do list. This project will integrate many of the core programming concepts from Module 1.1, including variables, control structures, functions, and file I/O for data persistence.

---

## 2. Learning Objectives (Project-Based)

This project is designed to solidify your understanding of the following concepts through practical application:

-   **Core Programming Concepts**: Variables, data types, control flow, functions.
-   **User Input**: Reading and parsing input from the command line.
-   **Data Persistence**: Saving the task list to a file (e.g., `.txt`, `.csv`, or `.json`) and loading it back when the application starts.
-   **Error Handling**: Gracefully handling invalid user input and file I/O errors.
-   **Modular Code**: Organizing your code into well-defined functions.

---

## 3. Core Features (Minimum Viable Product)

Your task management application should support the following commands:

1.  **`add <task description>`**: Adds a new task to the list.
    -   Each task should have a unique ID, a description, and a "pending" status.
2.  **`list`**: Displays all the tasks in the list, showing their ID, description, and status.
3.  **`done <task ID>`**: Marks a specific task as "completed".
4.  **`remove <task ID>`**: Deletes a task from the list.
5.  **`help`**: Displays a list of all available commands.
6.  **`exit`**: Exits the application, ensuring the current list of tasks is saved to a file.

---

## 4. Step-by-Step Implementation Guide

### Step 1: Basic Setup

-   Set up your project structure.
-   Create a main function or entry point for your application.
-   Implement a main loop (e.g., a `while` loop) that continuously prompts the user for a command.

### Step 2: In-Memory Task Management

-   Decide on a data structure to store your tasks in memory. A list of objects or dictionaries is a good choice.
-   Implement the `add` and `list` commands first. Don't worry about file persistence yet.
-   Implement the `done` and `remove` commands.

### Step 3: Command Parsing

-   Write a function that takes the user's raw input string and parses it into a command and its arguments (e.g., the input `"add Finish the project"` should be parsed into `command="add"` and `arguments="Finish the project"`).

### Step 4: Data Persistence

-   Choose a file format for saving your tasks. JSON is a great choice as it's human-readable and maps well to objects.
-   Implement a `save_tasks_to_file()` function.
-   Implement a `load_tasks_from_file()` function that is called when the application starts.
-   Ensure the `save_tasks_to_file()` function is called whenever the task list is modified (or at least when the user exits).

### Step 5: Error Handling

-   Add checks for invalid commands.
-   Handle cases where the user provides an invalid task ID for the `done` or `remove` commands.
-   Wrap your file I/O operations in `try...catch` blocks to handle potential errors like the file not being found.

---

## 5. Deliberate Practice and Mastery Checklist

-   [ ] The application correctly adds new tasks.
-   [ ] The application correctly lists all tasks with their status.
-   [ ] The application can mark a task as complete.
-   [ ] The application can remove a task.
-   [ ] The task list is successfully saved to a file when the application exits.
-   [ ] The task list is successfully loaded from the file when the application starts.
-   [ ] The application handles invalid user commands and arguments gracefully.
-   [ ] The code is organized into clear, single-responsibility functions.

---

## 6. Potential Extensions (Going Further)

Once you have the core features working, you can extend the project to practice more advanced concepts:

-   **Edit Tasks**: Add an `edit <task ID> <new description>` command.
-   **Priority Levels**: Add a priority level (e.g., low, medium, high) to each task.
-   **Due Dates**: Add the ability to set a due date for a task. Modify the `list` command to show tasks that are overdue.
-   **Sorting and Filtering**: Add options to the `list` command to sort tasks by priority or filter by status (e.g., `list --status completed`).
-   **Better Data Format**: Use a more robust format like SQLite for storage instead of a plain text or JSON file.

---

## 7. Tools and Resources

-   **Your Chosen Programming Language**: Python, JavaScript (Node.js), Java, C#, and Go are all excellent choices for this project.
-   **File Format Libraries**:
    -   Python: `json` or `csv` module.
    -   JavaScript: `JSON.parse()` and `JSON.stringify()`.
-   **Command-Line Argument Parsers**: For a more advanced CLI, you can use libraries like `argparse` (Python) or `yargs` (Node.js) to handle commands and arguments, but for the basic version, simple string splitting is sufficient.
