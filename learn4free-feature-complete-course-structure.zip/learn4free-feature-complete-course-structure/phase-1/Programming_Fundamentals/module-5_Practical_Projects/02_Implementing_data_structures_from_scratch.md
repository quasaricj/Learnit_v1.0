# Practical Project: Implementing Data Structures from Scratch

## 1. Project Goal

To deepen your understanding of how fundamental data structures work by implementing them from scratch, without relying on built-in libraries. This project will challenge you to apply your knowledge of core programming concepts, especially classes, pointers (or references), and memory management.

---

## 2. Learning Objectives (Project-Based)

This project is designed to solidify your understanding of the following concepts through practical application:

-   **Data Structures**: Gain a deep, "under the hood" understanding of linked lists, stacks, and queues.
-   **Object-Oriented Programming**: Use classes (`Node`, `LinkedList`, etc.) to model the structure and behavior of each data structure.
-   **Pointers/References**: Master the manipulation of references to link nodes together.
-   **Algorithmic Thinking**: Implement the logic for insertion, deletion, and traversal.
-   **Testing**: Write test cases to ensure your implementations are correct and handle edge cases.

---

## 3. Core Requirements

You are to implement the following data structures from scratch. You should only use basic language primitives (arrays for the underlying structure of a stack/queue if you choose, but not for the linked list).

### 1. Singly Linked List

-   Create a `Node` class with `data` and `next` attributes.
-   Create a `LinkedList` class.
-   **Methods to implement**:
    -   `insert_at_head(data)`
    -   `insert_at_tail(data)`
    -   `delete(data)`
    -   `search(data)`
    -   `is_empty()`
    -   `print_list()`

### 2. Stack (using your Linked List)

-   Create a `Stack` class.
-   **This class should use your `LinkedList` as its underlying storage.** This is a key requirement.
-   **Methods to implement**:
    -   `push(data)` (should use `insert_at_head` on your linked list)
    -   `pop()` (should remove the head from your linked list)
    -   `peek()` (should return the head's data without removing it)
    -   `is_empty()`

### 3. Queue (using your Linked List)

-   Create a `Queue` class.
-   **This class should also use your `LinkedList` as its underlying storage.**
-   **Methods to implement**:
    -   `enqueue(data)` (should use `insert_at_tail` on your linked list)
    -   `dequeue()` (should remove the head from your linked list)
    -   `front()` (should return the head's data without removing it)
    -   `is_empty()`

---

## 4. Step-by-Step Implementation Guide

### Step 1: The `Node` and `LinkedList`

-   Start by creating the `Node` class. This is the simplest piece.
-   Next, create the `LinkedList` class. Implement one method at a time, testing as you go.
-   **Crucially, draw the nodes and pointers on a whiteboard or paper** as you write the code for each method. This is the best way to avoid pointer errors.
-   Pay special attention to edge cases: an empty list, a list with one node, inserting/deleting at the head vs. the tail.

### Step 2: The `Stack`

-   Once your `LinkedList` is working and well-tested, the `Stack` should be relatively straightforward.
-   Instantiate a `LinkedList` object inside your `Stack`'s constructor.
-   The `Stack` methods will be simple "wrappers" that call the appropriate `LinkedList` methods. For example, `push` will call `insert_at_head`.

### Step 3: The `Queue`

-   This will be very similar to the `Stack`.
-   Instantiate a `LinkedList` object inside your `Queue`'s constructor.
-   Map the queue operations to the correct linked list methods. `enqueue` will call `insert_at_tail`, and `dequeue` will call a `delete_at_head` method (you may need to add this to your `LinkedList`).

### Step 4: Testing

-   For each data structure, write a separate test script.
-   Create instances, add data, remove data, and print the results to verify that everything is working as expected.
-   Example test for a stack: Push 3, 2, 1. Pop. The result should be 1. Peek. The result should be 2.

---

## 5. Deliberate Practice and Mastery Checklist

-   [ ] A `Node` class is correctly implemented.
-   [ ] The `LinkedList` class correctly handles insertion at the head and tail.
-   [ ] The `LinkedList` class correctly handles deletion and searching.
-   [ ] The `Stack` class is implemented using the `LinkedList` and correctly follows the LIFO principle.
-   [ ] The `Queue` class is implemented using the `LinkedList` and correctly follows the FIFO principle.
-   [ ] Edge cases (e.g., operating on an empty list) are handled gracefully.
-   [ ] The code is clean, well-commented, and organized into separate classes.

---

## 6. Potential Extensions (Going Further)

-   **Doubly Linked List**: Upgrade your `SinglyLinkedList` to a `DoublyLinkedList` with `previous` pointers.
-   **Generic Data**: If your language supports generics, make your data structures generic so they can hold any type of data, not just numbers or strings.
-   **Circular Linked List**: Modify your linked list so the tail's `next` pointer points back to the head.
-   **Array-Based Implementations**: As a separate exercise, try implementing the `Stack` and `Queue` using a fixed-size array as the underlying data structure. What are the trade-offs of this approach compared to the linked list approach?

---

## 7. Tools and Resources

-   **Your Chosen Programming Language** with a focus on its object-oriented features.
-   **A Whiteboard or Notebook**: Absolutely essential for visualizing the pointers.
-   **A Debugger**: Step through your insertion and deletion methods to watch the `next` pointers change in real-time. This is the best way to catch bugs.
