# Practical Project: Text-Based Adventure Game using OOP

## 1. Project Goal

To design and build a simple text-based adventure game (also known as interactive fiction). This project will heavily utilize the Object-Oriented Programming principles from Module 1.4 to create a structured, extensible, and maintainable game world.

---

## 2. Learning Objectives (Project-Based)

This project is designed to solidify your understanding of the following concepts through practical application:

-   **Object-Oriented Design**: Modeling a complex system (a game world) using classes and objects.
-   **The Four Pillars of OOP**:
    -   **Encapsulation**: Each class (`Player`, `Room`, `Item`) will manage its own state.
    -   **Abstraction**: Hiding the complexity of the game engine behind a simple command parser.
    -   **Inheritance**: Creating specialized types of rooms or items (e.g., a `MagicSword` that is a subclass of `Item`).
    -   **Polymorphism**: Treating different types of game objects in a uniform way.
-   **Class Relationships**: Managing the relationships between objects (e.g., a `Player` is in a `Room`, a `Room` contains `Items`).
-   **State Management**: Tracking the state of the game world and the player's progress.

---

## 3. Core Features (Minimum Viable Product)

Create a small game world with at least 4-5 interconnected rooms. The player should be able to:

1.  **Move between rooms**: Implement commands like `go north`, `go east`, `go south`, `go west`.
2.  **Look around**: A `look` command that describes the current room and any items or characters within it.
3.  **Manage an inventory**:
    -   A `take <item>` command to pick up an item from a room.
    -   A `drop <item>` command to leave an item in a room.
    -   An `inventory` command to see what items the player is carrying.
4.  **Interact with items**: A simple `use <item>` command.
5.  **A Goal**: There should be a simple goal, such as finding a specific item and using it in a specific location to "win" the game.

---

## 4. Step-by-Step Implementation Guide

### Step 1: Design Your Classes (The World Model)

Before writing code, design your core classes on paper or a whiteboard. You will likely need:

-   `Player`:
    -   Attributes: `current_room`, `inventory`.
    -   Methods: `move()`, `take_item()`, `drop_item()`.
-   `Room`:
    -   Attributes: `name`, `description`, `exits` (a dictionary mapping directions to other `Room` objects), `items` (a list of `Item` objects).
    -   Methods: `get_description()`.
-   `Item`:
    -   Attributes: `name`, `description`.
    -   Methods: `on_take()`, `on_use()`.
-   `Game`:
    -   The main class that runs the game loop, parses user input, and manages the overall game state.

### Step 2: Build the World

-   Implement the `Room` and `Item` classes first.
-   In your main `Game` class, create instances of your `Room` objects.
-   "Link" the rooms together by setting their `exits`. For example: `room1.exits['north'] = room2` and `room2.exits['south'] = room1`.
-   Place some `Item` objects into the rooms.

### Step 3: Implement the Player and the Game Loop

-   Implement the `Player` class.
-   Implement the main game loop in your `Game` class. This loop should:
    1.  Print the description of the player's current room.
    2.  Prompt the user for input.
    3.  Parse the input into a command and arguments (e.g., `go north` -> command=`go`, argument=`north`).
    4.  Call the appropriate methods on your `Player` or `Game` objects based on the command.
    5.  Repeat.

### Step 4: Implement Game Logic

-   Flesh out the methods for moving, taking, dropping, and using items.
-   The `Player.move()` method, for example, should check if an exit exists in the given direction in the `current_room`. If it does, it should update the `player.current_room` to the new room.
-   Define a "win" condition and check for it at the end of each loop.

---

## 5. Deliberate Practice and Mastery Checklist

-   [ ] The game world is modeled using distinct classes for `Player`, `Room`, and `Item`.
-   [ ] The player can move between interconnected rooms.
-   [ ] The `look` command provides a proper description of the room and its contents.
-   [ ] The player can pick up and drop items, which are moved between the room and the player's inventory.
-   [ ] A simple win condition is implemented and can be achieved.
-   [ ] The code is well-structured, with each class having a clear, single responsibility (SRP).
-   [ ] The game handles invalid commands gracefully.

---

## 6. Potential Extensions (Going Further)

-   **Inheritance and Polymorphism**:
    -   Create a `Food` subclass of `Item` that can be eaten.
    -   Create a `Weapon` subclass of `Item` that can be used to fight.
    -   Create a `LockedRoom` subclass of `Room` that requires a specific `Key` (another `Item` subclass) to enter.
-   **Characters**: Add `Character` or `NPC` (Non-Player Character) classes. Give them dialogue and the ability to hold items.
-   **Puzzles**: Implement more complex puzzles that require using specific items in specific rooms.
-   **Combat**: Implement a simple combat system.
-   **Load/Save Game**: Use your file I/O skills to implement a feature to save and load the game state.

---

## 7. Tools and Resources

-   **Your Chosen Programming Language**: Any language with strong OOP support is great. Python is a particularly popular choice for interactive fiction.
-   **A Design Document**: A simple text file where you plan out your game's map, items, and puzzles before you start coding.
-   **Graph Paper or a Whiteboard**: For mapping out your rooms and their connections.
