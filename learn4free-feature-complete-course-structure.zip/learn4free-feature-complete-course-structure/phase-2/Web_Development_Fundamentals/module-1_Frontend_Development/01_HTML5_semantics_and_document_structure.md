# HTML5 Semantics and Document Structure

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** the purpose of HTML and its role as the structure layer of the web.
- **Differentiate** between semantic and non-semantic HTML elements.
- **Structure** a web page using modern semantic HTML5 tags like `<header>`, `<footer>`, `<nav>`, `<main>`, `<article>`, and `<section>`.
- **Write** a well-formed and valid HTML document.
- **Understand** the importance of a logical document outline for accessibility and SEO.

---

## 2. Introduction to HTML5 and Semantics

**HTML (HyperText Markup Language)** is the standard language for creating web pages. It provides the fundamental **structure** of a page, which is then styled with CSS and made interactive with JavaScript. **HTML5** is the latest version, which introduced a host of new features, most notably a richer set of **semantic elements**.

A semantic element clearly describes its meaning to both the browser and the developer. For example, `<nav>` indicates a block of navigation links, and `<article>` represents a self-contained piece of content. This is in contrast to non-semantic elements like `<div>` and `<span>`, which tell you nothing about their content.

---

## 3. Core Concepts

### The Basic HTML Document Structure

Every HTML document follows a basic structure:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>
</head>
<body>
    <!-- Page content goes here -->
</body>
</html>
```

- `<!DOCTYPE html>`: Declares the document type.
- `<html>`: The root element of the page.
- `<head>`: Contains meta-information about the page (title, character set, stylesheets, etc.).
- `<body>`: Contains the visible content of the page.

### Key HTML5 Semantic Elements

- **`<header>`**: Represents introductory content for a page or a section. Often contains a logo, navigation links, and a search bar.
- **`<nav>`**: Contains the main navigation links for the site.
- **`<main>`**: Represents the dominant, unique content of the document. There should only be one `<main>` element per page.
- **`<article>`**: Represents a self-contained piece of content that could be distributed independently (e.g., a blog post, a news story, a forum post).
- **`<section>`**: Represents a thematic grouping of content. It's a way to group related content together.
- **`<aside>`**: Represents content that is tangentially related to the main content, such as a sidebar or a call-out box.
- **`<footer>`**: Represents the footer for a page or section. Often contains copyright information, contact details, and links to related pages.
- **`<figure>` and `<figcaption>`**: Used to group an image, diagram, or code snippet with a caption.

---

## 4. Deliberate Practice

1.  **Structure a Blog Post**: Take a plain text blog post and mark it up with HTML5 semantic elements. Identify the `<header>`, `<article>`, `<section>`s for different parts of the post, and a `<footer>`.
2.  **Create a Page Layout**: Create an HTML file that lays out the structure of a typical website homepage using only semantic tags. Don't worry about styling.
3.  **Replace `div`s**: Look at an older website's source code (or your own past projects). Identify `div`s that could be replaced with more semantic HTML5 tags (e.g., `<div id="header">` can become `<header>`).
4.  **Validate Your HTML**: Use an online tool like the [W3C Markup Validation Service](https://validator.w3.org/) to check if your HTML is well-formed and valid.

---

## 5. Active Recall Questions

- What is the difference between a semantic and a non-semantic element?
- What is the purpose of the `<main>` tag?
- When would you use `<article>` vs. `<section>`?
- What kind of content goes in the `<head>` of an HTML document?
- Why is using semantic HTML important for accessibility?

---

## 6. Tools, Frameworks, and Platforms

-   **Web Browser**: The ultimate tool for viewing your HTML. Use the "View Page Source" and "Inspect Element" features in your browser's developer tools.
-   **Code Editor**: A good code editor like VS Code with HTML boilerplate generators and syntax highlighting is essential.
-   **HTML Validator**: The [W3C Validator](https://validator.w3.org/) is the official tool for checking your markup.

---

## 7. Feedback and Self-Assessment

-   **Document Outline**: Use browser extensions (like "HTML5 Outliner" for Chrome) to view the document outline created by your semantic tags. Does it make logical sense?
-   **Accessibility Check**: Tools like Lighthouse in Chrome DevTools can audit your page for accessibility. Proper use of semantic HTML is a major factor in the accessibility score.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A news website's homepage.
- The entire page might be wrapped in a layout.
- The `<header>` would contain the newspaper's masthead and main navigation (`<nav>`).
- The `<main>` section would contain a series of `<article>`s, one for each news story.
- Within an `<article>`, you might have `<section>`s for the introduction and the main body.
- A sidebar with links to related stories would be an `<aside>`.
- The `<footer>` would have contact information and copyright.

This shows how these elements can be nested to create a rich, meaningful document structure.

---

## 9. Collaborative Activities

-   **Peer Code Review**: Swap your "Blog Post" practice exercise with a partner. Does their use of semantic tags make sense? Can you suggest any improvements?
-   **"Div" Police**: As a group, look at a website and identify all the places where a `<div>` is used. Debate whether a more semantic tag could have been used instead.

---

## 10. Summary and Mastery Checklist

-   [ ] I can write a basic, valid HTML5 document from scratch.
-   [ ] I can explain the purpose of at least five different semantic HTML5 tags.
-   [ ] I can structure a web page using `<header>`, `<nav>`, `<main>`, and `<footer>`.
-   [ ] I understand that semantic tags improve accessibility and SEO.
-   [ ] I know the difference between `<article>` and `<section>`.

---

## 11. Research and References

-   **MDN Web Docs - HTML basics**: [Link](https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/HTML_basics)
-   **HTML5 Doctor**: A great resource for understanding the nuances of different semantic elements. [Link](http://html5doctor.com/)
-   **"HTML and CSS: Design and Build Websites" by Jon Duckett**: A beautifully designed and highly recommended book for beginners.