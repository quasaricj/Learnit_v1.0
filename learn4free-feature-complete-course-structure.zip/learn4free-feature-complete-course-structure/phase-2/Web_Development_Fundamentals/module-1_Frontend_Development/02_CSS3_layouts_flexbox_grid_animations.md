# CSS3: Layouts, Flexbox, Grid, and Animations

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** the role of CSS and how it applies styles to HTML.
- **Differentiate** between the three ways to include CSS: external, internal, and inline.
- **Understand** the CSS box model (content, padding, border, margin).
- **Create** complex page layouts using modern CSS techniques like Flexbox and Grid.
- **Implement** CSS animations and transitions to create engaging user interfaces.
- **Write** responsive CSS using media queries.

---

## 2. Introduction to CSS3

**CSS (Cascading Style Sheets)** is the language used to describe the presentation and styling of a document written in HTML. It controls the colors, fonts, spacing, and layout of your web pages. **CSS3** is the latest evolution of the CSS specification, and it introduced powerful new features for layout, such as **Flexbox** and **Grid**, as well as capabilities for **animations** and **transitions**.

---

## 3. Core Concepts

### Linking CSS to HTML

1.  **External Stylesheet**: The best practice. CSS is in a separate `.css` file, linked in the HTML `<head>`:
    `<link rel="stylesheet" href="styles.css">`
2.  **Internal Stylesheet**: CSS is inside a `<style>` tag in the HTML `<head>`.
3.  **Inline Styles**: CSS is applied directly to an HTML element using the `style` attribute. This is generally discouraged.

### The Box Model

Every element on a page is a rectangular box. The box model describes the layers of this box:
- **Content**: The text, image, or other content inside the element.
- **Padding**: The space between the content and the border.
- **Border**: A line that goes around the padding and content.
- **Margin**: The space outside the border, separating the element from other elements.

### Layout with Flexbox

**Flexbox (Flexible Box Layout)** is a one-dimensional layout model designed for distributing space among items in an interface.
- **Key Concepts**: It works with a `flex container` and `flex items`. You can control alignment, direction (row or column), and order.
- **Use Case**: Perfect for component-level layouts like aligning items in a navigation bar, centering content, or creating rows of cards.

### Layout with Grid

**CSS Grid Layout** is a two-dimensional layout system, meaning it can handle both columns and rows simultaneously.
- **Key Concepts**: It allows you to define a grid with rows and columns and then place items precisely into that grid.
- **Use Case**: Ideal for overall page layouts, such as creating a traditional header, sidebar, main content, and footer structure.

### Transitions and Animations

- **Transitions**: Allow you to smoothly change property values over a given duration. For example, you can make a button's color change gradually when the user hovers over it.
- **Animations**: Allow you to create more complex, multi-step animations using `@keyframes`. You can control the state of an element at various points during the animation.

### Responsive Design

**Responsive web design** is the practice of building web pages that look good on all devices (desktops, tablets, and phones). The primary tool for this is the **media query**.

- **Media Queries**: A feature of CSS that allows you to apply styles only when certain conditions are met, such as the screen being a certain width.
  ```css
  @media (max-width: 600px) {
    /* Styles for screens 600px or smaller */
  }
  ```

---

## 4. Deliberate Practice

1.  **Style Your Blog Post**: Take the semantic HTML blog post you created in the previous module and apply CSS to style it. Define fonts, colors, and spacing.
2.  **Flexbox Nav Bar**: Create a horizontal navigation bar using an unordered list (`<ul>`) and Flexbox to align the items.
3.  **Grid Page Layout**: Create a classic "holy grail" page layout (header, left sidebar, main content, right sidebar, footer) using CSS Grid.
4.  **Button Hover Effect**: Create a button that uses a CSS transition to smoothly change its background color and grow slightly when the user hovers their mouse over it.

---

## 5. Active Recall Questions

- What are the four components of the CSS box model?
- What is the main difference between Flexbox and Grid?
- What is the purpose of a media query?
- What is the difference between a CSS transition and a CSS animation?
- Which method of including CSS is considered the best practice?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Developer Tools**: The "Elements" or "Inspector" panel is your best friend for debugging CSS. You can see which styles are being applied to an element, experiment with changes in real-time, and visualize the box model.
-   **Can I Use...**: A website that shows which CSS features are supported by which browsers. [Link](https://caniuse.com/)
-   **Flexbox Froggy**: A fun, interactive game for learning Flexbox. [Link](https://flexboxfroggy.com/)
-   **CSS Grid Garden**: A game for learning CSS Grid. [Link](https://cssgridgarden.com/)

---

## 7. Feedback and Self-Assessment

-   **Test on Different Devices**: Use your browser's "Device Mode" to see how your layout looks on different screen sizes. Does it adapt correctly?
-   **Refactor**: Is your CSS "DRY" (Don't Repeat Yourself)? If you are writing the same styles over and over, can you combine them into a reusable class?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A responsive card-based layout.
-   On a large desktop screen, you want to display a 3-column grid of product cards.
-   On a tablet, you want it to switch to a 2-column grid.
-   On a mobile phone, you want it to stack into a single column.
-   This can be achieved with CSS Grid and media queries. The grid layout can be defined with "repeat(auto-fit, minmax(300px, 1fr))", which automatically handles wrapping, or you can use media queries to set the number of columns explicitly.

---

## 9. Collaborative Activities

-   **CSS Battle**: Websites like [CSS Battle](https://cssbattle.dev/) challenge you to recreate a target image using the smallest amount of CSS possible. This is a fun way to practice and learn new tricks.
-   **Component Styling**: One person builds the HTML for a component (like a comment card), and the other person styles it with CSS.

---

## 10. Summary and Mastery Checklist

-   [ ] I can link an external CSS file to an HTML document.
-   [ ] I can explain the difference between margin, border, and padding.
-   [ ] I can use Flexbox to align items in a container.
-   [ ] I can use CSS Grid to create a page layout.
-   [ ] I can use a media query to apply different styles for mobile devices.
-   [ ] I can create a simple hover effect using a CSS transition.

---

## 11. Research and References

-   **MDN Web Docs - CSS: Cascading Style Sheets**: [Link](https://developer.mozilla.org/en-US/docs/Web/CSS)
-   **CSS-Tricks**: An indispensable resource for all things CSS, especially their guides on Flexbox and Grid.
    -   [A Complete Guide to Flexbox](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
    -   [A Complete Guide to Grid](https://css-tricks.com/snippets/css/complete-guide-grid/)
-   **"HTML and CSS: Design and Build Websites" by Jon Duckett**
