# Responsive Web Design and Mobile-First Approach

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** responsive web design (RWD) and explain its importance.
- **Explain** the "mobile-first" design philosophy.
- **Implement** the three key technical components of RWD: fluid grids, flexible images, and media queries.
- **Use** the viewport meta tag correctly.
- **Differentiate** between px, em, rem, and viewport units (vw, vh).
- **Develop** a layout that adapts seamlessly to different screen sizes.

---

## 2. Introduction to Responsive Web Design

In the early days of the web, sites were designed for a single screen size: the desktop monitor. Today, users access the web on a vast array of devices with different screen sizes, from tiny smartwatches to massive TVs. **Responsive Web Design (RWD)** is an approach that allows a website's layout to adapt to the size of the user's screen, providing an optimal viewing experience for everyone.

The **mobile-first** approach is a core philosophy of modern RWD. It means you design for the smallest screen first (the mobile layout) and then add complexity and enhancements as the screen real estate increases. This forces you to prioritize content and results in a cleaner, more performant experience for all users.

---

## 3. Core Concepts

### The Three Pillars of RWD

1.  **Fluid Grids**:
    - Instead of using fixed-width units like pixels (`px`) for your layout containers, you use relative units like percentages (`%`).
    - This allows your layout to stretch and shrink fluidly with the browser window.
    - CSS Grid and Flexbox are inherently fluid and are the modern tools for creating these grids.

2.  **Flexible Images and Media**:
    - By default, a large image will not shrink to fit a smaller container.
    - To make images responsive, you use the following CSS:
      ```css
      img, video {
        max-width: 100%;
        height: auto;
      }
      ```
    - This ensures that the image will never be wider than its container, but it will scale down proportionally.

3.  **Media Queries**:
    - Media queries are the CSS feature that allows you to apply styles based on the characteristics of the device, most commonly the viewport width.
    - They are the key to making a design truly responsive, as you can change the layout, font sizes, and even hide or show elements at different "breakpoints".
      ```css
      /* Base styles (mobile-first) */
      .container { width: 95%; }

      /* Styles for tablets and larger */
      @media (min-width: 768px) {
        .container { width: 80%; }
      }
      ```

### The Viewport Meta Tag

This is a critical piece of HTML that must be included in the `<head>` of any responsive site.

`<meta name="viewport" content="width=device-width, initial-scale=1.0">`

- `width=device-width`: This tells the browser to set the width of the viewport to the width of the device's screen.
- `initial-scale=1.0`: This sets the initial zoom level when the page is first loaded.

Without this tag, mobile browsers will "lie" about their width and try to render the page as if it were on a desktop, resulting in a tiny, zoomed-out view.

### Relative CSS Units

- **`em`**: Relative to the font-size of the parent element.
- **`rem` (root em)**: Relative to the font-size of the root (`<html>`) element. This is generally preferred over `em` for consistent sizing.
- **`vw` (viewport width)**: A percentage of the viewport's width. `10vw` is 10% of the viewport width.
- **`vh` (viewport height)**: A percentage of the viewport's height.

Using relative units for fonts and spacing can help create more fluid and scalable designs.

---

## 4. Deliberate Practice

1.  **Make Your Layout Responsive**: Take the CSS Grid layout you created in the previous module. Use media queries to make it adapt:
    - On mobile, the sidebars should stack below the main content.
    - On a tablet, it should have one sidebar.
    - On a desktop, it should have two sidebars.
2.  **Mobile-First CSS**: Create a simple component (like a product card) using the mobile-first approach. Write the base CSS for the mobile layout first. Then, add a media query to apply styles for larger screens (e.g., placing the image and text side-by-side instead of stacked).
3.  **Fluid Typography**: Experiment with using `rem` for font sizes and `vw` for a large headline to see how they scale with the browser window.

---

## 5. Active Recall Questions

- What are the three technical components of responsive web design?
- What is the purpose of the viewport meta tag?
- Explain the "mobile-first" approach. Why is it beneficial?
- What is the difference between `em` and `rem` units?
- What CSS property makes an image flexible?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Developer Tools**: The "Device Mode" or "Responsive Design Mode" in Chrome, Firefox, and Safari is essential for testing your design on different screen sizes without needing physical devices.
-   **CSS Frameworks**: Frameworks like Bootstrap and Tailwind CSS are built with a mobile-first, responsive grid system, which can save a lot of development time. It's important to understand the underlying principles of RWD before relying on a framework.

---

## 7. Feedback and Self-Assessment

-   **Real Device Testing**: While browser emulation is good, always try to test your site on a real mobile device. The feel of the layout, touch target sizes, and performance can be very different.
-   **Content Prioritization**: Look at your mobile design. Is the most important content visible and easy to access? The mobile-first approach forces you to make these important content strategy decisions.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A complex data table.
- Data tables are notoriously difficult to make responsive. On a desktop, you have plenty of space for many columns. On a mobile phone, this is impossible.
- **Responsive Strategy**:
  1.  **Mobile-first**: On mobile, you might display only the 2-3 most important columns.
  2.  **Progressive Enhancement**: As the screen gets wider, you can use media queries to reveal more columns.
  3.  **Alternative Approach**: Another common pattern is to reflow the table on mobile, so that each row becomes a "card" with the column headers and values listed vertically. This requires more complex CSS but provides a better user experience.

---

## 9. Collaborative Activities

-   **Responsive Bug Bash**: Take an existing website and test it at different screen sizes as a group. Identify and document any responsive design bugs (e.g., text overflowing, elements overlapping).
-   **Component Challenge**: One person designs a mobile view of a component, and another person is responsible for writing the CSS and media queries to make it work on desktop.

---

## 10. Summary and Mastery Checklist

-   [ ] I can explain the benefits of the mobile-first design approach.
-   [ ] I always include the viewport meta tag in my HTML.
-   [ ] I can use percentages or CSS Grid/Flexbox to create a fluid grid.
-   [ ] I can use `max-width: 100%` to make images responsive.
-   [ ] I can write a media query to change a layout at a specific breakpoint.

---

## 11. Research and References

-   **"Responsive Web Design" by Ethan Marcotte**: The original book that defined the field.
-   **MDN Web Docs - Responsive design**: [Link](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)
-   **Google's Web Fundamentals - Responsive Web Design Basics**: [Link](https://developers.google.com/web/fundamentals/design-and-ux/responsive)
-   **A List Apart**: The online magazine where Ethan Marcotte first published his seminal article on RWD. [Link](https://alistapart.com/article/responsive-web-design/)
