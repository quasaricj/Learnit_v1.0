# JavaScript Fundamentals and ES6+ Features

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** the role of JavaScript as the behavior layer of the web.
- **Declare** variables using `var`, `let`, and `const`, and explain their differences.
- **Work with** core JavaScript data types (String, Number, Boolean, Array, Object).
- **Write** functions, including arrow functions.
- **Understand** and use modern ES6+ features like template literals, destructuring, and the spread/rest operators.
- **Grasp** the basics of asynchronous JavaScript with Promises and `async/await`.

---

## 2. Introduction to JavaScript

JavaScript is the programming language of the web. While HTML provides the structure and CSS provides the styling, JavaScript adds **interactivity and behavior** to a web page. It allows you to create dynamically updating content, control multimedia, animate images, and much more.

**ES6 (ECMAScript 2015)** was a major update to the language that introduced a host of new features and syntax improvements, making the language more powerful and easier to work with. Most modern JavaScript code is written using ES6+ features.

---

## 3. Core Concepts

### Variables and Scope

- **`var`**: The old way of declaring variables. It is function-scoped and can have some confusing behavior (like hoisting). It is generally avoided in modern JavaScript.
- **`let`**: The modern way to declare a variable that can be reassigned. It is block-scoped (`{}`).
- **`const`**: The modern way to declare a variable that cannot be reassigned (a constant). It is also block-scoped.

### Functions

- **Function Declaration**: The classic way to define a function.
  ```javascript
  function add(a, b) {
    return a + b;
  }
  ```
- **Arrow Functions (ES6)**: A more concise syntax for writing functions.
  ```javascript
  const add = (a, b) => {
    return a + b;
  };
  // Or even more concisely:
  const add = (a, b) => a + b;
  ```

### Key ES6+ Features

- **Template Literals**: A better way to create strings, allowing for embedded expressions and multi-line strings.
  ```javascript
  const name = "World";
  const greeting = `Hello, ${name}!`; // Instead of "Hello, " + name + "!"
  ```
- **Destructuring**: A shorthand for extracting values from arrays or objects.
  ```javascript
  // Object destructuring
  const person = { name: "Alice", age: 30 };
  const { name, age } = person; // Extracts name and age into variables

  // Array destructuring
  const [first, second] = [1, 2, 3]; // first = 1, second = 2
  ```
- **Spread Operator (`...`)**: Expands an iterable (like an array or object) into its individual elements.
  ```javascript
  const arr1 = [1, 2];
  const arr2 = [...arr1, 3, 4]; // arr2 is [1, 2, 3, 4]
  ```
- **Rest Operator (`...`)**: Collects multiple elements into a single array. Often used in function parameters.
  ```javascript
  function sum(...numbers) { // Gathers all arguments into a 'numbers' array
    return numbers.reduce((acc, current) => acc + current, 0);
  }
  ```

### Asynchronous JavaScript

JavaScript in the browser is single-threaded, meaning it can only do one thing at a time. Asynchronous operations (like fetching data from a server) are crucial to prevent the user interface from freezing.

- **Promises**: An object that represents the eventual completion (or failure) of an asynchronous operation. A `Promise` can be in one of three states: pending, fulfilled, or rejected.
- **`async/await` (ES2017)**: A modern syntax that makes working with Promises much cleaner and easier to read. The `async` keyword is used to declare a function as asynchronous, and the `await` keyword pauses the execution of the function until a `Promise` is resolved.

  ```javascript
  async function fetchData() {
    try {
      const response = await fetch('https://api.example.com/data');
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error("Failed to fetch data:", error);
    }
  }
  ```

---

## 4. Deliberate Practice

1.  **Refactor with `let` and `const`**: Go back to any simple JavaScript you've written and replace all `var` declarations with `let` or `const` as appropriate.
2.  **Arrow Function Conversion**: Rewrite a few traditional function declarations as arrow functions.
3.  **Destructuring Practice**: Create an object that represents a user (with name, email, and address). Use destructuring to extract the name and email into separate variables.
4.  **Fetch Data**: Use the `fetch` API with `async/await` to get data from a public API (like the [JSONPlaceholder API](https://jsonplaceholder.typicode.com/)) and log it to the console.

---

## 5. Active Recall Questions

- What is the difference between `let` and `const`?
- What are the advantages of using template literals?
- What is the difference between the spread and rest operators?
- What problem does asynchronous JavaScript solve?
- What does the `await` keyword do?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Console**: The JavaScript console in your browser's developer tools is the best place to quickly test and run JavaScript code.
-   **Node.js**: Allows you to run JavaScript outside of a browser, which is essential for backend development.
-   **Linters (like ESLint)**: A linter will analyze your code and enforce modern best practices, such as suggesting you use `const` over `let` if a variable is not reassigned.

---

## 7. Feedback and Self-Assessment

-   **`const` by Default**: Get into the habit of declaring all variables with `const` first. Only change it to `let` if you know you need to reassign it. This helps prevent accidental reassignments.
-   **Readability**: Compare a function that uses Promises with `.then()` and `.catch()` to one that uses `async/await`. Which is easier to read and understand? The `async/await` version usually looks more like synchronous code, which is a major advantage.

---

## 8. Summary and Mastery Checklist

-   [ ] I can explain the difference between `var`, `let`, and `const`, and I use `let` and `const` in my code.
-   [ ] I can write an arrow function.
-   [ ] I can use template literals to create strings with embedded variables.
-   [ ] I can use destructuring to extract data from objects and arrays.
-   [ ] I can use `fetch` with `async/await` to make a basic API call.

---

## 9. Research and References

-   **MDN Web Docs - A re-introduction to JavaScript**: [Link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/A_re-introduction_to_JavaScript)
-   **"Eloquent JavaScript" by Marijn Haverbeke**: A comprehensive and highly respected book on the language. It's available for free online.
-   **javascript.info**: An excellent, modern tutorial website that covers everything from the basics to advanced topics.
-   **ES6 Features**: A great website that provides clear, simple examples of all the new features in ES6. [Link](https://es6-features.org/)
