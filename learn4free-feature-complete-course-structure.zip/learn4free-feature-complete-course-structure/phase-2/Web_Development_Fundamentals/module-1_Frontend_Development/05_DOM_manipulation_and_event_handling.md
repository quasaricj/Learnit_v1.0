# DOM Manipulation and Event Handling

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the Document Object Model (DOM).
- **Select** elements from the DOM using methods like `querySelector` and `getElementById`.
- **Modify** the content and attributes of DOM elements.
- **Change** the style of DOM elements.
- **Create and add** new elements to the DOM.
- **Listen for and respond** to user interactions using event listeners.

---

## 2. Introduction to the DOM

When a web browser loads an HTML document, it creates a model of that document in memory. This model is called the **Document Object Model (DOM)**. The DOM represents the document as a tree-like structure of **nodes** and **objects**. JavaScript can interact with this DOM to access, change, add, or delete HTML elements and their content. This is the core of how you create dynamic and interactive web pages.

**Event Handling** is the process of listening for user actions (like clicks, mouse movements, or key presses) and running a piece of JavaScript code in response.

---

## 3. Core Concepts

### The DOM Tree

You can think of the DOM as a family tree:
- The `document` object is the root of the tree.
- The `<html>` element is its child.
- The `<body>` and `<head>` are siblings, and children of `<html>`.
- Any elements inside the `<body>` are its children, and so on.

JavaScript provides methods on the `document` object to access and manipulate this tree.

### Selecting Elements

To manipulate an element, you first have to select it.

- **`document.querySelector(selector)`**: The modern, all-purpose method. It returns the *first* element that matches a specified CSS selector.
  ```javascript
  const mainHeading = document.querySelector('#main-heading');
  const firstButton = document.querySelector('.btn');
  ```
- **`document.querySelectorAll(selector)`**: Returns a `NodeList` (which is like an array) of *all* elements that match the selector.
- **`document.getElementById(id)`**: An older, but very fast, method for selecting an element by its `id`.

### Manipulating Elements

Once you have an element selected, you can change it.

- **Changing Content**:
  - `element.textContent`: Changes the text content of the element.
  - `element.innerHTML`: Changes the full HTML content inside the element. (Use with caution, as it can be a security risk if you're inserting user-provided content).
- **Changing Attributes**:
  - `element.setAttribute('href', 'https://example.com')`
  - `element.getAttribute('href')`
- **Changing Styles**:
  - `element.style.color = 'blue';`
  - `element.style.backgroundColor = '#f0f0f0';`
- **Changing Classes**:
  - `element.classList.add('active')`
  - `element.classList.remove('active')`
  - `element.classList.toggle('active')`

### Creating and Adding Elements

You can create new elements from scratch and add them to the DOM.

```javascript
// 1. Create a new element
const newParagraph = document.createElement('p');

// 2. Give it content
newParagraph.textContent = "This is a new paragraph.";

// 3. Find a place to add it
const container = document.querySelector('.container');

// 4. Add it to the DOM
container.appendChild(newParagraph);
```

### Event Handling

To make a page interactive, you listen for events.

- **`element.addEventListener(eventName, eventHandler)`**: The modern and best way to handle events.
  - `eventName`: A string representing the event to listen for (e.g., `'click'`, `'mouseover'`, `'keydown'`).
  - `eventHandler`: The function to be called when the event occurs. This function automatically receives an `event` object with information about the event.

```javascript
const myButton = document.querySelector('#myButton');

myButton.addEventListener('click', (event) => {
  console.log('Button was clicked!');
  // The 'event' object has useful info, like event.target
  event.target.textContent = "I've been clicked!";
});
```

---

## 4. Deliberate Practice

1.  **Simple Counter**: Create an HTML page with a number displayed (e.g., in a `<h1>`) and two buttons, "Increment" and "Decrement". Use JavaScript to make the buttons update the number.
2.  **To-Do List**: Build a simple to-do list.
    - An input field and an "Add" button to add new items to a `<ul>`.
    - When an item is added, it should be a new `<li>` element.
    - Clicking on an `<li>` should toggle a "completed" class that strikes through the text.
3.  **Image Gallery**: Create a simple image gallery where clicking on a thumbnail image displays a larger version of that image in a main display area.

---

## 5. Active Recall Questions

- What does DOM stand for?
- What is the difference between `querySelector` and `querySelectorAll`?
- What is the difference between `textContent` and `innerHTML`?
- What are the four steps for creating a new element and adding it to the page?
- What are the two arguments you pass to `addEventListener`?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Developer Tools**: The "Elements" or "Inspector" panel is crucial. You can see the live DOM tree, and changes you make with JavaScript will be reflected there instantly. The "Console" is where you'll see your `console.log` output and error messages.
-   **JavaScript Frameworks (React, Vue, Angular)**: In the long run, you will use frameworks like these to manage the DOM. These frameworks provide a more efficient and declarative way to handle DOM updates. However, it is absolutely essential to understand how to manipulate the DOM directly first.

---

## 7. Summary and Mastery Checklist

-   [ ] I can select an element from the DOM using `querySelector`.
-   [ ] I can change the text content and a CSS style of a selected element.
-   [ ] I can add and remove a CSS class from an element.
-   [ ] I can create a new HTML element and append it to an existing element.
-   [ ] I can attach a 'click' event listener to a button to run a function when it is clicked.

---

## 8. Research and References

-   **MDN Web Docs - Introduction to the DOM**: [Link](https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model/Introduction)
-   **"JavaScript and JQuery: Interactive Front-End Web Development" by Jon Duckett**: A fantastic, visually-driven book that covers DOM manipulation in great detail.
-   **javascript.info - DOM tree**: [Link](https://javascript.info/dom-nodes)
-   **Wes Bos - JavaScript 30**: A free video course with 30 vanilla JavaScript projects that heavily involve DOM manipulation. [Link](https://javascript30.com/)
