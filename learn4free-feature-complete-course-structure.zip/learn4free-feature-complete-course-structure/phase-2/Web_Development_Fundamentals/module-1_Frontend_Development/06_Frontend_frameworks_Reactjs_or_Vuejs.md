# Frontend Frameworks: React.js or Vue.js

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** why frontend frameworks are used and the problems they solve.
- **Describe** the concept of a component-based architecture.
- **Understand** the core ideas of declarative rendering and the virtual DOM.
- **Set up** a basic "Hello World" application using either React or Vue.
- **Create** a simple component that accepts data via `props`.
- **Manage** a component's internal state.

---

## 2. Introduction to Frontend Frameworks

While you can build interactive websites with "vanilla" JavaScript and direct DOM manipulation, it can quickly become complex and difficult to manage as your application grows. **Frontend frameworks** (also called libraries) like React and Vue provide a higher level of abstraction to solve this problem.

They allow you to build your user interface as a set of reusable **components**. They also provide a more efficient way to update the DOM, leading to better performance and a more organized and scalable codebase.

### React vs. Vue

- **React**: Developed by Facebook, it is the most popular frontend library in the world. It has a massive ecosystem and job market. It can be a bit more verbose and has a steeper learning curve in some areas (like state management).
- **Vue**: A progressive framework that is known for its excellent documentation and gentle learning curve. It is often considered more "batteries-included" than React.

Both are excellent choices, and the concepts you learn in one are highly transferable to the other.

---

## 3. Core Concepts

### Component-Based Architecture

This is the fundamental idea behind all modern frontend frameworks. Instead of thinking about your application as a collection of HTML pages, you think of it as a tree of **components**.
- A component is a self-contained, reusable piece of the UI. For example, a button, a search bar, a user profile card, or an entire page can be a component.
- Components can be nested inside other components, allowing you to build a complex UI from small, simple building blocks.

### Declarative Rendering

With direct DOM manipulation, you write **imperative** code: you tell the browser *how* to change the page step-by-step ("create a p, set its text, append it to the div...").

Frameworks use **declarative** rendering. You describe *what* the UI should look like for a given state, and the framework takes care of the "how".

```jsx
// React Example
function Greeting({ name }) {
  // You declare WHAT to render:
  return <h1>Hello, {name}!</h1>;
}
```
You don't tell React how to create the `<h1>` and update it; you just tell it that the `h1` should exist and contain the current `name`.

### The Virtual DOM

Directly manipulating the real DOM is slow. To improve performance, frameworks use a **Virtual DOM**.
1.  When your application's state changes, the framework creates a new, in-memory representation of the UI (a new Virtual DOM).
2.  It then compares (or "diffs") this new Virtual DOM with the previous one.
3.  It calculates the most efficient, minimal set of changes needed to make the real DOM match the new Virtual DOM.
4.  It then performs these "batched" updates to the real DOM.

This process is much faster than re-rendering the entire page on every change.

### Props and State

These are the two types of data that control a component.

- **`props` (properties)**: Data that is passed **down** from a parent component to a child component. Props are **read-only**; a component should not modify the props it receives.
- **`state`**: Data that is managed **internally** by the component itself. When a component's state changes, the framework will automatically re-render the component to reflect the new state.

---

## 4. Deliberate Practice

1.  **Choose a Framework**: Pick either React or Vue to focus on for now.
2.  **Follow the Official Tutorial**: Both frameworks have excellent "getting started" tutorials on their official websites. Follow one to set up a new project.
    -   **React**: [Create a new React app](https://react.dev/learn)
    -   **Vue**: [Vue Quick Start](https://vuejs.org/guide/quick-start.html)
3.  **Create a `Greeting` Component**: Create a reusable `Greeting` component that accepts a `name` as a prop and displays a message like "Hello, [name]!".
4.  **Create a Counter Component**: Build a simple counter component that:
    -   Has a `count` variable in its internal `state`.
    -   Displays the current count.
    -   Has a button that, when clicked, increments the count.

---

## 5. Active Recall Questions

- What is the main problem that frontend frameworks solve?
- What is a component?
- What is the difference between declarative and imperative programming?
- What is the purpose of the Virtual DOM?
- What is the difference between `props` and `state`?

---

## 6. Tools, Frameworks, and Platforms

-   **Node.js and npm/yarn**: You will need these to manage your project dependencies and run a local development server.
-   **Build Tools (Vite, Create React App)**: These are command-line tools that set up a complete development environment for you with one command.
-   **Browser DevTools**: Both React and Vue have dedicated developer tools that you can install as browser extensions. They allow you to inspect your component tree, view component props and state, and debug your application.

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain why I would use a framework instead of just vanilla JavaScript.
-   [ ] I can describe the concept of a UI component.
-   [ ] I understand that in a declarative framework, I describe the UI based on the current state.
-   [ ] I can explain the basic difference between `props` (data passed in) and `state` (internal data).
-   [ ] I have successfully set up a basic "Hello World" application in either React or Vue.

---

## 8. Research and References

### React
-   **Official React Documentation**: [react.dev](https://react.dev/) (The new official docs are fantastic).
-   **"The Road to React" by Robin Wieruch**: A great book for beginners.

### Vue
-   **Official Vue.js Documentation**: [vuejs.org](https://vuejs.org/)
-   **Vue Mastery**: A website with high-quality video courses on Vue.

### General
-   **"Modern Frontend Development" by Smashing Magazine**: A book that covers the entire landscape of modern frontend development, including frameworks.
