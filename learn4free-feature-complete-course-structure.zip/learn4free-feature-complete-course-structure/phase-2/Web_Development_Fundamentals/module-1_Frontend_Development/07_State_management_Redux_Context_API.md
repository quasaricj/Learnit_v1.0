# State Management (Redux, Context API)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** "state" in the context of a frontend application.
- **Explain** the problem of "prop drilling" and why it occurs.
- **Describe** the concept of a centralized, global state management solution.
- **Understand** the basic data flow of Redux (Action -> Reducer -> Store).
- **Understand** how React's Context API can be used for state management.
- **Identify** when it is appropriate to use a global state management solution versus local component state.

---

## 2. Introduction to State Management

In a component-based application, you have two main types of data: `props` (passed down from parents) and `state` (managed inside a component). For a small application, this is sufficient.

However, as your application grows, you often have pieces of "global" state that need to be accessed by many different components, often in different parts of the component tree. For example:
- The currently logged-in user.
- The user's chosen theme (e.g., dark or light mode).
- Data from a shopping cart.

Trying to manage this shared state by passing props down through many layers of components is called **"prop drilling"**. It's inefficient, hard to maintain, and a common source of bugs.

**State management libraries** solve this problem by providing a centralized, global "store" for your application's state. Any component that needs to can access or update the state in this store without having to pass props through intermediate components.

---

## 3. Core Concepts

### Local vs. Global State

- **Local State**: State that is only needed by a single component or a small, co-located group of components. The built-in state management of your framework (e.g., `useState` in React) is perfect for this.
- **Global State**: State that is needed by many components across the application. This is where you would reach for a state management library.

### React's Context API

The Context API is a feature built into React that provides a way to share state between components without prop drilling.
- **How it works**:
  1.  You create a `Context` object.
  2.  You use a `Provider` component to "provide" a value to all the components inside it.
  3.  Any child component in the tree can then "consume" this value using a `useContext` hook.
- **Use Case**: It's excellent for low-frequency updates of simple state, like theme data or user authentication status. It can become complex to manage for high-frequency updates (like complex form state).

### Redux

Redux is the most popular and powerful state management library for JavaScript applications (it can be used with any framework, not just React). It enforces a strict, one-way data flow that makes your application's state predictable and easy to debug.

**The Three Principles of Redux:**

1.  **Single Source of Truth**: The entire state of your application is stored in a single object tree within a single **store**.
2.  **State is Read-Only**: The only way to change the state is to dispatch an **action**, which is a plain object describing what happened. You cannot directly modify the state.
3.  **Changes are Made with Pure Functions**: To specify how the state tree is transformed by actions, you write pure **reducers**. A reducer is a function that takes the previous state and an action, and returns the next state.

**Redux Data Flow:**

`UI Event -> dispatch(Action) -> Reducer -> New State in Store -> UI Re-renders`

- **Modern Redux**: The modern way to write Redux is with **Redux Toolkit**, which dramatically simplifies the setup and reduces boilerplate code.

---

## 4. Deliberate Practice

1.  **Prop Drilling Exercise**: Create a simple React/Vue app with a deeply nested component structure (e.g., `App -> Page -> Section -> Component`). Pass a piece of data from `App` all the way down to `Component` via props.
2.  **Refactor with Context**: Take the app from the previous exercise and refactor it to use the Context API instead of prop drilling.
3.  **Redux Counter**: Follow the official **Redux Toolkit** "counter" tutorial. This is the "Hello World" of Redux and will walk you through setting up a store, creating a slice (a reducer and its actions), dispatching actions, and reading the state in a component.
    - [Redux Toolkit Quick Start](https://redux-toolkit.js.org/introduction/quick-start)

---

## 5. Active Recall Questions

- What is "prop drilling"?
- What is the difference between local and global state?
- What are the three core parts of the Redux data flow? (Action, Reducer, Store).
- In Redux, can you modify the state directly?
- What is the name of the React hook used to consume a Context value?

---

## 6. Tools, Frameworks, and Platforms

-   **Redux DevTools**: A browser extension that is an absolute superpower for debugging Redux applications. It allows you to:
    -   Inspect the current state of your store at any time.
    -   View a history of all actions that have been dispatched.
    -   "Time travel" by reversing or replaying actions to see how they affect the state.
-   **React DevTools**: Also useful for seeing where state is coming from (props, context, or Redux).

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain what application state is and the difference between local and global state.
-   [ ] I can describe the problem of "prop drilling".
-   [ ] I understand the basic idea of a centralized state store.
-   [ ] I can describe the one-way data flow of Redux (Action -> Reducer -> Store).
-   [ ] I know that React's Context API is a simpler, built-in solution for sharing state.
-   [ ] I understand that you don't always need a global state manager; local state is often enough.

---

## 8. Research and References

-   **React Docs - Passing Data with Context**: [Link](https://react.dev/learn/passing-data-deeply-with-context)
-   **Redux Toolkit Official Documentation**: [Link](https://redux-toolkit.js.org/) (This is the modern standard for Redux).
-   **"You Might Not Need Redux" by Dan Abramov**: A classic article that provides perspective on when and when not to use a global state management library.
-   **Vuex Documentation** (for Vue users): The official state management library for Vue, which is conceptually very similar to Redux. [Link](https://vuex.vuejs.org/)
