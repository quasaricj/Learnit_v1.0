# CSS3: Layouts, Flexbox, Grid, and Animations

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** the role of CSS in web development.
-   **Understand** the CSS Box Model (`content`, `padding`, `border`, `margin`).
-   **Create** one-dimensional layouts using **Flexbox**.
-   **Create** two-dimensional layouts using **CSS Grid**.
-   **Differentiate** between Flexbox and Grid and know when to use each.
-   **Implement** simple animations and effects using CSS Transitions.
-   **Create** complex, multi-step animations using CSS Keyframe Animations.
-   **Write** CSS selectors to target specific HTML elements.

---

## 2. Introduction to CSS

CSS (Cascading Style Sheets) is the language we use to style and lay out web pages. While HTML provides the structure and semantics, CSS provides the presentation. It controls the colors, fonts, spacing, and, most importantly, the **layout** of the content. Modern CSS has evolved with two incredibly powerful layout systems, Flexbox and Grid, that have made creating complex, responsive web designs easier than ever before.

---

## 3. Core Concepts

### The CSS Box Model

Every element on a page is a rectangular box. The box model describes how this box is composed:
-   **Content**: The actual content of the box (text, an image, etc.).
-   **Padding**: The space between the content and the border.
-   **Border**: A line that goes around the padding and content.
-   **Margin**: The space outside the border, separating the element from other elements.

### CSS Layout Systems

#### 1. Flexbox (The Flexible Box Layout Module)

Flexbox is a **one-dimensional** layout system. It excels at distributing space along a single axis (either a row or a column).

-   **To use it**: Apply `display: flex;` to a container element.
-   **Main Concepts**:
    -   **`flex-direction`**: Defines the main axis (`row` or `column`).
    -   **`justify-content`**: Aligns items along the main axis (e.g., `center`, `space-between`).
    -   **`align-items`**: Aligns items along the cross axis (the axis perpendicular to `flex-direction`).
-   **Best For**: Aligning items in a navigation bar, centering a group of items, distributing items evenly in a container.

#### 2. CSS Grid (The Grid Layout Module)

Grid is a **two-dimensional** layout system. It allows you to control the layout in both rows and columns simultaneously, like a spreadsheet.

-   **To use it**: Apply `display: grid;` to a container element.
-   **Main Concepts**:
    -   **`grid-template-columns` / `grid-template-rows`**: Define the number and size of the columns and rows in your grid. The `fr` unit (fractional unit) is extremely useful here.
    -   **`gap`**: Defines the space between grid cells.
    -   **Item Placement**: You can precisely place items into grid cells using line numbers, `grid-column`, and `grid-row`.
-   **Best For**: Overall page layout (header, sidebar, main content, footer), photo galleries, or any component that requires alignment in both rows and columns.

### CSS Animations

#### 1. Transitions

Transitions provide a way to control the speed of an animation when a CSS property changes. They create a simple, smooth animation from a starting state to an ending state.

-   **How it works**: You define the `transition` property on an element, specifying which CSS property to animate and the duration. When that property is changed (e.g., on `:hover`), the browser will create a smooth animation.

#### 2. Keyframe Animations

For more complex, multi-step animations, you can use keyframes.

-   **How it works**:
    1.  Define the animation sequence using a `@keyframes` rule, specifying the styles at different points (e.g., `0%`, `50%`, `100%`).
    2.  Apply the animation to an element using the `animation` property, specifying the keyframe name and duration.

---

## 4. Deliberate Practice

1.  **Flexbox Nav Bar**: Create a horizontal navigation bar. Use Flexbox to evenly space the links.
2.  **Grid Layout**: Create a classic "holy grail" page layout with a header, footer, main content area, and two sidebars using CSS Grid.
3.  **Button Hover Effect**: Create a button. Use a CSS `transition` to make its background color and text color change smoothly when the user hovers over it.
4.  **Loading Spinner**: Use `@keyframes` to create a simple rotating loading spinner animation.

---

## 5. Active Recall Questions

-   What are the four components of the CSS Box Model?
-   What is the main difference between Flexbox and Grid (in terms of dimensions)?
-   Which Flexbox property is used for alignment along the main axis?
-   Which Grid property is used to define the columns of a grid?
-   What is the difference between a CSS Transition and a Keyframe Animation?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Developer Tools**: The "Inspector" or "Elements" panel is your best friend for CSS. You can edit styles live, and modern browsers have dedicated Flexbox and Grid inspectors that visualize your layouts.
-   **CodePen / JSFiddle**: Online code editors that are perfect for experimenting with small CSS snippets.
-   **CSS-Tricks**: An indispensable website with articles and guides on everything CSS, especially Flexbox and Grid.
-   **Flexbox Froggy & Grid Garden**: Fun, interactive games for learning Flexbox and Grid.

---

## 7. Feedback and Self-Assessment

-   **Use the Layout Inspectors**: When building a layout, constantly use the Flexbox and Grid inspectors in your browser's dev tools to check that your properties are having the intended effect.
-   **Responsive Check**: Resize your browser window. Does your layout break? How can you use CSS to make it adapt to different screen sizes? (This is the topic of the next module).
-   **Performance**: For animations, `transform` and `opacity` are the most performant properties to animate. Animating properties like `width`, `height`, or `margin` can be less efficient as they cause the browser to re-calculate the layout.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Building a card-based component.
-   Imagine a UI component for a product card that contains an image, a title, a description, and a price.
-   You could use **CSS Grid** to structure the overall card, defining rows for the image, title, description, and price.
-   Within the title area, if you have a title on the left and a "favorite" icon on the right, you could use a nested **Flexbox** container (`display: flex`, `justify-content: space-between`) to easily position them.

This demonstrates that Flexbox and Grid are not mutually exclusive; they are often used together to build complex components.

---

## 9. Collaborative Activities

-   **Layout Duplication**: As a group, find a well-designed website and try to re-create its main layout using Flexbox and Grid on CodePen.
-   **Pair Styling**: Work with a partner. One person writes the HTML structure for a component, and the other person writes the CSS to style and lay it out.

---

## 10. Psychological and Cognitive Principles

-   **Visual Feedback Loop**: CSS is highly visual and provides an immediate feedback loop. This makes it a great candidate for learning by experimentation. Don't be afraid to change values and see what happens.
-   **One Dimension vs. Two**: Create a strong mental model: "Flexbox is for one dimension (a row OR a column). Grid is for two dimensions (rows AND columns)". This simple heuristic will help you choose the right tool for the job most of the time.

---

## 11. Summary and Mastery Checklist

-   [ ] I can explain the CSS Box Model.
-   [ ] I can use Flexbox to align items in a single dimension.
-   [ ] I can use CSS Grid to create a two-dimensional page layout.
-   [ ] I can explain the primary use cases for Flexbox vs. Grid.
-   [ ] I can create a simple hover effect using a CSS Transition.
-   [ ] I can create a basic multi-step animation using `@keyframes`.

---

## 13. Research and References

-   **A Complete Guide to Flexbox (CSS-Tricks)**: [Link](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
-   **A Complete Guide to Grid (CSS-Tricks)**: [Link](https://css-tricks.com/snippets/css/complete-guide-grid/)
-   **MDN Web Docs - CSS basics**: [Link](https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/CSS_basics)
-   **Flexbox Froggy**: [Link](https://flexboxfroggy.com/)
-   **Grid Garden**: [Link](https://cssgridgarden.com/)
