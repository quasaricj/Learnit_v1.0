# DOM Manipulation and Event Handling

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** the Document Object Model (DOM) and explain its tree-like structure.
-   **Select** elements from the DOM using methods like `querySelector` and `getElementById`.
-   **Manipulate** DOM elements: change their content, style, and attributes.
-   **Create and remove** elements from the DOM.
-   **Define** event handling and its role in user interaction.
-   **Listen for and respond** to user events like clicks, keyboard input, and form submissions using `addEventListener`.
-   **Understand** event propagation (bubbling and capturing) and the use of `event.stopPropagation()`.

---

## 2. Introduction to the DOM

The Document Object Model (DOM) is the bridge between your HTML document and your JavaScript code. When a browser loads a web page, it creates a "model" of that page in memory. The DOM is this object-based representation of the HTML document. It represents the page as a tree of nodes and objects, allowing programming languages like JavaScript to connect to the page and manipulate it. **DOM manipulation** is the act of using JavaScript to change the structure, style, and content of a web page.

---

## 3. Core Concepts

### The DOM Tree

The browser parses your HTML into a tree-like structure. Every HTML tag becomes an **element node** in the tree. The text between tags becomes a **text node**. This tree is a live representation of your page.

### Selecting Elements

To manipulate an element, you first need to select it.

-   **`document.getElementById('id')`**: Selects a single element by its unique ID.
-   **`document.querySelector('selector')`**: The modern, preferred method. It selects the *first* element that matches a given CSS selector (e.g., `'#myId'`, `.myClass`, `p`).
-   **`document.querySelectorAll('selector')`**: Selects *all* elements that match a given CSS selector and returns them in a `NodeList`.

### Manipulating Elements

Once you have selected an element object, you can change it.

-   **Changing Content**:
    -   `element.textContent`: Changes the text content of the element.
    -   `element.innerHTML`: Changes the full HTML content inside the element (use with caution, as it can be a security risk).
-   **Changing Styles**:
    -   `element.style.property`: Directly manipulates a specific CSS property (e.g., `element.style.color = 'blue'`).
    -   `element.classList.add('className')`, `element.classList.remove()`, `element.classList.toggle()`: The preferred way to change styles, by adding or removing predefined CSS classes.
-   **Changing Attributes**:
    -   `element.setAttribute('attribute', 'value')`
    -   `element.getAttribute('attribute')`

### Creating and Removing Elements

-   **`document.createElement('tagName')`**: Creates a new element node (e.g., `document.createElement('p')`).
-   **`parentNode.appendChild(childNode)`**: Appends a child node to the end of a parent's list of children.
-   **`element.remove()`**: Removes the element from the DOM.

### Event Handling

Event handling is the process of responding to user actions (events) like clicks, key presses, mouse movements, etc.

-   **`addEventListener('eventType', callbackFunction)`**: The standard way to listen for events.
    -   `eventType`: The name of the event (e.g., `'click'`, `'keydown'`).
    -   `callbackFunction`: The function that will be executed when the event occurs. This function automatically receives an `event` object with details about the event.

-   **The `event` Object**: This object contains useful information, such as `event.target` (the element that triggered the event) and methods like `event.preventDefault()` (to stop the browser's default behavior, like a form submitting) and `event.stopPropagation()` (to stop an event from "bubbling" up to parent elements).

---

## 4. Deliberate Practice

1.  **Simple Clicker**: Create an HTML page with a button and a paragraph that displays a counter (initially 0). Use JavaScript to add a `'click'` event listener to the button that increments the counter and updates the paragraph's text content.
2.  **To-Do List**: Build a simple to-do list.
    -   Have an input field and an "Add" button.
    -   When the button is clicked, create a new list item (`<li>`) with the input's text and append it to an unordered list (`<ul>`).
3.  **Event Delegation**: In your to-do list, instead of adding an event listener to each `<li>` to mark it as done, add a single event listener to the parent `<ul>`. Use `event.target` to figure out which `<li>` was clicked. This is a more efficient pattern called event delegation.

---

## 5. Active Recall Questions

-   What does "DOM" stand for?
-   What is the difference between `querySelector` and `querySelectorAll`?
-   What is the difference between `textContent` and `innerHTML`?
-   What are the three arguments for `addEventListener`? (The third, `options`, is optional).
-   What is the purpose of `event.preventDefault()`?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Developer Tools**: The "Elements" panel lets you inspect the live DOM tree, and the "Console" lets you run JavaScript to select and manipulate elements on the fly. You can also inspect event listeners attached to any element.
-   **JavaScript Frameworks (React, Vue, Angular)**: These frameworks provide a higher-level abstraction over direct DOM manipulation. You typically declare what the UI should look like based on the application's state, and the framework handles the efficient updating of the DOM. **Understanding the underlying DOM is still crucial for using these frameworks effectively.**

---

## 7. Feedback and Self-Assessment

-   **Performance**: Repeatedly reading from and writing to the DOM can be slow. It's often more performant to create a "fragment" of DOM nodes in memory and then append the entire fragment to the page in a single operation.
-   **Security**: Be very careful when using `innerHTML` with user-provided content. It can expose your site to Cross-Site Scripting (XSS) attacks. `textContent` is always safer for displaying text.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A "Dark Mode" Toggle
-   You have a button on your page that allows users to switch between light and dark themes.
-   **HTML**: `<button id="theme-toggle">Toggle Dark Mode</button>`
-   **CSS**:
    ```css
    body.dark-mode {
        background-color: #333;
        color: #fff;
    }
    ```
-   **JavaScript**:
    ```javascript
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
    });
    ```
This simple, practical example combines element selection, event handling, and class list manipulation to create a common and useful feature.

---

## 9. Collaborative Activities

-   **Pair Programming a Modal Window**: Work with a partner to create a modal pop-up window. One person can write the JavaScript to create the elements and toggle the CSS classes, while the other writes the CSS to style the modal and its open/closed states.
-   **Event Debugging**: Create a simple page with nested elements and click listeners on each. Log a message from each listener and observe the order in which they fire (event bubbling). Use `event.stopPropagation()` to see how it changes the behavior.

---

## 11. Psychological and Cognitive Principles

-   **The Page is an Object**: The core mental shift of this module is to stop seeing a web page as a static document and start seeing it as a live, mutable object (`document`) that your code can interact with.
-   **Cause and Effect**: Event-driven programming is about setting up a series of "cause and effect" relationships. "When a *click* happens on the *button*, then *this function* should run."

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that the DOM is a JavaScript object representation of an HTML page.
-   [ ] I can select any element on the page using `querySelector`.
-   [ ] I can modify the content and styles of an element.
-   [ ] I can create a new element and add it to the page.
-   [ ] I can add a `'click'` event listener to a button to make a page interactive.

---

## 13. Research and References

-   **MDN Web Docs - Introduction to the DOM**: [Link](https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model/Introduction)
-   **MDN Web Docs - Introduction to events**: [Link](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Building_blocks/Events)
-   **JavaScript.info - The Document Object Model**: [Link](https://javascript.info/dom-basics)
