# Frontend Frameworks: React.js and Vue.js

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** what a frontend framework is and explain the problems they solve.
-   **Describe** the concept of a component-based architecture.
-   **Explain** the idea of a declarative UI and how it differs from imperative DOM manipulation.
-   **Understand** the basic principles of React: JSX, components, props, and state.
-   **Understand** the basic principles of Vue: templates, components, props, and reactive data.
-   **Compare** the general philosophies of React and Vue.
-   **Set up** a basic "Hello, World" application using a starter kit like `create-react-app` or `create-vue`.

---

## 2. Introduction to Frontend Frameworks

While you can build interactive websites using only vanilla JavaScript and DOM manipulation, it can quickly become complex and difficult to manage as your application grows. **Frontend frameworks** like React, Vue, and Angular provide a higher level of abstraction to solve this problem. They offer a structured, organized, and efficient way to build complex user interfaces. The core idea behind all modern frameworks is **component-based architecture**.

---

## 3. Core Concepts

### The Problem: Imperative vs. Declarative

-   **Imperative (Vanilla JS)**: You manually tell the browser *how* to change the page. "First, select the paragraph. Then, change its text content. Then, add this CSS class." This is what we did in the DOM manipulation module.
-   **Declarative (Frameworks)**: You describe *what* the UI should look like for a given state, and the framework takes care of the "how". You declare that the paragraph's text should be the value of the `message` variable, and the framework automatically and efficiently updates the DOM whenever `message` changes.

### Component-Based Architecture

This is the fundamental paradigm of all modern frontend frameworks.
-   **Component**: A self-contained, reusable piece of the user interface. A component encapsulates its own HTML structure, CSS styles, and JavaScript logic.
-   **Composition**: You build a complex UI by composing small, single-purpose components together, like Lego bricks. A page might be made of a `NavBar` component, a `Sidebar` component, and a `PostList` component. The `PostList` component, in turn, is made up of multiple `Post` components.

### React.js

-   **Creator**: Facebook
-   **Core Philosophy**: React is a "JavaScript library for building user interfaces". It focuses heavily on the UI layer and is often paired with other libraries for things like routing and global state management.
-   **Key Features**:
    -   **JSX (JavaScript XML)**: A syntax extension that allows you to write HTML-like code directly within your JavaScript. This lets you keep your markup and logic in the same place.
    -   **Components**: Typically written as JavaScript functions or classes that return JSX.
    -   **Props (Properties)**: Data passed *down* from a parent component to a child component. Props are read-only.
    -   **State**: Data that is managed *within* a component. When a component's state changes, React automatically re-renders the component.

### Vue.js

-   **Creator**: Evan You (an ex-Google developer)
-   **Core Philosophy**: Vue is a "progressive framework" for building user interfaces. It is designed to be incrementally adoptable. You can use it as a simple library for a small part of your page, or as a full-featured framework for a large single-page application.
-   **Key Features**:
    -   **Templates**: Vue uses an HTML-based template syntax. Logic is added using special attributes called "directives" (e.g., `v-if`, `v-for`). This provides a clear separation of markup and logic.
    -   **Components**: Typically written in Single-File Components (`.vue` files) that contain the `<template>`, `<script>`, and `<style>` for that component in one file.
    -   **Props**: Similar to React, data passed from parent to child.
    -   **Reactivity**: Vue's "reactivity" system automatically tracks dependencies. When you change a piece of data in your component's `data` object, Vue knows exactly which parts of the DOM to update.

---

## 4. Deliberate Practice

1.  **"Thinking in Components"**: Look at a website you use frequently (e.g., Twitter, YouTube). On paper or a whiteboard, break down its UI into a hierarchy of components.
2.  **Setup `create-react-app`**: Follow the official tutorial to install and run a new React project. Change the text in the main `App.js` file and see the change appear in your browser.
3.  **Setup `create-vue`**: Follow the official tutorial to install and run a new Vue project. Change the text in the main `App.vue` file.
4.  **Create a Simple Component**: In either React or Vue, create a simple `Greeting` component that accepts a `name` prop and displays "Hello, [name]!". Use this component multiple times in your main App component with different names.

---

## 5. Active Recall Questions

-   What is the main problem that frontend frameworks solve?
-   Explain the difference between imperative and declarative UI.
-   What is a component?
-   What is JSX, and which framework uses it?
-   In the parent-child component relationship, how is data passed down? (Props).
-   What is the purpose of "state" in a component?

---

## 6. Tools, Frameworks, and Platforms

-   **Node.js and npm/yarn**: Required for installing and running the build tools for modern frameworks.
-   **CLI Tools**: `create-react-app` and `create-vue` are command-line tools that set up a complete, configured development environment for you.
-   **Browser DevTools**: The React and Vue browser extensions are essential. They let you inspect your component tree, view the props and state of each component, and debug your application.

---

## 7. Feedback and Self-Assessment

-   **One-Way Data Flow**: A core principle in both React and Vue is one-way data flow. State flows down from parent to child via props. A child should not directly modify its props. How does a child communicate back up to a parent? (By emitting events).
-   **Framework vs. Library**: React is technically a library, while Vue is a framework. What is the difference? (A library is a tool you call in your code. A framework is a structure that calls *your* code).

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A "Like" Button
-   This is a perfect example of a component.
-   **State**: The component needs a piece of state, `isLiked`, which can be `true` or `false`.
-   **Declarative UI**: You write a single `render` function that says: "If `isLiked` is true, show a red heart. If `isLiked` is false, show an empty heart."
-   **Event Handling**: You add a click event listener to the button.
-   **State Update**: When the button is clicked, you update the `isLiked` state. The framework then automatically and efficiently re-renders the component to reflect the new state.

You don't manually select the button and change its icon. You just change the state and declare what the UI should look like for that state.

---

## 9. Collaborative Activities

-   **Component Design**: As a group, design the component structure for a simple application, like a to-do list. What components do you need? What props and state does each component have?
-   **Framework Debate**: Discuss the pros and cons of React's JSX (logic and markup in one place) versus Vue's templates (separation of concerns).

---

## 11. Psychological and Cognitive Principles

-   **Abstraction**: Frameworks are a powerful abstraction over the messy details of direct DOM manipulation. This allows you to focus on your application's logic and state, not on the low-level details of updating the browser.
-   **Declarative Mindset**: Shifting from an imperative to a declarative mindset is a major step in becoming a modern frontend developer. It can be tricky at first, but it leads to more predictable and maintainable code in the long run.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain why frameworks are used and the concept of a declarative UI.
-   [ ] I can break down a UI into a hierarchy of components.
-   [ ] I understand that components have `props` (for parent-to-child data) and `state` (for internal data).
-   [ ] I can describe the key difference between React (JSX) and Vue (templates).
-   [ ] I have successfully set up a basic project using the CLI for either React or Vue.

---

## 13. Research and References

-   **React Official Tutorial**: [Link](https://reactjs.org/tutorial/tutorial.html)
-   **Vue.js Official Guide**: [Link](https://vuejs.org/guide/introduction.html)
-   **"Thinking in React"**: A classic article that explains the philosophy of building with components.
-   **Frontend Masters Courses**: A high-quality platform with in-depth courses on both React and Vue.
