# HTML5 Semantics and Document Structure

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** what semantic HTML is and explain its importance.
-   **Structure** a web page using the core HTML5 semantic elements (`<header>`, `<footer>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>`).
-   **Differentiate** between `<div>` and semantic elements, and know when to use each.
-   **Explain** how semantic HTML improves accessibility (a11y) and search engine optimization (SEO).
-   **Construct** a well-formed, valid HTML5 document from scratch.
-   **Select** the appropriate HTML tags for various types of content (headings, paragraphs, lists, links, images).

---

## 2. Introduction to Semantic HTML

HTML (HyperText Markup Language) is the standard language for creating web pages. While it's possible to build a website using only generic `<div>` and `<span>` tags, this approach lacks meaning. **Semantic HTML** is the practice of using HTML tags that accurately describe the *meaning* and *purpose* of the content they enclose. This provides crucial context for browsers, screen readers, and search engine crawlers, leading to a more accessible and discoverable web.

---

## 3. Core Concepts

### The Basic HTML5 Document Structure

A typical HTML5 document has the following structure:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>
</head>
<body>
    <!-- Content goes here -->
</body>
</html>
```
-   **`<!DOCTYPE html>`**: Declares the document type.
-   **`<html>`**: The root element of the page.
-   **`<head>`**: Contains meta-information about the page (title, character set, styles, etc.). Not visible to the user.
-   **`<body>`**: Contains the visible content of the page.

### Key HTML5 Semantic Elements

These elements are designed to structure the main parts of a web page:

-   **`<header>`**: Represents introductory content for the page or a section. Typically contains headings, a logo, or a search form.
-   **`<nav>`**: Contains the main navigation links for the site.
-   **`<main>`**: Represents the dominant, unique content of the page. There should only be one `<main>` element per page.
-   **`<section>`**: A thematic grouping of content, typically with a heading. Can be thought of as a chapter in a book.
-   **`<article>`**: A self-contained piece of content that could be distributed independently (e.g., a blog post, a news article, a forum comment).
-   **`<aside>`**: Content that is tangentially related to the main content, such as a sidebar or a callout box.
-   **`<footer>`**: Represents the footer for the page or a section. Typically contains authorship information, copyright data, or related links.

### `div` vs. Semantic Elements

-   Use semantic elements (`<section>`, `<article>`, etc.) when the content fits the description of the element.
-   Use `<div>` (a "division" or a container) only when there is no other more appropriate semantic element, typically for styling or grouping purposes.

---

## 4. Deliberate Practice

1.  **Structure a Blog Post**: Take a news article or blog post and mark it up using HTML5 semantic elements. Identify the `<header>`, `<main>`, `<article>`, `<section>`s for comments, and `<footer>`.
2.  **Create a Page Skeleton**: From a blank file, write the complete HTML5 boilerplate for a simple website layout, including a `<header>`, `<nav>`, `<main>`, `<aside>`, and `<footer>`.
3.  **Refactor a `div`-based layout**: Find a simple website that uses a lot of `<div>` tags for its layout. Copy its HTML and refactor it to use more appropriate semantic elements.
4.  **Content Markup**: Write a piece of HTML that correctly uses headings (`<h1>` through `<h6>`), paragraphs (`<p>`), unordered lists (`<ul>`), and ordered lists (`<ol>`).

---

## 5. Active Recall Questions

-   What is the main purpose of the `<main>` tag?
-   What is the difference between `<section>` and `<article>`?
-   Why is it better to use `<nav>` for navigation links instead of a `<div>`?
-   Name two benefits of using semantic HTML.
-   Where does the `<title>` tag go, and what does it do?

---

## 6. Tools, Frameworks, and Platforms

-   **W3C Markup Validation Service**: An online tool that checks your HTML for errors and ensures it is well-formed. [Link](https://validator.w3.org/)
-   **Browser Developer Tools**: Use the "Elements" or "Inspector" tab in your browser's developer tools to see how the browser parses your HTML into a DOM tree.
-   **MDN Web Docs**: The ultimate reference for all HTML elements.

---

## 7. Feedback and Self-Assessment

-   **Accessibility Check**: Use a screen reader (like NVDA for Windows or VoiceOver for Mac) on your structured page. Does the semantic structure make the page easier to navigate and understand?
-   **SEO Analysis**: Tools like Lighthouse (in Chrome DevTools) can audit your page and provide feedback on SEO best practices, which are heavily influenced by your HTML structure.
-   **Code Review**: Ask a peer to review your HTML. Is it clear? Is the structure logical? Did you use the most appropriate tags?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A company homepage.
-   The logo and main navigation bar would be inside the `<header>`.
-   The navigation links themselves would be wrapped in a `<nav>` element.
-   The main "hero" section, "About Us," and "Our Services" would each be a `<section>` within the `<main>` element.
-   A customer testimonial, which is a self-contained piece of content, could be an `<article>` inside a section.
-   A sidebar with "Latest News" links would be an `<aside>`.
-   The copyright and contact info at the bottom would be in the `<footer>`.

This exercise demonstrates how to combine the semantic elements to create a meaningful and robust page structure.

---

## 9. Collaborative Activities

-   **Website Deconstruction**: As a group, pick a popular website and, using the browser's developer tools, analyze its document structure. Identify where they have used semantic elements correctly and where they could improve.
-   **Layout Planning**: On a whiteboard, design the layout for a new web page and agree on the correct semantic HTML structure before writing any code.

---

## 10. Domain-Specific Mastery Strategies

-   **Content Management Systems (CMS)**: When building themes for a CMS like WordPress or Drupal, using correct semantic HTML is critical for ensuring the content is displayed accessibly and is SEO-friendly, regardless of what the user enters.
-   **Single Page Applications (SPA)**: Even in JavaScript-heavy frameworks like React or Vue, the foundation of your application is still HTML. Using semantic elements in your components is just as important.

---

## 11. Psychological and Cognitive Principles

-   **Meaningful Names**: Semantic HTML is like using meaningful variable names. It makes the code self-documenting and easier for other developers (and your future self) to understand at a glance.
-   **Creating a Mental Model**: A well-structured HTML document creates a clear mental model of the page's layout and content hierarchy, which makes it easier to reason about and style with CSS.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the benefits of using semantic HTML (Accessibility, SEO, Maintainability).
-   [ ] I can write a valid HTML5 document skeleton from memory.
-   [ ] I can identify and use the main HTML5 layout elements (`<header>`, `<nav>`, `<main>`, `<footer>`, etc.).
-   [ ] I know the difference between `<section>` and `<article>`.
-   [ ] I know when to use a `<div>` versus a more specific semantic tag.

---

## 13. Research and References

-   **MDN Web Docs - HTML basics**: [Link](https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/HTML_basics)
-   **HTML5 Doctor**: A great resource for understanding the nuances of different HTML5 elements. [Link](http://html5doctor.com/)
-   **The A11Y Project**: A community-driven effort to make web accessibility easier. [Link](https://www.a11yproject.com/)
