# JavaScript Fundamentals and ES6+ Features

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** the role of JavaScript in web development.
-   **Declare variables** using `var`, `let`, and `const`, and understand their scope differences.
-   **Write and use** functions, including arrow function syntax (`=>`).
-   **Manipulate** arrays and objects using modern methods (`map`, `filter`, `reduce`) and syntax (spread/rest operators, destructuring).
-   **Understand** asynchronous JavaScript, including callbacks, Promises, and `async/await`.
-   **Use** template literals for easier string construction.
-   **Write** modular code using ES6 Modules (`import`/`export`).

---

## 2. Introduction to JavaScript

JavaScript is the programming language of the web. While HTML provides the structure and CSS provides the style, JavaScript provides **interactivity**. It allows you to create dynamically updating content, control multimedia, animate images, and much more. Originally a simple scripting language, it has evolved into a powerful and versatile language used in both frontend and backend development. This module focuses on the modern version of the language, often referred to as ES6 (ECMAScript 2015) and beyond.

---

## 3. Core Concepts

### Variables and Scope

-   **`var`**: The original variable declaration. It is function-scoped and has some quirky behaviors (like hoisting). Its use is generally discouraged in modern JavaScript.
-   **`let`**: A block-scoped variable. This is the preferred way to declare a variable that is expected to change its value.
-   **`const`**: A block-scoped constant. The value cannot be reassigned after declaration. This is the preferred default for all variable declarations unless you know the value will need to change.

### Functions

-   **Function Declaration**: The classic `function myFunction() { ... }` syntax.
-   **Arrow Functions**: The modern, concise `() => { ... }` syntax. Arrow functions are lexically scoped, meaning they inherit the `this` value from their surrounding context, which is a very useful feature.

### Arrays and Objects

-   **Destructuring**: A shorthand syntax for extracting values from arrays or objects into distinct variables.
-   **Spread (`...`) Operator**: Expands an iterable (like an array or object) into its individual elements. Useful for creating copies or combining arrays/objects.
-   **Rest (`...`) Operator**: Collects multiple elements into a single array. Often used in function parameters.
-   **Array Methods**: Modern JavaScript has powerful, functional methods for working with arrays:
    -   `map()`: Creates a new array by applying a function to each element.
    -   `filter()`: Creates a new array with all elements that pass a test.
    -   `reduce()`: Executes a reducer function on each element, resulting in a single output value.

### Asynchronous JavaScript

JavaScript is single-threaded, meaning it can only do one thing at a time. To handle long-running operations like network requests without freezing the browser, JavaScript uses an asynchronous, non-blocking model.

1.  **Callbacks**: The original way to handle async operations. A function is passed as an argument to another function, to be "called back" when the operation completes. This can lead to "callback hell" (deeply nested callbacks).
2.  **Promises**: An object that represents the eventual completion (or failure) of an asynchronous operation. They allow you to chain `then()` and `catch()` methods for cleaner async code.
3.  **`async/await`**: Modern "syntactic sugar" on top of Promises. It lets you write asynchronous code that *looks* and *behaves* like synchronous code, making it much easier to read and reason about.

### ES6 Modules

-   **`export`**: Used to export functions, objects, or primitives from a given file (a "module").
-   **`import`**: Used to import the exported values into another module. This is the foundation of modern, modular JavaScript development.

---

## 4. Deliberate Practice

1.  **`let` vs `const`**: Write a piece of code that demonstrates the difference between `let` and `const`.
2.  **Arrow Functions**: Refactor a traditional `function` into an arrow function.
3.  **Array Methods**: Given an array of numbers, use `filter` to get the even numbers, and then use `map` to square them.
4.  **Destructuring**: Create an object representing a user. Use destructuring to pull out the `name` and `email` properties into variables.
5.  **`async/await`**: Use the `fetch` API with `async/await` to get data from a public API (e.g., the [JSONPlaceholder API](https://jsonplaceholder.typicode.com/)) and log it to the console.

---

## 5. Active Recall Questions

-   What is the difference between `let` and `const`?
-   What is a major benefit of arrow functions regarding the `this` keyword?
-   What does the `map` array method do?
-   What problem does `async/await` solve?
-   What is the purpose of the `import` and `export` keywords?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Console**: The JavaScript console in your browser's developer tools is the best place to quickly test and experiment with JavaScript code.
-   **Node.js**: A JavaScript runtime that allows you to run JavaScript code outside of a browser, essential for backend development.
-   **Code Editors**: VS Code has excellent, built-in support for modern JavaScript, including syntax highlighting, linting, and debugging.
-   **Babel**: A tool that transpiles modern JavaScript (ES6+) into older versions (ES5) so that it can run on older browsers that don't support the new features.

---

## 7. Feedback and Self-Assessment

-   **Linting**: Use a linter like ESLint to enforce modern best practices, such as preferring `const` over `let` and avoiding `var`.
-   **Refactoring**: Look at older JavaScript code (pre-ES6). How would you refactor it to use modern features like arrow functions, `let`/`const`, and template literals?
-   **Promise Hell?**: While `async/await` is cleaner, it's crucial to understand the Promises they are built on. Ensure you understand how `.then()` and `.catch()` work.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Fetching and Displaying Data
-   You need to fetch a list of users from an API and display their names in a list on a webpage.
-   **Step 1 (Async)**: Use `fetch` with `async/await` to get the user data. This is an asynchronous operation.
-   **Step 2 (Data Manipulation)**: The API returns an array of user objects. Use the `map` method to create a new array containing only the `name` of each user.
-   **Step 3 (DOM Manipulation)**: For each name in your new array, create a list item (`<li>`) and add it to the page. (This is covered in the next module).

This demonstrates how modern JavaScript features work together to handle a very common web development task.

---

## 9. Collaborative Activities

-   **Code Review**: Review a peer's solution to the `async/await` practice problem. Did they handle potential errors with a `try...catch` block?
-   **Functional Chaining**: As a group, take a complex data manipulation task and try to solve it in a single chain of `filter`, `map`, and `reduce` calls.

---

## 11. Psychological and Cognitive Principles

-   **Declarative vs. Imperative**: Functional array methods like `map` and `filter` are more **declarative** (you describe *what* you want) than a traditional `for` loop, which is **imperative** (you describe *how* to do it). Declarative code is often more concise and easier to reason about.
-   **Syntactic Sugar**: Features like `async/await` and destructuring are "syntactic sugar". They don't introduce new fundamental capabilities, but they provide a much nicer and more readable syntax for existing ones.

---

## 12. Summary and Mastery Checklist

-   [ ] I use `let` and `const` for variable declarations and understand their scope.
-   [ ] I can write and use arrow functions.
-   [ ] I can use `map`, `filter`, and `reduce` to process arrays.
-   [ ] I can use `async/await` to handle asynchronous operations.
-   [ ] I understand the basics of ES6 modules for organizing my code.

---

## 13. Research and References

-   **MDN Web Docs - JavaScript Guide**: [Link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide)
-   **"Eloquent JavaScript" by Marijn Haverbeke**: A comprehensive and highly-respected book on the language. Available online for free.
-   **JavaScript.info**: An excellent, modern tutorial that covers everything from the basics to advanced topics. [Link](https://javascript.info/)
-   **ES6 for Everyone by Wes Bos**: A popular and highly-rated video course for learning modern JavaScript.
