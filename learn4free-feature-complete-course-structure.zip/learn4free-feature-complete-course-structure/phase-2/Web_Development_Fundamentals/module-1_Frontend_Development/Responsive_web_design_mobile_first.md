# Responsive Web Design and Mobile-First Approach

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** responsive web design (RWD).
-   **Explain** the "mobile-first" design philosophy and its benefits.
-   **Implement** CSS Media Queries to apply different styles based on screen size.
-   **Use** a fluid grid and flexible images to create adaptable layouts.
-   **Understand** the role of the viewport meta tag.
-   **Debug and test** responsive layouts using browser developer tools.

---

## 2. Introduction to Responsive Web Design

In the modern web, users access websites on a vast array of devices, from small mobile phones to large desktop monitors. **Responsive Web Design (RWD)** is an approach that makes your web pages render well on all of these devices. A responsive site automatically adapts its layout to the viewing environment by using fluid grids, flexible images, and CSS media queries. This ensures a good user experience, regardless of the device being used.

---

## 3. Core Concepts

### The Three Pillars of RWD

1.  **Fluid Grids**: Instead of using fixed-width layouts (e.g., `width: 960px`), responsive designs use relative units like percentages (`%`) or viewport units (`vw`) for widths. This allows the layout to expand and contract with the screen size. Both Flexbox and Grid are inherently fluid layout systems.

2.  **Flexible Images**: Images should also be able to scale within their containing element. A common technique is to use `max-width: 100%;` and `height: auto;` to ensure that an image never overflows its container.

3.  **Media Queries**: Media queries are the heart of RWD. They are a feature of CSS3 that allows you to apply a block of CSS styles only if a certain condition is true. The most common condition is the width of the viewport.

### The Viewport Meta Tag

For RWD to work correctly on mobile devices, you must include the viewport meta tag in the `<head>` of your HTML document.

`<meta name="viewport" content="width=device-width, initial-scale=1.0">`

-   `width=device-width`: This tells the browser to set the width of the viewport to the width of the device's screen.
-   `initial-scale=1.0`: This sets the initial zoom level when the page is first loaded.

Without this tag, mobile browsers will "lie" about their width (typically reporting 980px) and zoom out to show the desktop layout, forcing the user to zoom in and pan around.

### The Mobile-First Approach

This is a design and development philosophy that advocates for starting your design process with the mobile version of the site first, and then progressively enhancing it for larger screens.

-   **Why?**
    1.  **Forces Prioritization**: The small screen of a mobile device forces you to focus on the most important content and features.
    2.  **Better Performance**: Mobile users are often on slower connections. A mobile-first approach encourages you to load only the essential CSS and JavaScript, leading to faster load times.
    3.  **Easier CSS**: It's generally easier to add complexity to a simple layout (for desktop) than it is to simplify a complex layout (for mobile). Your media queries will use `min-width` and build on top of the base mobile styles.

**CSS Example (Mobile-First):**
```css
/* Base styles for mobile */
.container {
    width: 100%;
}

/* Styles for tablets and larger */
@media (min-width: 768px) {
    .container {
        width: 80%;
        margin: 0 auto;
    }
}

/* Styles for desktops and larger */
@media (min-width: 1024px) {
    .container {
        display: flex;
    }
}
```

---

## 4. Deliberate Practice

1.  **Make an Existing Layout Responsive**: Take the "holy grail" layout you built with CSS Grid in the previous module. Write media queries to make it adapt:
    -   On mobile, the sidebars and main content should stack vertically, each taking up 100% of the width.
    -   On desktop, they should be in their multi-column layout.
2.  **Responsive Image Gallery**: Create a gallery of images. On desktop, they should appear in a 3-column grid. On mobile, they should be in a single column.
3.  **Mobile-First Menu**: Design a navigation bar. On desktop, it's a horizontal list of links. On mobile, the links are hidden behind a "hamburger" menu icon. (This will require a small amount of JavaScript to toggle the menu's visibility, which is covered in a later module).

---

## 5. Active Recall Questions

-   What are the three main components of responsive web design?
-   What does the viewport meta tag do?
-   Explain the "mobile-first" approach.
-   What is the CSS syntax for a media query that applies styles to screens wider than 800px?
-   What is the difference between using a fixed unit like `px` for width and a relative unit like `%`?

---

## 6. Tools, Frameworks, and Platforms

-   **Browser Developer Tools (Device Mode)**: This is the most important tool for RWD. All modern browsers have a "Device Mode" or "Responsive Design Mode" that lets you instantly see how your site looks on different screen sizes and simulate various mobile devices.
-   **CSS Frameworks**: Frameworks like Bootstrap and Tailwind CSS have responsive design built into their core. They provide utility classes that make it very fast to build responsive layouts (e.g., `<div class="col-md-6 col-sm-12">`).

---

## 7. Feedback and Self-Assessment

-   **Test on Real Devices**: While device mode in the browser is great, it's not a perfect simulation. Always test your responsive designs on actual physical devices (your phone, a tablet) if possible.
-   **Content-Driven Breakpoints**: Don't just pick arbitrary screen widths for your media query breakpoints (e.g., 320px, 768px, 1024px). Instead, let your content determine the breakpoints. Resize your browser window and, at the point where your layout starts to look bad or "break", add a media query to fix it.
-   **Performance**: Are you loading large, high-resolution images on mobile? You can use responsive image techniques (`<picture>` element, `srcset` attribute) to serve smaller images to smaller devices.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A news website's article page.
-   **Mobile**: A single-column layout is best. The heading, the main image, and the article text should flow vertically. This is optimized for reading on a narrow screen.
-   **Tablet**: You might introduce a two-column layout, with the article text on the left and a sidebar (`<aside>`) with related articles on the right.
-   **Desktop**: The layout might become three columns, adding an additional sidebar for advertisements or social media links.

This demonstrates how a mobile-first approach allows you to start with the core content (the article) and progressively add secondary content as screen space becomes available.

---

## 9. Collaborative Activities

-   **Responsive Refactor**: Find a non-responsive website from the early 2000s. As a group, discuss and implement a strategy to make it responsive using modern CSS.
-   **Breakpoint Debate**: For a given design, discuss as a group where the most logical media query breakpoints should be placed and why.

---

## 11. Psychological and Cognitive Principles

-   **Constraints Foster Creativity**: The constraints of a small mobile screen force you to make important decisions about your content hierarchy and user interface. This often leads to a cleaner, more focused design that also benefits users on larger screens.
-   **Progressive Enhancement**: The mobile-first approach is a form of progressive enhancement. You start with a baseline experience that works for everyone (mobile), and then add enhancements for users who have more capable devices (larger screens).

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that RWD is about making websites work well on all screen sizes.
-   [ ] I can add the viewport meta tag to an HTML document.
-   [ ] I can write a CSS media query to target a specific range of screen widths.
-   [ ] I understand the mobile-first philosophy and can write CSS in that style (using `min-width`).
-   [ ] I can use my browser's developer tools to test and debug a responsive layout.

---

## 13. Research and References

-   **MDN Web Docs - Responsive design**: [Link](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)
-   **"Responsive Web Design" by Ethan Marcotte**: The original book that defined the term and the approach.
-   **Google Web Fundamentals - Responsive Web Design Basics**: [Link](https://developers.google.com/web/fundamentals/design-and-ux/responsive)
