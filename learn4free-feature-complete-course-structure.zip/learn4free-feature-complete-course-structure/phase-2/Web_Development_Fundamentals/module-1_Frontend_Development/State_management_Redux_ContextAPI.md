# State Management: Redux and Context API

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** "state" in the context of a frontend application.
-   **Differentiate** between local component state and global application state.
-   **Explain** the problem of "prop drilling" and why global state management is needed.
-   **Describe** the basic principles of React's Context API for sharing state.
-   **Explain** the core concepts of Redux: store, actions, and reducers.
-   **Understand** the unidirectional data flow of Redux.
-   **Compare** the use cases for Context API versus a full-featured library like Redux.

---

## 2. Introduction to State Management

In a component-based application, each component often has its own **local state**. For example, a form input might have state for its current value, or a "like" button might have a boolean state for `isLiked`. This is fine for simple cases. But what happens when multiple, deeply nested components all need to access and manipulate the same piece of data (e.g., the currently logged-in user)?

Passing this data through many layers of components via props is called **"prop drilling"**, and it can become very cumbersome. **Global state management** is the solution to this problem. It involves creating a central store for the application's shared state, which any component can access directly.

---

## 3. Core Concepts

### Local vs. Global State

-   **Local State**: Data that is only needed by a single component or a small group of related components. It is typically managed within that component (e.g., using `useState` in React).
-   **Global State**: Data that is needed by many components across the application. Examples include the current user, the theme (light/dark mode), or data in a shopping cart.

### React's Context API

The Context API is React's built-in solution for solving the prop drilling problem. It provides a way to pass data through the component tree without having to pass props down manually at every level.

-   **How it works**:
    1.  **`createContext`**: You create a `Context` object.
    2.  **`Provider`**: You wrap a high-level component (like your main `App` component) in the `Context.Provider`. The `Provider` has a `value` prop where you pass the data you want to share.
    3.  **`useContext`**: Any child component, no matter how deeply nested, can then use the `useContext` hook to subscribe to the context and get the shared data.

-   **Best For**: Simple to moderately complex global state that doesn't change too frequently, such as user authentication status or theme information.

### Redux

Redux is a popular, standalone library for managing application state. It is more complex than the Context API but provides a more predictable and scalable pattern for managing large and frequently updated state. Redux is based on three core principles:

1.  **Single Source of Truth**: The entire state of your application is stored in a single object tree within a single **store**.
2.  **State is Read-Only**: The only way to change the state is to dispatch an **action**, which is a plain JavaScript object describing what happened.
3.  **Changes are Made with Pure Functions**: To specify how the state tree is transformed by actions, you write pure **reducers**. A reducer is a function that takes the previous state and an action, and returns the next state.

### The Redux Data Flow (Unidirectional)

1.  **UI Event**: The user clicks a button.
2.  **`dispatch(action)`**: The UI dispatches an action object (e.g., `{ type: 'ADD_ITEM', payload: 'milk' }`).
3.  **Reducer**: The `store` calls the `reducer` with the current state and the action. The reducer calculates the new state and returns it.
4.  **Store Update**: The `store` saves the new state.
5.  **UI Update**: The UI is subscribed to the store and automatically re-renders to reflect the new state.

-   **Best For**: Complex, large-scale applications where many components interact with the same state, and the state changes frequently. It provides powerful developer tools and a strict, predictable pattern that is very useful in large teams.

---

## 4. Deliberate Practice

1.  **Prop Drilling**: Build a simple React app with a deeply nested component structure. Pass a piece of data from the top-level component all the way down to the lowest child via props to experience the pain of prop drilling.
2.  **Refactor with Context**: Take the app from the previous exercise and refactor it to use the Context API to share the data instead of passing props.
3.  **Redux To-Do List**: Follow a basic tutorial to build a to-do list application using Redux. Pay close attention to defining your actions (`ADD_TODO`) and writing the reducer logic.
4.  **Redux DevTools**: Install and use the Redux DevTools browser extension. Use its "time-travel" debugging feature to step back and forth through the actions that have changed your application's state.

---

## 5. Active Recall Questions

-   What is "prop drilling"?
-   What is the difference between local and global state?
-   What are the two main parts of the Context API that you use? (`Provider` and `useContext`).
-   What are the three core principles of Redux?
-   In Redux, what is the only way to change the state?

---

## 6. Tools, Frameworks, and Platforms

-   **React DevTools**: Helps you inspect the component tree and see which components are consuming a particular context.
-   **Redux DevTools**: An incredibly powerful browser extension for debugging Redux applications. It lets you see every action as it's dispatched, inspect the state before and after, and even "time-travel" by reverting actions.
-   **Redux Toolkit**: The official, recommended way to write Redux logic. It simplifies a lot of the boilerplate and encourages best practices.

---

## 7. Feedback and Self-Assessment

-   **Context vs. Redux**: When should you use Context and when should you use Redux?
    -   Use **Context** when you have low-frequency updates to simple state (e.g., theme, user info).
    -   Consider **Redux** when you have complex state logic or high-frequency updates, and when you would benefit from the powerful debugging capabilities of the Redux DevTools.
-   **Pure Reducers**: A Redux reducer *must* be a pure function. This means it cannot mutate its arguments, perform side effects (like API calls), or call non-pure functions. Is your reducer pure?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A Shopping Cart
-   The state of a shopping cart (the list of items, their quantities, the total price) is a classic example of global state.
-   A `ProductCard` component needs to be able to add an item to the cart.
-   A `Navbar` component needs to display the number of items in the cart.
-   A `ShoppingCartPage` component needs to display the full details of the cart.
-   All these components, which are in different parts of the component tree, need to share and manipulate the same piece of state. This makes it a perfect candidate for a global state management solution. For a simple cart, **Context API** would be sufficient. For a complex e-commerce site, **Redux** might be a better choice.

---

## 9. Collaborative Activities

-   **State Management Debate**: As a group, discuss the pros and cons of Context vs. Redux. When does the complexity of Redux become justified?
-   **Action/Reducer Design**: For a given feature (like a shopping cart), design the Redux actions and the structure of the reducer function on a whiteboard.

---

## 11. Psychological and Cognitive Principles

-   **Single Source of Truth**: The core idea behind global state management is to create a single, reliable source of truth. This makes your application's state predictable. You know that if the user data is in the store, it's the correct, up-to-date data. This eliminates a whole class of bugs related to inconsistent or out-of-sync state.
-   **Decoupling**: State management libraries decouple your components from each other. A `ProductCard` component doesn't need to know anything about the `Navbar`. It just dispatches an `ADD_TO_CART` action. The `Navbar` simply listens for changes to the cart state in the store.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the problem that global state management solves ("prop drilling").
-   [ ] I can use the React Context API to pass data down the component tree without using props.
-   [ ] I can describe the three main parts of Redux: the store, actions, and reducers.
-   [ ] I can explain the unidirectional data flow in Redux.
-   [ ] I can make an informed decision about when to use local state, Context, or Redux.

---

## 13. Research and References

-   **React Docs - Passing Data with Context**: [Link](https://react.dev/learn/passing-data-deeply-with-context)
-   **Redux Official Documentation**: [Link](https://redux.js.org/)
-   **Redux Toolkit Official Documentation**: [Link](https://redux-toolkit.js.org/)
-   **"Getting Started with Redux" by Dan Abramov (the creator of Redux)**: A fantastic video series.
