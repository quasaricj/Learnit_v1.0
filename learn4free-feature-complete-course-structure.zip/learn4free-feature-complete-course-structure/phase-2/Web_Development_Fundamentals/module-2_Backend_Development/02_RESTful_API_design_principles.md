# RESTful API Design Principles

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** what an API is and what REST stands for.
- **Explain** the six architectural constraints of REST.
- **Design** a logical and hierarchical API endpoint structure using nouns for resources.
- **Use** the correct HTTP verbs (GET, POST, PUT, DELETE) for different actions.
- **Understand** and use standard HTTP status codes to indicate the outcome of a request.
- **Structure** API responses using JSON.

---

## 2. Introduction to APIs and REST

An **API (Application Programming Interface)** is a set of rules and protocols that allows different software applications to communicate with each other. In web development, a **web API** is the interface that a backend server exposes for a frontend client to interact with. It defines the "endpoints" (URLs) that the client can request, the format of the data, and the operations that can be performed.

**REST (REpresentational State Transfer)** is an architectural style for designing networked applications. It is not a strict protocol, but a set of constraints that, when followed, lead to a web service that is scalable, reliable, and easy to use. An API that follows these principles is called a **RESTful API**.

---

## 3. The Six Constraints of REST

1.  **Client-Server Architecture**: The client (frontend) and the server (backend) are separated. The server manages data and logic, while the client manages the user interface. They communicate over a network.
2.  **Statelessness**: Each request from a client to a server must contain all the information needed to understand and complete the request. The server does not store any session state about the client between requests.
3.  **Cacheability**: Responses from the server should be defined as cacheable or non-cacheable. This allows the client to reuse old data for a certain period, improving performance.
4.  **Layered System**: The client should not be able to tell whether it is connected directly to the end server, or to an intermediary (like a load balancer or a cache) along the way.
5.  **Uniform Interface**: This is the most important constraint for API design and has four sub-constraints:
    -   **Identification of resources**: Resources are identified by a stable, unique URL (e.g., `/users/123`).
    -   **Manipulation of resources through representations**: The client receives a representation of the resource (e.g., a JSON object) and can modify it and send it back to the server.
    -   **Self-descriptive messages**: Each request and response should contain enough information to describe how to process it (e.g., using HTTP headers like `Content-Type: application/json`).
    -   **Hypermedia as the Engine of Application State (HATEOAS)**: Responses can include links to other related actions or resources, allowing the client to "discover" the API. (This is the least commonly implemented constraint).
6.  **Code on Demand (Optional)**: The server can temporarily extend the functionality of a client by transferring executable code (e.g., JavaScript).

---

## 4. Core Principles of RESTful API Design

### Use Nouns for Resources, Not Verbs

Your API endpoints should refer to "things" or resources, not actions. The action is conveyed by the HTTP method.
- **Good**: `/users`, `/products/42`, `/users/123/orders`
- **Bad**: `/getAllUsers`, `/createNewProduct`, `/deleteOrder/5`

### Use HTTP Verbs for Actions

The HTTP method you use to make the request should define the action you want to perform.

| Verb     | Action                                         | Example                             |
| -------- | ---------------------------------------------- | ----------------------------------- |
| **GET**  | Retrieve a resource or a collection of resources | `GET /users` (get all users)        |
|          |                                                | `GET /users/123` (get user 123)     |
| **POST** | Create a new resource                          | `POST /users` (create a new user)   |
| **PUT**  | Update/replace an existing resource entirely   | `PUT /users/123` (update user 123)  |
| **PATCH**| Partially update an existing resource          | `PATCH /users/123` (update one field)|
| **DELETE**| Delete a resource                              | `DELETE /users/123` (delete user 123)|

### Use Plural Nouns for Collections

It is a common convention to use plural nouns for your resource collections to keep the API consistent.
- `GET /products`
- `GET /products/42`
- `POST /products`

### Use HTTP Status Codes for Responses

The server should use standard HTTP status codes in its response to tell the client the outcome of its request.

- **`2xx` - Success**:
  - `200 OK`: Standard success response for a GET request.
  - `201 Created`: The request was successful, and a new resource was created (used for POST).
  - `204 No Content`: The request was successful, but there is no data to send back (used for DELETE).
- **`4xx` - Client Errors**:
  - `400 Bad Request`: The server could not understand the request (e.g., malformed JSON).
  - `401 Unauthorized`: The client is not authenticated.
  - `403 Forbidden`: The client is authenticated, but does not have permission to access this resource.
  - `404 Not Found`: The requested resource could not be found.
- **`5xx` - Server Errors**:
  - `500 Internal Server Error`: A generic error indicating something went wrong on the server.

---

## 5. Deliberate Practice

1.  **Design a Blog API**: On paper or in a text file, design the RESTful API endpoints for a simple blog application. Define the endpoints and the HTTP verbs for the following actions:
    -   Get all posts.
    -   Get a single post by its ID.
    -   Create a new post.
    -   Update a post.
    -   Delete a post.
    -   Get all comments for a specific post.
2.  **Implement API Routes**: Take your "Hello World" backend server from the previous module. Implement the routes you just designed. For now, you don't need a database; you can just use an in-memory array of objects.
3.  **Use a REST Client**: Use a tool like Postman, Insomnia, or the `curl` command to make requests to your new API endpoints. Verify that each verb performs the correct action and that your server returns the correct status codes and JSON data.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that REST is an architectural style for building APIs.
-   [ ] I can name at least 3 of the 6 REST constraints (Client-Server, Stateless, Uniform Interface).
-   [ ] I design my API endpoints using plural nouns for resources (e.g., `/users`).
-   [ ] I use the correct HTTP verbs for CRUD operations (GET, POST, PUT, DELETE).
-   [ ] I can name at least one `2xx`, one `4xx`, and one `5xx` HTTP status code and explain what they mean.

---

## 7. Research and References

-   **"Architectural Styles and the Design of Network-based Software Architectures"**: The original dissertation by Roy Fielding that defined REST. It is very academic but foundational.
-   **REST API Tutorial**: A great website that explains the core concepts in a very clear way. [Link](https://www.restapitutorial.com/)
-   **MDN Web Docs - An overview of HTTP**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview)
-   **Postman**: An essential tool for working with and testing APIs. [Link](https://www.postman.com/)
