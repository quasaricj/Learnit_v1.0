# HTTP Methods, Status Codes, and Headers

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** HTTP and its role as the foundation of communication on the web.
- **Differentiate** between the most common HTTP methods (verbs) and their semantics.
- **Explain** the concept of idempotency in the context of HTTP methods.
- **Categorize and interpret** the five main classes of HTTP status codes (1xx, 2xx, 3xx, 4xx, 5xx).
- **Describe** the purpose of HTTP headers in both requests and responses.
- **Identify and use** common headers like `Content-Type`, `Authorization`, and `Cache-Control`.

---

## 2. Introduction to HTTP

**HTTP (Hypertext Transfer Protocol)** is the protocol that governs communication between a client (like your web browser) and a server. It defines the format of the messages that are exchanged and the rules for how they should be handled. Every time you visit a website or your frontend application fetches data from an API, it is using HTTP.

An HTTP message consists of a start line, headers, and an optional body.

---

## 3. Core Concepts

### HTTP Methods (Verbs)

HTTP methods indicate the desired action to be performed on a resource.

- **`GET`**: Requests a representation of a specified resource. Should only be used to retrieve data.
  - **Safe**: `GET` requests should not have any side effects on the server.
- **`POST`**: Submits an entity to the specified resource, often causing a change in state or side effects on the server.
  - **Not Idempotent**: Sending the same `POST` request multiple times will likely create multiple new resources.
- **`PUT`**: Replaces the entire representation of the target resource with the request payload.
  - **Idempotent**: Sending the same `PUT` request multiple times will have the same effect as sending it once (the resource will be in the same final state).
- **`DELETE`**: Deletes the specified resource.
  - **Idempotent**: Deleting a resource multiple times has the same effect as deleting it once (it stays deleted).
- **`PATCH`**: Applies partial modifications to a resource.
  - **Not Idempotent**: A `PATCH` request to "add 10 to a value" will have a different result if sent twice.
- **`HEAD`**: Asks for a response identical to a `GET` request, but without the response body. Useful for checking if a resource exists before downloading it.
- **`OPTIONS`**: Describes the communication options for the target resource (e.g., which methods are supported).

### HTTP Status Codes

Status codes are issued by the server in response to a client's request. They are grouped into five classes:

- **`1xx` - Informational**: The request was received, and the process is continuing. (Rarely used in typical web development).
- **`2xx` - Success**: The action was successfully received, understood, and accepted.
  - `200 OK`: Standard success.
  - `201 Created`: A new resource was created.
  - `202 Accepted`: The request has been accepted for processing, but the processing has not been completed.
  - `204 No Content`: Success, but there is no body to return.
- **`3xx` - Redirection**: Further action must be taken in order to complete the request.
  - `301 Moved Permanently`: The requested URL has been permanently moved.
  - `302 Found`: The requested URL has been temporarily moved.
  - `304 Not Modified`: A cached response can be used.
- **`4xx` - Client Error**: The request contains bad syntax or cannot be fulfilled.
  - `400 Bad Request`: The server cannot or will not process the request due to a client error.
  - `401 Unauthorized`: Authentication is required and has failed or has not yet been provided.
  - `403 Forbidden`: The client does not have permission.
  - `404 Not Found`: The server cannot find the requested resource.
- **`5xx` - Server Error**: The server failed to fulfill an apparently valid request.
  - `500 Internal Server Error`: A generic error message.
  - `502 Bad Gateway`: The server was acting as a gateway or proxy and received an invalid response from the upstream server.
  - `503 Service Unavailable`: The server is not ready to handle the request (e.g., it is down for maintenance or overloaded).

### HTTP Headers

Headers are key-value pairs that carry additional information with HTTP requests and responses.

- **Request Headers**:
  - `Host`: The domain name of the server.
  - `User-Agent`: Information about the client (e.g., browser name and version).
  - `Accept`: The media types that are acceptable for the response (e.g., `application/json`).
  - `Content-Type`: The media type of the body of the request (e.g., `application/json`).
  - `Authorization`: Contains the credentials to authenticate a client with a server.

- **Response Headers**:
  - `Content-Type`: The media type of the response body.
  - `Content-Length`: The size of the response body in bytes.
  - `Cache-Control`: Directives for caching mechanisms in both requests and responses.
  - `Set-Cookie`: Sends a cookie from the server to the user agent.

---

## 4. Deliberate Practice

1.  **Inspect Network Traffic**:
    -   Open the "Network" tab in your browser's developer tools.
    -   Visit a website (e.g., https://github.com).
    -   Click on the main document request (the first one, usually the name of the site).
    -   Inspect the "Headers" section. Look at the request headers your browser sent and the response headers the server sent back.
2.  **Use a REST Client**:
    -   In a tool like Postman or Insomnia, make a `GET` request to a public API like `https://jsonplaceholder.typicode.com/posts/1`. Inspect the status code and response headers.
    -   Now, make a `POST` request to `/posts` with a JSON body. Observe the `201 Created` status code.
    -   Make a `DELETE` request to `/posts/1`. Observe the `200 OK` status code.
3.  **Set Headers**: In your REST client, try setting a custom `Accept` header in a request to `application/xml`. Observe how some servers might respond differently based on this header.

---

## 5. Summary and Mastery Checklist

-   [ ] I can name and describe the purpose of GET, POST, PUT, and DELETE.
-   [ ] I can explain that "idempotent" means performing an operation multiple times has the same result as performing it once.
-   [ ] I can recognize the five classes of HTTP status codes.
-   [ ] I know that `200` means OK, `201` means Created, `404` means Not Found, and `500` means Internal Server Error.
-   [ ] I can explain that headers provide meta-information about a request or response.
-   [ ] I know that the `Content-Type` header is used to specify the format of the request/response body (e.g., `application/json`).

---

## 6. Research and References

-   **MDN Web Docs - An overview of HTTP**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview) (The ultimate reference).
-   **"HTTP: The Definitive Guide" by David Gourley & Brian Totty**: A comprehensive, in-depth book on the protocol.
-   **HTTP Status Cats**: A fun way to learn the meaning of different status codes. [Link](https://http.cat/)
-   **IANA Media Types**: The official registry of all MIME types that can be used in the `Content-Type` header. [Link](https://www.iana.org/assignments/media-types/media-types.xhtml)
