# Authentication and Authorization (JWT, OAuth)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Differentiate** clearly between authentication and authorization.
- **Explain** how session-based authentication works.
- **Explain** how token-based authentication works.
- **Describe** the structure and purpose of a JSON Web Token (JWT).
- **Understand** the high-level concept of OAuth2 as a delegated authorization framework.
- **Implement** a basic protected route in a backend application.

---

## 2. Introduction: Securing Your Application

Once you have a backend server, a critical next step is to secure it. You need to ensure that only the right users can access and modify your data. This is handled by two related but distinct concepts: **authentication** and **authorization**.

- **Authentication (AuthN)**: This is the process of verifying who a user is. It's about identity. When you log in with a username and password, you are authenticating.
- **Authorization (AuthZ)**: This is the process of verifying what a user is allowed to do. It's about permissions. Just because you are an authenticated user doesn't mean you should be able to access the admin dashboard.

---

## 3. Core Concepts

### Session-Based Authentication (Traditional)

This is a stateful approach.
1.  **Login**: A user sends their credentials (e.g., username/password) to the server.
2.  **Verification**: The server verifies the credentials.
3.  **Session Creation**: If valid, the server creates a "session" and stores it in its own memory or database. It sends a unique session ID back to the client, usually in a cookie.
4.  **Subsequent Requests**: The client sends the session ID cookie with every subsequent request.
5.  **Lookup**: The server looks up the session ID to identify the user and check their permissions.
- **Pros**: Simple to understand.
- **Cons**: Does not scale well, as the server needs to store session data for every logged-in user.

### Token-Based Authentication (Modern & Stateless)

This is a stateless approach, common in modern APIs.
1.  **Login**: A user sends their credentials to the server.
2.  **Verification**: The server verifies the credentials.
3.  **Token Generation**: If valid, the server generates an encrypted, self-contained **token** and sends it to the client.
4.  **Client Storage**: The client stores this token (e.g., in `localStorage`).
5.  **Subsequent Requests**: The client sends the token with every subsequent request, usually in the `Authorization` header.
6.  **Server Verification**: The server decodes and verifies the token's signature on each request to identify the user. The server does not need to store anything.

### JSON Web Tokens (JWT)

JWT (pronounced "jot") is the most popular format for tokens. A JWT is a compact, URL-safe string that consists of three parts separated by dots:

`header.payload.signature`

1.  **Header**: Contains metadata about the token, like the hashing algorithm used.
2.  **Payload**: Contains the "claims" or data about the user (e.g., `userId`, `username`, `roles`). This is readable by anyone, so you should **never** put sensitive information in the payload.
3.  **Signature**: This is a cryptographic signature. It is created by the server using the header, the payload, and a secret key. This is how the server verifies that the token has not been tampered with.

### OAuth2

OAuth2 is not an authentication protocol; it is a **delegated authorization framework**. It allows a user to grant a third-party application limited access to their resources on another service, without exposing their credentials.

- **Analogy**: "Login with Google". When you use this feature on a third-party site:
  1.  The site (the "Client") redirects you to Google (the "Authorization Server").
  2.  You authenticate with Google and are asked if you want to grant the site permission to access your basic profile info.
  3.  If you agree, Google sends an **authorization code** back to the site.
  4.  The site then exchanges this code with Google for an **access token**.
  5.  The site can now use this access token to make API requests to Google to get your profile information.

You never gave the third-party site your Google password. You delegated authorization to it.

---

## 4. Deliberate Practice

1.  **Password Hashing**: When storing user passwords in a database, you must **never** store them in plain text. Use a library like `bcrypt` to "hash" the passwords before saving them. Implement a simple user registration function that hashes the password.
2.  **JWT Implementation**:
    -   Create a `/login` route in your backend application.
    -   If the user's credentials are valid, generate a JWT containing their user ID.
    -   Send the JWT back to the client.
3.  **Create a Protected Route**:
    -   Create a new route, for example, `/api/profile`.
    -   Create a "middleware" function that checks for a valid JWT in the `Authorization` header of the request.
    -   If the token is valid, allow the request to proceed to the profile route.
    -   If the token is missing or invalid, send back a `401 Unauthorized` status code.
4.  **Use a REST Client**: Use Postman to test your flow. First, hit the `/login` endpoint to get a token. Then, copy that token and use it in the `Authorization` header (as a "Bearer Token") to access your protected `/api/profile` route.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that **authentication** is about verifying identity, and **authorization** is about verifying permissions.
-   [ ] I can describe the difference between stateful (session-based) and stateless (token-based) authentication.
-   [ ] I know that a JSON Web Token (JWT) is a common format for stateless authentication tokens.
-   [ ] I understand that I must never store passwords in plain text and should use a hashing library like bcrypt.
-   [ ] I can explain the high-level idea of OAuth2 ("Login with Google").
-   [ ] I understand that protected API routes should check for a valid token and return a 401 status if it's missing or invalid.

---

## 6. Research and References

-   **JWT.io**: The official website for JSON Web Tokens, with a great debugger tool. [Link](https://jwt.io/)
-   **The OAuth 2.0 Authorization Framework**: The official specification (RFC 6749). It is very dense.
-   **"An Illustrated Guide to OAuth and OpenID Connect"**: A much more accessible explanation of OAuth2. [Link](https://www.oauth.com/oauth2-servers/background/an-illustrated-guide/)
-   **bcrypt**: A popular and highly secure password hashing function. Libraries are available for every major language.
