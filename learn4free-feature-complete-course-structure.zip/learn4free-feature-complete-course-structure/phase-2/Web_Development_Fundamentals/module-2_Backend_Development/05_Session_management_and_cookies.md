# Session Management and Cookies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a web session and explain why it is needed.
- **Explain** the purpose of cookies and how they work.
- **Differentiate** between session cookies and persistent cookies.
- **Set and read** cookies from a backend server.
- **Describe** common cookie attributes like `HttpOnly`, `Secure`, and `SameSite`.
- **Understand** the security implications of using cookies for session management.

---

## 2. Introduction to Sessions and Cookies

HTTP is a **stateless** protocol. This means that each request from a client to a server is treated as an independent event. The server has no built-in memory of previous requests from the same client.

This is a problem for applications that need to maintain a continuous interaction with a user, such as an e-commerce site where a user adds items to a shopping cart. A **session** is the mechanism used to create a "stateful" experience over the stateless HTTP protocol. It's a way for the server to remember a user across multiple requests.

**Cookies** are the most common technology used to implement sessions.

---

## 3. Core Concepts

### Cookies

A **cookie** is a small piece of data that a server sends to a user's web browser. The browser then stores the cookie and sends it back to the same server with every subsequent request.

- **How it works**:
  1.  The server includes a `Set-Cookie` header in an HTTP response.
  2.  The browser receives the response and stores the cookie.
  3.  On every future request to that same server, the browser includes the stored cookie in a `Cookie` header.

### Session Management with Cookies

This is the classic way to manage user sessions:
1.  A user logs in.
2.  The server creates a session for that user and stores it on the server-side (in memory, a cache, or a database).
3.  The server generates a unique, random, and long **Session ID**.
4.  The server sends this Session ID back to the client in a `Set-Cookie` header.
5.  The browser stores this Session ID.
6.  On all future requests, the browser sends the Session ID cookie back to the server.
7.  The server uses the Session ID to look up the user's session data and identify the user.

**Important**: The cookie itself does not contain the user's data (like their username). It only contains a random identifier that *points* to the user's data on the server.

### Cookie Attributes

When setting a cookie, the server can include several attributes to control its behavior and security.

- `Expires` or `Max-Age`:
  - If these are set, the cookie is a **persistent cookie** and will be stored on the user's disk until the expiration date.
  - If they are not set, the cookie is a **session cookie** and will be deleted when the browser is closed.
- `HttpOnly`:
  - This is a critical security attribute. If a cookie is marked as `HttpOnly`, it **cannot be accessed by client-side JavaScript** (`document.cookie`).
  - This helps to mitigate Cross-Site Scripting (XSS) attacks, where an attacker could try to steal a session cookie.
- `Secure`:
  - If a cookie is marked as `Secure`, the browser will only send it over an HTTPS connection.
  - This prevents the cookie from being intercepted in a man-in-the-middle attack on an insecure network.
- `SameSite`:
  - This attribute helps to mitigate Cross-Site Request Forgery (CSRF) attacks.
  - It controls whether a cookie is sent with requests initiated from third-party domains.
  - `SameSite=Strict` or `SameSite=Lax` are the recommended values.

### Cookies vs. Local Storage for Tokens

When using token-based authentication (like JWTs), you have a choice of where to store the token on the client-side:

- **Local Storage**:
  - **Pros**: Easy to use.
  - **Cons**: Accessible by any JavaScript running on your site, making it vulnerable to XSS attacks. If an attacker can inject a script onto your page, they can steal the token.
- **Cookies**:
  - **Pros**: If you use `HttpOnly` and `Secure` cookies, you can largely protect the token from being stolen by XSS or network sniffing. The browser handles sending the token automatically.
  - **Cons**: Vulnerable to CSRF attacks if you don't use the `SameSite` attribute correctly.

For security reasons, storing session tokens in a well-configured **`HttpOnly`, `Secure`, `SameSite` cookie is generally considered the best practice**.

---

## 4. Deliberate Practice

1.  **Set a Cookie**: In your backend application, create a simple route (e.g., `/set-cookie`) that sends a `Set-Cookie` header in the response.
2.  **Read a Cookie**: Create another route (e.g., `/read-cookie`) that reads the `Cookie` header from the request and displays the value of the cookie you set.
3.  **Use a Library**: Most backend frameworks have libraries to make session management easier (e.g., `express-session` for Express). Implement a simple session-based view counter: every time a user visits a page, a counter stored in their session is incremented.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that HTTP is stateless and that sessions are a way to create a stateful experience.
-   [ ] I can describe the role of a cookie in session management.
-   [ ] I know that the session cookie should only contain a random ID, not the actual session data.
-   [ ] I can explain the purpose of the `HttpOnly` and `Secure` cookie attributes and why they are important for security.
-   [ ] I understand the security trade-offs between storing tokens in local storage versus cookies.

---

## 6. Research and References

-   **MDN Web Docs - HTTP Cookies**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Cookies)
-   **OWASP Cheat Sheet - Session Management**: [Link](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html) (An essential security resource).
-   **"Stop using JWT for sessions"**: A series of blog posts that go into detail about the security of token-based sessions.
