# Server Architecture and Request Handling

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Describe** the basic components of a typical web server architecture.
- **Explain** the concept of a request handling pipeline (or middleware chain).
- **Differentiate** between single-threaded and multi-threaded server models.
- **Understand** the role of a process manager in a Node.js application.
- **Grasp** the concept of Model-View-Controller (MVC) as a design pattern for server applications.
- **Explain** why environment variables are used for configuration.

---

## 2. Introduction to Server Architecture

A simple "Hello World" server runs in a single process. A real-world, production-ready web application, however, is a more complex system with multiple components working together to handle requests efficiently, reliably, and securely. **Server architecture** is the high-level structure of this system. Understanding these architectural concepts is key to building applications that can scale and be maintained over time.

---

## 3. Core Concepts

### The Request Handling Pipeline (Middleware)

In most modern backend frameworks (like Express, Django, and ASP.NET Core), an incoming HTTP request does not go directly to a single function. Instead, it passes through a **pipeline** or a **chain of middleware**.

- **Middleware**: A piece of software that is executed on an incoming request before it reaches the final route handler. Each piece of middleware can:
  1.  Execute any code.
  2.  Make changes to the request and response objects.
  3.  End the request-response cycle.
  4.  Call the *next* middleware in the chain.

- **Common Middleware Functions**:
  - **Logging**: Log details about every incoming request.
  - **Authentication**: Check for a valid session token and attach the user to the request object.
  - **Body Parsing**: Parse the incoming request body (e.g., from a JSON string into an object).
  - **CORS**: Handle Cross-Origin Resource Sharing headers.
  - **Error Handling**: A final piece of middleware to catch any errors that occurred in the previous steps.

This pattern is extremely powerful as it allows you to compose your request handling logic from small, reusable, and independent pieces.

### Concurrency Models

How does a server handle multiple requests at the same time?

- **Multi-threaded (e.g., Java/Spring, Apache)**:
  - The server maintains a "thread pool".
  - Each incoming request is assigned to a thread from the pool.
  - This thread handles the entire request from start to finish. If the request involves waiting for a database, the thread is "blocked" and cannot do anything else.
  - **Pros**: Simple to reason about.
  - **Cons**: Threads consume a lot of memory. Can be inefficient if many threads are blocked waiting for I/O.

- **Single-threaded, Event-driven (e.g., Node.js)**:
  - The server has a single main thread and an **event loop**.
  - When a request comes in, it's handled on the main thread.
  - If the request involves a slow I/O operation (like a database query), the server **does not wait**. It offloads the operation to a separate worker pool and registers a callback.
  - The single main thread is now free to handle another request.
  - When the I/O operation is complete, the event loop picks up the callback and executes it.
  - **Pros**: Highly memory efficient and excellent at handling many concurrent I/O-bound operations.
  - **Cons**: Complex, long-running CPU-bound tasks can block the single main thread and make the entire server unresponsive.

### Process Managers (for Node.js)

Because a Node.js server runs on a single thread, it cannot take advantage of multi-core CPUs. A **process manager** (like `pm2` or `cluster`) is a tool that allows you to run multiple instances (a "cluster") of your Node.js application, one on each CPU core. The process manager also handles things like restarting your application if it crashes.

### Model-View-Controller (MVC)

MVC is a mature architectural pattern for separating the concerns in an application.
- **Model**: The data and business logic of the application. It is responsible for interacting with the database.
- **View**: The user interface. In the context of a modern API, the "view" is often the JSON representation of a resource.
- **Controller**: Receives the user's input (the HTTP request), interacts with the Model to perform actions, and then selects a View to render the response.

This separation makes the application more organized, easier to test, and simpler to maintain. Frameworks like Django, Ruby on Rails, and ASP.NET MVC are heavily based on this pattern.

### Configuration Management

You should never hard-code configuration values like database passwords or API keys into your application code. This is a major security risk. Instead, you should use **environment variables**.
- An environment variable is a key-value pair that is set in the operating system where your application is running.
- Your application reads these values at startup.
- This allows you to have different configurations for different environments (development, testing, production) without changing your code.

---

## 4. Summary and Mastery Checklist

-   [ ] I can describe a request handling pipeline and the concept of middleware.
-   [ ] I can name at least two common tasks that are handled by middleware (e.g., logging, authentication).
-   [ ] I can explain the high-level difference between a multi-threaded server model and Node.js's single-threaded event loop model.
-   [ ] I can explain the purpose of the Model, View, and Controller in the MVC pattern.
-   [ ] I understand that I should use environment variables for configuration and never hard-code secrets.

---

## 5. Research and References

-   **Express.js Docs - Writing middleware**: [Link](https://expressjs.com/en/guide/writing-middleware.html)
-   **"Node.js Design Patterns" by Mario Casciaro and Luciano Mammino**: An excellent book that covers architectural patterns in depth.
-   **MDN Web Docs - Introduction to MVC**: [Link](https://developer.mozilla.org/en-US/docs/Glossary/MVC)
-   **The Twelve-Factor App**: A methodology for building modern, scalable web applications. The section on configuration is a must-read. [Link](https://12factor.net/config)
-   **PM2 Official Website**: [Link](https://pm2.keymetrics.io/)
