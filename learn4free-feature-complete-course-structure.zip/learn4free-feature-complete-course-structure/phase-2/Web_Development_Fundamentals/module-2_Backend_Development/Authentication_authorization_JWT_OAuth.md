# Authentication and Authorization (JWT, OAuth)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Differentiate** clearly between Authentication and Authorization.
-   **Explain** how session-based authentication works.
-   **Define** token-based authentication and its benefits in a stateless API context.
-   **Describe** the structure of a JSON Web Token (JWT).
-   **Implement** a basic login flow that returns a JWT to the client.
-   **Define** OAuth 2.0 and explain the problem it solves (delegated access).
-   **Differentiate** between the roles in an OAuth flow (Resource Owner, Client, Authorization Server, Resource Server).

---

## 2. Introduction to Security Concepts

In any application that has user accounts, two fundamental security concepts come into play: **Authentication** and **Authorization**. While they sound similar, they serve very different purposes. Understanding this difference is the first step toward building secure systems. Modern web applications typically handle these concepts using token-based systems like JWT or protocols like OAuth 2.0.

---

## 3. Core Concepts

### Authentication vs. Authorization

-   **Authentication (AuthN)**: The process of verifying **who you are**. When you enter your username and password on a login form, you are authenticating. You are proving your identity.
-   **Authorization (AuthZ)**: The process of verifying **what you are allowed to do**. Once you are authenticated, the system needs to check if you have permission to access a specific resource or perform an action. For example, a regular user might not be authorized to access the admin dashboard.

**Analogy**: Authentication is showing your ID to get into a building. Authorization is having the correct security clearance to open specific doors inside that building.

### Session-Based Authentication (Stateful)

-   **How it works**:
    1.  The user logs in with their credentials.
    2.  The server verifies the credentials and creates a "session" in its database, assigning it a unique Session ID.
    3.  The server sends this Session ID back to the browser, which stores it in a cookie.
    4.  On every subsequent request, the browser automatically sends the cookie. The server looks up the Session ID in its database to identify the user.
-   **Drawback**: This is a **stateful** approach. The server must store session information for every logged-in user, which can be a problem for scalability.

### Token-Based Authentication (Stateless) with JWT

This is the standard approach for modern, stateless REST APIs.

-   **How it works**:
    1.  The user logs in with their credentials.
    2.  The server verifies the credentials and generates a **JSON Web Token (JWT)**.
    3.  The JWT is a self-contained, digitally signed string that contains user information (like their ID and role).
    4.  The server sends this JWT back to the client.
    5.  The client stores the JWT (typically in local storage) and sends it with every subsequent request in the `Authorization` header.
    6.  The server can verify the signature of the JWT to trust the information within it, without needing to look up anything in a database.

-   **Structure of a JWT**: A JWT consists of three parts separated by dots (`.`):
    1.  **Header**: Contains the algorithm used to sign the token.
    2.  **Payload**: Contains the actual data ("claims"), such as the user ID, username, and an expiration date.
    3.  **Signature**: A cryptographic signature that the server uses to verify that the token has not been tampered with.

### OAuth 2.0 (Delegated Access)

OAuth 2.0 is not about authentication; it's an **authorization framework**. It solves the problem of a third-party application needing to access a user's data on another service, without the user having to share their password.

-   **The Problem**: Imagine a "Print my Photos" app wants to access your photos on Google Photos. You don't want to give that app your Google password.
-   **The Solution (OAuth Flow)**:
    1.  The "Print my Photos" app (the **Client**) asks for your permission to access your photos.
    2.  It redirects you to Google's login page (the **Authorization Server**).
    3.  You (the **Resource Owner**) log in to Google and grant permission.
    4.  Google gives the "Print my Photos" app an **Access Token**.
    5.  The app can now use this Access Token to make API calls to the Google Photos server (the **Resource Server**) to retrieve your photos. The token is limited in scope (e.g., it can only read photos, not delete them) and time.

---

## 4. Deliberate Practice

1.  **Decode a JWT**: Go to the website [jwt.io](https://jwt.io). Look at the example encoded token. Can you see the three parts? Can you read the JSON in the payload?
2.  **Implement a Login Endpoint**: In your backend application, create a `/login` endpoint.
    -   It should accept a username and password in the request body.
    -   For now, you can just hardcode a correct username/password combination.
    -   If the login is successful, use a JWT library to generate a token containing the user's ID and send it back to the client.
3.  **Implement a Protected Route**: Create another endpoint, `/api/profile`, that requires authentication.
    -   The client must send a JWT in the `Authorization: Bearer <token>` header.
    -   Your server should have "middleware" that checks for this header, verifies the token's signature, and extracts the user ID from the payload. If the token is invalid or missing, it should return a `401 Unauthorized` error.

---

## 5. Active Recall Questions

-   What is the difference between Authentication and Authorization?
-   What is the main drawback of session-based authentication?
-   What are the three parts of a JWT?
-   In a token-based system, where does the client send the token on each request?
-   What problem does OAuth 2.0 solve?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: "Log in with Google"
-   This is a feature that combines authentication and authorization, often using protocols like OpenID Connect (OIDC) built on top of OAuth 2.0.
-   **Authentication**: By logging into Google, you are proving your identity to your application.
-   **Authorization**: You are authorizing the application to access certain information from your Google profile (like your name and email address).
-   The application receives a token from Google, which it can use to verify your identity and create an account for you in its own system.

---

## 11. Psychological and Cognitive Principles

-   **Trust**: Security is about establishing trust. A JWT's signature allows a server to trust the data contained within it, even though it came from an untrusted client, because only the server could have created that signature.
-   **Separation of Concerns**: OAuth is a great example of this. It separates the concern of authenticating the user from the concern of authorizing a third-party application.

---

## 12. Summary and Mastery Checklist

-   [ ] I can clearly explain the difference between AuthN and AuthZ.
-   [ ] I understand why token-based authentication is preferred for stateless REST APIs.
-   [ ] I can describe what a JWT is and what its three parts represent.
-   [ ] I know that the client must send the JWT in the `Authorization` header for protected routes.
-   [ ] I can explain that OAuth is about a user granting a third-party app access to their data on another service.

---

## 13. Research and References

-   **JWT.io**: The definitive resource for all things JWT.
-   **OAuth 2.0 Official Website**: [Link](https://oauth.net/2/)
-   **"An Illustrated Guide to OAuth and OpenID Connect"**: A very clear and visual explanation. [Link](https://www.oauth.com/oauth2-servers/background/an-illustrated-guide-to-oauth-and-openid-connect/)
-   **MDN Web Docs - Authentication**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Authentication)
