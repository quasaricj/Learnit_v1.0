# HTTP Methods, Status Codes, and Headers

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** HTTP as the protocol of the web.
-   **Describe** the structure of an HTTP request and response.
-   **List and explain** the most common HTTP methods (verbs): GET, POST, PUT, PATCH, DELETE.
-   **Identify** and **interpret** common HTTP status code ranges (1xx, 2xx, 3xx, 4xx, 5xx).
-   **Define** HTTP headers and their purpose.
-   **Inspect** the methods, status codes, and headers of a live network request using browser developer tools.
-   **Set** a custom header in an API response.

---

## 2. Introduction to HTTP

HTTP (HyperText Transfer Protocol) is the foundation of data communication for the World Wide Web. It is a **request-response protocol**, meaning that a client (like a web browser) sends a request to a server, and the server sends back a response. Every time you visit a website, download an image, or fetch data from an API, you are using HTTP. Understanding the components of an HTTP message is essential for web development.

---

## 3. Core Concepts

### The HTTP Message Structure

Both requests and responses have a similar structure:

1.  **Start-line**:
    -   *Request*: Contains the HTTP method, the URI (path), and the HTTP version. (e.g., `GET /users/123 HTTP/1.1`)
    -   *Response*: Contains the HTTP version, a status code, and a status message. (e.g., `HTTP/1.1 200 OK`)
2.  **Headers**: A set of key-value pairs that provide additional information about the request or response.
3.  **Blank Line**: A single blank line that separates the headers from the body.
4.  **Body (Optional)**: Contains the data being sent (e.g., JSON data in a POST request, or the HTML content in a response). GET requests do not have a body.

### HTTP Methods (Verbs)

As covered in the REST module, methods define the desired action to be performed on a resource.

-   **`GET`**: Requests a representation of the specified resource. Safe and idempotent.
-   **`POST`**: Submits an entity to the specified resource, often causing a change in state or side effects on the server. Not idempotent.
-   **`PUT`**: Replaces all current representations of the target resource with the request payload. Idempotent.
-   **`PATCH`**: Applies partial modifications to a resource. Not idempotent.
-   **`DELETE`**: Deletes the specified resource. Idempotent.
-   **`HEAD`**: Asks for a response identical to a GET request, but without the response body.
-   **`OPTIONS`**: Describes the communication options for the target resource (e.g., which methods are supported).

### HTTP Status Codes

Status codes are issued by a server in response to a client's request. They are grouped into five classes:

-   **`1xx Informational`**: The request was received, continuing process. (Rarely used in practice).
-   **`2xx Success`**: The request was successfully received, understood, and accepted.
    -   `200 OK`: Standard success response.
    -   `201 Created`: The request has been fulfilled and resulted in a new resource being created.
    -   `204 No Content`: The server successfully processed the request but is not returning any content.
-   **`3xx Redirection`**: Further action needs to be taken to complete the request.
    -   `301 Moved Permanently`: The requested resource has been assigned a new permanent URI.
    -   `302 Found`: The resource temporarily resides under a different URI.
-   **`4xx Client Error`**: The request contains bad syntax or cannot be fulfilled.
    -   `400 Bad Request`: The server cannot or will not process the request due to something that is perceived to be a client error.
    -   `401 Unauthorized`: The client must authenticate itself to get the requested response.
    -   `403 Forbidden`: The client does not have access rights to the content.
    -   `404 Not Found`: The server cannot find the requested resource.
-   **`5xx Server Error`**: The server failed to fulfill an apparently valid request.
    -   `500 Internal Server Error`: A generic error message, given when an unexpected condition was encountered.
    -   `503 Service Unavailable`: The server is not ready to handle the request (e.g., it's down for maintenance or overloaded).

### HTTP Headers

Headers let the client and the server pass additional information with an HTTP request or response.

-   **Request Headers**:
    -   `Host`: The domain name of the server.
    -   `User-Agent`: A string that lets servers identify the application, OS, vendor, and version of the requesting user agent.
    -   `Accept`: Informs the server about the types of data the client can understand (e.g., `application/json`).
    -   `Authorization`: Contains the authentication credentials for a client.
-   **Response Headers**:
    -   `Content-Type`: Indicates the media type of the resource in the body (e.g., `text/html`, `application/json`).
    -   `Cache-Control`: Directives for caching mechanisms in both requests and responses.
    -   `Set-Cookie`: Sends a cookie from the server to the user agent.

---

## 4. Deliberate Practice

1.  **Inspect Network Traffic**: Open your browser's developer tools and go to the "Network" tab. Visit any website (e.g., google.com).
    -   Click on the first request (the main document).
    -   Examine the "Headers" section. Find the Request Method, Status Code, and look at the various request and response headers.
2.  **Use Postman/Insomnia**: Make a `GET` request to a public API like `https://jsonplaceholder.typicode.com/posts/1`.
    -   Examine the status code and the response headers.
    -   Try to make a `POST` request to `/posts` with some JSON data in the body. Look at the response (it should be `201 Created`).
3.  **Set a Custom Header**: In your "Hello, World" backend application, modify one of your routes to set a custom response header (e.g., `X-Hello: World`). Verify that the header is present in the response using your browser or Postman.

---

## 5. Active Recall Questions

-   What are the two main parts of an HTTP message after the start-line?
-   What is the difference between `PUT` and `PATCH`?
-   What does a `201 Created` status code signify?
-   What is the difference between a `404` and a `500` error?
-   What is the purpose of the `Content-Type` response header?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A client-side `fetch` request.
```javascript
fetch('https://api.example.com/users', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer YOUR_TOKEN_HERE'
    },
    body: JSON.stringify({ name: 'John Doe' })
})
```
-   **Start-line (Implicit)**: The browser constructs `POST /users HTTP/1.1`.
-   **Headers**: We are explicitly setting the `Content-Type` to tell the server we are sending JSON, and the `Authorization` header to authenticate ourselves.
-   **Body**: We are sending a JSON string representing the new user.
-   **Expected Response**: A successful response would likely have a status of `201 Created` and a body containing the newly created user object with its server-assigned ID.

This shows how the concepts of methods, headers, and body all come together in a practical API call.

---

## 11. Psychological and Cognitive Principles

-   **Standardization**: HTTP is a well-defined standard (an RFC). This standardization is what allows any browser to talk to any web server. Relying on standards is a core principle of robust engineering.
-   **Clarity of Communication**: Using the correct HTTP methods and status codes makes your API's communication clear and self-documenting. A `404` status code is an unambiguous signal that the resource doesn't exist.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that HTTP is a request-response protocol.
-   [ ] I can name and describe the 5 main HTTP methods (GET, POST, PUT, PATCH, DELETE).
-   [ ] I can explain the general meaning of the 2xx, 4xx, and 5xx status code ranges.
-   [ ] I can explain the purpose of headers like `Content-Type` and `Authorization`.
-   [ ] I can use my browser's network inspector to view the details of an HTTP request.

---

## 13. Research and References

-   **MDN Web Docs - An overview of HTTP**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview) (The definitive web developer resource for HTTP).
-   **HTTP Status Cats**: A fun way to learn the different HTTP status codes. [Link](https://http.cat/)
-   **"High Performance Browser Networking" by Ilya Grigorik**: An in-depth book (available free online) that covers the technical details of HTTP and other networking protocols.
