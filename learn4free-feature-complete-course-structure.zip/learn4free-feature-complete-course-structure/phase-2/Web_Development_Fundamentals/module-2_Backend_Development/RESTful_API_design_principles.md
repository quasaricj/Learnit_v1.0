# RESTful API Design Principles

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** what an API is and what REST stands for.
-   **Explain** the six guiding constraints of a RESTful architecture.
-   **Design** a logical and hierarchical resource URI.
-   **Use** the correct HTTP methods (verbs) for different actions (GET, POST, PUT, DELETE).
-   **Utilize** HTTP status codes to provide meaningful feedback in API responses.
-   **Understand** what it means for an API to be stateless.
-   **Design** a simple RESTful API for a resource like "posts" or "users".

---

## 2. Introduction to RESTful APIs

An **API (Application Programming Interface)** is a set of rules and protocols that allows different software applications to communicate with each other. In web development, the most common type of API is a **Web API**, which allows a frontend application (running in the browser) to request data from and send data to a backend server.

**REST (REpresentational State Transfer)** is an architectural style for designing networked applications. It is not a strict protocol, but rather a set of constraints that, when followed, lead to a web service that is scalable, reliable, and easy to use. An API that adheres to these constraints is said to be **RESTful**.

---

## 3. The Six Constraints of REST

1.  **Client-Server Architecture**: The client (frontend) and the server (backend) are separate entities that communicate over a network. This separation of concerns allows them to be developed, deployed, and scaled independently.

2.  **Statelessness**: This is a crucial constraint. **Every request from a client to a server must contain all the information needed to understand and complete the request.** The server does not store any information about the client's state between requests. If the client needs to be authenticated, it must send its authentication credentials with every single request. This makes the API highly scalable, as any server can handle any request.

3.  **Cacheability**: Responses from the server should be defined as cacheable or not. This allows the client (or an intermediary proxy) to cache responses, which can dramatically improve performance and reduce server load for repeated requests.

4.  **Uniform Interface**: This is the core principle that simplifies and decouples the architecture. It consists of four sub-constraints:
    -   **Resource-Based**: APIs are designed around "resources" (e.g., users, posts, products), which are identified by URIs (e.g., `/users/123`).
    -   **Manipulation of Resources Through Representations**: The client interacts with a *representation* of the resource, typically in a format like JSON.
    -   **Self-Descriptive Messages**: Each request and response contains enough information for the other party to understand it (e.g., using standard HTTP methods and status codes).
    -   **Hypermedia as the Engine of Application State (HATEOAS)**: A more advanced principle where responses from the server include links to other related actions or resources.

5.  **Layered System**: The client should not be able to tell whether it is connected directly to the end server or to an intermediary (like a load balancer or a cache). This allows for better scalability and security.

6.  **Code on Demand (Optional)**: A server can temporarily extend or customize the functionality of a client by transferring logic that it can execute (e.g., JavaScript). This is the only optional constraint.

---

## 4. REST in Practice: Resources, URIs, and Verbs

### Resource Naming (URIs)

-   URIs should refer to **nouns** (resources), not verbs (actions).
-   Use plural nouns for collections.
-   Use hierarchical nesting for related resources.

**Good Examples**:
-   `GET /users` - Get a list of all users.
-   `GET /users/123` - Get a single user with ID 123.
-   `GET /users/123/posts` - Get all posts for user 123.

**Bad Examples**:
-   `/getAllUsers`
-   `/createNewUser`

### HTTP Methods (Verbs)

Use the standard HTTP verbs to operate on the resources.

-   **`GET`**: Retrieve a resource or a collection of resources. (Safe, Idempotent)
-   **`POST`**: Create a new resource. (Not Idempotent)
-   **`PUT`**: Update/replace an existing resource completely. (Idempotent)
-   **`PATCH`**: Partially update an existing resource. (Not Idempotent)
-   **`DELETE`**: Delete a resource. (Idempotent)

*Idempotent*: An operation is idempotent if making the same request multiple times has the same effect as making it once.

### HTTP Status Codes

Use standard HTTP status codes to indicate the outcome of a request.

-   **2xx (Success)**
    -   `200 OK`
    -   `201 Created` (after a successful POST)
    -   `204 No Content` (after a successful DELETE)
-   **3xx (Redirection)**
-   **4xx (Client Errors)**
    -   `400 Bad Request` (e.g., invalid JSON)
    -   `401 Unauthorized` (missing or invalid authentication)
    -   `403 Forbidden` (user is authenticated but doesn't have permission)
    -   `404 Not Found`
-   **5xx (Server Errors)**
    -   `500 Internal Server Error`

---

## 5. Deliberate Practice

1.  **API Design on Paper**: Design the RESTful API endpoints for a simple blog application. Define the URIs, HTTP methods, and expected request/response formats for actions like:
    -   Fetching all posts.
    -   Creating a new post.
    -   Fetching a single post.
    -   Updating a post.
    -   Deleting a post.
    -   Fetching all comments for a post.
2.  **Explore an Existing API**: Use a tool like Postman or `curl` to make requests to a public REST API like the [GitHub API](https://docs.github.com/en/rest) or [JSONPlaceholder](https://jsonplaceholder.typicode.com/). Examine the structure of the requests and the responses.
3.  **Implement a Simple Endpoint**: In the "Hello, World" server you created in the previous module, implement the `GET /api/users` and `GET /api/users/:id` endpoints.

---

## 6. Active Recall Questions

-   What does REST stand for?
-   What does it mean for an API to be "stateless"?
-   Should a URI contain a verb or a noun?
-   Which HTTP method should be used to create a new resource?
-   Which HTTP method should be used to update an existing resource?
-   What is the difference between a `401 Unauthorized` and a `403 Forbidden` status code?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Designing an API for a `Product` resource in an e-commerce site.

-   `GET /products`: Get a list of all products.
-   `POST /products`: Create a new product. Requires product data in the request body. Returns `201 Created`.
-   `GET /products/456`: Get the product with ID 456. Returns `200 OK`. If not found, returns `404 Not Found`.
-   `PUT /products/456`: Completely replace the product with ID 456. Requires a full representation of the product in the request body.
-   `PATCH /products/456`: Partially update the product with ID 456 (e.g., just change the price).
-   `DELETE /products/456`: Delete the product with ID 456. Returns `204 No Content`.

This demonstrates a standard, predictable, and RESTful way to design a CRUD (Create, Read, Update, Delete) API.

---

## 11. Psychological and Cognitive Principles

-   **Convention over Configuration**: REST is a strong set of conventions. By following these conventions, you make your API predictable and easy for other developers to understand and use, because it works just like they expect it to.
-   **Shared Language**: Just like design patterns, REST provides a shared vocabulary for web development. When you say "this is the `POST /users` endpoint," every web developer immediately knows what that means: it's the endpoint for creating a new user.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that REST is an architectural style for designing APIs.
-   [ ] I understand the importance of statelessness in a RESTful API.
-   [ ] I can design resource-based URIs using plural nouns.
-   [ ] I can map the CRUD operations to the correct HTTP verbs (GET, POST, PUT, DELETE).
-   [ ] I can name and describe at least one status code from the 2xx, 4xx, and 5xx ranges.

---

## 13. Research and References

-   **"Architectural Styles and the Design of Network-based Software Architectures"**: The original dissertation by Roy Fielding that defined REST. (Academic and dense, but the source of truth).
-   **MDN Web Docs - An overview of HTTP**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview)
-   **Red Hat - What is a REST API?**: [Link](https://www.redhat.com/en/topics/api/what-is-a-rest-api)
-   **Richardson Maturity Model**: A model for grading how "RESTful" an API is.
