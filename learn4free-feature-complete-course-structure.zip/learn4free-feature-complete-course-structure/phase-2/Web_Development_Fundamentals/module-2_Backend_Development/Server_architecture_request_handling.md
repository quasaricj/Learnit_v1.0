# Server Architecture and Request Handling

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Describe** the lifecycle of an HTTP request from the client to the server and back.
-   **Define** the concept of "middleware" in a backend framework.
-   **Explain** the role of a router in mapping a request URI to a specific controller or handler function.
-   **Differentiate** between single-threaded (Node.js) and multi-threaded (Java Spring, Django) server models.
-   **Understand** the purpose of a reverse proxy (like Nginx).
-   **Sketch** a diagram of a simple web server architecture.

---

## 2. Introduction to Server Architecture

A web server's fundamental job is to receive an HTTP request, process it, and send back an HTTP response. However, what happens inside the server can vary dramatically. Modern backend frameworks provide a structured architecture for handling this process. Understanding this architecture, including the concepts of routing, middleware, and controllers, is key to building organized and scalable backend applications.

---

## 3. The Request-Response Lifecycle

When you type a URL into your browser or your frontend makes an API call, a multi-step process begins:

1.  **DNS Lookup**: The browser uses the Domain Name System (DNS) to translate the human-readable domain name (e.g., `www.google.com`) into a server IP address.
2.  **TCP Handshake**: The client establishes a TCP connection with the server.
3.  **HTTP Request**: The client sends the HTTP request to the server.
4.  **Server Processing**: The server receives and processes the request. This is where the backend architecture comes into play.
5.  **HTTP Response**: The server sends back an HTTP response, including a status code, headers, and a body.
6.  **Client Processing**: The client (browser) receives the response and renders it.

### Inside the Server

This is a typical pipeline for a request inside a modern backend framework (like Express.js):

`Request -> Middleware 1 -> Middleware 2 -> Router -> Controller -> Response`

### 1. Router

The **router** is responsible for inspecting the request's URI (e.g., `/users/123`) and its HTTP method (`GET`) and matching it to a specific piece of code that is meant to handle it. This mapping of a URL to a function is called **routing**.

### 2. Controller / Handler

The **controller** (in MVC patterns) or **handler function** is the final destination for a request. This is the code that contains the main business logic. It interacts with the database, calls other services, and is ultimately responsible for constructing and returning the response.

### 3. Middleware

**Middleware** functions are the heart of a modern backend framework's request pipeline. A middleware is a function that has access to the request object, the response object, and the *next* middleware function in the application’s request-response cycle.

-   **What can middleware do?**
    -   Execute any code.
    -   Make changes to the request and the response objects.
    -   End the request-response cycle.
    -   Call the next middleware in the stack.

-   **Common Middleware Use Cases**:
    -   **Logging**: Logging every incoming request.
    -   **Authentication**: Checking for a valid JWT or session ID. If the user isn't authenticated, the middleware can end the request early by sending a `401 Unauthorized` response.
    -   **Body Parsing**: Parsing incoming request bodies (e.g., JSON) and making them available on the request object.
    -   **CORS**: Adding CORS (Cross-Origin Resource Sharing) headers to the response.

### Concurrency Models

-   **Multi-Threaded (Thread-per-Request)**: Used by traditional servers like Apache and frameworks like Java's Spring or Python's Django. Each incoming request is handled by a separate thread from a thread pool.
    -   *Pros*: Simple to reason about. CPU-intensive tasks in one request don't block others.
    -   *Cons*: Threads consume memory. Doesn't scale well to a huge number of concurrent, idle connections.
-   **Single-Threaded (Event Loop)**: Used by Node.js. A single main thread handles all requests. When an asynchronous, I/O-bound operation (like a database query) is started, the operation is offloaded to the system, and the event loop is free to handle other requests. When the I/O operation finishes, its callback is placed in a queue and executed by the event loop.
    -   *Pros*: Very memory-efficient. Can handle tens of thousands of concurrent connections.
    -   *Cons*: CPU-intensive tasks can block the entire server.

### Reverse Proxy (Nginx, Apache)

In a production environment, you rarely expose your application server (e.g., your Node.js or Django app) directly to the internet. Instead, you put a **reverse proxy** like Nginx in front of it.

-   **Responsibilities of a Reverse Proxy**:
    -   **Load Balancing**: Distributing incoming requests across multiple instances of your application server.
    -   **SSL Termination**: Handling the HTTPS encryption/decryption so your application server doesn't have to.
    -   **Serving Static Files**: Serving static assets like images, CSS, and JS directly, which is much faster.
    -   **Caching**: Caching common responses.

---

## 4. Deliberate Practice

1.  **Middleware Logger**: In your backend application, write a simple logger middleware that prints the method and URL of every incoming request to the console.
2.  **Authentication Middleware**: Write a placeholder "authentication" middleware that checks for a specific `Authorization` header. If the header is not present, it should send back a `401` error. If it is present, it should call the `next()` function to pass the request to the actual route handler.
3.  **Diagramming**: On a whiteboard, draw the full architecture of a production web application, including a client, a reverse proxy (Nginx), multiple instances of your application server, and a database. Trace the path of a single request through this system.

---

## 5. Active Recall Questions

-   What is the main job of a router?
-   What is middleware? Name two common use cases.
-   What is the main difference between a single-threaded and a multi-threaded server model?
-   Which model does Node.js use?
-   What is a reverse proxy, and what is one of its primary responsibilities?

---

## 12. Summary and Mastery Checklist

-   [ ] I can describe the basic lifecycle of an HTTP request.
-   [ ] I can explain that a router maps a URL to a handler function.
-   [ ] I can define middleware and give an example of its use (e.g., logging or authentication).
-   [ ] I can describe the high-level difference between the Node.js event loop and a traditional multi-threaded server.
-   [ ] I know that in production, a reverse proxy like Nginx is placed in front of the application server.

---

## 13. Research and References

-   **Express.js Docs - Writing middleware**: [Link](https://expressjs.com/en/guide/writing-middleware.html)
-   **MDN Web Docs - How the Web works**: [Link](https://developer.mozilla.org/en-US/docs/Learn/Common_questions/How_does_the_Web_work)
-   **"Node.js Design Patterns"**: A book that covers the event loop and other Node.js-specific architectural patterns in great detail.
-   **DigitalOcean - Understanding the Node.js Event Loop**: [Link](https://www.digitalocean.com/community/tutorials/understanding-the-node-js-event-loop)
-   **Nginx Docs - What is a Reverse Proxy?**: [Link](https://docs.nginx.com/nginx/admin-guide/web-server/reverse-proxy/)
