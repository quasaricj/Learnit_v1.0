# Server-Side Programming (Node.js, Django, Flask, Spring)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** server-side (or backend) programming and its role in a web application.
-   **Differentiate** between frontend and backend responsibilities.
-   **Describe** the key characteristics of major backend frameworks and languages.
-   **Understand** the event-driven, non-blocking model of Node.js.
-   **Differentiate** between a full-featured framework (Django, Spring) and a microframework (Flask).
-   **Explain** the Model-View-Controller (MVC) and Model-View-Template (MVT) architectural patterns.
-   **Set up** a basic "Hello, World" server in a language/framework of your choice.

---

## 2. Introduction to Server-Side Programming

While frontend development deals with what the user sees and interacts with in the browser, **server-side development** (or backend development) is about everything that happens behind the scenes. The backend is responsible for storing data, processing business logic, handling user authentication, and providing data to the frontend through APIs. It is the engine that powers the web application.

---

## 3. Core Concepts

### Responsibilities of the Backend

-   **Database Operations**: Storing, retrieving, updating, and deleting data in a database.
-   **Business Logic**: Implementing the core rules and processes of the application (e.g., calculating a final price, checking if a user has permission to do something).
-   **Authentication & Authorization**: Managing user login, registration, and controlling access to resources.
-   **API Development**: Creating endpoints that the frontend can communicate with to get or send data.
-   **Serving Frontend Assets**: In some architectures, the server is also responsible for sending the initial HTML, CSS, and JavaScript files to the browser.

### Architectural Patterns

-   **Model-View-Controller (MVC)**: A common pattern for organizing backend code.
    -   **Model**: Represents the data and business logic (e.g., a `User` class that maps to the users table in the database).
    -   **View**: Represents the presentation layer (e.g., an HTML template).
    -   **Controller**: Handles user input, interacts with the Model, and selects a View to render.
-   **Model-View-Template (MVT)**: A similar pattern used by Django. The `Template` is the presentation layer, and the `View` acts as the controller.

### Popular Backend Languages and Frameworks

#### 1. Node.js (with Express.js)

-   **Language**: JavaScript
-   **Key Idea**: An **event-driven, non-blocking I/O** model. This means that Node.js can handle many concurrent connections very efficiently, making it excellent for real-time applications (like chat apps) and APIs. It is not ideal for CPU-intensive tasks (like complex calculations).
-   **Framework**: Express.js is the de facto minimal and flexible web application framework for Node.js.

#### 2. Python (with Django or Flask)

-   **Language**: Python
-   **Frameworks**:
    -   **Django**: A high-level, "batteries-included" framework. It comes with a huge amount of built-in functionality, including an ORM (Object-Relational Mapper), an admin panel, and authentication. It follows the MVT pattern and is great for building large, complex applications quickly.
    -   **Flask**: A "microframework". It is very lightweight and provides only the bare essentials. This gives the developer more flexibility and control, but it also means you have to choose and integrate your own libraries for things like database access.

#### 3. Java (with Spring)

-   **Language**: Java
-   **Framework**: Spring (specifically Spring Boot) is a very powerful, comprehensive, "batteries-included" framework. It is known for its robustness, scalability, and strong typing. It is a top choice for large, enterprise-level applications, especially in the corporate world. It relies heavily on the Dependency Inversion Principle.

---

## 4. Deliberate Practice

1.  **"Hello, World" Server**: Choose one of the frameworks above (Node.js/Express is often a good starting point for frontend developers) and follow its official "getting started" guide to create a simple web server that responds with "Hello, World!" to a browser request.
2.  **Simple Routes**: In the server you just created, add two routes:
    -   `/about` should respond with "This is the about page."
    -   `/api/user` should respond with a simple JSON object, like `{ "name": "John Doe", "email": "john@example.com" }`.
3.  **Explore a Framework's CLI**: Frameworks like Django and Spring Boot have powerful command-line interface (CLI) tools for creating new projects, applications, and database migrations. Explore the basic commands.

---

## 5. Active Recall Questions

-   What are three main responsibilities of a backend server?
-   What does "non-blocking I/O" mean in the context of Node.js?
-   What is the main difference between a "batteries-included" framework like Django and a "microframework" like Flask?
-   What does MVC stand for?
-   Which language/framework would be a natural choice for a developer who is already comfortable with frontend JavaScript?

---

## 6. Tools, Frameworks, and Platforms

-   **Postman / Insomnia**: Desktop applications for testing your API endpoints without needing to build a frontend.
-   **Docker**: A containerization tool that is extremely useful for creating consistent development and production environments for your backend application and its database.
-   **ORM (Object-Relational Mapper)**: Libraries that let you interact with your database using the objects and classes of your programming language, instead of writing raw SQL queries. Django's ORM and Prisma (for Node.js) are popular examples.

---

## 7. Feedback and Self-Assessment

-   **Choosing the Right Tool**: There is no single "best" backend framework. The choice depends on the project's requirements, the team's expertise, and performance needs. Reflect on the characteristics of each framework. When would you choose one over the other?
-   **Stateless vs. Stateful**: Most modern backends for APIs are "stateless", meaning they don't store any information about the client between requests. All the state needed to fulfill a request is provided in the request itself. This is crucial for scalability.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A Social Media Backend
-   **User Data**: You need a `User` model to store user information.
-   **Posts**: You need a `Post` model.
-   **Logic**: The business logic would handle creating new posts, fetching a user's feed, handling "likes", etc.
-   **API**: You would create API endpoints like:
    -   `POST /api/posts` (to create a new post)
    -   `GET /api/feed` (to get the current user's feed)
    -   `POST /api/posts/:id/like` (to like a post)
-   **Framework Choice**:
    -   **Node.js/Express** would be great for the real-time aspects, like notifications.
    -   **Django** would allow for very rapid development with its built-in admin panel and ORM.
    -   **Spring Boot** would be a solid choice for a large, enterprise-scale version of the platform.

---

## 11. Psychological and Cognitive Principles

-   **Separation of Concerns**: The frontend/backend split is a classic example of "separation of concerns". By dividing the application into two distinct parts with a clear contract between them (the API), you can develop, test, and deploy them independently.
-   **Abstraction**: A backend framework is an abstraction over the raw, complex details of handling HTTP requests, routing, and database connections. It lets you focus on your application's business logic.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the role of a backend server in a web application.
-   [ ] I can list the key features of Node.js (non-blocking I/O).
-   [ ] I can explain the difference between Django and Flask.
-   [ ] I understand the basic concept of the MVC pattern.
-   [ ] I have successfully created a simple "Hello, World" server with a basic route.

---

## 13. Research and References

-   **MDN Web Docs - Introduction to the server side**: [Link](https://developer.mozilla.org/en-US/docs/Learn/Server-side/First_steps/Introduction)
-   **Express.js "Hello world" example**: [Link](https://expressjs.com/en/starter/hello-world.html)
-   **The Django Project**: [Link](https://www.djangoproject.com/)
-   **Flask "A Minimal Application"**: [Link](https://flask.palletsprojects.com/en/2.0.x/quickstart/#a-minimal-application)
-   **Spring Boot "Building an Application"**: [Link](https://spring.io/guides/gs/spring-boot/)
