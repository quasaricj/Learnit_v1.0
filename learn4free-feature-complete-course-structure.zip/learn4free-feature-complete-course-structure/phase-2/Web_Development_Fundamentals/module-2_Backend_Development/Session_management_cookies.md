# Session Management and Cookies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a web session and explain its purpose.
-   **Describe** the role of a cookie in session management.
-   **Explain** the request/response flow of a cookie-based session.
-   **Differentiate** between stateful (session) and stateless (token) authentication.
-   **List** common cookie attributes like `HttpOnly`, `Secure`, and `SameSite`.
-   **Inspect** cookies in your browser's developer tools.
-   **Understand** the security implications of session management (e.g., session hijacking, CSRF).

---

## 2. Introduction to Sessions and Cookies

HTTP is an inherently **stateless** protocol. Each request is independent, and the server has no built-in memory of previous requests from the same user. This is a problem for applications that need to maintain a consistent user experience, like knowing if a user is logged in.

**Session management** is the process of creating a "session" to track a user's state across multiple requests. The most common mechanism for implementing sessions on the web is by using **cookies**.

---

## 3. Core Concepts

### What is a Cookie?

A cookie is a small piece of data that a server sends to a user's web browser. The browser stores the cookie and sends it back to the same server with every subsequent request. This allows the server to "remember" information about the user.

### The Session Management Flow

This is the classic, **stateful** authentication flow:

1.  **Login**: The user submits their username and password to the server.
2.  **Verification**: The server verifies the credentials against its database.
3.  **Session Creation**: If the credentials are valid, the server creates a unique **Session ID**. It then stores this Session ID in its own database or in-memory cache, along with the corresponding user's information (e.g., user ID, role).
4.  **`Set-Cookie` Header**: The server sends a response back to the browser with a `Set-Cookie` header. This header contains the Session ID.
5.  **Browser Storage**: The browser receives the response and stores the cookie.
6.  **Subsequent Requests**: For every future request to that same server, the browser will automatically include the cookie in a `Cookie` request header.
7.  **Server-Side Lookup**: The server receives the request, extracts the Session ID from the cookie, and looks it up in its session store. If it finds a valid session, it knows which user is making the request and can process it accordingly.

### Key Cookie Attributes

When a server sets a cookie, it can include several attributes to enhance security and control its behavior:

-   **`Expires` / `Max-Age`**: Determines how long the cookie will be stored by the browser. A "session cookie" has no `Expires` attribute and is deleted when the browser is closed.
-   **`HttpOnly`**: A crucial security flag. If set, the cookie cannot be accessed by client-side JavaScript (`document.cookie`). This helps to mitigate Cross-Site Scripting (XSS) attacks.
-   **`Secure`**: If set, the cookie will only be sent over an encrypted HTTPS connection.
-   **`SameSite`**: A security attribute that helps to prevent Cross-Site Request Forgery (CSRF) attacks. It controls whether a cookie is sent with cross-origin requests. Common values are `Strict`, `Lax`, and `None`.

### Sessions vs. Tokens (Stateful vs. Stateless)

-   **Session (Stateful)**: The server stores the session data. The client only has a meaningless Session ID.
    -   *Pro*: The actual user data is not exposed to the client.
    -   *Con*: Requires server-side storage, which can be a scalability bottleneck.
-   **Token/JWT (Stateless)**: The server stores nothing. The token itself contains all the necessary user data, and the server just verifies it.
    -   *Pro*: Highly scalable, as any server can validate the token. Works well with microservices.
    -   *Con*: Tokens can be harder to invalidate immediately (e.g., on logout).

---

## 4. Deliberate Practice

1.  **Inspect Cookies**:
    -   Open your browser's developer tools and go to the "Application" (Chrome) or "Storage" (Firefox) tab.
    -   Find the "Cookies" section.
    -   Log in to any website (e.g., GitHub, a news site).
    -   Observe the cookies that are set for that domain. Look for a session cookie and examine its attributes.
2.  **Cookie Implementation**: In your backend application, create a simple endpoint (e.g., `/set-cookie`) that sets a cookie in the response. Create another endpoint (`/read-cookie`) that reads the cookie from the request and displays its value.
3.  **Basic Session Login**: If your backend framework has a session management library (most do), use it to implement a simple login flow that creates a session for the user.

---

## 5. Active Recall Questions

-   Why is HTTP considered a stateless protocol?
-   What is the main purpose of a cookie in session management?
-   In a session-based system, what does the server store, and what does the client store?
-   What does the `HttpOnly` cookie attribute do, and why is it important for security?
-   What is a major scalability advantage of token-based authentication over session-based authentication?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: The "Remember Me" Checkbox
-   When you log in to a website, you often see a "Remember Me" checkbox. How does this work?
-   If the box is **unchecked**, the server sets a **session cookie**. This cookie has no expiration date and will be deleted when you close your browser, logging you out.
-   If the box is **checked**, the server sets a **persistent cookie**. It adds an `Expires` or `Max-Age` attribute to the cookie, telling the browser to keep it for a long time (e.g., 30 days). This is how you stay logged in even after closing and reopening your browser.

---

## 11. Psychological and Cognitive Principles

-   **State Management**: This is a core problem in all of computing. Session management is a specific form of state management for the web, designed to solve the problem of HTTP's statelessness. It's a foundational concept that demonstrates the need to explicitly manage the "memory" of an application.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that sessions are a way to make the stateless HTTP protocol stateful.
-   [ ] I can describe the role of the `Set-Cookie` (response) and `Cookie` (request) headers.
-   [ ] I can explain the difference between a session cookie and a persistent cookie.
-   [ ] I know that `HttpOnly` is a critical security feature to protect cookies from JavaScript.
-   [ ] I can describe the high-level trade-offs between stateful sessions and stateless JWTs.

---

## 13. Research and References

-   **MDN Web Docs - HTTP Cookies**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Cookies) (The definitive guide).
-   **OWASP Cheat Sheet - Session Management**: A comprehensive guide to the security aspects of session management from a leading web security organization.
-   **"HTTP: The Definitive Guide"**: An in-depth book covering all aspects of the protocol.
