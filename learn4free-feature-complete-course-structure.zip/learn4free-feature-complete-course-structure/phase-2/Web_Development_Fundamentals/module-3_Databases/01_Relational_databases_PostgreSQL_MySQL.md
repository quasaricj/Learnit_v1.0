# Relational Databases (PostgreSQL, MySQL)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** what a database is and its role in an application.
- **Explain** the relational model for storing data.
- **Describe** the key components of a relational database: tables, rows, columns, and keys.
- **Differentiate** between a primary key and a foreign key.
- **Understand** the basic characteristics of popular relational databases like PostgreSQL and MySQL.
- **Connect** a backend application to a relational database.

---

## 2. Introduction to Databases

A **database** is an organized collection of structured information, or data, typically stored electronically in a computer system. In a web application, the database is the component responsible for **data persistence**. While your backend server handles the logic, the database handles the long-term storage and retrieval of the data.

The **Relational Database** has been the dominant model for decades. It organizes data into one or more **tables** (or "relations") of columns and rows, with a unique key identifying each row.

---

## 3. Core Concepts of the Relational Model

### Tables, Rows, and Columns

- **Table**: A collection of related data entries. It represents an "entity" like `users`, `products`, or `orders`.
- **Column**: A vertical entity in a table that contains all information of one specific type. It represents an "attribute" of the entity (e.g., `first_name`, `price`). Each column has a specific data type (e.g., `VARCHAR`, `INT`, `DATETIME`).
- **Row**: A horizontal entity in a table. It represents a single record or instance of the entity (e.g., a specific user, one product).

### Keys

Keys are crucial for establishing relationships between tables.

- **Primary Key (PK)**:
  - A column (or set of columns) that **uniquely identifies** each row in a table.
  - A primary key cannot have `NULL` values.
  - A table can have only one primary key.
  - The most common primary key is an auto-incrementing integer called `id`.

- **Foreign Key (FK)**:
  - A column in one table that is used to **establish a link** to the primary key of another table.
  - This is how you create relationships. For example, an `orders` table might have a `user_id` column that is a foreign key referencing the `id` column in the `users` table. This links each order to the user who placed it.
  - This enforcement of relationships by the database is called "referential integrity".

### ACID Properties

Relational databases are known for their reliability, which is guaranteed by the ACID properties for transactions:
- **Atomicity**: A transaction is "all or nothing". If one part of the transaction fails, the entire transaction fails, and the database is left unchanged.
- **Consistency**: A transaction can only bring the database from one valid state to another.
- **Isolation**: Concurrent transactions result in a system state that would be obtained if transactions were executed serially.
- **Durability**: Once a transaction has been committed, it will remain so, even in the event of power loss or a system crash.

---

## 4. Popular Relational Databases

### MySQL

- **History**: One of the world's most popular and widely used open-source databases. Originally developed in 1995. Now owned by Oracle.
- **Characteristics**:
  - Known for its reliability, ease of use, and strong performance.
  - The "M" in the classic LAMP stack (Linux, Apache, MySQL, PHP).
  - A very common choice for web applications, especially in the PHP world (e.g., WordPress, Drupal).

### PostgreSQL (often "Postgres")

- **History**: An advanced, open-source object-relational database system. It has a strong reputation for reliability, feature robustness, and performance.
- **Characteristics**:
  - More feature-rich than MySQL. It has better support for complex queries, JSON data, and advanced data types.
  - Often considered more "standards-compliant" than MySQL.
  - A very popular choice for new, data-intensive applications.

### SQLite

- **History**: A C-language library that implements a small, fast, self-contained, serverless, zero-configuration, transactional SQL database engine.
- **Characteristics**:
  - **Serverless**: The database is not a separate server process; it's just a file on disk.
  - **Embedded**: It is often embedded directly into applications.
- **Use Case**: Excellent for development, testing, and for applications that need a simple, embedded database (e.g., mobile apps, desktop apps). It is not designed for high-concurrency, multi-user web applications.

---

## 5. Deliberate Practice

1.  **Install a Database**: Install PostgreSQL or MySQL on your local machine. Also, install a GUI tool like DBeaver or pgAdmin (for Postgres) to make it easier to interact with.
2.  **Create a Database and Table**:
    -   Create a new database for a simple blog application.
    -   Inside that database, create a `posts` table with the following columns: `id` (Primary Key, Auto-incrementing Integer), `title` (VARCHAR), `content` (TEXT), `created_at` (DATETIME).
3.  **Connect Your App**: Configure your backend application to connect to your new database. Find a database driver or library for your language (e.g., `pg` for Node.js, `psycopg2` for Python).
4.  **Run a Query**: Write a simple function in your backend app that connects to the database, runs a `SELECT * FROM posts` query, and logs the results.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that a relational database stores data in tables made of rows and columns.
-   [ ] I can define a primary key and a foreign key and explain their purpose.
-   [ ] I know that foreign keys are used to create relationships between tables.
-   [ ] I can name at least two popular open-source relational databases (e.g., PostgreSQL, MySQL).
-   [ ] I have successfully connected my backend application to a local database instance.

---

## 7. Research and References

-   **SQLZoo**: An excellent, interactive site for learning and practicing SQL. [Link](https://sqlzoo.net/)
-   **"SQL in 10 Minutes" by Ben Forta**: A very popular and easy-to-read book for beginners.
-   **PostgreSQL Official Documentation**: [Link](https://www.postgresql.org/docs/)
-   **MySQL Official Documentation**: [Link](https://dev.mysql.com/doc/)
-   **DBeaver**: A free, universal database tool. [Link](https://dbeaver.io/)
