# SQL Queries: SELECT, JOIN, Aggregate Functions, Subqueries

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Write** basic `SELECT` statements to retrieve data from a table.
- **Filter** data using the `WHERE` clause.
- **Sort** results using the `ORDER BY` clause.
- **Join** data from multiple tables together using `INNER JOIN` and `LEFT JOIN`.
- **Use** aggregate functions like `COUNT`, `SUM`, and `AVG`.
- **Group** aggregated results using the `GROUP BY` clause.
- **Understand** the basic concept of a subquery.

---

## 2. Introduction to SQL

**SQL (Structured Query Language)** is the standard language for managing and manipulating data in a relational database. It is a declarative language, meaning you describe *what* data you want, and the database engine figures out *how* to get it. A "query" is a command, written in SQL, that you send to the database to perform an action. The most common action is retrieving data, which is done with the `SELECT` statement.

---

## 3. Core Concepts

### The `SELECT` Statement

This is the workhorse of SQL.

- **Selecting all columns from a table**:
  `SELECT * FROM users;`
- **Selecting specific columns**:
  `SELECT email, created_at FROM users;`
- **Filtering with `WHERE`**:
  `SELECT * FROM products WHERE price > 100;`
  `SELECT * FROM users WHERE email = 'alice@example.com';`
- **Sorting with `ORDER BY`**:
  `SELECT * FROM products ORDER BY price DESC;` (Descending order)
  `SELECT * FROM products ORDER BY name ASC;` (Ascending order)
- **Limiting results with `LIMIT`**:
  `SELECT * FROM posts ORDER BY created_at DESC LIMIT 10;` (Get the 10 most recent posts)

### `JOIN`s

`JOIN` clauses are used to combine rows from two or more tables based on a related column between them.

- **`INNER JOIN`**:
  - Returns records that have matching values in **both** tables.
  - This is the most common type of join.
  - **Example**: Get a list of orders and the names of the users who placed them.
    ```sql
    SELECT orders.id, users.name
    FROM orders
    INNER JOIN users ON orders.user_id = users.id;
    ```
- **`LEFT JOIN` (or `LEFT OUTER JOIN`)**:
  - Returns **all** records from the left table, and the matched records from the right table. The result is `NULL` from the right side if there is no match.
  - **Example**: Get a list of all users and any orders they may have placed. Users with no orders will still be included.
    ```sql
    SELECT users.name, orders.id
    FROM users
    LEFT JOIN orders ON users.id = orders.user_id;
    ```

### Aggregate Functions

Aggregate functions perform a calculation on a set of values and return a single value.

- **`COUNT(*)`**: Counts the number of rows.
  `SELECT COUNT(*) FROM users;`
- **`SUM(column)`**: Calculates the sum of a numeric column.
  `SELECT SUM(price) FROM products;`
- **`AVG(column)``**: Calculates the average of a numeric column.
  `SELECT AVG(price) FROM products;`
- **`MAX(column)` / `MIN(column)`**: Gets the maximum or minimum value in a column.

### `GROUP BY`

The `GROUP BY` statement groups rows that have the same values into summary rows, like "find the number of customers in each country". It is often used with aggregate functions.

- **Example**: Count the number of orders placed by each user.
  ```sql
  SELECT user_id, COUNT(*) AS order_count
  FROM orders
  GROUP BY user_id;
  ```

### Subqueries (or Nested Queries)

A subquery is a SQL query nested inside a larger query.

- **Example**: Get all users who have placed more than 10 orders.
  ```sql
  SELECT name
  FROM users
  WHERE id IN (
      SELECT user_id
      FROM orders
      GROUP BY user_id
      HAVING COUNT(*) > 10
  );
  ```

---

## 4. Deliberate Practice

Use a tool like SQLZoo, DB Fiddle, or a local database with sample data to practice.

**Scenario**: You have two tables, `employees` (`id`, `name`, `department_id`) and `departments` (`id`, `name`).

1.  Write a query to find all employees in the "Sales" department. (Requires a `JOIN`).
2.  Write a query to count the number of employees in each department. (Requires `GROUP BY` and `COUNT`).
3.  Write a query to find the department with the most employees. (Requires a subquery or `ORDER BY` and `LIMIT`).
4.  Write a query to find all employees whose names start with the letter 'A'. (Hint: use the `LIKE` operator).

---

## 5. Summary and Mastery Checklist

-   [ ] I can write a `SELECT` statement to get specific columns from a table.
-   [ ] I can use the `WHERE` clause to filter rows based on a condition.
-   [ ] I can use `ORDER BY` to sort the results.
-   [ ] I can use `INNER JOIN` to combine data from two related tables.
-   [ ] I can use `LEFT JOIN` to include all records from the "left" table.
-   [ ] I can use `COUNT()` to count rows and `GROUP BY` to create summary data.

---

## 6. Research and References

-   **SQLZoo**: The best interactive tutorial for learning SQL by doing. [Link](https://sqlzoo.net/wiki/SQL_Tutorial)
-   **"SQL in 10 Minutes" by Ben Forta**: The standard quick-start guide for SQL.
-   **PostgreSQL Official Tutorial**: [Link](https://www.postgresql.org/docs/current/tutorial-sql.html)
-   **A Visual Explanation of SQL Joins**: A helpful blog post that uses Venn diagrams to explain joins. [Link](https://blog.codinghorror.com/a-visual-explanation-of-sql-joins/)
-   **W3Schools SQL Tutorial**: A comprehensive reference for all SQL keywords and functions. [Link](https://www.w3schools.com/sql/)
