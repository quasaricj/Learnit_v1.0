# Database Design and Normalization (1NF, 2NF, 3NF)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Model** real-world entities and their relationships.
- **Define** database normalization and explain its purpose.
- **Describe** the problems caused by data redundancy (update, insertion, and deletion anomalies).
- **Explain** the rules for First Normal Form (1NF).
- **Explain** the rules for Second Normal Form (2NF).
- **Explain** the rules for Third Normal Form (3NF).
- **Design** a simple, normalized database schema for a given problem.

---

## 2. Introduction to Database Design

Database design is the process of organizing data according to a database model. The most important part of this is deciding what tables you need, what columns they will contain, and how they will relate to each other. A well-designed database is crucial for data integrity, performance, and maintainability.

**Normalization** is a formal process for designing a database to reduce **data redundancy** and improve **data integrity**. It involves dividing larger tables into smaller, well-structured tables and defining relationships between them.

### Why is Redundancy Bad?

Imagine a flat table that stores order information, including customer details:

| OrderID | OrderDate | CustomerID | CustomerName | CustomerEmail     | Item      | Price |
|---------|-----------|------------|--------------|-------------------|-----------|-------|
| 101     | 2023-01-10| C123       | Alice Smith  | alice@example.com | Keyboard  | 75    |
| 102     | 2023-01-11| C456       | Bob Johnson  | bob@example.com   | Mouse     | 25    |
| 103     | 2023-01-12| C123       | Alice Smith  | alice@example.com | Webcam    | 50    |

Notice that Alice Smith's name and email are repeated for every order she makes. This leads to:
- **Update Anomaly**: If Alice changes her email, you have to update it in multiple places. If you miss one, the data becomes inconsistent.
- **Insertion Anomaly**: You cannot add a new customer to the system until they have placed at least one order.
- **Deletion Anomaly**: If you delete Alice's last order (OrderID 103), you might also lose all information about Alice herself.

Normalization solves these problems.

---

## 3. The Normal Forms

The normal forms are a series of guidelines. For most practical purposes, achieving Third Normal Form (3NF) is considered sufficient.

### First Normal Form (1NF)

**Rule**:
1.  The table must have a primary key.
2.  Each column must hold a single, atomic value (you can't have a list of values in one cell).
3.  All entries in a column must be of the same data type.

**Example Violation**:
A `products` table with a `colors` column that contains `"red, green, blue"`.
**Solution**:
Create a separate `product_colors` table to store the relationship between products and colors.

### Second Normal Form (2NF)

**Prerequisite**: The table must be in 1NF.
**Rule**:
1.  All non-key attributes must be fully functionally dependent on the **entire** primary key.

This rule is only relevant for tables that have a **composite primary key** (a primary key made up of two or more columns).

**Example Violation**:
A table `order_details` with a composite primary key `(OrderID, ProductID)`.
| OrderID | ProductID | ProductName | Quantity |
|---------|-----------|-------------|----------|
| 101     | P1        | Keyboard    | 1        |
| 101     | P2        | Mouse       | 2        |
Here, `Quantity` depends on both `OrderID` and `ProductID`. But `ProductName` depends *only* on `ProductID`. `ProductName` is not fully dependent on the whole primary key.
**Solution**:
Split the table. Move `ProductName` to a `products` table where `ProductID` is the primary key. The `order_details` table will only contain `OrderID`, `ProductID`, and `Quantity`.

### Third Normal Form (3NF)

**Prerequisite**: The table must be in 2NF.
**Rule**:
1.  There should be no **transitive dependencies**. This means that no non-key attribute should be dependent on another non-key attribute.

**Example Violation**:
A table `employees` with columns `(EmployeeID, Name, DepartmentName, DepartmentLocation)`.
Here, `DepartmentLocation` depends on `DepartmentName`, which in turn depends on `EmployeeID`. This is a transitive dependency.
**Solution**:
Split the table. Create a `departments` table with `(DepartmentID, DepartmentName, DepartmentLocation)` and link it to the `employees` table with a foreign key.

---

## 4. A Normalized Design

The solution to the initial redundant `orders` table is to split it into two tables:

**`customers` table:**
| CustomerID (PK) | CustomerName | CustomerEmail     |
|-----------------|--------------|-------------------|
| C123            | Alice Smith  | alice@example.com |
| C456            | Bob Johnson  | bob@example.com   |

**`orders` table:**
| OrderID (PK) | OrderDate | CustomerID (FK) | Item      | Price |
|--------------|-----------|-----------------|-----------|-------|
| 101          | 2023-01-10| C123            | Keyboard  | 75    |
| 102          | 2023-01-11| C456            | Mouse     | 25    |
| 103          | 2023-01-12| C123            | Webcam    | 50    |

Now, customer information is stored only once. The anomalies are gone. This design is in 3NF.

---

## 5. Deliberate Practice

1.  **Design a University Database**: On paper, design the database schema for a simple university system. You'll need to model `Students`, `Courses`, and `Enrollments`.
    -   What tables do you need?
    -   What columns go in each table?
    -   What are the primary and foreign keys?
    -   How do you represent the many-to-many relationship between students and courses? (Hint: you'll need a "join table").
2.  **Normalize a "Flat" Table**: Take a spreadsheet with redundant data (e.g., a list of music albums that includes the artist's name and genre on every row) and normalize it into a proper 3NF database design.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that normalization is about reducing data redundancy.
-   [ ] I can identify an update, insertion, or deletion anomaly in a "flat" table.
-   [ ] I know that First Normal Form (1NF) means no repeating groups or multi-valued columns.
-   [ ] I know that Second Normal Form (2NF) is about removing partial dependencies on a composite key.
-   [ ] I know that Third Normal Form (3NF) is about removing transitive dependencies.
-   [ ] I can design a simple 3NF schema with at least two related tables.

---

## 7. Research and References

-   **"Database Design for Mere Mortals" by Michael J. Hernandez**: A very accessible, non-technical guide to database design.
-   **Wikipedia - Database normalization**: [Link](https://en.wikipedia.org/wiki/Database_normalization)
-   **Guru99 - Database Normalization**: [Link](https://www.guru99.com/database-normalization.html) (Provides clear, simple examples).
-   **Database Design Tools**: Tools like `dbdiagram.io` or Lucidchart can help you visually design your database schema.
