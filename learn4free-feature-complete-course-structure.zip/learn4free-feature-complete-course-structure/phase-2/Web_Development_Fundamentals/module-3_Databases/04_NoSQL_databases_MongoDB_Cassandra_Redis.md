# NoSQL Databases (MongoDB, Cassandra, Redis)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** NoSQL and explain how it differs from the relational (SQL) model.
- **Describe** the four main types of NoSQL databases (Document, Key-Value, Column-Family, Graph).
- **Explain** the basic characteristics of MongoDB as a document database.
- **Explain** the basic characteristics of Redis as a key-value store.
- **Understand** the CAP theorem and the concept of eventual consistency.
- **Identify** use cases where a NoSQL database might be a better choice than a SQL database.

---

## 2. Introduction to NoSQL

**NoSQL** (often interpreted as "Not Only SQL") is a broad category of database management systems that do not use the traditional relational (table-based) model. NoSQL databases emerged to handle the challenges of "big data" and modern web applications, offering more flexibility, scalability, and performance for certain types of problems.

Key differences from SQL databases:
- **Flexible Schema**: NoSQL databases are often "schema-less," allowing you to store unstructured and semi-structured data.
- **Horizontal Scalability**: They are typically designed to "scale out" by adding more servers, whereas relational databases are often "scaled up" by using a more powerful server.
- **Non-relational**: They do not use tables with rows and columns, and they do not typically use SQL for querying.

---

## 3. The Four Main Types of NoSQL Databases

### 1. Document Databases

- **How it works**: Stores data in **documents**, which are typically in a format like JSON or BSON (a binary version of JSON). Each document can have a different structure.
- **Example**: A `user` document might contain a name, email, and an array of blog posts, all within a single document.
- **Leading Example**: **MongoDB**
- **Use Case**: The most general-purpose NoSQL model. Great for content management, user profiles, and most applications that would have used a relational database but need more flexibility.

### 2. Key-Value Stores

- **How it works**: The simplest NoSQL model. It's essentially a giant dictionary or hash map. You store data as a `key`-`value` pair.
- **Example**: `key = "user:123"`, `value = "{ name: 'Alice', ... }"`
- **Leading Example**: **Redis**, Amazon DynamoDB
- **Use Case**: Caching, session management, real-time leaderboards. Incredibly fast for simple lookups.

### 3. Column-Family (or Wide-Column) Stores

- **How it works**: Stores data in tables, but the rows and columns can be defined dynamically. It's optimized for fast queries over large datasets by storing columns of data together, instead of rows.
- **Leading Example**: **Apache Cassandra**, Google Bigtable
- **Use Case**: Big data applications, analytics, time-series data (e.g., from IoT devices).

### 4. Graph Databases

- **How it works**: Stores data in **nodes** (entities) and **edges** (relationships). It is specifically designed to handle highly connected data.
- **Leading Example**: **Neo4j**
- **Use Case**: Social networks, recommendation engines, fraud detection. Excels at queries that involve traversing complex relationships (e.g., "find the friends of my friends who like this product").

---

## 4. The CAP Theorem and Eventual Consistency

The CAP theorem is a fundamental concept in distributed systems. It states that a distributed database can only provide **two** of the following three guarantees at the same time:

1.  **Consistency**: Every read receives the most recent write or an error.
2.  **Availability**: Every request receives a (non-error) response, without the guarantee that it contains the most recent write.
3.  **Partition Tolerance**: The system continues to operate despite an arbitrary number of messages being dropped (or delayed) by the network between nodes.

In a modern distributed system, you cannot sacrifice Partition Tolerance (P). Therefore, you must choose between Consistency (C) and Availability (A).
- **SQL Databases** typically choose **Consistency** (CP).
- **NoSQL Databases** often choose **Availability** (AP), which leads to the concept of **eventual consistency**.

**Eventual Consistency**: This is a model where, if no new updates are made to a given data item, all accesses to that item will *eventually* return the last updated value. It's a trade-off made to achieve high availability and scalability.

---

## 5. Deliberate Practice

1.  **Install MongoDB**: Install MongoDB on your local machine and a GUI tool like MongoDB Compass.
2.  **Create a Collection**: In MongoDB, a "collection" is like a table. Create a `users` collection.
3.  **Insert Documents**: Insert a few user documents into the collection. Notice that they don't have to have the exact same fields.
    ```json
    { "name": "Alice", "email": "alice@example.com", "interests": ["reading", "hiking"] }
    { "name": "Bob", "email": "bob@example.com", "company": "Tech Corp" }
    ```
4.  **Query Data**:
    -   Connect your backend application to MongoDB.
    -   Write a function to find a user by their name.
    -   Write a function to find all users who have an interest in "reading".

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that NoSQL databases are a flexible alternative to traditional relational (SQL) databases.
-   [ ] I can name the four main types of NoSQL databases (Document, Key-Value, Column-Family, Graph).
-   [ ] I know that **MongoDB** is a popular **document** database that uses a JSON-like format.
-   [ ] I know that **Redis** is a popular **key-value** store, often used for caching.
-   [ ] I can explain the high-level trade-off of the CAP Theorem (Consistency vs. Availability).
-   [ ] I can identify a use case (e.g., unstructured content management) where a document database like MongoDB would be a good fit.

---

## 7. Research and References

-   **MongoDB University**: Free online courses on MongoDB. [Link](https://learn.mongodb.com/)
-   **Redis Official Website**: [Link](https://redis.io/)
-   **"NoSQL Distilled" by Pramod Sadalage and Martin Fowler**: A classic and highly readable overview of the NoSQL landscape.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: An in-depth and highly respected book that covers the theory behind both SQL and NoSQL databases.
-   **A Plain English Introduction to CAP Theorem**: [Link](https://www.infoq.com/articles/cap-theorem-plain-english/)
