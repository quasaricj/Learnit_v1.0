# Data Modeling for SQL vs. NoSQL

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** data modeling and its importance.
- **Describe** the general approach to data modeling in SQL (normalization).
- **Describe** the general approach to data modeling in NoSQL (denormalization, application-driven).
- **Explain** the concept of "embedding" vs. "referencing" in document databases.
- **Analyze** a set of application requirements to decide on an appropriate data model.
- **Understand** the trade-offs between the SQL and NoSQL modeling approaches.

---

## 2. Introduction to Data Modeling

**Data modeling** is the process of creating a conceptual model of the information that needs to be stored in a database. It is the most critical step in designing a database. A good data model will result in a system that is performant, scalable, and easy to work with. A bad data model will cause persistent problems throughout the life of an application.

The approach you take to data modeling is fundamentally different depending on whether you are using a SQL or a NoSQL database.

---

## 3. SQL Data Modeling: The Relational Approach

- **Philosophy**: **Data-first**. The primary goal is to create a single, well-structured, and highly normalized "source of truth" for the data. The structure of the data is prioritized, and the application's queries must adapt to it.
- **Core Technique**: **Normalization**.
  - The goal is to eliminate data redundancy.
  - Data is split into many small, distinct tables representing individual entities (`users`, `products`, `orders`).
  - **Relationships** are established between these tables using foreign keys.
- **Querying**: Data is brought back together at read time using powerful `JOIN` operations.
- **When to use this model**:
  - When your data is highly structured and relational.
  - When data integrity and consistency are your top priorities (e.g., financial systems).
  - When your query patterns are varied and you need the flexibility to ask ad-hoc questions of your data.

**Example**: A blog platform.
- You would have a `users` table, a `posts` table, and a `comments` table.
- A `post` would have a `user_id` foreign key to link it to the author.
- A `comment` would have a `user_id` foreign key and a `post_id` foreign key.
- To get a post and all its comments, you would perform a `JOIN` between the `posts` and `comments` tables.

---

## 4. NoSQL Data Modeling: The Application-Driven Approach

- **Philosophy**: **Application-first**. The data model is designed specifically to support the queries that the application needs to perform. The structure of the queries is prioritized, and the data is shaped to fit them.
- **Core Technique**: **Denormalization**.
  - Data redundancy is not only allowed but often encouraged to improve read performance.
  - Instead of splitting data apart, you often group related data together in a single document or record.
  - The model is optimized for the most common access patterns.
- **Querying**: There are no `JOIN`s. All the data needed for a given view is typically retrieved in a single query.
- **When to use this model**:
  - When your data is semi-structured or unstructured.
  - When read performance and horizontal scalability are your top priorities.
  - When your application has a few well-defined, high-traffic query patterns.

**Example**: A blog platform (Document DB like MongoDB).
- You would have a `users` collection.
- You might have a `posts` collection where each `post` document looks like this:
  ```json
  {
    "_id": "post123",
    "title": "My First Post",
    "content": "...",
    "author": { // Author data is EMBEDDED
      "user_id": "user456",
      "username": "alice"
    },
    "comments": [ // A list of comments is EMBEDDED
      { "comment_id": "c1", "body": "Great post!", "author_username": "bob" },
      { "comment_id": "c2", "body": "Thanks!", "author_username": "alice" }
    ]
  }
  ```
- To get a post and its comments, you just fetch the single `post` document. This is extremely fast, but it comes at the cost of data redundancy (the author's username is duplicated).

### Embedding vs. Referencing

This is the key decision in document data modeling.

- **Embedding**:
  - **Pros**: Fast reads (no extra queries needed).
  - **Cons**: Can lead to very large documents. Updating embedded data can be complex (e.g., if a user changes their username, you have to update it in every post they've written).
  - **Use for**: "has-a" relationships where the embedded data is not accessed on its own (e.g., the comments on a blog post).

- **Referencing**:
  - **Pros**: Data is not duplicated. Easier to update.
  - **Cons**: Requires a second query to "manually" join the data in your application code.
  - **Use for**: "belongs-to" relationships or when the referenced data is frequently accessed on its own (e.g., the author of a blog post).

---

## 5. Summary and Mastery Checklist

-   [ ] I understand that SQL data modeling prioritizes the structure of the data (normalization).
-   [ ] I understand that NoSQL data modeling prioritizes the needs of the application's queries (denormalization).
-   [ ] I can explain that SQL uses `JOIN`s to bring data together at read time.
-   [ ] I can explain that NoSQL often embeds related data to avoid `JOIN`s and improve read performance.
-   [ ] I can describe the trade-off between embedding and referencing in a document database.
-   [ ] For a simple problem (like a blog), I can sketch out both a normalized SQL schema and a denormalized NoSQL document model.

---

## 6. Research and References

-   **"NoSQL Distilled" by Pramod Sadalage and Martin Fowler**: Has excellent chapters on data modeling for different types of NoSQL databases.
-   **MongoDB Docs - Data Modeling Introduction**: [Link](https://www.mongodb.com/docs/manual/core/data-modeling-introduction/)
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Provides a deep dive into the theoretical underpinnings of both models.
-   **"SQL vs NoSQL: How to Choose"**: A common topic for blog posts and articles that provide good rules of thumb.
