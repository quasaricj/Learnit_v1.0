# Database Indexing and Query Optimization

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a database index and explain its purpose.
- **Explain** how an index works using a real-world analogy (like a book's index).
- **Understand** the trade-off of using indexes (faster reads vs. slower writes).
- **Identify** which columns are good candidates for indexing.
- **Use** the `EXPLAIN` command to analyze a query's execution plan.
- **Describe** common query optimization techniques.

---

## 2. Introduction to Performance

Writing a query that returns the correct data is only the first step. In a real-world application with a large amount of data, it's also critical that the query runs **efficiently**. A single, unoptimized query on a large table can slow down an entire application. **Query optimization** is the process of improving the performance of your database queries. The most important tool for achieving this is the **database index**.

---

## 3. Core Concepts

### What is an Index?

A database index is a special lookup table that the database search engine can use to speed up data retrieval. An index is a pointer to data in a table. It is very much like the index at the back of a book: instead of having to read the entire book to find a specific topic (a "full table scan"), you can look up the topic in the index, which will tell you exactly which page to go to.

- **How it works**:
  1.  You create an index on a specific column of a table (e.g., the `email` column of the `users` table).
  2.  The database creates a separate data structure (commonly a B-Tree) that stores the indexed column's values and a pointer to the location of the full row on the disk.
  3.  This data structure is sorted, which makes searching very fast (similar to a binary search).
  4.  When you run a query with a `WHERE` clause on that column (e.g., `SELECT * FROM users WHERE email = '...'`), the database can use the index to quickly find the location of the data, instead of scanning the entire table.

### The Trade-off of Indexes

- **Faster Reads**: Indexes dramatically speed up `SELECT` queries with `WHERE` clauses.
- **Slower Writes**: When you `INSERT`, `UPDATE`, or `DELETE` a row, the database must not only write to the table but also update all the indexes on that table. This adds overhead.

Because of this trade-off, you should not just add indexes to every column.

### What to Index?

- **Primary Keys**: Are always indexed automatically.
- **Foreign Keys**: Are almost always good candidates for indexes. You will be using them in `JOIN`s, which an index will speed up significantly.
- **Columns in `WHERE` clauses**: Any column that you frequently use to filter data is a strong candidate for an index (e.g., `username`, `email`).
- **Columns in `ORDER BY` clauses**: Indexing a column can also speed up sorting operations on that column.

### The `EXPLAIN` Command

How do you know if your query is using an index? The `EXPLAIN` command is a powerful tool that shows you the **query execution plan** that the database will use.

- **Usage**: Just add the `EXPLAIN` keyword before your query:
  `EXPLAIN SELECT * FROM users WHERE email = 'alice@example.com';`
- **Output**: The output will be a detailed breakdown of the steps the database will take. You can see if it's planning to use an "Index Scan" (good) or a "Sequential Scan" (a full table scan, often bad for large tables).

### Basic Query Optimization Techniques

1.  **Use `EXPLAIN`**: Always analyze your slow queries to understand what the database is doing.
2.  **Add Indexes**: The most common and effective optimization.
3.  **Be Specific in `SELECT`**: Avoid `SELECT *`. Only select the columns you actually need. This reduces the amount of data that needs to be transferred from the database to your application.
4.  **Avoid complex operations in `WHERE`**: Applying functions to columns in a `WHERE` clause (e.g., `WHERE UPPER(name) = 'ALICE'`) can often prevent the database from using an index on that column.

---

## 4. Deliberate Practice

1.  **Create a Large Table**: Create a `users` table and write a script to insert a large number of rows into it (e.g., 100,000).
2.  **Run `EXPLAIN`**:
    -   Run `EXPLAIN ANALYZE SELECT * FROM users WHERE email = 'some_email';` (The `ANALYZE` keyword actually executes the query and shows the real time taken).
    -   Note the execution time and that the plan involves a "Sequential Scan".
3.  **Add an Index**:
    -   Create an index on the `email` column: `CREATE INDEX users_email_idx ON users(email);`
4.  **Run `EXPLAIN` Again**:
    -   Run the same `EXPLAIN ANALYZE` command from step 2.
    -   Observe the dramatic improvement in the execution time and that the plan now uses an "Index Scan".

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that a database index is a data structure that speeds up data retrieval.
-   [ ] I can use the analogy of a book's index to explain how a database index works.
-   [ ] I understand that indexes make reads faster but can make writes (INSERT, UPDATE, DELETE) slower.
-   [ ] I can identify good candidates for an index (foreign keys, columns in `WHERE` clauses).
-   [ ] I know that the `EXPLAIN` command can be used to see how a database will execute a query.

---

## 6. Research and References

-   **"High Performance MySQL" by Baron Schwartz, Peter Zaitsev, and Vadim Tkachenko**: A classic, in-depth book on database performance.
-   **Use The Index, Luke**: A website dedicated to explaining the importance of database indexing. [Link](https://use-the-index-luke.com/)
-   **PostgreSQL Docs - EXPLAIN**: [Link](https://www.postgresql.org/docs/current/sql-explain.html)
-   **MongoDB Docs - Indexes**: Indexing is just as important in NoSQL databases. [Link](https://www.mongodb.com/docs/manual/indexes/)
