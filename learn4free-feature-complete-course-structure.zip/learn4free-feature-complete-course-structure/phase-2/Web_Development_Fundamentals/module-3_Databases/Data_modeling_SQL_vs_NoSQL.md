# Data Modeling for SQL vs. NoSQL

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** data modeling and its importance.
-   **Describe** the process of data modeling for a SQL database (normalization).
-   **Describe** the process of data modeling for a NoSQL document database (embedding and referencing).
-   **Analyze** a set of application requirements and decide whether a relational or non-relational model is more appropriate.
-   **Model** a one-to-many relationship in both a SQL and a NoSQL database.
-   **Model** a many-to-many relationship in both a SQL and a NoSQL database.
-   **Understand** the performance trade-offs between normalized (SQL) and denormalized/embedded (NoSQL) data models.

---

## 2. Introduction to Data Modeling

**Data modeling** is the process of creating a conceptual model of the data that an application will store and the relationships between different data items. It is a crucial step in application design. A well-designed data model can lead to an application that is fast, scalable, and easy to maintain. A poorly designed model can lead to the opposite.

The way you model your data is fundamentally different in SQL and NoSQL databases, and the choice of which to use depends heavily on your application's access patterns.

---

## 3. SQL Data Modeling: The Relational Approach

-   **Philosophy**: "Normalize until it hurts, then denormalize until it works."
-   **Core Idea**: The primary goal is to **reduce data redundancy** and improve data integrity. You start with the principles of normalization (1NF, 2NF, 3NF).
-   **Process**:
    1.  Identify the entities in your application (e.g., `User`, `Post`, `Comment`).
    2.  Create a separate table for each entity.
    3.  Define the columns (attributes) for each table with strict data types.
    4.  Identify primary keys for each table.
    5.  Use foreign keys and join tables to represent the relationships between entities.
-   **Result**: The data is "shredded" into many small, interconnected tables. To reassemble a complete piece of information (like a blog post with its comments and author), you use `JOIN`s at read time.

**Example: A Blog Post**
-   **`users` table**: `id`, `name`
-   **`posts` table**: `id`, `title`, `content`, `user_id (FK)`
-   **`comments` table**: `id`, `text`, `post_id (FK)`, `user_id (FK)`

To get a post and all its comments, you would need to `JOIN` all three tables.

---

## 4. NoSQL Data Modeling: The Document Approach (for MongoDB)

-   **Philosophy**: "Structure your data to match how your application will query and display it."
-   **Core Idea**: The primary goal is to **optimize for read performance** and co-locate data that is accessed together. Data redundancy is often acceptable and even encouraged.
-   **Process**:
    1.  Think about the "views" of your application. What data is needed on each screen?
    2.  Model your data in a way that allows you to fetch all the necessary information for a view in a single query.
    3.  Decide between **embedding** (denormalizing) and **referencing** (linking).

### Embedding vs. Referencing

This is the central trade-off in document database modeling.

-   **Embedding (Denormalization)**:
    -   You place related data directly inside a single "parent" document.
    -   **Example**: Store the comments for a blog post in an array *inside* the post document.
    ```json
    {
      "id": "post123",
      "title": "My Post",
      "author_name": "John Doe", // Denormalized
      "comments": [
        { "text": "Great post!", "author_name": "Jane" },
        { "text": "I agree!", "author_name": "Bill" }
      ]
    }
    ```
    -   *Pros*: Incredibly fast reads. You can get a post and all its comments in one database operation.
    -   *Cons*: Can lead to very large documents. Updating embedded data can be more complex. Data can become duplicated (e.g., `author_name`).

-   **Referencing (Normalization)**:
    -   You store related data in a separate collection and reference it by its ID. This is similar to foreign keys in SQL.
    -   **Example**:
    ```json
    // posts collection
    { "id": "post123", "title": "My Post", "author_id": "user456" }
    // comments collection
    { "id": "comment789", "text": "Great post!", "post_id": "post123" }
    ```
    -   *Pros*: Reduces data duplication.
    -   *Cons*: Requires multiple queries (or a `$lookup`, the equivalent of a `JOIN`) to retrieve all the information for a view, which is slower.

### Rules of Thumb for NoSQL Modeling

-   Favor **embedding** unless there is a compelling reason not to.
-   Use **referencing** when:
    -   The embedded data would be very large or have an unbounded number of items (e.g., a post with thousands of comments).
    -   The related data is frequently accessed and updated on its own.
    -   The data represents a many-to-many relationship.

---

## 5. Modeling Relationships: A Comparison

### One-to-Many

-   **SQL**: Two tables with a foreign key. (e.g., `users` and `posts`).
-   **NoSQL**:
    -   **Embedding**: If the "many" side is small and not accessed on its own, embed an array of sub-documents. (e.g., `address`es within a `user` document).
    -   **Referencing**: If the "many" side is large, store an array of IDs in the "one" side, or store the ID of the "one" in each of the "many" documents (the relational approach).

### Many-to-Many

-   **SQL**: A third "join table". (e.g., `students`, `courses`, `student_courses`).
-   **NoSQL**:
    -   **Two-way referencing**: The most common approach. Store an array of `course_ids` in the `student` document, and an array of `student_ids` in the `course` document. This introduces redundancy but optimizes for reads.

---

## 6. Deliberate Practice

1.  **Model a Twitter Clone**:
    -   How would you model users, tweets, and followers in a **SQL** database? Draw the schema.
    -   How would you model the same entities in a **MongoDB** (document) database? Would you embed tweets in the user document? How would you handle the "followers" relationship?
2.  **E-commerce Product**:
    -   Model a product that has a name, price, and a list of reviews. Each review has a rating and a comment.
    -   Design the SQL schema.
    -   Design the MongoDB document. Would you embed the reviews? Why or why not?

---

## 12. Summary and Mastery Checklist

-   [ ] I understand that SQL modeling prioritizes **eliminating redundancy** through normalization.
-   [ ] I understand that NoSQL (document) modeling prioritizes **read performance** by co-locating data.
-   [ ] I can explain the trade-off between embedding and referencing in a document database.
-   [ ] I favor embedding, but know when referencing is the better choice.
-   [ ] I can model a simple one-to-many relationship in both SQL and NoSQL.

---

## 13. Research and References

-   **MongoDB Docs - Data Model Design**: [Link](https://www.mongodb.com/docs/manual/core/data-model-design/) (An excellent and comprehensive guide).
-   **"6 Rules of Thumb for MongoDB Schema Design"**: A series of classic blog posts that are highly recommended.
-   **"SQL vs NoSQL: Or Why Your Database is Not The Problem"**: A great talk by Rick Houlihan that focuses on access patterns.
