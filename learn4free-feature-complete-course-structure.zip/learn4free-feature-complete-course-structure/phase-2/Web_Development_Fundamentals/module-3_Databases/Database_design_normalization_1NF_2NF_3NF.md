# Database Design and Normalization (1NF, 2NF, 3NF)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** database normalization and its goals.
-   **Explain** the problems caused by data redundancy and update anomalies.
-   **Describe** the requirements for the First Normal Form (1NF).
-   **Describe** the requirements for the Second Normal Form (2NF).
-   **Describe** the requirements for the Third Normal Form (3NF).
-   **Analyze** a simple, unnormalized table and normalize it to 3NF.
-   **Understand** the trade-off between normalization and query performance (denormalization).

---

## 2. Introduction to Database Normalization

**Database normalization** is the process of structuring a relational database in accordance with a series of so-called "normal forms" in order to reduce data redundancy and improve data integrity. In simpler terms, it's a set of rules for designing your database tables to ensure that your data is stored logically, efficiently, and without duplication.

The primary goals of normalization are:
1.  **Eliminate Redundant Data**: Storing the same piece of information in multiple places is wasteful and dangerous.
2.  **Prevent Data Anomalies**: Poorly structured tables can lead to errors when you try to insert, update, or delete data.
3.  **Improve Data Integrity**: Ensure that the data in your database is reliable and consistent.

---

## 3. Core Concepts

### Data Anomalies

Anomalies are the problems that occur in poorly designed databases.

-   **Insertion Anomaly**: You are unable to add a new record to the database because some data is missing. (e.g., You can't add a new course until at least one student has enrolled in it).
-   **Deletion Anomaly**: The deletion of one record unintentionally causes the loss of other, unrelated data. (e.g., If you delete the last student enrolled in a course, the course itself is deleted from the database).
-   **Update Anomaly**: To update a single piece of information, you have to change it in multiple places, leading to inconsistencies if you miss one. (e.g., If a professor's name is stored with every course they teach, changing their name requires updating many rows).

### The Normal Forms

Normalization is a process of refinement, moving through a series of "normal forms". For most practical purposes, achieving the Third Normal Form (3NF) is considered sufficient.

#### First Normal Form (1NF)

A table is in 1NF if it meets two conditions:
1.  **Each cell must contain a single, atomic value**: You cannot have a list or array of values in a single cell.
2.  **Each record must be unique**: This is typically achieved by having a primary key.

**Violation**: A `courses` table where a `students` column contains a comma-separated list of student names.
**Solution**: Create a separate `students` table and a `student_courses` join table.

#### Second Normal Form (2NF)

A table is in 2NF if:
1.  It is in 1NF.
2.  **All non-key attributes are fully functionally dependent on the entire primary key**.
This rule only applies to tables that have a **composite primary key** (a primary key made up of two or more columns). It means that every column that is not part of the key must depend on *all* parts of the key, not just a portion of it.

**Violation**: A table `order_items` with a composite key `(order_id, product_id)` and columns for `quantity`, `product_price`, and `order_date`. Here, `order_date` depends only on `order_id`, not the full key. `product_price` depends only on `product_id`.
**Solution**: Move `order_date` to the `orders` table and `product_price` to the `products` table.

#### Third Normal Form (3NF)

A table is in 3NF if:
1.  It is in 2NF.
2.  **There are no transitive dependencies**.
A transitive dependency is when a non-key attribute depends on another non-key attribute, which in turn depends on the primary key. (A -> B and B -> C, therefore A -> C).

**Violation**: A `users` table with columns `user_id (PK)`, `username`, `department_id`, and `department_name`. Here, `department_name` depends on `department_id`, which depends on `user_id`.
**Solution**: Remove `department_name` from the `users` table and create a separate `departments` table with `department_id (PK)` and `department_name`.

### Denormalization

Sometimes, for performance reasons, a database is intentionally designed to be in a lower normal form. This is called **denormalization**. For example, you might include a `post_count` column in your `users` table to avoid having to run a `COUNT(*)` query every time you display a user. This introduces redundancy (the count can be calculated from the `posts` table) but can dramatically improve read performance. This is a trade-off: you gain read speed at the cost of more complex writes (you have to update the count every time a post is added or deleted).

---

## 4. Deliberate Practice

**The Unnormalized Table**:
Consider the following table that tracks book rentals from a library.

| Member ID | Member Name | Book ID | Book Title       | Genre       | Author         | Author Nationality | Date Rented |
|-----------|-------------|---------|------------------|-------------|----------------|--------------------|-------------|
| 1         | John Smith  | 101     | The Great Gatsby | Fiction     | F. Scott Fitzgerald | American           | 2023-10-01  |
| 2         | Jane Doe    | 102     | Dune             | Sci-Fi      | Frank Herbert       | American           | 2023-10-03  |
| 1         | John Smith  | 102     | Dune             | Sci-Fi      | Frank Herbert       | American           | 2023-10-05  |

**Exercise**: Take this single table and normalize it to 3NF.
-   What are the repeating groups and atomic value violations (1NF)?
-   What are the partial dependencies (2NF)?
-   What are the transitive dependencies (3NF)?
-   You should end up with several smaller, well-structured tables (`members`, `books`, `authors`, `rentals`). Draw the final schema and the relationships between the tables.

---

## 5. Active Recall Questions

-   What are the two main goals of normalization?
-   What is an "update anomaly"?
-   What is the rule for First Normal Form (1NF)?
-   What is a "transitive dependency" in the context of 3NF?
-   What is denormalization, and why would you ever do it?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Why normalization matters.
-   Imagine the unnormalized table from the practice exercise.
-   What if Frank Herbert's nationality was entered incorrectly? To fix it, you would have to find and update *every single row* for every book he has ever written. This is an **update anomaly**.
-   What if you want to add a new author to your database who hasn't written any books yet? You can't, because you need a `Book ID` to create a row. This is an **insertion anomaly**.
-   What if John Smith returns "The Great Gatsby" and you delete that rental record? If this is the only book by F. Scott Fitzgerald in your library, you have now lost all information about him. This is a **deletion anomaly**.
-   A normalized schema solves all of these problems.

---

## 11. Psychological and Cognitive Principles

-   **Single Source of Truth**: Normalization is the database equivalent of the "Don't Repeat Yourself" (DRY) principle in programming. The goal is to have a single, canonical location for each piece of information. This makes the system easier to reason about and reduces the chance of inconsistencies.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that normalization reduces redundancy and prevents data anomalies.
-   [ ] **1NF**: I know that a table must have a primary key and that each cell must hold a single value.
-   [ ] **2NF**: I know that this rule applies to composite keys and means all non-key columns must depend on the *entire* key.
-   [ ] **3NF**: I know that a table in 3NF has no transitive dependencies (non-key columns don't depend on other non-key columns).
-   [ ] I can look at a simple denormalized table and identify the problems that need to be fixed.

---

## 13. Research and References

-   **"Database Design for Mere Mortals" by Michael J. Hernandez**: The go-to guide for learning database design and normalization in a clear, non-academic way.
-   **GeeksforGeeks - Normalization in DBMS**: [Link](https://www.geeksforgeeks.org/normalization-in-dbms/)
-   **YouTube - "Database Normalization" by Caleb Curry**: A very popular and easy-to-follow video series on the topic.
