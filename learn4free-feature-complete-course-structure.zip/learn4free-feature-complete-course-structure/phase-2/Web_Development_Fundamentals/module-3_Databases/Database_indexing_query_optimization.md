# Database Indexing and Query Optimization

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a database index and explain its purpose.
-   **Explain** how an index speeds up read queries but slows down write operations.
-   **Use** the `EXPLAIN` or `EXPLAIN ANALYZE` command to inspect a query's execution plan.
-   **Identify** slow queries that could benefit from an index (e.g., queries with a `WHERE` clause on a non-indexed column).
-   **Create** a single-column index on a table.
-   **Understand** the concept of a composite index (an index on multiple columns).
-   **Recognize** common query optimization techniques beyond indexing.

---

## 2. Introduction to Performance

Having a well-structured database is the first step, but it doesn't guarantee performance. As your tables grow to millions of rows, even a simple query like `SELECT * FROM users WHERE email = '...';` can become incredibly slow. **Query optimization** is the process of improving the speed of your database queries. The single most important tool for achieving this is the **database index**.

---

## 3. Core Concepts

### What is an Index?

A database index is a special data structure (most commonly a B-Tree) that stores a small portion of a table's data in a specific order, making it very fast to find the rows matching a query.

-   **Analogy**: An index at the back of a book. Instead of scanning the entire book (a "full table scan") to find a topic, you can go to the index, find the topic, and get the exact page number(s) to jump to. The index is a sorted list of keywords that points to the location of the full data.

### How Does an Index Work?

-   When you create an index on a column (e.g., the `email` column of a `users` table), the database creates a separate, sorted list of all the email addresses. Each entry in this list has a pointer back to the original row in the main table.
-   When you run a query with `WHERE email = '...'`, the database can now do a very fast search (like a binary search) on the sorted index to find the matching entry, and then use the pointer to retrieve the full row data from the main table.
-   This avoids a **full table scan**, where the database would have to look at every single row in the table, one by one.

### The Trade-Off of Indexing

-   **Reads (SELECT)**: Indexes dramatically **speed up** read queries that filter on the indexed columns.
-   **Writes (INSERT, UPDATE, DELETE)**: Indexes **slow down** write operations. When you add, update, or delete a row, the database must not only modify the main table but also update every index that is associated with that table.

**Rule of Thumb**: Add indexes for columns that you frequently use in `WHERE` clauses, `JOIN` conditions, and `ORDER BY` clauses. Don't index every single column.

### The `EXPLAIN` Command

How do you know if your query is using an index? The `EXPLAIN` command is a powerful tool that asks the database to show you its **query plan**. The query plan is the sequence of steps the database will take to execute your query.

-   **`EXPLAIN SELECT * FROM users WHERE email = '...';`**
-   When you run this, you can inspect the output to see if it mentions using an "Index Scan" (good) or a "Sequential Scan" / "Full Table Scan" (bad, for large tables).
-   `EXPLAIN ANALYZE` is even better, as it actually runs the query and shows you the plan along with the actual time it took.

### Types of Indexes

-   **Single-Column Index**: An index on a single column. Primary keys are automatically indexed.
-   **Composite Index (Multi-Column Index)**: An index on two or more columns. The order of the columns in the index matters. A composite index on `(last_name, first_name)` is very efficient for queries that filter on `last_name` and `first_name`, or just on `last_name`. It is *not* efficient for queries that only filter on `first_name`.

---

## 4. Deliberate Practice

1.  **Create a Large Table**: In your local database, create a `users` table and write a script to insert at least 100,000 rows of sample data.
2.  **Run a Slow Query**: Write a `SELECT` query to find a user by their email address. Use `EXPLAIN ANALYZE` to run it. Note the execution time and observe that it's doing a "Sequential Scan".
3.  **Create an Index**: Write the SQL command to create an index on the `email` column.
    -   `CREATE INDEX idx_users_email ON users(email);`
4.  **Run the Fast Query**: Run the *exact same* `SELECT` query from step 2 again with `EXPLAIN ANALYZE`. The execution time should be dramatically faster (likely milliseconds), and the query plan should now show an "Index Scan".
5.  **Composite Index Practice**: Add a `last_name` and `first_name` column to your table. Run a query that filters on both (`WHERE last_name = '...' AND first_name = '...'`). Create a composite index and see how it improves the query performance.

---

## 5. Active Recall Questions

-   What is the purpose of a database index? Use an analogy.
-   What is the main trade-off of adding an index?
-   What is a "full table scan" and why is it bad for performance?
-   What SQL command can you use to see the database's query plan?
-   In a composite index on `(col_a, col_b)`, which query would be faster: one filtering on `col_a` or one filtering on `col_b`?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: Optimizing a Social Media Feed
-   A query to fetch the 10 most recent posts for a user's feed might look like this: `SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC LIMIT 10;`
-   Without an index, the database would have to find *all* posts by that user, load them into memory, sort them all by date, and then take the top 10.
-   With a **composite index on `(user_id, created_at)`**, the database can do something much smarter. It can go directly to the section of the index for that `user_id`, and since the data is already pre-sorted by `created_at` within that section, it can just read the first 10 entries. This is an incredibly common and powerful optimization pattern.

---

## 11. Psychological and Cognitive Principles

-   **Proactive vs. Reactive Optimization**: "Premature optimization is the root of all evil." Don't start by adding indexes to every column. Start by writing your application. Then, use tools like `EXPLAIN` and application performance monitoring to *find* the slow queries and optimize them reactively.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that an index is a data structure that speeds up database reads.
-   [ ] I know that indexes slow down writes (`INSERT`, `UPDATE`, `DELETE`).
-   [ ] I know to add indexes to columns used in `WHERE`, `JOIN`, and `ORDER BY` clauses.
-   [ ] I can use `EXPLAIN ANALYZE` to inspect a query plan and look for "Sequential Scans".
-   [ ] I can write the SQL to create a single-column or composite index.

---

## 13. Research and References

-   **"Use The Index, Luke"**: A fantastic, in-depth website that explains the fundamentals of database indexing.
-   **PostgreSQL Documentation - EXPLAIN**: [Link](https://www.postgresql.org/docs/current/sql-explain.html)
-   **"High Performance MySQL"**: A classic book for deep-diving into database optimization.
