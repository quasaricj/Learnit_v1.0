# NoSQL Databases (MongoDB, Cassandra, Redis)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** NoSQL and explain how it differs from the relational (SQL) model.
-   **Describe** the four main types of NoSQL databases: document, key-value, wide-column, and graph.
-   **Explain** the advantages of NoSQL databases, particularly horizontal scalability and flexible data models.
-   **Understand** the basic principles of a document database like MongoDB.
-   **Understand** the basic principles of a key-value store like Redis.
-   **Understand** the CAP theorem and its implications for distributed databases.
-   **Identify** use cases where a NoSQL database might be a better choice than a SQL database.

---

## 2. Introduction to NoSQL

**NoSQL** (often interpreted as "Not Only SQL") is a term for a broad category of database management systems that differ from the traditional relational (SQL) model. While SQL databases have rigid, predefined schemas, NoSQL databases are built for flexibility, scalability, and handling large volumes of unstructured or semi-structured data. They became popular with the rise of large-scale web applications (like Google, Facebook, Amazon) that needed to handle massive amounts of data and traffic.

---

## 3. Core Concepts

### SQL vs. NoSQL: Key Differences

| Feature               | SQL (Relational)                            | NoSQL (Non-Relational)                               |
| --------------------- | ------------------------------------------- | ---------------------------------------------------- |
| **Data Model**        | Structured (tables with rows and columns)   | Flexible (documents, key-value pairs, graphs, etc.)  |
| **Schema**            | Rigid, predefined (schema-on-write)         | Dynamic, flexible (schema-on-read)                   |
| **Scalability**       | Primarily **Vertical** (increase server power) | Primarily **Horizontal** (add more servers)          |
| **Consistency**       | Strong consistency (ACID)                   | Tunable consistency (often BASE)                     |
| **Query Language**    | SQL (Structured Query Language)             | Varies by database (e.g., MongoDB Query API)         |

### The CAP Theorem

A fundamental concept in distributed systems (which includes most NoSQL databases). The CAP theorem states that it is impossible for a distributed data store to simultaneously provide more than two out of the following three guarantees:
-   **Consistency**: Every read receives the most recent write or an error.
-   **Availability**: Every request receives a (non-error) response, without the guarantee that it contains the most recent write.
-   **Partition Tolerance**: The system continues to operate despite an arbitrary number of messages being dropped (or delayed) by the network between nodes.

In a distributed system, you *must* have Partition Tolerance. Therefore, the trade-off is between Consistency and Availability. NoSQL databases often allow you to "tune" this trade-off.

### Types of NoSQL Databases

#### 1. Document Databases (e.g., MongoDB)

-   **How it works**: Stores data in **documents**, which are typically in a JSON-like format (BSON in MongoDB's case). A document contains fields and values, and can include nested documents and arrays.
-   **Analogy**: A filing cabinet of individual, self-contained documents. Each document has all the information it needs.
-   **Use Case**: The most general-purpose NoSQL database. Great for content management, user profiles, and many web application backends.

#### 2. Key-Value Stores (e.g., Redis, Amazon DynamoDB)

-   **How it works**: The simplest NoSQL model. Data is stored as a collection of **key-value pairs**. You store a value (which can be a simple string or a complex object) with a unique key, and you retrieve it using that key.
-   **Analogy**: A giant dictionary or hash table.
-   **Use Case**: Caching, session management, real-time leaderboards. **Redis** is extremely fast because it often operates in-memory.

#### 3. Wide-Column Stores (e.g., Cassandra, HBase)

-   **How it works**: Organizes data into "column families," which are containers for rows. Unlike a relational table, each row can have a different set of columns. It's designed for massive-scale data storage and high write throughput.
-   **Analogy**: A table where each row can have its own unique set of columns.
-   **Use Case**: Big data applications, IoT sensor data, and systems that need to handle huge amounts of write operations.

#### 4. Graph Databases (e.g., Neo4j)

-   **How it works**: Designed specifically to store and navigate relationships. The model consists of **nodes** (entities), **edges** (relationships), and **properties** (information about the nodes and edges).
-   **Analogy**: A social network graph, a mind map.
-   **Use Case**: Social networks, fraud detection, recommendation engines, and any problem where the relationships between data points are the most important feature.

---

## 4. Deliberate Practice

1.  **Install MongoDB**: Install MongoDB on your machine and a GUI tool like MongoDB Compass.
2.  **Create Documents**: In MongoDB, create a `users` collection. Insert a few user documents with different structures (e.g., one user has an `address` sub-document, another doesn't).
3.  **Install Redis**: Install Redis. Use the `redis-cli` to perform basic commands:
    -   `SET mykey "Hello World"`
    -   `GET mykey`
    -   `EXPIRE mykey 10` (make the key expire in 10 seconds)
4.  **Data Modeling Exercise**: For a social media application, which type of NoSQL database would be best for storing the "friend" relationships? Which would be best for caching user sessions?

---

## 5. Active Recall Questions

-   What are two key differences between SQL and NoSQL databases?
-   What does the "C" in the CAP theorem stand for?
-   Which type of NoSQL database is most similar to a giant hash table?
-   Which type of NoSQL database uses a JSON-like format to store data?
-   What is the primary use case for a graph database?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: When to choose SQL vs. NoSQL
-   **An E-commerce Site**:
    -   **SQL is a great choice** for the core product, customer, and order data. The data is highly structured, and data integrity is critical (ACID transactions are important for financial data).
    -   **NoSQL (Redis)** would be an excellent choice for storing the user's **shopping cart** and **session data**. This data is often temporary and needs to be accessed very quickly.
    -   **NoSQL (MongoDB)** could be used to store product **reviews**, where each product might have a document containing an array of all its reviews.
-   This "polyglot persistence" approach—using the right database for the right job—is very common in modern system design.

---

## 11. Psychological and Cognitive Principles

-   **Flexibility vs. Rigidity**: The choice between SQL and NoSQL is often a trade-off between the flexibility of a dynamic schema and the safety and consistency of a rigid schema. A flexible schema makes it easy to evolve your application, but a rigid schema can prevent bad data from ever entering your system.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that NoSQL databases are non-relational and generally have flexible schemas.
-   [ ] I can name the four main types of NoSQL databases (document, key-value, wide-column, graph).
-   [ ] I know that MongoDB is a document database.
-   [ ] I know that Redis is a very fast, in-memory key-value store, often used for caching.
-   [ ] I can identify a use case (e.g., social network graph) where a NoSQL database would be a better fit than a SQL database.

---

## 13. Research and References

-   **MongoDB University**: Free online courses on MongoDB. [Link](https://university.mongodb.com/)
-   **Redis University**: Free online courses for Redis. [Link](https://redis.com/redis-enterprise/training/redis-university/)
-   **"NoSQL Distilled" by Pramod Sadalage and Martin Fowler**: A classic, concise book that provides a great overview of the NoSQL landscape.
-   **YouTube - "SQL vs. NoSQL" by Fireship**: A fast-paced and entertaining overview of the key differences.
