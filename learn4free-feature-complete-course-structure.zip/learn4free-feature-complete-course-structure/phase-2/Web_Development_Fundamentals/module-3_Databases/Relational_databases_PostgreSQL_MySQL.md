# Relational Databases (PostgreSQL, MySQL)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** what a relational database is and its core principles.
-   **Explain** the concepts of schemas, tables, rows, and columns.
-   **Describe** primary keys, foreign keys, and the concept of a relationship.
-   **Differentiate** between the three main types of relationships: one-to-one, one-to-many, and many-to-many.
-   **Understand** the role of a Relational Database Management System (RDBMS).
-   **Compare** the key features of PostgreSQL and MySQL.
-   **Connect** to a relational database and perform a basic query.

---

## 2. Introduction to Relational Databases

A **relational database** is a type of database that stores and provides access to data points that are related to one another. The data is organized into a predefined structure of **tables**, where each table consists of **rows** and **columns**. This structured approach, based on the principles of relational algebra, has been the dominant model for data storage for decades and is the foundation for a vast number of applications. The software used to manage these databases is called a **Relational Database Management System (RDBMS)**.

---

## 3. Core Concepts

### The Relational Model

-   **Schema**: The overall design of the database, including all its tables and the relationships between them.
-   **Table**: A collection of related data entries, consisting of columns and rows. A table is like a spreadsheet. (e.g., a `users` table, a `products` table).
-   **Column (or Attribute)**: A vertical entity in a table that contains all information of one specific type (e.g., a `first_name` column). Each column has a defined data type (e.g., `VARCHAR`, `INTEGER`, `TIMESTAMP`).
-   **Row (or Record)**: A horizontal entity in a table, representing a single data entry. (e.g., a single user's information).

### Keys and Relationships

-   **Primary Key (PK)**: A column (or set of columns) that **uniquely identifies** each row in a table. A primary key cannot have `NULL` values and must be unique. `user_id` is a classic example.
-   **Foreign Key (FK)**: A column in one table that is a **reference to the primary key** of another table. Foreign keys are the mechanism used to link tables together. For example, a `posts` table might have a `user_id` foreign key that links to the `id` of the user who created the post.

### Types of Relationships

1.  **One-to-One (1:1)**: Each record in Table A can be linked to one, and only one, record in Table B. (e.g., a `users` table and a `user_profiles` table). This is less common.
2.  **One-to-Many (1:N)**: A single record in Table A can be linked to many records in Table B, but each record in Table B is linked to only one record in Table A. This is the most common relationship type. (e.g., one `user` can have many `posts`).
3.  **Many-to-Many (M:N)**: A record in Table A can be linked to many records in Table B, and a record in Table B can be linked to many records in Table A. (e.g., `students` and `courses`; a student can enroll in many courses, and a course can have many students). This is implemented using a third "join table" or "junction table".

### Popular RDBMS: PostgreSQL vs. MySQL

Both are powerful, open-source, and widely-used relational database systems.

-   **MySQL**:
    -   Known for its ease of use, high speed, and reliability.
    -   The most popular open-source database in the world.
    -   A fantastic choice for web applications, especially in the LAMP (Linux, Apache, MySQL, PHP) stack. It is the database for WordPress.
-   **PostgreSQL (or "Postgres")**:
    -   Known for its advanced feature set, extensibility, and strict adherence to SQL standards.
    -   Often considered more feature-rich than MySQL, with support for more complex data types and advanced queries.
    -   A great choice for complex, data-intensive applications, especially in the worlds of financial services and scientific data.

For most standard web applications, either is an excellent choice.

---

## 4. Deliberate Practice

1.  **Database Modeling**: On paper or with a diagramming tool, design the database schema for a simple blog.
    -   What tables do you need? (`users`, `posts`, `comments`, `categories`).
    -   What columns does each table have?
    -   What are the primary and foreign keys?
    -   What are the relationships between the tables? (e.g., a user has many posts, a post has many comments).
2.  **Install an RDBMS**: Install either PostgreSQL or MySQL on your local machine. Use a GUI tool like DBeaver or pgAdmin (for Postgres) / MySQL Workbench (for MySQL) to connect to it.
3.  **Create a Table**: Write the SQL `CREATE TABLE` statement to create a `users` table with `id`, `username`, `email`, and `created_at` columns.

---

## 5. Active Recall Questions

-   What is the difference between a row and a column?
-   What are the two main properties of a primary key?
-   How is a many-to-many relationship implemented?
-   What does RDBMS stand for?
-   Name one key difference between PostgreSQL and MySQL.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: An E-commerce Store
-   **`customers` table**: `id (PK)`, `name`, `email`.
-   **`orders` table**: `id (PK)`, `order_date`, `customer_id (FK to customers.id)`.
-   **`products` table**: `id (PK)`, `name`, `price`.
-   **`order_items` table**: `id (PK)`, `order_id (FK to orders.id)`, `product_id (FK to products.id)`, `quantity`.

-   The relationship between `customers` and `orders` is **one-to-many**.
-   The relationship between `orders` and `products` is **many-to-many**. The `order_items` table is the **join table** that facilitates this relationship.

This schema demonstrates how to model real-world business concepts using the relational model.

---

## 11. Psychological and Cognitive Principles

-   **Structure and Order**: The human brain is good at thinking about structured, tabular data. The relational model's spreadsheet-like mental model is intuitive and one of the reasons for its enduring popularity.
-   **Consistency**: Relational databases place a strong emphasis on data consistency and integrity through constraints like primary keys, foreign keys, and data types. This reliability is a core reason they are trusted for financial and business-critical data.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that a relational database organizes data into tables of rows and columns.
-   [ ] I can define a primary key and a foreign key.
-   [ ] I can describe the one-to-many and many-to-many relationships.
-   [ ] I know that a many-to-many relationship requires a join table.
-   [ ] I can name PostgreSQL and MySQL as two popular open-source RDBMSs.

---

## 13. Research and References

-   **SQLZoo**: An interactive tutorial for learning SQL. [Link](https://sqlzoo.net/)
-   **PostgreSQL Tutorial**: A comprehensive and easy-to-follow tutorial for PostgreSQL.
-   **MySQL Tutorial**: A similar tutorial for MySQL.
-   **"Database Design for Mere Mortals" by Michael J. Hernandez**: A classic, very accessible book on the principles of relational database design.
