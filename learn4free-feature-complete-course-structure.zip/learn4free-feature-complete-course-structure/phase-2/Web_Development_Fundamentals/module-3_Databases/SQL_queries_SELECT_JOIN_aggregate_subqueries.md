# SQL Queries: SELECT, JOIN, Aggregates, and Subqueries

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** SQL and its purpose as a query language.
-   **Write** a basic `SELECT` statement to retrieve data from a table.
-   **Filter** results using the `WHERE` clause.
-   **Sort** results using the `ORDER BY` clause.
-   **Combine** data from multiple tables using `INNER JOIN`, `LEFT JOIN`, and `RIGHT JOIN`.
-   **Use** aggregate functions (`COUNT`, `SUM`, `AVG`, `MAX`, `MIN`) to perform calculations on data.
-   **Group** aggregated results using the `GROUP BY` clause.
-   **Write** a simple subquery to perform more complex filtering.

---

## 2. Introduction to SQL

**SQL (Structured Query Language)** is the standard language for managing and querying data in a relational database. It is a **declarative** language, meaning you describe *what* data you want, and the database engine figures out the most efficient way to retrieve it. Mastering SQL is a fundamental skill for any backend developer, as it is the primary way your application will interact with its data.

This module focuses on the Data Query Language (DQL) portion of SQL, primarily the powerful `SELECT` statement.

---

## 3. Core Concepts

### The `SELECT` Statement

This is the workhorse of SQL. It's used to retrieve data from the database.

-   **Basic Syntax**: `SELECT column1, column2 FROM table_name;`
-   **Selecting all columns**: `SELECT * FROM table_name;`
-   **Filtering with `WHERE`**: `SELECT * FROM users WHERE status = 'active';`
-   **Sorting with `ORDER BY`**: `SELECT * FROM products ORDER BY price DESC;`
-   **Limiting results**: `SELECT * FROM posts ORDER BY created_at DESC LIMIT 10;`

### `JOIN` Clauses

`JOIN`s are used to combine rows from two or more tables based on a related column between them (usually a primary key-foreign key relationship).

-   **`INNER JOIN`**: Returns only the records that have matching values in **both** tables. If a user has no posts, that user will not appear in a `JOIN` between `users` and `posts`.
-   **`LEFT JOIN`**: Returns **all** records from the left table (the first one mentioned), and the matched records from the right table. If there is no match, the columns from the right table will be `NULL`. (e.g., Get all users, and any posts they may have).
-   **`RIGHT JOIN`**: The opposite of a `LEFT JOIN`. Returns all records from the right table. (Less commonly used).

**Example**:
```sql
SELECT users.username, posts.title
FROM users
INNER JOIN posts ON users.id = posts.user_id;
```

### Aggregate Functions

These functions perform a calculation on a set of rows and return a single, summary value.

-   **`COUNT(*)`**: Counts the number of rows.
-   **`SUM(column)`**: Calculates the sum of the values in a numeric column.
--  **`AVG(column)`**: Calculates the average of the values in a numeric column.
-   **`MAX(column)` / `MIN(column)`**: Returns the maximum or minimum value in a column.

### The `GROUP BY` Clause

The `GROUP BY` clause is used with aggregate functions to group rows that have the same values in specified columns into summary rows.

**Example**: Count the number of posts each user has created.
```sql
SELECT user_id, COUNT(*) AS post_count
FROM posts
GROUP BY user_id;
```

### Subqueries (Nested Queries)

A subquery is a SQL query nested inside a larger query. They can be used in `WHERE`, `FROM`, or `SELECT` clauses and are a powerful tool for performing complex queries.

**Example**: Find all users who have created more than 10 posts.
```sql
SELECT username
FROM users
WHERE id IN (
    SELECT user_id
    FROM posts
    GROUP BY user_id
    HAVING COUNT(*) > 10
);
```

---

## 4. Deliberate Practice

Use a tool like SQLZoo, DB Fiddle, or a local database with sample data for these exercises.

1.  **Simple Queries**:
    -   Find all products with a price greater than $50.
    -   Find all users whose email address ends in `@gmail.com`.
    -   Find the 10 most recent orders.
2.  **JOIN Practice**:
    -   Write a query to find the username and the title of all the posts they have made.
    -   Write a query to find all users, and include the titles of any posts they have, even if they have no posts (this requires a `LEFT JOIN`).
3.  **Aggregation Practice**:
    -   Count the total number of users.
    -   Find the average price of all products.
    -   Find the total number of comments for each post.
4.  **Subquery Practice**:
    -   Find the title of the post with the most comments.

---

## 5. Active Recall Questions

-   What is the difference between `SELECT *` and `SELECT column_name`?
-   What is the purpose of the `WHERE` clause?
-   What is the difference between an `INNER JOIN` and a `LEFT JOIN`?
-   Which clause is used with aggregate functions to group the results?
-   In your own words, what is a subquery?

---

## 6. Tools, Frameworks, and Platforms

-   **Database GUI Tools**: DBeaver, pgAdmin, MySQL Workbench. These provide a graphical interface for writing and running queries.
-   **Online SQL Fiddles**: SQLZoo, DB Fiddle, SQL Fiddle. These are great for practicing queries without needing to set up a local database.
-   **ORM (Object-Relational Mapper)**: While ORMs (like Django's ORM or Sequelize) are convenient, they generate SQL for you. It is *crucial* to understand the underlying SQL so you can debug performance issues and write efficient queries when the ORM isn't enough.

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: The N+1 Query Problem
-   A common performance pitfall. Imagine you fetch 10 posts, and then, in your application code, you loop through those 10 posts and run a *separate* query for each one to get the author's username. This results in 1 (for the posts) + 10 (for the authors) = **11 total queries**.
-   **The SQL Solution**: Use a `JOIN`. By writing `SELECT * FROM posts JOIN users ON posts.user_id = users.id`, you can get all the post and author information in a **single query**.
-   Understanding how to use `JOIN`s effectively is one of the most important skills for writing performant, database-driven applications.

---

## 11. Psychological and Cognitive Principles

-   **Declarative Thinking**: SQL requires a shift in thinking for many developers. You don't tell the database *how* to get the data (e.g., "loop through this table, then loop through that one..."). You describe the final set of data that you *want*. This declarative approach allows the database's query optimizer to figure out the best "how" on its own.

---

## 12. Summary and Mastery Checklist

-   [ ] I can write a `SELECT` query to get specific columns from a table.
-   [ ] I can use the `WHERE` clause to filter data based on a condition.
-   [ ] I can explain the difference between `INNER JOIN` and `LEFT JOIN`.
-   [ ] I can use `COUNT()` and `GROUP BY` to get a summary of my data.
-   [ ] I understand the basic concept of a subquery.

---

## 13. Research and References

-   **SQLZoo**: [Link](https://sqlzoo.net/) - The best place to start with interactive SQL practice.
-   **"SQL in 10 Minutes, Sams Teach Yourself" by Ben Forta**: A very popular and highly-rated book for beginners.
-   **PostgreSQL Exercises**: An online tool for practicing PostgreSQL-specific queries.
-   **The Art of SQL by Stéphane Faroult**: A book that focuses on writing elegant and efficient SQL.
