# RESTful API Design and Best Practices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Recap** the core principles of RESTful API design.
- **Implement** versioning for an API.
- **Structure** consistent and predictable JSON responses.
- **Handle** errors gracefully and provide meaningful error messages.
- **Implement** filtering, sorting, and pagination for collection endpoints.
- **Understand** the importance of clear and comprehensive API documentation.

---

## 2. Introduction to API Best Practices

Building an API that is functional is the first step. Building an API that is a pleasure for other developers (including your future self) to use is the next. Good API design is about consistency, predictability, and clarity. This module covers some of the common best practices that go beyond the basic REST principles to help you create a robust and user-friendly API.

---

## 3. Core Concepts and Best Practices

### API Versioning

As your application evolves, you will inevitably need to make breaking changes to your API (e.g., renaming a field, changing the structure of a resource). To avoid breaking existing client applications, you should **version** your API.

- **Common Strategy**: URL Path Versioning.
  - You include the version number in the URL path.
  - `https://api.example.com/v1/posts`
  - `https://api.example.com/v2/posts`
- This allows you to maintain the old version (`v1`) for existing clients while you develop and roll out the new version (`v2`).

### Consistent JSON Response Structure

Your API should always return JSON responses in a consistent and predictable format. A good practice is to use a standard "envelope" for your responses.

- **For successful responses**:
  ```json
  {
    "status": "success",
    "data": {
      // The actual resource object or array of objects
      "post": { "id": 1, "title": "..." }
    }
  }
  ```
- **For error responses**:
  ```json
  {
    "status": "error",
    "message": "A descriptive error message for the developer."
  }
  ```
  Or for validation errors:
  ```json
  {
    "status": "fail",
    "data": {
      // Field-specific validation errors
      "email": "Email address is invalid."
    }
  }
  ```

### Filtering, Sorting, and Pagination

Collection endpoints (like `/posts`) can return a huge amount of data. You must provide a way for the client to filter, sort, and paginate the results. This is typically done with **query parameters**.

- **Filtering**: `GET /posts?status=published`
- **Sorting**: `GET /posts?sort=-created_at` (the `-` indicates descending order)
- **Pagination**:
  - **Limit/Offset**: `GET /posts?limit=10&offset=20` (Get 10 posts, skipping the first 20).
  - **Cursor-based**: More complex but more robust. The API response includes a "cursor" (an opaque string) that the client can use to request the next page of results.

### Use Plural Nouns and Concrete Names

- **Plural nouns**: As covered before, always use plural nouns for your resource collections (`/users`, `/products`).
- **Concrete names**: Be specific. `/users/123/blog-posts` is better and more intuitive than `/users/123/items`.

### Security Best Practices

- **Use HTTPS**: Always use SSL/TLS to encrypt all communication between the client and the server.
- **Rate Limiting**: Protect your API from abuse (both intentional and unintentional) by limiting the number of requests a client can make in a given period of time.
- **Validate Input**: Never trust data from the client. Always validate incoming data on the server-side to prevent security vulnerabilities like SQL injection and to ensure data integrity.

### API Documentation

Your API is only as good as its documentation. Good documentation should be:
- **Clear and Comprehensive**: It should cover every endpoint, the required parameters, the authentication methods, and provide example requests and responses.
- **Interactive**: Modern documentation tools allow users to make live API calls directly from the documentation page.
- **The OpenAPI Specification (formerly Swagger)** is the most popular standard for defining and documenting RESTful APIs. Tools like Swagger UI and ReDoc can generate beautiful, interactive documentation from an OpenAPI specification file.

---

## 4. Deliberate Practice

1.  **Implement Pagination**: Take an existing endpoint in your backend application that returns a list of items. Add `limit` and `offset` query parameter handling to implement pagination.
2.  **Implement Error Handling**: Create a centralized error handling middleware in your application. It should catch any errors, log them, and send back a consistently formatted JSON error response with the appropriate HTTP status code.
3.  **Write Documentation**: Choose one of your API endpoints and write documentation for it in a simple Markdown file. Describe the URL, the HTTP method, any required parameters, and show an example of a successful response and an error response.
4.  **Explore OpenAPI/Swagger**: Use an online editor to create a simple OpenAPI specification for your Blog API. See how the specification maps to the interactive documentation.

---

## 5. Summary and Mastery Checklist

-   [ ] I version my API in the URL (e.g., `/v1/`).
-   [ ] I use a consistent JSON "envelope" for my API responses.
-   [ ] I use query parameters to allow clients to filter, sort, and paginate collection results.
-   [ ] I always validate user input on the server.
-   [ ] I understand the importance of clear API documentation and have heard of the OpenAPI/Swagger specification.

---

## 6. Research and References

-   **"APIs: A Strategy Guide" by Daniel Jacobson, Greg Brail, and Dan Woods**: A book about the business and strategy of APIs.
-   **OpenAPI Specification**: [Link](https://www.openapis.org/)
-   **Swagger**: The most popular set of tools for working with the OpenAPI specification. [Link](https://swagger.io/)
-   **Microsoft REST API Guidelines**: A comprehensive set of design guidelines from a major industry player. [Link](https://github.com/microsoft/api-guidelines/blob/vNext/Guidelines.md)
-   **Zalando RESTful API Guidelines**: Another excellent and very detailed set of public design guidelines.
