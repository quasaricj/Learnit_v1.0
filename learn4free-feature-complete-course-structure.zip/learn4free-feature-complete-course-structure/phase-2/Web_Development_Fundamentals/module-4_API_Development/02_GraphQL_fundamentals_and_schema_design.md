# GraphQL Fundamentals and Schema Design

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** GraphQL and explain how it differs from REST.
- **Describe** the problems that GraphQL was designed to solve (over-fetching and under-fetching).
- **Differentiate** between the three main operation types: `Query`, `Mutation`, and `Subscription`.
- **Understand** the role of a schema and the Schema Definition Language (SDL).
- **Write** a simple GraphQL query to fetch data.
- **Define** a simple type in the GraphQL SDL.

---

## 2. Introduction to GraphQL

**GraphQL** is a **query language** for APIs and a runtime for fulfilling those queries with your existing data. It was developed by Facebook and open-sourced in 2015. Unlike REST, which has many endpoints for different resources, a GraphQL API typically has a **single endpoint**. The client specifies exactly what data it needs in a single request, and the server returns exactly that data.

### The Problems GraphQL Solves

GraphQL was designed to address two common problems with REST APIs:

1.  **Over-fetching**: This happens when a REST endpoint returns more data than the client actually needs. For example, a `/users/1` endpoint might return 30 fields of user data, but the client only needs to display the user's name and profile picture. This wastes bandwidth, especially on mobile devices.
2.  **Under-fetching**: This happens when a single REST endpoint doesn't provide enough data, forcing the client to make multiple requests to get everything it needs. For example, to get a blog post and its comments, a client might have to make a request to `/posts/1` and then a separate request to `/posts/1/comments`. This can be slow.

With GraphQL, the **client is in control**. It can ask for just the fields it needs and can fetch related data in a single request.

---

## 3. Core Concepts

### Single Endpoint

A GraphQL API is typically exposed over a single URL (e.g., `/graphql`), and all requests are sent as `POST` requests. The "action" to be taken is not determined by the URL or the HTTP verb, but by the content of the query in the request body.

### The Schema

The **schema** is the heart of a GraphQL API. It is a strongly-typed contract that defines all the data that can be queried and the relationships between them. The schema is written in the **Schema Definition Language (SDL)**.

- **Types**: You define `types` to represent your resources.
  ```graphql
  type Post {
    id: ID!
    title: String!
    content: String
    author: User!
  }

  type User {
    id: ID!
    name: String!
    email: String!
  }
  ```
  The `!` means the field is non-nullable.

### Operation Types

1.  **`Query`**: For fetching data (read operations). This is the equivalent of a `GET` request in REST.
    ```graphql
    # This is a Query sent by the client
    query GetPostAndAuthor {
      post(id: "123") {
        title
        content
        author {
          name
        }
      }
    }
    ```
    The server's response would be a JSON object that exactly matches the shape of the query.

2.  **`Mutation`**: For creating, updating, or deleting data (write operations). This is the equivalent of `POST`, `PUT`, or `DELETE`.
    ```graphql
    mutation CreatePost {
      createPost(title: "New Post", content: "...") {
        id
        title
      }
    }
    ```

3.  **`Subscription`**: A long-lasting connection for receiving real-time data updates from the server, often using WebSockets.
    ```graphql
    subscription NewComment {
      newComment(postId: "123") {
        id
        body
      }
    }
    ```

### Resolvers

A **resolver** is a function on the backend that is responsible for fetching the data for a single field in your schema. For every field in your schema, there is a corresponding resolver function. This is how GraphQL knows where to get the data to fulfill a query.

---

## 4. Deliberate Practice

1.  **Explore a Public GraphQL API**: The GitHub API is a great example. Use their [Explorer tool](https://docs.github.com/en/graphql/overview/explorer) to write some queries.
    -   Write a query to get your own username and the titles of the last 5 repositories you created.
    -   Notice how you can get all this information in a single request.
2.  **Design a Schema**: Take the blog application model from the REST modules. Design the GraphQL schema for it. Define the `Post`, `User`, and `Comment` types, and the `Query` and `Mutation` types for the main operations.
3.  **"Hello World" GraphQL Server**: Follow the "getting started" guide for a GraphQL server library in your chosen backend language (e.g., `apollo-server` for Node.js, `graphene` for Python) to set up a basic server with a simple schema.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that GraphQL is a query language for APIs.
-   [ ] I can describe the problems of over-fetching and under-fetching that GraphQL solves.
-   [ ] I know that a GraphQL API typically has a single endpoint.
-   [ ] I can name the three main operation types: `Query` (read), `Mutation` (write), and `Subscription` (real-time).
-   [ ] I understand that the **schema** is the contract that defines the API's capabilities.
-   [ ] I understand that the **client** specifies exactly what data it needs in a query.

---

## 6. Research and References

-   **Official GraphQL Website**: [graphql.org](https://graphql.org/) (The "Introduction to GraphQL" section is excellent).
-   **Apollo GraphQL Platform**: Apollo is the leading company in the GraphQL space, and their documentation and blog are fantastic resources for learning. [Link](https://www.apollographql.com/docs/)
-   **How to GraphQL**: A free, open-source tutorial website. [Link](https://www.howtographql.com/)
-   **"The GraphQL Guide" by John Resig and Loren Sands-Ramshaw**: A comprehensive book on GraphQL.
