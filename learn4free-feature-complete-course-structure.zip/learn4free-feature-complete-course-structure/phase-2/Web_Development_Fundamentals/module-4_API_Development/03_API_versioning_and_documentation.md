# API Versioning and Documentation

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** why API versioning is critical for maintaining a stable application.
- **Describe** the most common strategy for versioning a REST API (URL path versioning).
- **Understand** how GraphQL's schema evolution can often reduce the need for traditional versioning.
- **Recognize** the importance of clear, comprehensive, and up-to-date API documentation.
- **Define** the OpenAPI Specification (Swagger) and its role in documenting REST APIs.
- **Define** the role of tools like GraphiQL or Apollo Studio in documenting GraphQL APIs.

---

## 2. API Versioning

### Why is Versioning Necessary?

Your API is a contract between your server and its clients. Once clients start using your API, you cannot make "breaking changes" without giving them a way to adapt. A **breaking change** is any change that will cause an existing client's request to fail or be processed incorrectly.

Examples of breaking changes:
- Removing a field from a response.
- Renaming a field.
- Changing the data type of a field (e.g., from an integer to a string).
- Adding a new required field to a request.

**Versioning** is the practice of creating and maintaining multiple versions of your API to allow clients to migrate to a new version at their own pace.

### Versioning REST APIs

The most common and straightforward way to version a REST API is to include the version number in the URL.

- **URL Path Versioning**:
  - `https://api.example.com/v1/users`
  - `https://api.example.com/v2/users`

When you need to introduce a breaking change, you create a new set of endpoints under a new version (e.g., `/v2`). You must then maintain both `/v1` and `/v2` until you can safely deprecate and remove the older version.

### Versioning and GraphQL

GraphQL is designed to be more evolutionary and less prone to breaking changes. Because the client specifies exactly the data it needs, you can add new fields to your schema without breaking existing clients.

- **Adding a new field is non-breaking**: Old clients simply won't ask for the new field.
- **Deprecating a field**: Instead of removing a field immediately, you can mark it as `@deprecated` in your schema. This will show up in documentation tools and alert developers that the field will be removed in the future, giving them time to migrate.

This approach allows a GraphQL schema to evolve over time, often without the need for a hard `/v2` version. However, if you need to make a fundamental change to the structure of your data, you might still need to introduce a new version.

---

## 3. API Documentation

Good documentation is not a "nice-to-have"; it is an essential part of a good API. Your API is a product for other developers, and they need a clear user manual.

### Documenting REST APIs: The OpenAPI Specification

- **OpenAPI (formerly Swagger)**: A standard, language-agnostic specification for describing REST APIs. You create a single `openapi.json` or `openapi.yaml` file that defines:
  - Every available endpoint (`/users`, `/users/{id}`).
  - The HTTP methods supported by each endpoint.
  - The parameters (path, query, header) for each endpoint.
  - The structure of the request and response bodies.
  - Authentication methods.
- **Benefits**:
  - **Single Source of Truth**: The specification file is the contract for your API.
  - **Auto-generated Interactive Documentation**: Tools like **Swagger UI** and **ReDoc** can take your OpenAPI file and generate a beautiful, interactive documentation website where users can read about and test your API endpoints directly in the browser.
  - **Code Generation**: You can generate client SDKs and server stubs in various languages from an OpenAPI file.

### Documenting GraphQL APIs: Introspection

GraphQL has a powerful feature called **introspection**. The GraphQL schema itself is queryable. This means you can ask the API to describe itself: what types are available, what fields they have, and what queries and mutations are supported.

- **GraphiQL and Apollo Studio**: These are powerful, interactive IDEs for exploring GraphQL APIs. They use introspection to provide:
  - **Live, auto-generated documentation**: A "Docs" panel that is always 100% up-to-date with the schema.
  - **Intelligent autocompletion**: It helps you write valid queries by suggesting fields and arguments as you type.
  - **Validation**: It tells you if your query is invalid before you even send it.

This built-in documentation is one of the most beloved features of GraphQL.

---

## 4. Summary and Mastery Checklist

-   [ ] I can explain that API versioning is necessary to avoid breaking client applications when I make changes.
-   [ ] I know that putting the version number in the URL (`/v1/`) is a common way to version a REST API.
-   [ ] I understand that GraphQL's schema can evolve, which often reduces the need for explicit versioning.
-   [ ] I recognize that the **OpenAPI (Swagger)** specification is the standard for documenting REST APIs.
-   [ ] I recognize that tools like **GraphiQL** and **Apollo Studio** provide powerful, auto-generated documentation for GraphQL APIs through introspection.

---

## 5. Research and References

-   **OpenAPI Specification Website**: [Link](https://www.openapis.org/)
-   **Swagger Tools**: [Link](https://swagger.io/)
-   **"Evolving Your API with GraphQL"**: An article from the Apollo GraphQL blog.
-   **"Versioning of a GraphQL API"**: A blog post by Phil Sturgeon that discusses different strategies.
