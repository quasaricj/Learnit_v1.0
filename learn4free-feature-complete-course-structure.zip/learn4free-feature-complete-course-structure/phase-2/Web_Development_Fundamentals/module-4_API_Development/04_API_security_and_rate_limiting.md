# API Security and Rate Limiting

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Identify** common API security threats.
- **Explain** the importance of input validation for preventing vulnerabilities like SQL Injection.
- **Describe** how CORS (Cross-Origin Resource Sharing) works and its role in web security.
- **Define** rate limiting and explain its purpose.
- **Understand** the importance of using HTTPS to encrypt all API traffic.
- **Recognize** that API security is an ongoing process, not a one-time setup.

---

## 2. Introduction to API Security

An API is a gateway to your application's data and logic. As such, it is a primary target for attackers. Securing your API is one of the most critical aspects of backend development. It involves protecting your data from unauthorized access, ensuring the integrity of your data, and making sure your service remains available to legitimate users.

This module covers a few foundational security practices that every developer should implement.

---

## 3. Core Concepts

### Input Validation

**Principle**: **Never trust data from the client.**
- **Threat**: Malicious users can send specially crafted input to try to exploit your application. The most classic example is **SQL Injection**, where an attacker sends a piece of SQL code in an input field (like a search bar) to try to trick your database into executing it.
- **Defense**:
  1.  **Always validate input on the server-side**, even if you have frontend validation.
  2.  Check for expected data types, lengths, and formats.
  3.  Use a validation library to do this systematically.
  4.  Use an **ORM (Object-Relational Mapper)** or **parameterized queries** when interacting with your database. These tools are specifically designed to prevent SQL injection by treating user input as data, never as executable code.

### CORS (Cross-Origin Resource Sharing)

- **The Same-Origin Policy**: By default, web browsers enforce the "same-origin policy," which prevents a web page from making a request to a different domain than the one it was served from. This is a crucial security feature.
- **CORS**: A mechanism that uses additional HTTP headers to tell a browser that it's okay to let a web application at one origin (domain) have permission to access selected resources from a server at a different origin.
- **How it works**:
  1.  A browser is about to make a cross-origin request (e.g., a `POST` request from `https://my-cool-app.com` to `https://api.my-cool-app.com`).
  2.  It first sends a "preflight" request using the `OPTIONS` HTTP method to the API.
  3.  The server responds with a set of CORS headers, like `Access-Control-Allow-Origin: https://my-cool-app.com`.
  4.  If the headers indicate that the origin is allowed, the browser proceeds with the actual `POST` request.
- **Implementation**: Most backend frameworks have a simple CORS middleware that you can configure with the allowed origins.

### Rate Limiting

- **Purpose**: To prevent a single client from overwhelming your API with too many requests, which could lead to a **Denial of Service (DoS)** attack or simply run up your server costs. It protects against both malicious attacks and poorly-written client code (e.g., an infinite loop of requests).
- **How it works**: The server keeps track of the number of requests made by each client (usually based on their IP address or API key). If a client exceeds a certain number of requests in a given time window (e.g., 100 requests per minute), the server will temporarily block them and respond with a `429 Too Many Requests` status code.

### Always Use HTTPS

- **Threat**: Without HTTPS, all data sent between the client and your API is in plain text. An attacker on the same network (e.g., a public Wi-Fi hotspot) can easily "sniff" this traffic and steal sensitive information like passwords or authentication tokens.
- **Defense**: **Use HTTPS for everything.** HTTPS encrypts the entire HTTP request and response, including the URL, headers, and body. This is made possible by an **SSL/TLS certificate** installed on your server. There is no longer any excuse not to use HTTPS; services like Let's Encrypt provide free SSL certificates.

### Authentication and Authorization

As covered in a previous module, this is a cornerstone of API security. You must ensure you have robust mechanisms to:
- Verify who the user is (Authentication).
- Check if they have the correct permissions to perform an action (Authorization).

---

## 4. Summary and Mastery Checklist

-   [ ] I know that I must **never trust client input** and must always validate it on the server.
-   [ ] I can explain that using an ORM or parameterized queries is the best defense against SQL Injection.
-   [ ] I can describe the purpose of CORS (to allow/disallow cross-origin requests).
-   [ ] I can explain that rate limiting is used to prevent a single client from overwhelming the API.
-   [ ] I understand that **HTTPS is non-negotiable** for any production API.

---

## 5. Research and References

-   **OWASP Top 10**: The Open Web Application Security Project's list of the 10 most critical web application security risks. This is the single most important security resource for a web developer. [Link](https://owasp.org/www-project-top-ten/)
-   **MDN Web Docs - Cross-Origin Resource Sharing (CORS)**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS)
-   **Let's Encrypt**: A non-profit organization that provides free SSL/TLS certificates. [Link](https://letsencrypt.org/)
-   **"API Security in Action" by Neil Madden**: A book that provides a comprehensive look at API security.
