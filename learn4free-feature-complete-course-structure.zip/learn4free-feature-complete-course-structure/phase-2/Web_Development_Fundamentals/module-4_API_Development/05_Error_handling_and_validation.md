# Error Handling and Validation

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Differentiate** between operational errors and programmer errors.
- **Implement** a centralized error handling strategy in a backend application.
- **Provide** consistent, meaningful error messages to the API consumer.
- **Implement** server-side data validation.
- **Understand** the importance of logging errors for debugging and monitoring.
- **Use** asynchronous error handling techniques (e.g., with Promises or `async/await`).

---

## 2. Introduction to Error Handling

No application is perfect; errors are an inevitable part of software. Robust **error handling** is the practice of anticipating and responding to errors in a way that prevents the application from crashing, provides useful feedback to developers and users, and maintains the integrity of the system. **Validation** is a key part of this process, as it involves proactively checking for potential errors in incoming data before it is processed.

Good error handling is a sign of a professional, production-ready application.

---

## 3. Core Concepts

### Types of Errors

- **Operational Errors**: These are runtime problems that are expected to happen. The application's state is still understood and the error can be handled gracefully.
  - *Examples*: Invalid user input, a database connection timing out, a third-party API being unavailable.
- **Programmer Errors (Bugs)**: These are mistakes in the code. They represent a state of the application that was not anticipated.
  - *Examples*: Trying to read a property of `undefined`, a logical flaw in an algorithm.
  - The best way to handle a programmer error is often to crash the application, log the error, and have a process manager restart it. This prevents the application from continuing in an unknown, potentially corrupt state.

### Centralized Error Handling

Instead of putting `try...catch` blocks in every single route handler, the best practice is to use a **centralized error handling middleware**.

- **How it works**:
  1.  You create a special piece of middleware that is placed at the very end of your middleware chain.
  2.  If an error occurs in any of the preceding route handlers or middleware, you call the `next()` function with the error object (`next(error)`).
  3.  This skips all other middleware and goes directly to your error handling middleware.
  4.  This central middleware is then responsible for logging the error and sending a formatted, user-friendly JSON response to the client with the appropriate status code.

### Consistent Error Responses

Your API should have a consistent format for error messages, as discussed in the "Best Practices" module.

```json
{
  "status": "error", // Or "fail" for validation errors
  "message": "A clear, developer-friendly message about what went wrong.",
  // Optionally, you can include more details in development mode
  "error": {
    "statusCode": 500,
    "stack": "..."
  }
}
```
**Important**: In a production environment, you should not send detailed error information (like a stack trace) to the client, as this can leak sensitive information about your server's architecture.

### Server-Side Validation

Validation is your first line of defense against errors. Before your business logic even runs, you should validate the incoming request data (`req.body`, `req.query`, `req.params`).

- **What to check**:
  - **Presence**: Is a required field missing?
  - **Type**: Is the `age` a number? Is the `email` a string?
  - **Format**: Is the `email` a valid email address format?
  - **Range**: Is the `age` between 18 and 120?
- **Validation Libraries**: Do not write validation logic manually. Use a dedicated library for your framework (e.g., `express-validator` for Express, `Joi`, or built-in validation in frameworks like Django or NestJS). These libraries make it easy to define validation rules and generate clear error messages.

### Error Logging

You cannot fix bugs you don't know about. **Logging** is the process of recording errors and other important events.
- In your centralized error handler, you should log the details of every error that occurs.
- In a production environment, you would use a dedicated logging service (like Winston for Node.js) to write logs to a file or send them to a third-party logging platform (like Datadog, Sentry, or LogRocket).
- A good error log should include:
  - The error message and stack trace.
  - The timestamp.
  - Details about the request that caused the error (URL, user ID, etc.).

### Asynchronous Error Handling

Handling errors in asynchronous code requires special attention.
- **Promises**: If a function returns a Promise, you handle errors by chaining a `.catch()` block.
- **`async/await`**: The modern and preferred way is to wrap your `await` calls in a `try...catch` block.
  ```javascript
  async function myController(req, res, next) {
    try {
      const data = await someAsyncOperation();
      res.json({ status: "success", data });
    } catch (error) {
      // Pass the error to the centralized handler
      next(error);
    }
  }
  ```

---

## 4. Summary and Mastery Checklist

-   [ ] I can explain the difference between an expected operational error and an unexpected programmer error.
-   [ ] I use a centralized error handling middleware to avoid duplicating error logic.
-   [ ] I send back consistent and helpful JSON error responses from my API.
-   [ ] I use a library to validate all incoming data from the client on the server-side.
-   [ ] I understand the importance of logging errors for debugging.
-   [ ] I use `try...catch` blocks to handle errors in my `async/await` functions.

---

## 5. Research and References

-   **MDN Web Docs - Error**: [Link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error)
-   **Express.js Docs - Error handling**: [Link](https://expressjs.com/en/guide/error-handling.html)
-   **"Node.js Design Patterns"**: Has an excellent chapter on error handling patterns.
-   **Joi**: A popular and powerful data validation library for JavaScript. [Link](https://joi.dev/)
-   **Sentry / LogRocket / Datadog**: Examples of professional application monitoring and error tracking services.
