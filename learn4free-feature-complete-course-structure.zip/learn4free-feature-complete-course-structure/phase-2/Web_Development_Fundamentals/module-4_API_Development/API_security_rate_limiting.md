# API Security and Rate Limiting

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **List** common security threats for web APIs.
-   **Explain** the importance of input validation for preventing security vulnerabilities.
-   **Define** rate limiting and explain its purpose.
-   **Implement** a basic rate-limiting middleware in your backend application.
-   **Describe** Cross-Origin Resource Sharing (CORS) and why it's a necessary security feature in browsers.
-   **Configure** a CORS policy on your server to allow requests from your frontend application.
-   **Understand** the importance of using HTTPS to protect data in transit.

---

## 2. Introduction to API Security

Once your API is deployed to the internet, it becomes a potential target for malicious actors. **API security** is the practice of protecting your API from attacks. It is not a single feature, but rather a collection of best practices that you must implement to ensure the confidentiality, integrity, and availability of your data and services. This module covers some of the most fundamental and essential security measures for any web API.

---

## 3. Core Concepts

### 1. Input Validation

This is the **single most important rule of web security**. Never trust data that comes from the client. You must validate everything: request bodies, query parameters, path parameters, and headers.

-   **The Threat**: Malicious users can send specially crafted input to exploit vulnerabilities in your application. A common example is a **SQL Injection** attack, where an attacker sends a piece of SQL code in a request parameter, which might then be executed by your database.
-   **The Solution**:
    -   **Validate Type and Format**: Ensure a user ID is an integer, an email looks like an email, and a string doesn't exceed a maximum length.
    -   **Use an ORM or Parameterized Queries**: An Object-Relational Mapper (ORM) or a library that supports parameterized queries will automatically "sanitize" your inputs, preventing SQL injection. **Never** construct SQL queries using string concatenation.
    -   **Use Validation Libraries**: Libraries like `Joi` (for Node.js) or `Pydantic` (for Python) allow you to define a schema for your request bodies and automatically validate incoming requests against it.

### 2. Rate Limiting

-   **The Threat**: A malicious actor (or a buggy script) could send thousands of requests per second to your API. This could overload your server, making it slow or unavailable for legitimate users (a **Denial-of-Service or DoS attack**). It can also be used to rapidly guess passwords or scrape data.
-   **The Solution**: **Rate limiting** is the practice of restricting the number of requests a user can make in a given time period. For example, you might limit a user to 100 requests per minute.
-   **Implementation**: Rate limiting is typically implemented as a middleware. It tracks the IP address or API key of the client and maintains a count of the requests made in a specific time window. Libraries like `express-rate-limit` for Express.js make this easy to implement.

### 3. CORS (Cross-Origin Resource Sharing)

-   **The Threat**: For security reasons, web browsers enforce the **Same-Origin Policy**. This policy prevents a web page from making requests to a different domain (or "origin") than the one that served the page. Without this policy, a malicious website could use your browser's credentials to make requests to your bank's API.
-   **The Solution**: **CORS** is a mechanism that uses HTTP headers to tell a browser to let a web application running at one origin have permission to access selected resources from a server at a different origin.
-   **Implementation**: This is handled on the **server**. Your backend application needs to include a `Access-Control-Allow-Origin` header in its response. For example, `Access-Control-Allow-Origin: https://my-frontend-app.com`. A `*` value can be used, but it is less secure and should be avoided in production if possible. Most backend frameworks have a built-in CORS middleware that makes this easy to configure.

### 4. HTTPS (HTTP Secure)

-   **The Threat**: Standard HTTP sends all data in plain text. Anyone "listening" on the network (e.g., on a public Wi-Fi network) can intercept and read the data, including passwords and authentication tokens. This is a **Man-in-the-Middle (MITM)** attack.
-   **The Solution**: Always use **HTTPS** in production. HTTPS is the secure version of HTTP, where the communication protocol is encrypted using Transport Layer Security (TLS) or, formerly, Secure Sockets Layer (SSL). This ensures that data sent between the client and the server is encrypted and cannot be read by third parties.
-   **Implementation**: You obtain an SSL/TLS certificate (free certificates are available from services like Let's Encrypt) and configure it on your web server or reverse proxy (e.g., Nginx).

---

## 4. Deliberate Practice

1.  **Implement Validation**: In an endpoint that accepts a request body (like a `POST /users` endpoint), add input validation. Ensure that the `email` is a valid email format and that the `password` is at least 8 characters long. Return a `400 Bad Request` error if the validation fails.
2.  **Implement Rate Limiting**: Add a rate-limiting middleware to your entire API. Set a low limit for testing (e.g., 5 requests per minute). Use Postman or a script to send more than 5 requests and verify that you receive a `429 Too Many Requests` error.
3.  **Configure CORS**:
    -   Run your backend server locally (e.g., on `http://localhost:3000`).
    -   Create a simple `index.html` file with a `fetch` call to your local server.
    -   Open the HTML file directly in your browser (it will have a `file:///` origin).
    -   Observe the CORS error in the browser console.
    -   Now, add and configure a CORS middleware on your server to allow requests from `null` (the origin for local files) or `*`. Verify that the `fetch` request now works.

---

## 5. Active Recall Questions

-   What is the most important rule of web security?
-   What is a SQL Injection attack?
-   What is the purpose of rate limiting?
-   What problem does CORS solve?
-   Why should you always use HTTPS in production?

---

## 12. Summary and Mastery Checklist

-   [ ] I know that I must **always validate all client input**.
-   [ ] I can explain that rate limiting is used to prevent abuse and DoS attacks.
-   [ ] I understand that CORS is a browser security feature and that it is the **server's** responsibility to configure the correct headers.
-   [ ] I know that HTTPS encrypts data in transit to prevent eavesdropping.
-   [ ] I can name at least 3 common API security best practices.

---

## 13. Research and References

-   **OWASP Top 10**: The Open Web Application Security Project's list of the 10 most critical web application security risks. It's essential reading for any web developer. [Link](https://owasp.org/www-project-top-ten/)
-   **MDN Web Docs - Cross-Origin Resource Sharing (CORS)**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS)
-   **Rate-Limiting Strategies**: An article from the Google Cloud blog on different approaches to rate limiting.
-   **Let's Encrypt**: A free, automated, and open certificate authority for getting SSL/TLS certificates. [Link](https://letsencrypt.org/)
