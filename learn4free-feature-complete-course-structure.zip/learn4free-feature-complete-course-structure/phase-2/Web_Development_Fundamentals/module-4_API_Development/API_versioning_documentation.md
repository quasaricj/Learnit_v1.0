# API Versioning and Documentation

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** why API versioning is necessary.
-   **Describe** the common strategies for versioning a REST API (URI, query parameter, header).
-   **Understand** the pros and cons of each versioning strategy.
-   **Explain** why API documentation is critical for API consumers.
-   **Describe** the OpenAPI (formerly Swagger) specification.
-   **Generate** interactive API documentation from code comments or a specification file.
-   **Understand** how GraphQL's schema-based approach simplifies versioning and documentation.

---

## 2. Introduction to API Lifecycle Management

Creating an API is just the first step. Once your API is being used by clients (whether it's your own frontend, mobile apps, or third-party developers), you need to manage its lifecycle. This means handling changes and communicating those changes to your users. **Versioning** is the mechanism for safely introducing breaking changes, and **documentation** is the method for communicating how your API works.

---

## 3. API Versioning (for REST APIs)

### Why Version?

Your API is a contract. When you make a **breaking change**—like removing a field, renaming a resource, or changing the authentication method—you risk breaking client applications that depend on the old contract. Versioning allows you to release a new version of your API with breaking changes while still supporting the old version for existing clients, giving them time to migrate.

**What is NOT a breaking change?** Adding a new field to a JSON response, adding a new optional request parameter, or adding a new API endpoint. These are generally considered safe, backward-compatible changes that do not require a new version.

### Common Versioning Strategies

1.  **URI Path Versioning**: This is the most common and straightforward approach. You include the version number directly in the URL.
    -   **Example**: `https://api.example.com/v1/users`
    -   *Pros*: Very explicit. Easy to see which version is being used.
    -   *Cons*: Can clutter the URI.

2.  **Query Parameter Versioning**: The version is specified as a query parameter.
    -   **Example**: `https://api.example.com/users?version=1`
    -   *Pros*: Simple to implement.
    -   *Cons*: Can be less clean and obvious than URI versioning.

3.  **Custom Header Versioning**: The version is specified in a custom HTTP header.
    -   **Example**: `Accept-Version: v1`
    -   *Pros*: Keeps the URIs "pure" and clean of version numbers.
    -   *Cons*: Less visible to the user. Requires a custom header, which is less intuitive for casual browsing of the API.

**Recommendation**: For most cases, **URI Path Versioning** is the clearest and most widely understood approach.

### Versioning in GraphQL

GraphQL has a different philosophy: **evolve the API without versions**. Because the client specifies exactly what data it wants, you can add new fields and types to the schema without breaking existing clients. Old fields can be marked as `deprecated` in the schema, which serves as a notice to developers that they should stop using them. This makes handling non-breaking changes seamless. Breaking changes (like removing a field) are still a major issue and are generally avoided.

---

## 4. API Documentation

Good documentation is what makes an API usable. If developers can't figure out how to use your API, they won't.

### The OpenAPI Specification (Swagger)

**OpenAPI** (originally known as Swagger) is a standard, language-agnostic specification for describing RESTful APIs. It allows you to describe your API in a structured `JSON` or `YAML` file, including:
-   All available endpoints (`/users/{id}`).
-   The HTTP methods for each endpoint.
-   The parameters (path, query, header) for each endpoint.
-   The structure of the request and response bodies.
-   Authentication methods.

### Interactive Documentation

The real power of an OpenAPI specification is that it is **machine-readable**. You can use a tool like **Swagger UI** or **Redoc** to automatically generate beautiful, interactive API documentation directly from your OpenAPI file. This documentation allows developers to not only read about your API but also make live API calls directly from the browser.

### Documentation-Driven Development

-   **Code-First**: You write your application code and then use a library to generate the OpenAPI specification and documentation from your code (often from comments/annotations).
-   **Design-First (or Spec-First)**: You write the OpenAPI `YAML` file first. This file becomes the contract. You can then use tools to generate boilerplate server code and mock servers from this specification. This is a powerful approach for large teams.

### Documentation in GraphQL

GraphQL is **self-documenting**. The schema itself is the documentation. Because the schema is strongly typed and defines every possible query, mutation, and type, you can use tools like **GraphiQL** or **Apollo Studio Explorer** to provide an interactive environment. These tools allow developers to explore the schema, see the available fields, and build queries with autocompletion, all without any extra documentation effort from the backend team.

---

## 5. Deliberate Practice

1.  **Choose a Versioning Strategy**: For the simple blog API you designed in a previous module, decide on a versioning strategy and update your endpoint URIs to reflect it (e.g., `/api/v1/posts`).
2.  **Explore Swagger UI**: Visit the live demo of the [Swagger Petstore API](https://petstore.swagger.io/).
    -   Explore the different endpoints.
    -   Try executing the `GET /pet/findByStatus` request directly from the documentation.
3.  **Generate Documentation**: If your backend framework has a library for generating OpenAPI specs (like `swagger-jsdoc` for Node.js or `drf-spectacular` for Django), try to add the necessary annotations to one of your endpoints to generate a basic documentation page.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that API versioning is for safely introducing breaking changes.
-   [ ] I can list the three common REST versioning strategies (URI, query, header).
-   [ ] I know that URI versioning (`/v1/`) is the most common approach.
-   [ ] I understand that OpenAPI (Swagger) is a specification for describing REST APIs.
-   [ ] I know that tools like Swagger UI can generate interactive documentation from an OpenAPI spec.
-   [ ] I can explain why GraphQL is considered self-documenting (thanks to its schema).

---

## 13. Research and References

-   **OpenAPI Specification**: The official website for the standard.
-   **Swagger**: The most popular set of tools for working with OpenAPI. [Link](https://swagger.io/)
-   **"Best Practices for API Versioning"**: A good article from the Google Apigee blog.
-   **GraphQL Docs - Best Practices (Versioning)**: [Link](https://graphql.org/learn/best-practices/#versioning)
