# Error Handling and Validation in APIs

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Design** a consistent and predictable error response format for your API.
-   **Differentiate** between client errors (4xx) and server errors (5xx) and use the appropriate status codes.
-   **Implement** server-side validation for incoming data.
-   **Provide** clear and actionable error messages for validation failures.
-   **Create** a centralized error handling mechanism in your backend application.
-   **Understand** the importance of logging errors for debugging.

---

## 2. Introduction to API Error Handling

Proper error handling and validation are crucial for creating a robust and developer-friendly API. When something goes wrong, the API should provide a clear, helpful, and consistent response that allows the client to understand the problem and act accordingly. Good error handling improves the developer experience for your API consumers and makes your own frontend and backend easier to debug.

---

## 3. Core Concepts

### Consistent Error Format

Don't just send back a plain text error message. Define a consistent JSON structure for all your error responses. This allows clients to parse the error programmatically.

**Good Error Response Example**:
```json
{
  "status": "error",
  "statusCode": 400,
  "message": "Validation failed.",
  "errors": [
    {
      "field": "email",
      "message": "Email is not a valid email address."
    },
    {
      "field": "password",
      "message": "Password must be at least 8 characters long."
    }
  ]
}
```
This format is predictable and provides detailed, field-specific feedback.

### Client Errors (4xx) vs. Server Errors (5xx)

It is critical to use the correct HTTP status code to differentiate between errors that are the client's fault and errors that are the server's fault.

-   **4xx Client Errors**: The client sent a bad request. The client should fix the request and try again.
    -   `400 Bad Request`: The most common error for validation failures.
    -   `401 Unauthorized`: Missing or invalid credentials.
    -   `403 Forbidden`: User is not allowed to access the resource.
    -   `404 Not Found`: The requested resource does not exist.
-   **5xx Server Errors**: Something went wrong on the server. The client cannot fix this; they can only wait and try again later.
    -   `500 Internal Server Error`: A generic "catch-all" for unexpected errors (e.g., a bug in your code, a database connection failure). **You should never let unhandled exceptions crash your server.**

### Server-Side Validation

As mentioned in the security module, you must **always** validate data on the server, even if you also have validation on the frontend. A malicious user can easily bypass your frontend validation and send a direct request to your API.

-   **How to Implement**:
    -   Use a dedicated validation library (like `Joi`, `express-validator`, `Pydantic`). These are the preferred method.
    -   Define a schema or a set of rules for your expected request body.
    -   If the validation fails, stop processing the request immediately and send a `400 Bad Request` response with detailed error messages.

### Centralized Error Handling

Don't litter your controller/handler functions with `try...catch` blocks for every possible error. Most backend frameworks allow you to create a **centralized error handling middleware**.

-   **How it works**:
    1.  Your route handlers can be simplified. Instead of a `try...catch`, you just let any errors "throw".
    2.  You create a special middleware function at the end of your middleware stack. This function is designed to catch any errors that are thrown from the route handlers.
    3.  In this single, centralized place, you can inspect the type of error and format a consistent JSON response with the correct status code.

### Logging

-   For **client errors (4xx)**, you might not need to log much, as it's the client's fault.
-   For **server errors (5xx)**, you must log as much detail as possible (the error message, the stack trace, the request that caused it). These logs are your primary tool for debugging problems in production.

---

## 4. Deliberate Practice

1.  **Create an Error Response Format**: Define a standard JSON error format for your API and document it.
2.  **Implement Validation Middleware**:
    -   Choose a validation library for your framework.
    -   Create a validation middleware or schema for an endpoint that creates a user (`POST /users`).
    -   Validate that `username` is a non-empty string and `email` is in a valid email format.
    -   Use Postman to send invalid data to your endpoint and verify that you receive a `400` status code with a well-formatted error response.
3.  **Centralized Error Handler**: Refactor your application to use a centralized error handling middleware.
    -   Create a route that intentionally throws an error (e.g., `throw new Error('Something broke!');`).
    -   Verify that your error handler catches it and sends back a standard `500 Internal Server Error` JSON response.

---

## 5. Active Recall Questions

-   Why is it important to have a consistent error format?
-   What is the difference between a 400 and a 500 status code?
-   Why must you always perform validation on the backend?
-   What is the benefit of a centralized error handling middleware?
-   What kind of errors should you always log in detail?

---

## 12. Summary and Mastery Checklist

-   [ ] I can design a consistent JSON format for my API's error responses.
-   [ ] I know to use `400 Bad Request` for validation failures.
-   [ ] I know to use `500 Internal Server Error` for unexpected server-side problems.
-   [ ] I understand the importance of using a validation library to check incoming data.
-   [ ] I can explain the purpose of a centralized error handler.

---

## 13. Research and References

-   **MDN Web Docs - HTTP status codes**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status)
-   **Google Cloud - API design guide: Errors**: [Link](https://cloud.google.com/apis/design/errors) (A professional guide to designing error responses).
-   **Express.js Docs - Error handling**: [Link](https://expressjs.com/en/guide/error-handling.html) (A good example of centralized error handling).
