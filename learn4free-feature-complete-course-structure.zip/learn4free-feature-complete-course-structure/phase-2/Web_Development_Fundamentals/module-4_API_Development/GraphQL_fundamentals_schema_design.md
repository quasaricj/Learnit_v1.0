# GraphQL Fundamentals and Schema Design

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** GraphQL and explain its core purpose.
-   **Differentiate** GraphQL from REST.
-   **Explain** the problems of over-fetching and under-fetching that GraphQL solves.
-   **Describe** the roles of a GraphQL schema, queries, mutations, and resolvers.
-   **Write** a basic GraphQL query to fetch specific fields of data.
-   **Define** a simple GraphQL schema using the Schema Definition Language (SDL).
-   **Understand** how a single GraphQL endpoint handles all requests.

---

## 2. Introduction to GraphQL

**GraphQL** is a query language for APIs and a runtime for fulfilling those queries with your existing data. It was developed by Facebook and open-sourced in 2015. Unlike REST, which has many endpoints for different resources, a GraphQL API typically has a **single endpoint**. The client specifies exactly what data it needs in a single request, and the server returns a JSON response with precisely that data. This approach solves several common problems encountered with RESTful APIs.

---

## 3. Core Concepts

### The Problem: Over-fetching and Under-fetching

-   **Over-fetching**: The client downloads more data than it actually needs. For example, a REST endpoint `GET /users/1` might return a user object with 20 fields, but the UI only needs to display the user's name. This wastes bandwidth, which is especially problematic on mobile devices.
-   **Under-fetching**: The client doesn't get all the data it needs in a single request, forcing it to make multiple follow-up requests. For example, to get a blog post and its comments, you might have to make one request to `GET /posts/1` and then another to `GET /posts/1/comments`. This can be slow.

### The GraphQL Solution: The Client is in Control

With GraphQL, the client sends a "query" document to the server that specifies the exact fields and related objects it wants.

**Example Query**:
```graphql
query {
  post(id: "1") {
    title
    content
    author {
      name
    }
    comments {
      text
    }
  }
}
```
The server will respond with a JSON object that **mirrors the shape of the query**, containing only the requested data.

### The Three Pillars of GraphQL

1.  **Schema**:
    -   The schema is the heart of a GraphQL API. It is a strongly-typed contract that defines all the data that can be queried and the relationships between them. It is written in the **Schema Definition Language (SDL)**.
    -   The schema defines `Types` (e.g., `type Post { ... }`), `Queries` (for fetching data), and `Mutations` (for creating, updating, or deleting data).

2.  **Queries and Mutations**:
    -   **Query**: A request to read data from the server.
    -   **Mutation**: A request to write data to the server. By convention, any operation that causes a data write is defined as a mutation.

3.  **Resolvers**:
    -   A resolver is a **function on the backend** that is responsible for fetching the data for a single field in the schema.
    -   When a query comes in, the GraphQL server calls the appropriate resolvers for the fields in the query. The `post` resolver would fetch the post data, the `author` resolver would fetch the author data, and so on. This architecture allows you to fetch data from different sources (e.g., a SQL database, a NoSQL database, a third-party API) and combine it seamlessly in a single API response.

### Single Endpoint

A GraphQL API is served over HTTP via a single URL (e.g., `/graphql`). The query is sent in the body of a `POST` request. This is a fundamental difference from REST's multiple-URL approach.

---

## 4. Deliberate Practice

1.  **Explore a GraphQL API**: Use a public GraphQL API, like the [SpaceX GraphQL API](https://api.spacex.land/graphql/), in its interactive "GraphiQL" interface.
    -   Explore the schema documentation on the right-hand side.
    -   Write a query to fetch the details of the latest launch, but only select the `mission_name` and `launch_date_utc`.
    -   Write another query to fetch a specific rocket and include its `name` and `cost_per_launch`.
2.  **Schema Design**: On paper, write a simple GraphQL schema for a blog application. You'll need `type` definitions for `User`, `Post`, and `Comment`, as well as a `RootQuery` type to define how you can fetch this data.
3.  **Basic Server Setup**: Follow the "getting started" guide for a GraphQL server library in your chosen backend language (e.g., `apollo-server` for Node.js, `graphene` for Python) and create a simple "Hello, World" GraphQL server.

---

## 5. Active Recall Questions

-   What are the problems of "over-fetching" and "under-fetching"?
-   How is GraphQL different from REST in terms of endpoints?
-   What is the purpose of a GraphQL schema?
-   What is the difference between a query and a mutation?
-   What is a resolver?

---

## 8. Strong Foundations and Analytical Skills

**Case Study**: A Mobile App's Homescreen
-   Imagine a mobile app homescreen that needs to display the user's name, their number of unread notifications, and the titles of their 3 most recent blog posts.
-   **With REST**, this would require at least three separate API calls:
    1.  `GET /users/me`
    2.  `GET /notifications?unread=true`
    3.  `GET /posts?author=me&limit=3`
-   **With GraphQL**, this can be done in a **single request**. The mobile client sends one query that asks for exactly those three pieces of information, and the server returns them all in one response. This is a perfect example of how GraphQL can improve performance and simplify client-side logic.

---

## 11. Psychological and Cognitive Principles

-   **Strongly-Typed Contract**: The schema acts as a powerful, strongly-typed contract between the frontend and the backend. This eliminates a whole class of bugs related to mismatched data expectations and makes the API self-documenting. Frontend developers can see exactly what data is available and what format it will be in.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that GraphQL is a query language for APIs that lets the client request exactly the data it needs.
-   [ ] I can describe the problems of over-fetching and under-fetching.
-   [ ] I know that a GraphQL API typically has only one endpoint.
-   [ ] I can describe the roles of the schema (the contract), queries (reads), and mutations (writes).
-   [ ] I understand that resolvers are the backend functions that fetch the data for each field.

---

## 13. Research and References

-   **GraphQL Official Website**: [Link](https://graphql.org/) (The best place to start).
-   **"How to GraphQL"**: A free, open-source tutorial series.
-   **Apollo GraphQL Documentation**: Apollo is a popular platform for building and using GraphQL APIs, and their documentation is excellent. [Link](https://www.apollographql.com/docs/)
-   **"The 2021 GraphQL Guide" by Eve Porcello**: A great talk on the modern state of GraphQL.
