# REST vs. GraphQL Trade-offs

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Summarize** the core philosophies of REST and GraphQL.
-   **Compare** the two architectural styles across several key areas (e.g., data fetching, endpoints, caching, error handling).
-   **List** the main advantages of GraphQL (solves over/under-fetching, strong schema).
-   **List** the main advantages of REST (simplicity, caching, mature ecosystem).
-   **Analyze** a project's requirements and make an informed recommendation on whether to use REST or GraphQL.
-   **Understand** that REST and GraphQL are not mutually exclusive and can be used together.

---

## 2. Introduction: Not a Competition, but a Trade-off

REST has been the dominant architectural style for web APIs for over a decade, and it is a proven, reliable, and simple approach. GraphQL is a newer technology that was designed specifically to solve some of the common pain points of REST.

The choice between them is not about which one is "better" in general, but which one is **better for your specific use case**. Understanding the trade-offs is key to making a good architectural decision.

---

## 3. Core Comparison

| Feature                    | REST (Representational State Transfer)                               | GraphQL (Graph Query Language)                                    |
| -------------------------- | -------------------------------------------------------------------- | ----------------------------------------------------------------- |
| **Data Fetching**          | **Server-driven**. The server defines the data in each resource.     | **Client-driven**. The client asks for exactly the data it needs.   |
| **Over/Under-fetching**    | A common problem. Clients get a fixed data structure.              | Solved. Clients get precisely the data they requested.            |
| **Endpoints**              | **Multiple Endpoints**. Each resource has its own URL (`/users`, `/posts`). | **Single Endpoint**. All requests go to one URL (`/graphql`).       |
| **Caching**                | **Built-in and simple**. Uses standard HTTP caching for GET requests. | **More complex**. Cannot use simple HTTP caching. Requires more sophisticated client-side or server-side caching. |
| **Error Handling**         | Uses standard HTTP status codes to indicate success or failure.      | **Typically returns `200 OK`**. Errors are returned in a special `errors` field in the JSON response. |
| **Schema / Contract**      | Loosely defined. Relies on documentation (e.g., OpenAPI/Swagger).  | **Strongly typed and central**. The schema is a strict, machine-readable contract. |
| **Ecosystem & Tooling**    | Vast and mature. Decades of tooling for every language.            | Newer but growing very rapidly. Excellent tooling (e.g., GraphiQL, Apollo). |
| **Learning Curve**         | Low. Based on standard HTTP concepts.                                | Higher. Requires learning a new query language, schema design, and resolver logic. |

---

## 4. When to Choose GraphQL

GraphQL shines in scenarios where the client's data needs are complex and varied.

-   **Mobile App or SPA Frontends**: When you have multiple clients (e.g., a web app, an iOS app, an Android app) that all have slightly different data requirements. GraphQL allows each client to fetch only what it needs, which is great for performance on mobile networks.
-   **Complex Data Relationships**: For applications with highly nested or graph-like data (e.g., a social network where you need to fetch a user, their friends, and the friends of their friends). GraphQL makes this easy to do in a single request.
-   **Aggregating Multiple Services (Federation)**: GraphQL is excellent as a single "data gateway" that sits in front of multiple underlying microservices. The client can make one GraphQL query, and the gateway will fetch the data from all the different services and combine it into one response.

---

## 5. When to Choose REST

REST is often the simpler, faster, and more pragmatic choice, especially when the data requirements are straightforward.

-   **Simple, Resource-Based APIs**: For standard CRUD (Create, Read, Update, Delete) APIs where the data model is simple and the clients' needs are predictable.
-   **Public APIs with a Focus on Caching**: If your API serves a lot of public, cachable data, REST's alignment with HTTP caching is a major advantage.
-   **When You Need to Get Started Quickly**: The ecosystem for REST is vast. It's often easier and faster to spin up a simple REST API because the concepts are familiar and tooling is ubiquitous.
-   **File Uploads/Downloads**: Handling file transfers is more straightforward in REST than in GraphQL.

---

## 6. They Are Not Mutually Exclusive

You don't have to choose one or the other. It's very common to see a hybrid approach:
-   A company might use REST for most of its internal, resource-based microservices.
-   They might then build a single **GraphQL gateway** that sits on top of these REST services to provide a unified, flexible API for its frontend clients.

---

## 7. Deliberate Practice

**Scenario Analysis**: For each of the following scenarios, decide whether REST or GraphQL would be a better fit, and be prepared to justify your answer.

1.  A public API for a weather service that provides current weather data for a given city. The data is public and changes infrequently.
2.  The backend API for the Facebook mobile app, which has a very complex UI showing users, posts, comments, likes, and groups all on one screen.
3.  A simple internal API for a company's HR system to manage a list of employees (CRUD operations).
4.  A new video streaming service that needs to provide a single API for its web, mobile, and smart TV applications to use.

---

## 12. Summary and Mastery Checklist

-   [ ] I can list at least two advantages of REST (e.g., simplicity, HTTP caching).
-   [ ] I can list at least two advantages of GraphQL (e.g., solves over-fetching, strongly typed schema).
-   [ ] I know that REST uses multiple endpoints, while GraphQL uses a single endpoint.
-   [ ] I understand that REST uses HTTP status codes for errors, while GraphQL typically returns errors in the response body.
-   [ ] I can analyze a set of requirements and make a reasoned argument for choosing one architecture over the other.

---

## 13. Research and References

-   **GraphQL Official Website - GraphQL vs. REST**: [Link](https://graphql.org/learn/thinking-in-graphs/#rest)
-   **"API Architecture: The Rise of GraphQL"**: A talk by the creators of GraphQL.
-   **Red Hat - "GraphQL vs. REST: Which is the best API?"**: A good, balanced article on the topic.
-   **Apollo GraphQL - "REST vs. GraphQL"**: [Link](https://www.apollographql.com/blog/graphql/basics/graphql-vs-rest/)
