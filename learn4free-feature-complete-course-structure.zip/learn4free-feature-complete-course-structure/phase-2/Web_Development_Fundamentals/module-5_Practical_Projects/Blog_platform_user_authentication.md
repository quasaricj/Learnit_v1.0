# Practical Project: Blog Platform with User Authentication

## 1. Project Goal

To build a full-stack blog platform where users can register, log in, create their own posts, and view posts from other users. This project reinforces the core concepts of full-stack development, with a particular focus on authentication, authorization, and data relationships.

---

## 2. Learning Objectives (Project-Based)

-   **Full-Stack CRUD**: Implement full Create, Read, Update, and Delete functionality for a resource (blog posts).
-   **Authentication**: Secure the application by implementing a robust user registration and login system.
-   **Authorization**: Ensure that users can only edit or delete their *own* posts, not posts made by others.
-   **Database Relationships**: Model and manage the one-to-many relationship between users and posts in the database.
-   **REST API Design**: Build a clean, RESTful API for all frontend-backend communication.
-   **Frontend Routing**: Create a multi-page frontend application using a routing library.

---

## 3. Core Features (Minimum Viable Product)

### Frontend

1.  **Homepage**: Displays a list of all blog posts from all users.
2.  **Post Detail Page**: Shows the full content of a single blog post.
3.  **Authentication Pages**:
    -   A `/register` page.
    -   A `/login` page.
4.  **Create Post Page**: A protected page with a form for creating a new blog post. This should only be accessible to logged-in users.
5.  **My Posts Page**: A protected page that shows a list of the posts created by the currently logged-in user, with options to edit or delete them.

### Backend (REST API)

1.  **Users API**:
    -   `POST /api/users/register`: Create a new user account.
    -   `POST /api/users/login`: Authenticate a user and return a JWT.
2.  **Posts API**:
    -   `GET /api/posts`: Get a list of all posts.
    -   `GET /api/posts/:id`: Get a single post by its ID.
    -   `POST /api/posts`: **Protected**. Create a new post. The server should associate the post with the logged-in user.
    -   `PUT /api/posts/:id`: **Protected**. Update a post. The server must verify that the user making the request is the owner of the post.
    -   `DELETE /api/posts/:id`: **Protected**. Delete a post. The server must verify that the user making the request is the owner of the post.

---

## 4. Step-by-Step Implementation Guide

### Phase 1: Backend and Database

1.  **Database Design**: Design a SQL schema with a `users` table and a `posts` table. The `posts` table should have a `user_id` foreign key.
2.  **Project Setup**: Initialize your backend project.
3.  **Authentication**: Implement the `register` and `login` endpoints first. This is the foundation for the rest of the backend.
4.  **Posts API (CRUD)**:
    -   Implement the public `GET` endpoints for fetching posts.
    -   Implement the protected `POST` endpoint for creating a post. Use your authentication middleware to get the user's ID from the JWT and associate it with the new post.
    -   Implement the protected `PUT` and `DELETE` endpoints. This is the trickiest part. In your handler logic, after finding the post by its ID, you must check if the `post.user_id` matches the `user_id` from the JWT. If not, return a `403 Forbidden` error.

### Phase 2: Frontend Development

1.  **Project Setup**: Initialize your frontend project and install a routing library (e.g., `react-router-dom` for React, `vue-router` for Vue).
2.  **Component Scaffolding**: Create components for the `Navbar`, `PostList`, `PostDetail`, `LoginForm`, `RegisterForm`, and `CreatePostForm`.
3.  **Routing**: Set up your frontend routes for the different pages.
4.  **Public Pages**: Build the homepage and post detail page, fetching data from your public `GET` endpoints.
5.  **Authentication Flow**:
    -   Build the login and register forms.
    -   Implement a global state (using Context API or another tool) to store the user's authentication status and JWT.
    -   When the user logs in, store the token and update the global state.
    -   Create a "protected route" component that checks if the user is logged in. If not, it redirects them to the login page. Use this to protect the `/create-post` and `/my-posts` pages.
6.  **Protected Features**: Build the "Create Post" and "My Posts" pages, which will make authenticated API calls to your protected backend endpoints.

---

## 5. Potential Extensions

-   **Comments**: Add a `comments` table to the database and implement API endpoints for adding and viewing comments on posts.
-   **"Rich Text" Editor**: Instead of a plain `<textarea>` for creating posts, integrate a rich text editor library like TinyMCE or Quill.js.
-   **File Uploads**: Allow users to upload a cover image for their blog posts.
-   **Pagination**: If the list of posts gets very long, implement pagination on your `GET /api/posts` endpoint.

---

## 7. Tools and Resources

-   **Frontend Routing**: `react-router-dom` or `vue-router`.
-   **Password Hashing**: A library like `bcrypt` is essential for securely hashing passwords before storing them in the database.
-   **Backend Frameworks**: Express, Django, Flask, etc.
-   **Database**: PostgreSQL or MySQL.
