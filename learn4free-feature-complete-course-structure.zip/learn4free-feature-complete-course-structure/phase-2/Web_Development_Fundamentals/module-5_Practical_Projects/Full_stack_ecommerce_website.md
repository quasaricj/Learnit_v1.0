# Practical Project: Full-Stack E-commerce Website

## 1. Project Goal

To build a complete, full-stack e-commerce web application. This large-scale project will require you to integrate everything you have learned in Phase 2, from building a responsive frontend with a modern framework, to designing a backend API, to modeling and interacting with a database.

---

## 2. Learning Objectives (Project-Based)

This project is designed to provide a comprehensive, hands-on review of all Phase 2 concepts:

-   **Full-Stack Integration**: Connect a frontend application (built with React or Vue) to a backend API (built with Node/Express, Django, etc.).
-   **Frontend Development**: Build a multi-page, component-based Single Page Application (SPA).
-   **State Management**: Manage a global state for the shopping cart.
-   **Backend Development**: Design and implement a complete RESTful API for products, users, and orders.
-   **Authentication**: Implement user registration and login using JWT.
-   **Database Design**: Design a normalized relational database schema to store all application data.
-   **Data Persistence**: Perform CRUD (Create, Read, Update, Delete) operations on the database using SQL queries or an ORM.

---

## 3. Core Features (Minimum Viable Product)

### Frontend

1.  **Homepage**: Displays a grid of all available products.
2.  **Product Detail Page**: Shows the details of a single product when clicked.
3.  **Shopping Cart**:
    -   An "Add to Cart" button on the product page.
    -   A cart view that shows all items, allows for quantity changes, and displays the total price.
4.  **User Authentication**:
    -   A registration page.
    -   A login page.
    -   Protect certain actions (like checkout) so they are only accessible to logged-in users.
5.  **Basic Checkout**: A simple "checkout" button that simulates placing an order (no real payment processing is needed).

### Backend (REST API)

1.  **Products API**:
    -   `GET /api/products`: Fetch a list of all products.
    -   `GET /api/products/:id`: Fetch a single product by its ID.
2.  **Users API**:
    -   `POST /api/users/register`: Create a new user account.
    -   `POST /api/users/login`: Authenticate a user and return a JWT.
3.  **Orders API**:
    -   `POST /api/orders`: A protected endpoint to create a new order. The request should contain the list of products and quantities. The server should validate the user is logged in.

---

## 4. Step-by-Step Implementation Guide

### Phase 1: Backend and Database Setup

1.  **Database Design**: Design your SQL schema first. You will need tables for `users`, `products`, `orders`, and `order_items`.
2.  **Project Setup**: Initialize your backend project (e.g., `npm init`, `django-admin startproject`).
3.  **API Scaffolding**: Create the basic file structure for your routes/controllers and models.
4.  **Product Endpoints**: Implement the public product endpoints first (`GET /api/products` and `GET /api/products/:id`). Populate your database with some sample product data so you can test them.
5.  **Authentication**: Implement the user registration and login endpoints, including password hashing and JWT generation.
6.  **Protected Routes**: Implement the "place order" endpoint (`POST /api/orders`) and protect it with authentication middleware.

### Phase 2: Frontend Setup

1.  **Project Setup**: Use a CLI tool (`create-react-app`, `create-vue`) to initialize your frontend project.
2.  **Component Planning**: Break down the UI into components (`ProductGrid`, `ProductCard`, `CartView`, `Navbar`, etc.).
3.  **Static UI**: Build the static version of your UI. Create the components and lay them out, using placeholder data. Don't worry about state or API calls yet.

### Phase 3: Connecting Frontend and Backend

1.  **Fetch Products**: On your homepage, use `fetch` or a library like `axios` to call your backend's `GET /api/products` endpoint and display the real data.
2.  **State Management for Cart**: Choose a state management solution (Context API is a great fit here) to manage the shopping cart's state globally.
3.  **Implement "Add to Cart"**: Wire up the "Add to Cart" button to update the global cart state.
4.  **Authentication Flow**: Build the login and registration forms. When a user logs in, save the received JWT to local storage. Create a system (e.g., an `axios` interceptor or a custom hook) to attach the JWT to the `Authorization` header of all subsequent API requests.
5.  **Checkout**: Implement the final checkout button, which sends the contents of the cart to your protected `POST /api/orders` endpoint.

---

## 5. Potential Extensions

-   **Admin Panel**: Create a separate section of the site where an admin user can add, edit, and delete products.
-   **User Profiles**: Allow users to see a history of their past orders.
-   **Product Reviews**: Add the ability for users to leave reviews on products.
-   **Search and Filter**: Implement search functionality and the ability to filter products by category or price.
-   **Payment Gateway Integration**: Integrate a real payment provider like Stripe or PayPal.

---

## 7. Tools and Resources

-   **Frontend**: React or Vue.
-   **Backend**: Node.js/Express, Python/Django/Flask, or Java/Spring.
-   **Database**: PostgreSQL or MySQL.
-   **API Testing**: Postman or Insomnia.
-   **State Management**: React Context API, Redux, or Vuex.
-   **Styling**: Plain CSS, or a CSS framework like Tailwind CSS or Bootstrap.
