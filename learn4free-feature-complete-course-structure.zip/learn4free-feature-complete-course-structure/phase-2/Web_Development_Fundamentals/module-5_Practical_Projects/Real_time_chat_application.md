# Practical Project: Real-Time Chat Application

## 1. Project Goal

To build a simple, real-time chat application. This project will introduce you to a new paradigm of web communication beyond the standard request-response model of HTTP. You will use WebSockets to enable bidirectional, persistent connections between the client and the server, allowing for instant message delivery.

---

## 2. Learning Objectives (Project-Based)

-   **WebSockets**: Understand the difference between the HTTP request-response model and the persistent, bidirectional connection of WebSockets.
-   **Real-Time Communication**: Implement a system where messages sent from one client are instantly broadcast to all other connected clients.
-   **Event-Driven Backend**: Structure your backend code to handle connection, disconnection, and message events.
-   **Stateful Backend Components**: Manage the state of connected clients on the server.
-   **Frontend UI Updates**: Dynamically add new messages to the UI as they are received from the server, without needing to refresh the page.

---

## 3. Core Features (Minimum Viable Product)

1.  **Username Entry**: When a user first opens the application, they should be prompted to enter a username.
2.  **Chat Interface**: The main interface should have:
    -   A message window that displays all the chat messages.
    -   An input field for typing a new message.
    -   A "Send" button.
3.  **Real-Time Messaging**:
    -   When a user sends a message, it should be sent to the server via a WebSocket connection.
    -   The server should then broadcast this message to **all** other connected clients.
    -   All clients should instantly see the new message appear in their chat window.
4.  **User Notifications**: When a new user joins the chat, a notification message (e.g., "John has joined the chat") should be broadcast to all clients.

---

## 4. Step-by-Step Implementation Guide

### Phase 1: Backend (WebSocket Server)

1.  **Project Setup**: In your chosen backend language, you will need a WebSocket library in addition to your web framework.
    -   **Node.js**: The `ws` or `socket.io` library is the standard. `socket.io` is often easier for beginners.
    -   **Python**: Libraries like `channels` (for Django) or `Flask-SocketIO` provide WebSocket support.
2.  **WebSocket Server Initialization**: Create a WebSocket server and attach it to your HTTP server.
3.  **Connection Handling**: Set up an event listener for new client connections (`'connection'`).
    -   When a new client connects, add them to a list of connected clients.
    -   Broadcast a "user has joined" message to all other clients.
4.  **Message Handling**: Within the connection handler, set up an event listener for incoming messages (`'message'`).
    -   When the server receives a message from a client, it should immediately broadcast that same message to every client in its list of connected clients.
5.  **Disconnection Handling**: Set up an event listener for client disconnections (`'disconnect'`).
    -   When a client disconnects, remove them from your list and broadcast a "user has left" message.

### Phase 2: Frontend (WebSocket Client)

1.  **UI Scaffolding**: Create the basic HTML and CSS for the chat interface (a message area, an input box, and a send button).
2.  **Establish Connection**: In your frontend JavaScript, create a new WebSocket connection to your backend server.
    -   `const socket = new WebSocket('ws://localhost:3000');` (or use the `socket.io-client` library if you used Socket.IO on the backend).
3.  **Sending Messages**:
    -   Add a `'click'` event listener to the "Send" button.
    -   When clicked, it should get the value from the input field and send it to the server through the WebSocket connection (`socket.send(...)`).
4.  **Receiving Messages**:
    -   Add a `'message'` event listener to your socket object.
    -   When a message is received from the server, create a new element (e.g., a `<p>` or `<div>`) and append it to your message window to display the message.

---

## 5. Potential Extensions

-   **Multiple Rooms**: Allow users to create and join different chat rooms. The server will need to manage lists of clients for each room and only broadcast messages to clients in the same room.
-   **Typing Indicators**: When a user starts typing in the input box, send a "user is typing" event to the server, which can then be broadcast to other users.
-   **Private Messaging**: Implement a way for one user to send a direct message to another user.
-   **Message Persistence**: Connect your chat server to a database. When a message is received, save it to the database so that the chat history can be loaded when a user joins a room.

---

## 7. Tools and Resources

-   **WebSocket Libraries**:
    -   **Node.js**: `socket.io` is highly recommended for its ease of use and fallback mechanisms.
    -   **Python**: `Flask-SocketIO` or `Django Channels`.
    -   **Java**: Spring Framework has built-in support for WebSockets.
-   **MDN Web Docs - WebSockets API**: The client-side documentation for the browser's WebSocket API. [Link](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API)
-   **Socket.IO "Get Started" Guide**: A fantastic tutorial for building a simple chat application. [Link](https://socket.io/get-started/chat)
