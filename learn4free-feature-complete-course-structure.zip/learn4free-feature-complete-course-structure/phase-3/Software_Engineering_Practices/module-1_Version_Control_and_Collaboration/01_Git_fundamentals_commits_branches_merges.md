# Git Fundamentals: Commits, Branches, and Merges

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Version Control and explain its importance in software development.
- **Differentiate** between centralized (e.g., SVN) and distributed (e.g., Git) version control systems.
- **Initialize** a new Git repository.
- **Perform** the basic Git workflow: modify, stage (`git add`), and commit (`git commit`).
- **Create and switch** between branches (`git branch`, `git checkout`).
- **Merge** changes from one branch into another (`git merge`).
- **View** the history of a project using `git log`.

---

## 2. Introduction to Version Control and Git

A **Version Control System (VCS)** is a tool that helps a software team manage changes to source code over time. It keeps track of every modification to the code in a special kind of database. If a mistake is made, developers can turn back the clock and compare earlier versions of the code to help fix the mistake while minimizing disruption to all team members.

**Git** is the world's most popular **Distributed Version Control System (DVCS)**. In a DVCS, every developer has a full copy of the entire project history on their local machine. This makes most operations incredibly fast and allows for powerful offline workflows.

---

## 3. The Core Git Workflow

### The Three States

A file in a Git repository can be in one of three states:
1.  **Modified**: You have changed the file, but have not committed it to your database yet.
2.  **Staged**: You have marked a modified file in its current version to go into your next commit snapshot. This is a "holding area".
3.  **Committed**: The data is safely stored in your local database.

### The Basic Commands

1.  **`git init`**: Initializes a new Git repository in the current directory. This creates a hidden `.git` subdirectory where Git stores all its metadata.
2.  **`git add <file>`**: Adds a file from the "Modified" state to the "Staged" state. You can also use `git add .` to stage all modified files.
3.  **`git commit -m "Your descriptive message"`**: Takes all the files from the staging area and stores a snapshot of them permanently in your local repository. The message is crucial for explaining *why* you made the change.
4.  **`git status`**: Shows the current state of your working directory and the staging area. It tells you which files are modified, staged, or untracked.
5.  **`git log`**: Shows the history of all commits in the repository.

---

## 4. Branching and Merging

Branching is the single most powerful feature of Git. A **branch** is an independent line of development. You can create a new branch to work on a new feature or fix a bug without affecting the main codebase (which is usually on a branch called `main` or `master`).

### Branching Commands

- **`git branch <branch-name>`**: Creates a new branch.
- **`git branch`**: Lists all the branches in your local repository.
- **`git checkout <branch-name>`**: Switches your working directory to the specified branch.
- **`git checkout -b <branch-name>`**: A shortcut that creates a new branch and immediately switches to it.

### Merging

Once you have completed the work on your feature branch, you will want to integrate it back into your main branch. This is done by **merging**.

- **`git merge <branch-name>`**: Merges the specified branch's history into the current branch.
  - **Example Workflow**:
    1.  `git checkout main` (Switch to the receiving branch)
    2.  `git merge feature-branch` (Merge the feature branch into main)

- **Merge Conflicts**: If you and another developer have changed the same part of the same file on different branches, Git won't be able to automatically merge them. This is a **merge conflict**. You will have to manually edit the conflicted file to resolve the differences and then commit the result.

---

## 5. Deliberate Practice

1.  **Create a Repo**: Create a new directory, navigate into it, and initialize a new Git repository.
2.  **First Commit**: Create a `README.md` file, add some text to it, and then stage and commit the file with a clear commit message.
3.  **Branching Practice**:
    -   Create a new branch called `feature/add-license`.
    -   Switch to this new branch.
    -   Create a `LICENSE` file and add some text to it.
    -   Stage and commit the `LICENSE` file.
4.  **Merging Practice**:
    -   Switch back to your `main` branch.
    -   Merge the `feature/add-license` branch into `main`.
    -   Use `git log` to see how the commit from the feature branch is now part of the `main` branch's history.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that Git is a distributed version control system.
-   [ ] I can describe the three states: modified, staged, and committed.
-   [ ] I can use `git add` to stage a file and `git commit` to create a new commit.
-   [ ] I understand that a branch is an independent line of development.
-   [ ] I can create a new branch with `git checkout -b`.
-   [ ] I can use `git merge` to integrate changes from one branch into another.

---

## 7. Research and References

-   **Pro Git by Scott Chacon and Ben Straub**: The definitive, free online book on Git. The first few chapters are essential reading. [Link](https://git-scm.com/book/en/v2)
-   **Learn Git Branching**: An interactive, visual tutorial for learning Git. [Link](https://learngitbranching.js.org/)
-   **Atlassian Git Tutorial**: A comprehensive and beginner-friendly set of tutorials from the makers of Bitbucket. [Link](https://www.atlassian.com/git/tutorials/what-is-git)
-   **GitHub Skills**: Interactive courses to learn Git and GitHub. [Link](https://skills.github.com/)
