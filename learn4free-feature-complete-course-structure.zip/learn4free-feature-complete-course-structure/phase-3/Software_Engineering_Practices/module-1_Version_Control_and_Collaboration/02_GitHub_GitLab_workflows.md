# GitHub/GitLab Workflows

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Differentiate** between Git (the tool) and GitHub/GitLab (the hosting platforms).
- **Explain** the concept of a "remote" repository.
- **Clone** an existing repository from a remote server to your local machine.
- **Push** your local commits to a remote repository.
- **Pull** the latest changes from a remote repository to your local machine.
- **Describe** the basic "fork and pull request" workflow for contributing to open-source projects.

---

## 2. Introduction to Remote Repositories

**Git** is the command-line tool that runs on your local machine. **GitHub** and **GitLab** are web-based hosting services for Git repositories. They provide a central place for teams to store their code, collaborate, and manage their projects.

A **remote** is a version of your repository that is hosted on the internet or a network. When you are working with a team, you will have your own **local** copy of the repository, and there will be a single, canonical **remote** repository (often called `origin`) that everyone syncs their changes with.

---

## 3. Core Concepts and Commands

### `git clone <url>`

This is how you get a local copy of an existing remote repository. It downloads the entire repository, including all its history and branches, onto your machine. It also automatically sets up a remote named `origin` that points to the URL you cloned from.

### `git remote -v`

This command lists all the remote repositories you have configured, along with their URLs.

### `git push`

After you have made some commits locally, you need to share them with your team. `git push` uploads your committed changes to a remote repository.

- **`git push <remote-name> <branch-name>`**: The full command.
- **`git push origin main`**: A typical example, pushing the `main` branch to the `origin` remote.
- The first time you push a new branch, you may need to set its "upstream" tracking branch with a command like `git push -u origin <branch-name>`.

### `git pull`

To keep your local repository up-to-date with the changes made by your teammates, you need to "pull" their changes from the remote repository.

- **`git pull <remote-name> <branch-name>`**: The full command.
- **`git pull origin main`**: A typical example.
- `git pull` is actually a combination of two other commands: `git fetch` (which downloads the latest changes from the remote but doesn't merge them) and `git merge` (which merges the downloaded changes into your current branch).

### The "Push/Pull" Dance

The most common collaborative workflow is a cycle:
1.  **`git pull`**: Before you start working, get the latest changes from the remote.
2.  **Work and Commit**: Make your changes and commit them locally.
3.  **`git pull`**: Before you push, pull again. Someone else might have pushed changes while you were working. You need to merge their changes into your local branch first.
4.  **`git push`**: Push your changes to the remote.

---

## 4. The GitHub/GitLab Flow (Feature Branching)

This is the most common workflow for teams.
1.  **Create a Branch**: Before you start work on a new feature or bugfix, you create a new branch from the `main` branch. The branch should have a descriptive name (e.g., `feature/user-authentication`).
2.  **Work Locally**: Make your changes and commit them to your feature branch.
3.  **Push the Branch**: Push your feature branch to the remote repository (`origin`).
4.  **Open a Pull Request**: In the GitHub or GitLab web interface, you open a **Pull Request** (PR) or **Merge Request** (MR). This is a formal request to merge your feature branch into the `main` branch.
5.  **Code Review and Discussion**: Your teammates can now review your code, leave comments, and suggest changes. This is a critical part of the collaboration process.
6.  **Merge**: Once the PR/MR is approved and any automated checks have passed, it is merged into the `main` branch.

### The Forking Workflow (for Open Source)

When you want to contribute to a project that you don't have push access to, you use the forking workflow.
1.  **Fork**: You create a personal copy (a "fork") of the project's repository on your own GitHub/GitLab account.
2.  **Clone**: You `git clone` your fork to your local machine.
3.  **Branch and Commit**: You create a branch and make your changes, just like in the normal workflow.
4.  **Push to Your Fork**: You push your changes to *your fork*, not the original project's repository.
5.  **Open a Pull Request**: From the GitHub/GitLab UI, you open a pull request from your fork's branch to the original ("upstream") project's `main` branch.

---

## 5. Deliberate Practice

1.  **Create a GitHub Repo**: Go to GitHub.com and create a new, empty repository.
2.  **Push Existing Repo**: Take the Git repository you created in the last module. Add your new GitHub repository as a remote (`git remote add origin <url>`) and then push your `main` branch to it.
3.  **Clone and Modify**:
    -   Clone a public repository (e.g., a simple "hello world" project) from GitHub to your machine.
    -   Create a new branch, make a small change, and commit it.
    -   (You won't be able to push this change unless you fork it first, but the local workflow is good practice).

---

## 6. Summary and Mastery Checklist

-   [ ] I know that GitHub and GitLab are services that host remote Git repositories.
-   [ ] I can use `git clone` to get a local copy of a remote repository.
-   [ ] I use `git pull` to get the latest changes from the remote.
-   [ ] I use `git push` to share my local commits with the remote.
-   [ ] I can describe the basic feature branching workflow (branch -> push -> pull request -> merge).
-   [ ] I understand that a "fork" is a personal copy of another user's repository.

---

## 7. Research and References

-   **Pro Git - Chapter 2.5: Working with Remotes**: [Link](https://git-scm.com/book/en/v2/Git-Basics-Working-with-Remotes)
-   **GitHub Docs - GitHub flow**: [Link](https://docs.github.com/en/get-started/quickstart/github-flow)
-   **"Happy Git and GitHub for the useR" by Jenny Bryan**: An excellent and very practical guide, even for non-R users.
