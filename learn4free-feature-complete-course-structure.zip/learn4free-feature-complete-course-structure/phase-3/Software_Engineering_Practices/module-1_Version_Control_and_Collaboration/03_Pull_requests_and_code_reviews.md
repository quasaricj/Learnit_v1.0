# Pull Requests and Code Reviews

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a Pull Request (PR) and explain its purpose in a collaborative workflow.
- **Create** a new Pull Request on GitHub or GitLab.
- **Describe** the key components of a good PR description.
- **Explain** the importance of code reviews for code quality and knowledge sharing.
- **Participate** effectively in a code review, both as an author and as a reviewer.
- **Update** a Pull Request based on feedback from a code review.

---

## 2. Introduction to Pull Requests

A **Pull Request (PR)**—called a **Merge Request (MR)** on GitLab—is the central feature of collaborative development on platforms like GitHub and GitLab. It is a formal request to merge the changes from one branch (your feature branch) into another (typically the main branch).

A PR is much more than just a merge request; it is a dedicated forum for **discussing a proposed change**. It provides a place for your team to review the code, discuss potential issues, and suggest improvements before the changes are integrated into the main codebase.

---

## 3. The Anatomy of a Good Pull Request

A clear and well-written PR is a courtesy to your reviewers and dramatically speeds up the review process.

### 1. A Clear and Concise Title

The title should summarize the change in one line. For example: "Feat: Add user authentication via JWT" or "Fix: Correct calculation error in payment module".

### 2. A Detailed Description

The description should provide the context that the reviewer needs to understand your changes. It should answer the "why" and the "what".

- **Why**: Why was this change made? What problem does it solve? If it's fixing a bug, link to the issue in your issue tracker.
- **What**: What did you change? Give a high-level overview of your approach.
- **How to Test**: Provide clear, step-by-step instructions on how a reviewer can test your changes.

Many teams use a **PR template** to ensure that all this information is included.

### 3. Small and Focused Changes

The best PRs are small and focused on a single issue. A PR that changes hundreds of files and touches a dozen different features is extremely difficult and time-consuming to review. It's better to break up a large piece of work into several smaller, independent PRs.

---

## 4. The Code Review Process

A **code review** is the process of having your teammates review your code before it is merged.

### Why is Code Review Important?

- **Improves Code Quality**: It's a powerful way to catch bugs, logic errors, and architectural issues before they get into the main codebase.
- **Knowledge Sharing**: The reviewer learns about the changes being made, and the author can learn from the reviewer's experience and suggestions. It's one of the best ways to spread knowledge and best practices across a team.
- **Maintains Consistency**: It helps to ensure that all code in the repository adheres to the team's established coding style and conventions.
- **Collective Ownership**: It promotes a sense of shared ownership of the code.

### Being a Good Reviewer

- **Be Kind and Constructive**: The goal is to improve the code, not to criticize the author. Frame your feedback as suggestions or questions ("What do you think about...?", "Have you considered...?").
- **Review the Logic**: Don't just look for style issues (a linter can do that). Try to understand the logic of the change. Does it solve the problem correctly? Does it handle edge cases?
- **Provide Specific Suggestions**: Instead of saying "this is confusing," try to explain *why* it's confusing and offer a specific suggestion for how to improve it.
- **Be Timely**: Don't leave a teammate's PR hanging for days. A timely review is a sign of respect and keeps the development process moving.

### Being a Good Author

- **Respond Graciously**: Be open to feedback. Remember that the goal is to create the best possible product.
- **Don't Take it Personally**: The review is about the code, not about you.
- **Explain Your Reasoning**: If you disagree with a suggestion, explain your reasoning clearly and professionally.
- **Update Your PR**: Make the requested changes, push the new commits to your feature branch (the PR will update automatically), and let the reviewer know when it's ready for another look.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that a Pull Request is a formal request to merge a branch and a forum for discussion.
-   [ ] I know that a good PR description should explain the "why" and the "what" of the change.
-   [ ] I understand that small, focused PRs are easier to review than large ones.
-   [ ] I can list at least two benefits of code review (e.g., improves code quality, shares knowledge).
-   [ ] I understand the basic etiquette for being a good code reviewer (be constructive, be timely).
-   [ ] I know how to update a PR by pushing new commits to the branch it's based on.

---

## 6. Research and References

-   **GitHub Docs - About pull requests**: [Link](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests)
-   **"The Art of the Pull Request"**: A blog post by Brent T. Var Ede.
-   **Google's Engineering Practices - How to do a code review**: A very detailed and highly respected guide. [Link](https://google.github.io/eng-practices/review/reviewer/)
-   **Conventional Commits**: A specification for adding human and machine-readable meaning to commit messages, which helps in creating clear PR titles. [Link](https://www.conventionalcommits.org/en/v1.0.0/)
