# Branching Strategies (Git Flow, Trunk-Based Development)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** what a branching strategy is and why it's important for a team.
- **Describe** the Git Flow branching model and its different types of branches.
- **Describe** the Trunk-Based Development branching model.
- **Compare and contrast** Git Flow and Trunk-Based Development.
- **Understand** the relationship between a branching strategy and a release process.

---

## 2. Introduction to Branching Strategies

A **branching strategy** (or branching model) is a set of rules and conventions that a software team agrees to follow when using Git. It defines how branches are named, what purpose they serve, and how changes flow between them.

Having a consistent branching strategy is crucial for a team because it:
- Creates a structured and predictable workflow.
- Helps to avoid confusion and "merge hell".
- Allows for parallel development on different features.
- Defines how to manage releases and hotfixes.

The two most popular branching strategies are Git Flow and Trunk-Based Development.

---

## 3. Git Flow

Git Flow is a robust and well-defined branching model that was one of the first to become widely popular. It is designed to support a strict release cycle.

### The Branches of Git Flow

Git Flow uses two long-lived branches:
1.  **`master` (or `main`)**: This branch represents the official, production-ready release history. It is tagged with version numbers (e.g., `v1.0`, `v1.1`).
2.  **`develop`**: This is the main integration branch for new features. All feature work is merged into `develop`.

And several types of short-lived, supporting branches:
3.  **`feature/*`**: Branched from `develop`. This is where you work on a new feature. When the feature is complete, it is merged back into `develop`.
4.  **`release/*`**: Branched from `develop`. When the `develop` branch is stable and you are preparing for a new release, you create a `release` branch. This branch is used for final bug fixes and preparation. No new features are added here.
5.  **`hotfix/*`**: Branched from `master`. If a critical bug is found in production, you create a `hotfix` branch from the tagged `master` branch. This allows you to fix the bug without interfering with the ongoing work in `develop`.

### The Flow

- Feature branches are merged into `develop`.
- When ready for a release, a `release` branch is created from `develop`.
- Once the `release` branch is stable, it is merged into **both `master` (and tagged)** and **`develop`**.
- If a `hotfix` is needed, it is branched from `master` and then merged into **both `master`** and **`develop`**.

**Pros**: Very structured, great for projects with a scheduled release cycle (e.g., desktop software).
**Cons**: Can be overly complex for web applications that deploy continuously.

---

## 4. Trunk-Based Development (TBD)

Trunk-Based Development is a simpler branching model that has become the standard for modern web applications that practice Continuous Integration and Continuous Deployment (CI/CD).

### The "Trunk"

In TBD, there is a single, central branch called the **`trunk`** (this is usually the `main` or `master` branch).

### The Flow

1.  Developers create short-lived feature branches from the `trunk`.
2.  They work on their feature, committing to their branch.
3.  Crucially, they must **frequently** pull and rebase/merge the latest changes from the `trunk` into their feature branch to stay up-to-date.
4.  When the feature is complete, it is merged into the `trunk` via a pull request.
5.  The `trunk` is always kept in a "green" (releasable) state. Automated tests are run on every commit to the `trunk`.

**Key Principles of TBD**:
- **Short-lived branches**: Feature branches should exist for no more than a few days.
- **Small, frequent commits**: Developers integrate their work with the `trunk` at least once a day.
- **Feature Flags**: If a feature is not yet complete but the code needs to be merged, it is hidden behind a "feature flag" (a runtime toggle) so that it doesn't affect users in production.

**Pros**: Simple, promotes collaboration, and is the foundation for CI/CD.
**Cons**: Requires a very strong automated testing culture.

---

## 5. Git Flow vs. Trunk-Based Development

| Feature              | Git Flow                                      | Trunk-Based Development                     |
| -------------------- | --------------------------------------------- | ------------------------------------------- |
| **Primary Branch**   | `master` (production) and `develop` (integration) | `trunk` (main/master)                       |
| **Branch Lifespan**  | Feature branches can be long-lived.           | Feature branches must be very short-lived.  |
| **Release Process**  | Explicit `release` branches; scheduled releases. | Any commit on the trunk can be a release.   |
| **Complexity**       | High. Many rules to follow.                   | Low. Simple and straightforward.            |
| **Best suited for**  | Projects with a formal, versioned release cycle. | Web apps, SaaS, projects practicing CI/CD.  |

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that a branching strategy is a set of rules for managing branches in a team.
-   [ ] I can name the two main, long-lived branches in Git Flow (`master` and `develop`).
-   [ ] I can describe the purpose of feature, release, and hotfix branches in Git Flow.
-   [ ] I can describe Trunk-Based Development as a simpler model with a single main branch (the "trunk").
-   [ ] I understand that Trunk-Based Development relies on short-lived branches and is essential for CI/CD.
-   [ ] I can explain the high-level trade-offs between the two strategies.

---

## 7. Research and References

-   **"A successful Git branching model" by Vincent Driessen**: The original and famous blog post that introduced Git Flow. [Link](https://nvie.com/posts/a-successful-git-branching-model/)
-   **Trunk-Based Development Website**: A website that explains the TBD model in great detail. [Link](https://trunkbaseddevelopment.com/)
-   **Atlassian - Git Branching Workflows**: A great article comparing different branching strategies. [Link](https://www.atlassian.com/git/tutorials/comparing-workflows)
-   **"The State of DevOps Report"**: An annual report that consistently finds that Trunk-Based Development is a key practice of high-performing technology organizations.
