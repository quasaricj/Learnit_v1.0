# Conflict Resolution and Merge Strategies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a merge conflict and explain why it occurs.
- **Identify** a merge conflict in your local repository.
- **Manually resolve** a merge conflict using a code editor.
- **Differentiate** between a regular merge and a rebase.
- **Perform** an interactive rebase (`rebase -i`) to clean up local commit history.
- **Understand** the "golden rule of rebasing".

---

## 2. Introduction to Merge Conflicts

A **merge conflict** is an event that occurs when Git is unable to automatically resolve differences in code between two commits. This is a normal and expected part of working with Git in a team. The key is to understand why conflicts happen and how to resolve them calmly and correctly.

A conflict occurs when two branches have changed the **same lines** in the **same file**, or when one branch has deleted a file that another branch has modified. Git is smart, but it's not a mind reader; it cannot know which version of the code is the correct one, so it stops and asks you, the developer, to resolve the conflict.

---

## 3. Resolving a Merge Conflict

When a merge conflict occurs, Git will pause the merge process and edit the conflicted file to show you both versions of the code, surrounded by "conflict markers".

```
<<<<<<< HEAD
This is the version of the code from your current branch (HEAD).
=======
This is the version of the code from the branch you are trying to merge.
>>>>>>> other-branch-name
```

**The Resolution Process**:
1.  **Identify the Conflict**: `git status` will show you which files are in a conflicted state.
2.  **Open the File**: Open the conflicted file in your code editor.
3.  **Edit the File**: Manually edit the file to resolve the conflict. You must:
    -   Decide which version of the code to keep (yours, theirs, or a combination of both).
    -   **Delete the conflict markers** (`<<<<<<<`, `=======`, `>>>>>>>`).
4.  **Stage the Resolved File**: Once you have resolved the conflict and saved the file, you must tell Git that the conflict is resolved by staging the file: `git add <resolved-file-name>`.
5.  **Complete the Merge**: Commit the changes to complete the merge. You can simply run `git commit`. Git will provide a default commit message indicating that a merge was performed.

---

## 4. Merge vs. Rebase

`git merge` and `git rebase` are two different ways to integrate changes from one branch into another.

### Merge (`git merge`)

- **What it does**: Takes all the commits from a feature branch and merges them into the target branch. It creates a new **merge commit** in the target branch that ties the two histories together.
- **Pros**:
  - **Preserves History**: It's non-destructive. It keeps the exact history of the feature branch as it was.
  - **Easy to understand**: The history is a true and accurate log of what happened.
- **Cons**:
  - **Messy History**: If many feature branches are being merged, the `git log` can become a complex, branching graph that is hard to read.

### Rebase (`git rebase`)

- **What it does**: Takes all the commits from your feature branch and **re-applies** them, one by one, on top of the latest commit from the target branch.
- **How it works**:
  1.  It "unwinds" your feature branch, saving the commits as temporary patches.
  2.  It fast-forwards your branch's starting point to the latest commit on the target branch.
  3.  It then applies your patches one by one.
- **Pros**:
  - **Linear History**: The result is a perfectly linear and clean project history. It looks as if you did all your work in a straight line, right after the latest work on the main branch.
- **Cons**:
  - **Rewrites History**: Rebasing fundamentally rewrites the commit history (it creates new commits with new SHA-1 hashes). This can be dangerous if you don't follow the golden rule.

### The Golden Rule of Rebasing

**Never rebase a branch that has been shared with others (i.e., pushed to a remote repository).**

If you rebase a branch that others are working on, you are rewriting the history that they have based their work on. When they try to pull your rebased changes, Git will see their history as having diverged from yours, and it will cause confusion and potential problems for the whole team.

**It is safe to rebase your own local feature branch that you have not yet pushed.**

### Interactive Rebase (`git rebase -i`)

This is a powerful tool for cleaning up your *local* commit history **before** you share it in a pull request. `git rebase -i HEAD~3` allows you to edit your last 3 commits to:
- **`squash`**: Combine multiple small commits (like "fix typo", "oops") into a single, meaningful commit.
- **`reword`**: Change the commit message.
- **`reorder`**: Change the order of the commits.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that a merge conflict happens when Git cannot automatically merge changes to the same lines in the same file.
-   [ ] I can find the conflict markers in a conflicted file and manually edit the file to resolve the conflict.
-   [ ] I know that I must `git add` the resolved file before committing to finish the merge.
-   [ ] I can describe the difference between `git merge` (which creates a merge commit) and `git rebase` (which creates a linear history).
-   [ ] I understand the "golden rule of rebasing" and know that I should only rebase my own local, un-pushed branches.
-   [ ] I know that `git rebase -i` can be used to "squash" and clean up my local commit history.

---

## 6. Research and References

-   **Pro Git - Chapter 3.6: Git Branching - Rebasing**: [Link](https://git-scm.com/book/en/v2/Git-Branching-Rebasing)
-   **Atlassian - Merging vs. Rebasing**: A fantastic tutorial with great diagrams. [Link](https://www.atlassian.com/git/tutorials/merging-vs-rebasing)
-   **"Git Interactive Rebase, Squash, Amend and Other Ways of Rewriting History"**: A clear blog post on cleaning up commit history.
