# Code Review Best Practices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** code review and explain its primary goals (improving code quality, knowledge sharing, mentorship).
-   **List** best practices for authors submitting their code for review.
-   **List** best practices for reviewers providing feedback.
-   **Write** clear, constructive, and actionable review comments.
-   **Categorize** feedback (e.g., critical, suggestion, nitpick).
-   **Respond** to review feedback professionally and effectively.

---

## 2. Introduction to Code Reviews

A **code review** is the process where developers other than the code's author examine a piece of code. It is a central part of the Pull Request workflow and one of a software team's most powerful tools.

The goals of a code review are not just to find bugs. A good code review process also serves to:
-   **Improve Code Quality**: Catch defects, improve readability, and ensure consistency with the team's coding standards.
-   **Share Knowledge**: Spread knowledge of the codebase across the team, reducing knowledge silos.
-   **Mentor and Learn**: Provide opportunities for junior developers to learn from seniors, and for seniors to learn new perspectives.
-   **Foster a Collaborative Culture**: Build a shared sense of ownership and collective responsibility for the code.

---

## 3. Best Practices for the Author

How you prepare your Pull Request has a huge impact on the quality and speed of the review you will receive.

1.  **Keep it Small**: The single most important rule. Small, focused PRs are much easier and faster to review. Aim for a PR that does one thing well. A PR with more than 400 lines of changes has a much higher chance of being reviewed poorly.
2.  **Write a Clear Title and Description**:
    -   The **title** should be a concise summary of the change.
    -   The **description** should provide context. Why is this change being made? What problem does it solve? Link to the relevant issue or ticket. If there are UI changes, include a screenshot or GIF.
3.  **Review Your Own Code First**: Before you assign reviewers, read through your own code one last time. You will often catch your own typos, bugs, or forgotten `console.log` statements.
4.  **Propose a Solution, Not a Masterpiece**: Your code doesn't have to be perfect. If you are unsure about a particular part of your implementation, leave a comment on your own PR to ask for specific feedback on that section.

---

## 4. Best Practices for the Reviewer

The goal is to be helpful, not to be a gatekeeper. Your tone and approach matter.

1.  **Be Kind and Respectful**: The author is not their code. Critique the code, not the person. Phrase comments as suggestions or questions, not commands.
    -   *Bad*: "Fix this. This is wrong."
    -   *Good*: "What do you think about renaming this variable to `isComplete` for clarity?"
2.  **Understand the Context**: Read the PR description and the associated ticket first. Understand the *goal* of the change before you dive into the code.
3.  **Balance Priorities**: Look for the most important issues first:
    -   **Critical**: Does the code work? Does it solve the problem? Are there major bugs or architectural flaws?
    -   **Important**: Is the code readable, maintainable, and well-tested? Does it follow team conventions?
    -   **Trivial (Nitpicks)**: Minor stylistic issues like whitespace or comment phrasing. It's fine to point these out, but preface them with "Nitpick:" to signal that they are not critical.
4.  **Provide Actionable Feedback**: Don't just say "This is confusing." Explain *why* it's confusing and suggest a clearer alternative.
5.  **Automate What You Can**: A human reviewer should not be spending their time checking for style violations (like tabs vs. spaces). This should be done by an automated linter in the CI pipeline. The reviewer's job is to focus on the things a machine can't, like logic, architecture, and readability.
6.  **Review Promptly**: A PR is a blocker for the author. Try to provide feedback within a reasonable timeframe (e.g., one business day).

---

## 5. Deliberate Practice

1.  **Review a PR**: Go to an open-source project on GitHub and find an open Pull Request. Read through the changes and the comments. Do the reviewers follow the best practices? Is the feedback constructive?
2.  **Self-Review**: Look at a piece of code you wrote a month ago. Imagine you are reviewing it for the first time. What feedback would you give yourself?
3.  **Practice Commenting**: Find a small code snippet and write two versions of a review comment for it: one that is blunt and unhelpful, and one that is constructive, kind, and provides a clear suggestion.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that the goal of code review is to improve code and share knowledge, not just find bugs.
-   [ ] **As an author**, I will create small, focused PRs with clear descriptions.
-   [ ] **As an author**, I will review my own code before submitting it.
-   [ ] **As a reviewer**, I will be kind, respectful, and focus my feedback on the code, not the person.
-   [ ] **As a reviewer**, I will provide clear, actionable suggestions, not just criticism.
-   [ ] **As a reviewer**, I will prioritize feedback, distinguishing between critical issues and minor nitpicks.

---

## 13. Research and References

-   **Google's Engineering Practices - How to do a code review**: A comprehensive guide from one of the world's top engineering organizations. [Link](https://google.github.io/eng-practices/review/)
-   **"The Art of Code Review"**: A great talk by Han-Wen Nienhuys.
-   **Conventional Comments**: A system for labeling review comments to make their importance clear. [Link](https://conventionalcomments.org/)
-   **"Stop Nitpicking in Code Reviews"**: An article that discusses the importance of focusing on what matters.
