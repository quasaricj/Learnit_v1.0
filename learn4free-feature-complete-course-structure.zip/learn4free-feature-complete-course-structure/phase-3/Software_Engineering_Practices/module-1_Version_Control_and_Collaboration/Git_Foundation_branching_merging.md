# Git Foundation: Branching and Merging

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** version control and its importance in software development.
-   **Differentiate** between centralized and distributed version control systems.
-   **Explain** the core Git concepts: repository, commit, branch, and HEAD.
-   **Perform** the basic Git workflow: `git add`, `git commit`, `git push`, `git pull`.
-   **Create and switch between** branches to work on features in isolation.
-   **Merge** changes from one branch into another.
-   **Understand** what a merge conflict is and how to resolve it.

---

## 2. Introduction to Version Control

A **Version Control System (VCS)** is a tool that helps you track changes to your code over time. It's like a "save" button for your entire project, allowing you to:
-   Keep a history of all changes.
-   Revert to previous versions if you make a mistake.
-   Collaborate with other developers on the same project without overwriting each other's work.
-   Experiment with new features without affecting the main, stable version of your code.

**Git** is the world's most popular **Distributed Version Control System (DVCS)**.

---

## 3. Core Concepts

### Repository (Repo)

A **repository** is your project's folder. The Git repository is a hidden subdirectory within this folder (named `.git`) where Git stores all of its tracking information, history, and metadata.

### The Three States

Git thinks about your files in three main states:
1.  **Modified**: You have changed a file, but have not yet committed it to your database.
2.  **Staged**: You have marked a modified file in its current version to go into your next commit snapshot. This is the "staging area".
3.  **Committed**: The data is safely stored in your local repository.

### Commit

A **commit** is a snapshot of your staged files at a particular point in time. It is the fundamental unit of Git history. Each commit has a unique ID and a commit message explaining the changes.

### Branch

A **branch** is a lightweight, movable pointer to a commit. It represents an independent line of development. The default branch is usually named `main` or `master`. You create new branches to work on new features or bug fixes in isolation from the main codebase.

-   **`HEAD`**: A special pointer that indicates which branch you are currently working on.

### Basic Workflow

1.  You modify files in your working directory.
2.  You stage the files you want to include in your next commit: `git add <filename>`
3.  You commit the staged files to your local repository: `git commit -m "Your descriptive message"`
4.  You push your committed changes to a remote repository (like GitHub): `git push origin <branch_name>`
5.  You pull changes from the remote repository to your local machine: `git pull origin <branch_name>`

### Merging

**Merging** is the process of taking the changes from one branch and integrating them into another. For example, when you finish a new feature on a `feature` branch, you will merge it back into the `main` branch.

-   **Fast-Forward Merge**: If the `main` branch has not had any new commits since you created your `feature` branch, Git will just move the `main` pointer forward to the latest commit of your `feature` branch.
-   **Three-Way Merge**: If both branches have had new commits, Git will create a new "merge commit" that combines the changes from both branches.

### Merge Conflicts

A **merge conflict** occurs when you try to merge two branches that have competing changes to the same line in the same file. Git doesn't know which change is correct, so it will stop the merge and ask you to resolve the conflict manually. You must edit the file to fix the conflicting section, save it, and then commit the resolved file.

---

## 4. Deliberate Practice

1.  **Initialize a Repository**: Create a new folder, and run `git init` to turn it into a Git repository.
2.  **Make Commits**: Create a file, add some text, and then use `git add` and `git commit` to make your first commit. Modify the file again and make a second commit. Use `git log` to see the history.
3.  **Branching Workflow**:
    -   Create a new branch called `my-new-feature` using `git checkout -b my-new-feature`.
    -   On this new branch, make some changes to a file and commit them.
    -   Switch back to the `main` branch using `git checkout main`. Notice that your changes are gone.
    -   Merge your new feature into the main branch using `git merge my-new-feature`. Notice that your changes reappear.
4.  **Simulate a Merge Conflict**:
    -   From `main`, create a new branch `branch-a`. Change the first line of a file and commit it.
    -   Switch back to `main`. Create another branch `branch-b`. Change the *same first line* of the *same file* to something different, and commit it.
    -   Try to merge `branch-a` into `main` (this will work).
    -   Now, try to merge `branch-b` into `main`. Git will report a merge conflict. Open the file, resolve the conflict, and complete the merge.

---

## 5. Active Recall Questions

-   What is a version control system used for?
-   What are the three "states" a file can be in according to Git?
-   What is a commit?
-   What is the purpose of creating a new branch?
-   What is a merge conflict?

---

## 6. Tools, Frameworks, and Platforms

-   **Git**: The command-line tool.
-   **GitHub / GitLab / Bitbucket**: Web-based platforms for hosting remote Git repositories. They provide a graphical interface and tools for collaboration (like pull requests, which are covered in the next module).
-   **GUI Clients**: Tools like Sourcetree, GitKraken, and the built-in Git support in VS Code provide a visual interface for working with Git, which can be very helpful for beginners.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain why version control is essential for team collaboration.
-   [ ] I can describe the `add -> commit -> push` workflow.
-   [ ] I can create a new branch to work on a feature.
-   [ ] I can switch between existing branches.
-   [ ] I can merge one branch into another.
-   [ ] I understand what a merge conflict is and the basic steps to resolve it.

---

## 13. Research and References

-   **Pro Git by Scott Chacon and Ben Straub**: The definitive book on Git, available for free online. [Link](https://git-scm.com/book/en/v2)
-   **GitHub Skills**: A set of interactive courses for learning Git and GitHub. [Link](https://skills.github.com/)
-   **Learn Git Branching**: An interactive, visual game that teaches you Git concepts. [Link](https://learngitbranching.js.org/)
-   **"Git for Professionals" Tutorial - FreeCodeCamp**: A comprehensive video tutorial.
