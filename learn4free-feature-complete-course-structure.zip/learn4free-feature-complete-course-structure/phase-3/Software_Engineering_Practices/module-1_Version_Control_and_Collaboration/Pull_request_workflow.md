# Pull Requests and Branching Strategies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a Pull Request (PR) and its purpose in a collaborative workflow.
-   **Describe** the standard Pull Request workflow (create branch, push, create PR, review, merge).
-   **Explain** the role of code reviews in maintaining code quality.
-   **Differentiate** between two common branching strategies: Git Flow and Trunk-Based Development.
-   **Choose** an appropriate branching strategy for a given project.
-   **Resolve** merge conflicts within a remote repository like GitHub.

---

## 2. Introduction to Collaborative Workflows

While Git provides the underlying tools for branching and merging, platforms like GitHub, GitLab, and Bitbucket provide the collaboration layer on top of them. The **Pull Request** (PR), also known as a Merge Request (MR), is the central feature of this collaboration. It's a formal way to propose changes to a codebase, allowing for discussion, automated checks, and code review before the changes are integrated into the main branch.

---

## 3. The Pull Request Workflow

This is the standard, modern workflow for contributing code to a shared project:

1.  **Fetch the Latest `main`**: Before starting any new work, make sure your local `main` branch is up-to-date with the remote repository.
    -   `git checkout main`
    -   `git pull origin main`
2.  **Create a Feature Branch**: Create a new, descriptively named branch for the feature or bugfix you are working on.
    -   `git checkout -b feature/add-user-login`
3.  **Commit Your Work**: Make your code changes and commit them to your feature branch. Make small, logical commits with clear messages.
4.  **Push Your Branch**: Push your new feature branch to the remote repository.
    -   `git push -u origin feature/add-user-login` (The `-u` sets the upstream for the first push).
5.  **Open a Pull Request**: Go to the GitHub/GitLab UI. You will see a prompt to open a new Pull Request from your recently pushed branch.
    -   Give your PR a clear title and a detailed description of the changes.
    -   Assign reviewers.
6.  **Code Review and Discussion**: Your teammates will now review your code.
    -   They can leave comments and suggest changes.
    -   You can push new commits to your branch to address their feedback. The PR will update automatically.
7.  **Automated Checks (CI)**: The repository is likely configured to run automated tests, linting, and other checks against your PR. All checks must pass.
8.  **Merge**: Once the PR is approved and all checks are green, it can be merged into the `main` branch. This is typically done via the web UI, often using a "Squash and Merge" strategy to combine all of your small commits into one clean commit on the `main` branch.
9.  **Clean Up**: After merging, you can delete your feature branch from the remote and local repositories.

---

## 4. Branching Strategies

A branching strategy is a set of rules and conventions that a team agrees to follow when using Git. It provides a consistent way to manage feature development, releases, and hotfixes.

### Git Flow

Git Flow is a very structured and well-defined branching model. It uses several long-lived branches:
-   **`master` / `main`**: This branch always reflects a production-ready state.
-   **`develop`**: This is the main development branch where all new features are integrated.
-   **Supporting Branches**:
    -   `feature/*`: Branched from `develop` for new feature work. Merged back into `develop`.
    -   `release/*`: Branched from `develop` to prepare for a new production release. Bugfixes only. Merged into `master` and `develop`.
    -   `hotfix/*`: Branched from `master` to fix an urgent production bug. Merged into `master` and `develop`.

-   **Best for**: Projects with a scheduled release cycle (e.g., desktop software, mobile apps) and a need to support multiple versions in production. It can be overly complex for many web applications.

### Trunk-Based Development (TBD)

Trunk-Based Development is a simpler model where all developers work on a **single main branch** (the "trunk," usually `main`).
-   **How it works**:
    1.  Developers create short-lived feature branches from `main`.
    2.  They commit their work to these branches and open a PR.
    3.  The work is reviewed and merged into `main` very quickly (ideally within a few hours or a day).
    4.  The `main` branch must *always* be in a releasable state. This is achieved through heavy reliance on automated testing and feature flags.
-   **Feature Flags**: A technique where a new feature is wrapped in a conditional (`if (featureIsEnabled) { ... }`) in the code. This allows you to merge incomplete features into `main` but keep them "turned off" in production.

-   **Best for**: Web applications and services that practice continuous integration and continuous deployment (CI/CD). It is the dominant model for modern DevOps environments.

---

## 5. Deliberate Practice

1.  **Go Through the PR Workflow**: Find a simple open-source project that is friendly to new contributors (or create your own). Go through the entire PR workflow: fork the repo, create a branch, make a small change (like fixing a typo in the README), push your branch, and open a PR.
2.  **Review a Pull Request**: Look at an open Pull Request on a project on GitHub. Read the code changes and the discussion.
3.  **Strategy Discussion**: For a project you are working on, discuss with a peer whether Git Flow or Trunk-Based Development would be a better fit and why.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define a Pull Request and explain its role in code review.
-   [ ] I can list the main steps of the PR workflow, from creating a branch to merging.
-   [ ] I understand that a PR is a place for discussion and automated checks before code is merged.
-   [ ] I can describe Git Flow and know it's good for projects with scheduled releases.
-   [ ] I can describe Trunk-Based Development and know it's good for projects with CI/CD.

---

## 13. Research and References

-   **GitHub Docs - About pull requests**: [Link](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests)
-   **"A successful Git branching model" by Vincent Driessen**: The original, classic blog post that defined Git Flow. [Link](https://nvie.com/posts/a-successful-git-branching-model/)
-   **Trunk Based Development**: The main website explaining the TBD branching model. [Link](https://trunkbaseddevelopment.com/)
-   **Atlassian - Gitflow vs. Trunk Based Development**: A good comparison of the two strategies.
