# Unit Testing: Testing Individual Functions/Methods

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** unit testing and explain its purpose in the testing pyramid.
- **Differentiate** between unit tests, integration tests, and end-to-end tests.
- **Write** a simple unit test for a pure function.
- **Understand** the "Arrange-Act-Assert" (AAA) pattern for structuring tests.
- **Describe** the characteristics of a good unit test (fast, isolated, repeatable).
- **Use** a testing framework (like Jest, JUnit, or pytest) to run tests and view results.

---

## 2. Introduction to Software Testing

Software testing is the process of evaluating and verifying that a software application does what it is supposed to do. The goal of testing is to find defects and ensure that the quality of the software meets the requirements. Testing is a critical part of the software development lifecycle.

### The Testing Pyramid

The testing pyramid is a model that helps to visualize a healthy and balanced testing strategy.
1.  **Unit Tests (Base)**: The largest number of tests. They are fast, cheap, and test small, isolated pieces of code.
2.  **Integration Tests (Middle)**: Fewer tests. They test how multiple components (units) work together.
3.  **End-to-End (E2E) Tests (Top)**: The smallest number of tests. They test the entire application workflow from the user's perspective. They are slow and expensive to write and maintain.

This module focuses on the foundation of the pyramid: **Unit Tests**.

---

## 3. Core Concepts of Unit Testing

A **unit test** is a piece of code written by a developer that exercises a very small, specific piece of the application's code (a "unit") in isolation. A "unit" is typically a single function or a method of a class.

The purpose of a unit test is to validate that the unit of code performs as designed, both for expected "happy path" inputs and for edge cases.

### Characteristics of a Good Unit Test

- **Fast**: Unit tests should run very quickly. You should be able to run hundreds of them in a few seconds.
- **Isolated**: A unit test should not depend on external factors like a database, a network connection, or other parts of the system. Its success or failure should depend only on the unit being tested.
- **Repeatable**: A unit test should produce the same result every time it is run.
- **Self-Checking**: The test should be able to automatically determine if it passed or failed without a human having to manually inspect the output.
- **Timely**: Unit tests should be written at the same time as the code they are testing.

### The "Arrange-Act-Assert" (AAA) Pattern

This is a common and highly recommended pattern for structuring your test cases.

1.  **Arrange**: Set up the test. This is where you initialize any variables, create objects, or prepare any inputs that your unit needs.
2.  **Act**: Execute the unit of code you are testing. Call the function or method with the prepared inputs.
3.  **Assert**: Verify the outcome. Check that the function's return value or the object's state is what you expected it to be. Every test must have at least one assertion. If the assertion is true, the test passes. If it's false, the test fails.

### Testing Frameworks

You don't write and run tests manually. You use a **testing framework** for your chosen language.

- **JavaScript**: Jest, Mocha, Vitest
- **Python**: pytest, unittest
- **Java**: JUnit, TestNG
- **C#**: NUnit, xUnit

These frameworks provide a "test runner" that discovers and runs your tests, and they provide the "assertion library" (e.g., `assertEquals`, `assertTrue`) that you use to make your checks.

---

## 4. Deliberate Practice

**Scenario**: You have a simple `Calculator` class with an `add(a, b)` method.

1.  **Write the Code**:
    ```javascript
    // calculator.js
    class Calculator {
      add(a, b) {
        return a + b;
      }
    }
    ```

2.  **Write the Test (using a Jest-like syntax)**:
    - **`describe`**: Groups related tests together.
    - **`it` or `test`**: Defines an individual test case.
    - **`expect` and `toBe`**: The assertion.
    ```javascript
    // calculator.test.js
    const Calculator = require('./calculator');

    describe('Calculator', () => {
      it('should correctly add two positive numbers', () => {
        // Arrange
        const calculator = new Calculator();

        // Act
        const result = calculator.add(2, 3);

        // Assert
        expect(result).toBe(5);
      });

      it('should correctly add a positive and a negative number', () => {
        // Arrange
        const calculator = new Calculator();
        // Act
        const result = calculator.add(5, -3);
        // Assert
        expect(result).toBe(2);
      });
    });
    ```
3.  **Run the Tests**: From your command line, you would run the test runner (e.g., `npm test`), which would discover and run your `calculator.test.js` file and report the results.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that a unit test checks a small, isolated piece of code (like a single function).
-   [ ] I can describe the "Arrange-Act-Assert" pattern for structuring a test.
-   [ ] I understand that a good unit test should be fast and isolated from external dependencies.
-   [ ] I know that an "assertion" is the part of the test that checks if the outcome is correct.
-   [ ] I have used a testing framework (even just in a tutorial) to run a simple test.

---

## 6. Research and References

-   **"Unit Testing Principles, Practices, and Patterns" by Vladimir Khorikov**: An excellent, modern book on unit testing.
-   **Martin Fowler - "Unit Test"**: A foundational article by a leading figure in software engineering. [Link](https://martinfowler.com/bliki/UnitTest.html)
-   **Jest Official Documentation**: [Link](https://jestjs.io/docs/getting-started)
-   **pytest Official Documentation**: [Link](https://docs.pytest.org/en/stable/)
-   **JUnit 5 User Guide**: [Link](https://junit.org/junit5/docs/current/user-guide/)
