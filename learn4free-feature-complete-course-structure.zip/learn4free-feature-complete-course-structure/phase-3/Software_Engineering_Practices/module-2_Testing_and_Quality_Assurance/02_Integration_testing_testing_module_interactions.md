# Integration Testing: Testing Module Interactions

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** integration testing and its place in the testing pyramid.
- **Differentiate** between unit testing and integration testing.
- **Explain** the purpose of integration testing: to verify interactions between components.
- **Describe** the concept of "test doubles" (mocks, stubs).
- **Identify** scenarios where an integration test is more appropriate than a unit test.
- **Write** a simple integration test for two or more interacting classes.

---

## 2. Introduction to Integration Testing

While unit tests are essential for verifying that individual components work correctly in isolation, they don't tell you if those components work correctly **together**. **Integration testing** is the phase in software testing in which individual software modules are combined and tested as a group.

The purpose of integration testing is to expose faults in the interaction between integrated units. For example, you might have a `UserService` that works perfectly on its own and a `UserRepository` that also works perfectly on its own. But if the `UserService` passes data in the wrong format to the `UserRepository`, your application will fail. Integration tests are designed to catch this kind of bug.

---

## 3. Core Concepts

### Scope of an Integration Test

- **Unit Test**: Tests a single class or function. All dependencies are typically replaced with "test doubles".
- **Integration Test**: Tests a small group of related classes or modules. Some external dependencies (like a database) might be real, while others (like an external payment API) might be faked.
- **End-to-End Test**: Tests the entire application stack, from the UI to the database, as a single unit.

### Test Doubles (Mocks and Stubs)

When you are testing the interaction between `Module A` and `Module B`, you are focused on the contract between them. Sometimes, you don't want to test their interaction with a third module, `Module C`. In this case, you can replace `Module C` with a **test double**.

- **Stub**: A simple fake object that provides canned responses to calls made during the test. For example, you could stub a `UserRepository` to always return a specific user when its `findById` method is called. This allows you to test the `UserService` without needing a real database.
- **Mock**: A more sophisticated fake object that is aware of the context of the test. You can set expectations on a mock, such as "I expect the `save` method to be called exactly once with this specific user object". If the expectation is not met, the test fails.

Mocks and stubs are essential for isolating the components you want to test and for avoiding slow, unreliable external dependencies (like a network connection to a third-party API).

---

## 4. An Example Integration Test

**Scenario**: You have a `NotificationService` that is responsible for sending a welcome email to a new user after they have been saved to the database by the `UserService`.

- **Units**: `UserService` and `NotificationService`.
- **Interaction**: The `UserService` calls the `NotificationService`.
- **External Dependency**: The actual email sending mechanism. We don't want to send a real email in our test.

**The Test**:
1.  **Arrange**:
    -   Create a real instance of the `UserService`.
    -   Create a **mock** of the `NotificationService`.
    -   Inject the mock `NotificationService` into the `UserService`.
    -   Set an expectation on the mock: "I expect the `sendWelcomeEmail` method to be called once with the email 'test@example.com'".
2.  **Act**:
    -   Call the `createUser` method on the `UserService` with the user data.
3.  **Assert**:
    -   The testing framework will automatically verify the mock's expectations. If the `sendWelcomeEmail` method was not called (or was called with the wrong email), the test will fail.

This test verifies that the `UserService` correctly calls the `NotificationService` when a new user is created, without relying on a real database or a real email server.

---

## 5. Deliberate Practice

1.  **Identify Integration Points**: Look at a project you've built. Identify two classes or modules that interact with each other. This point of interaction is a candidate for an integration test.
2.  **Write a Test**:
    -   Consider a `CartService` that uses a `ProductService` to get the price of an item before adding it to a cart.
    -   Write an integration test that verifies that the `CartService` correctly calls the `ProductService`'s `getPrice` method.
    -   You can use a real `ProductService` or you can stub it to return a known price for the test.
3.  **API Integration Test**:
    -   An integration test for a backend API often involves sending a real HTTP request to an endpoint and checking the response and the state of a test database.
    -   Write a test that makes a `POST` request to create a user and then makes a `GET` request to verify that the user was actually created in the test database.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that integration testing is about verifying the interactions between different parts of a system.
-   [ ] I know that integration tests are higher up the testing pyramid than unit tests (meaning there are fewer of them).
-   [ ] I can describe the purpose of a "test double" like a mock or a stub (to fake a dependency).
-   [ ] I can give an example of an interaction that would be a good candidate for an integration test (e.g., a service calling a repository).
-   [ ] I understand that an API test that involves a real HTTP request and a test database is a form of integration test.

---

## 7. Research and References

-   **"Unit Testing Principles, Practices, and Patterns" by Vladimir Khorikov**: This book has excellent, detailed chapters on the difference between unit and integration tests.
-   **Martin Fowler - "Test Double"**: The definitive article explaining the different types of test doubles. [Link](https://martinfowler.com/bliki/TestDouble.html)
-   **Google Testing Blog - "Just Say No to More End-to-End Tests"**: A famous article that argues for the importance of a balanced testing pyramid with a strong base of unit and integration tests.
-   **Mocking Libraries**:
    -   **Jest**: Has built-in mocking capabilities.
    -   **Mockito** (Java), **Moq** (C#), **unittest.mock** (Python) are popular mocking frameworks.
