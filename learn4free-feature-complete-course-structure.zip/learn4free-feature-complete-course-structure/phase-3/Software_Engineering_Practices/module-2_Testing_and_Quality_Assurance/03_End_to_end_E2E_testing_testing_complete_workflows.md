# End-to-End (E2E) Testing: Testing Complete Workflows

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** end-to-end (E2E) testing and its position at the top of the testing pyramid.
- **Explain** the purpose of E2E testing: to simulate real user scenarios from start to finish.
- **Differentiate** E2E testing from unit and integration testing.
- **Describe** the trade-offs of E2E tests (high confidence vs. slow, brittle, and expensive).
- **Identify** a critical user workflow that would be a good candidate for an E2E test.
- **Recognize** popular E2E testing frameworks like Cypress and Playwright.

---

## 2. Introduction to End-to-End Testing

**End-to-End (E2E) testing** is a technique used to test whether the flow of an application from start to finish is behaving as expected. The purpose of E2E testing is to simulate a real user's experience and validate that all the integrated components of the system work together correctly in a production-like environment.

E2E tests sit at the very top of the testing pyramid. They are the most expensive and slowest tests to run, so you should have a small number of them, focused only on the most critical user workflows.

### E2E vs. Unit vs. Integration

- **Unit Test**: Does my `add` function return the correct sum? (Tests one thing in isolation).
- **Integration Test**: Does my `UserService` correctly save a user to the database? (Tests a few things working together).
- **E2E Test**: Can a user sign up, log in, add an item to their cart, and check out? (Tests the entire system, from the UI to the database and back).

---

## 3. Core Concepts

### Simulating a Real User

E2E tests for a web application work by launching a real web browser and programmatically controlling it to perform the same actions a user would:
- Clicking on buttons.
- Typing in input fields.
- Navigating between pages.
- Asserting that a certain piece of text or an element is visible on the page.

### The Trade-offs of E2E Tests

- **Pros**:
  - **High Confidence**: A passing E2E test gives you a very high degree of confidence that your application is working correctly from the user's perspective. It's the ultimate smoke test.
- **Cons**:
  - **Slow**: They are very slow to run because they involve launching a browser, making real network requests, and waiting for pages to load. A single E2E test can take seconds or even minutes, whereas you can run thousands of unit tests in that time.
  - **Brittle (Flaky)**: E2E tests can fail for reasons that have nothing to do with a bug in your code. A slow network connection, a third-party API being down, or a slight change in the UI's CSS can all cause a test to fail. This makes them less reliable.
  - **Expensive**: They are time-consuming to write and require a complex setup to run, especially in an automated CI/CD pipeline.
  - **Poor Debugging**: When an E2E test fails, it can be very difficult to pinpoint the exact cause of the failure, as the problem could be in the frontend, the backend, the database, or the network.

### What to Test with E2E

Because of these trade-offs, you should only use E2E tests for your most critical, high-level user workflows. These are the "happy paths" that absolutely must work.

- **Examples**:
  - The user registration and login flow.
  - The "add to cart" and checkout process in an e-commerce app.
  - The "create a post" flow in a blog application.

Do **not** use E2E tests to check every possible edge case, validation error, or variation of a feature. Those should be covered by unit and integration tests.

### E2E Testing Frameworks

Modern E2E testing is done with powerful tools that make the process much easier.
- **Cypress**: A very popular, all-in-one testing framework that is known for its excellent developer experience, interactive test runner, and reliability.
- **Playwright**: A newer framework from Microsoft that is known for its speed and its ability to run tests across all major browsers (Chrome, Firefox, and Safari/WebKit).
- **Selenium**: The original browser automation tool. It is still widely used, but it is generally considered more difficult to work with than modern alternatives like Cypress or Playwright.

---

## 4. An Example E2E Test (in Cypress-like pseudocode)

```javascript
describe('User Login Flow', () => {
  it('should allow a user to log in and see the dashboard', () => {
    // 1. Visit the login page
    cy.visit('/login');

    // 2. Find the input fields and type into them
    cy.get('input[name="email"]').type('test@example.com');
    cy.get('input[name="password"]').type('password123');

    // 3. Find the submit button and click it
    cy.get('button[type="submit"]').click();

    // 4. Assert that the URL has changed to the dashboard
    cy.url().should('include', '/dashboard');

    // 5. Assert that the dashboard contains a welcome message
    cy.contains('h1', 'Welcome, test@example.com!');
  });
});
```

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that E2E tests simulate a real user's workflow from start to finish.
-   [ ] I know that E2E tests are at the top of the testing pyramid, meaning I should have only a few of them.
-   [ ] I can list the major trade-offs of E2E tests: high confidence, but slow and brittle.
-   [ ] I can identify a critical "happy path" workflow (like login) that is a good candidate for an E2E test.
-   [ ] I can name a modern E2E testing framework like Cypress or Playwright.

---

## 6. Research and References

-   **Cypress.io Official Documentation**: Excellent "getting started" guides and a great developer experience. [Link](https://docs.cypress.io/)
-   **Playwright Official Documentation**: [Link](https://playwright.dev/docs/intro)
-   **"The Practical Test Pyramid" by Ham Vocke**: A blog post that provides a modern and practical take on the testing pyramid.
-   **"Write tests. Not too many. Mostly integration."**: A well-known article by Kent C. Dodds that argues for the value of integration tests.
