# Test-Driven Development (TDD)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Test-Driven Development (TDD) as a software development process.
- **Describe** the three steps of the "Red-Green-Refactor" cycle.
- **Explain** the benefits of TDD, such as improved code quality and regression safety.
- **Differentiate** between TDD and traditional "write code, then write tests" workflows.
- **Write** a simple function by following the TDD process.

---

## 2. Introduction to TDD

**Test-Driven Development (TDD)** is a software development process where you write your tests *before* you write the code that is supposed to be tested. It is a "test-first" approach that turns the traditional development workflow on its head. Instead of writing tests as a way to validate code you've already written, you use the tests to drive the design and implementation of the code itself.

TDD is not primarily a testing technique; it is a **design and development technique**. The resulting comprehensive test suite is a useful byproduct, not the main goal.

---

## 3. The Red-Green-Refactor Cycle

TDD is built around a very short, repetitive cycle. Each cycle should take only a few minutes.

### Step 1: Red — Write a Failing Test

- Before you write any implementation code, you write a small, automated test case for a new piece of functionality.
- This test should describe *what* you want the code to do, not *how* it will do it.
- You then run your test suite, and the new test should fail (turn "red"). This is a critical step, as it proves that your test is actually capable of failing and that the functionality does not yet exist.

### Step 2: Green — Make the Test Pass

- Now, you write the **simplest, most minimal amount of code possible** to make the failing test pass (turn "green").
- The goal here is not to write beautiful or perfect code. The goal is just to pass the test. You can "fake it" or hardcode the result if you need to. The key is to get to a passing state quickly.

### Step 3: Refactor — Improve the Code

- Now that you have a passing test, your code is in a safe, working state. You can now **refactor** the implementation code you just wrote to improve its design, remove duplication, and enhance its readability, all while being confident that you haven't broken anything.
- You can re-run your test suite at any point during refactoring to ensure that everything still passes.
- After refactoring, you start the cycle all over again by writing another failing test for the next small piece of functionality.

This tight feedback loop encourages the development of simple, clean, and well-tested code.

---

## 4. An Example TDD Workflow

**Goal**: Write a function `isPalindrome(str)` that checks if a string is a palindrome.

1.  **Red**: Write the first test.
    ```javascript
    test('should return true for a simple palindrome', () => {
      expect(isPalindrome('racecar')).toBe(true);
    });
    ```
    Run the test. It fails because `isPalindrome` doesn't exist.

2.  **Green**: Write the simplest code to make it pass.
    ```javascript
    function isPalindrome(str) {
      return true; // Fake it!
    }
    ```
    Run the test. It passes.

3.  **Red**: Write a second test that will force a real implementation.
    ```javascript
    test('should return false for a non-palindrome', () => {
      expect(isPalindrome('hello')).toBe(false);
    });
    ```
    Run the tests. The first test passes, but the new one fails.

4.  **Green**: Write a real implementation.
    ```javascript
    function isPalindrome(str) {
      const reversed = str.split('').reverse().join('');
      return str === reversed;
    }
    ```
    Run the tests. Both now pass.

5.  **Refactor**: The code is simple and clean. No refactoring is needed at this point.

6.  **Red**: Add another test for an edge case.
    ```javascript
    test('should be case-insensitive', () => {
      expect(isPalindrome('Racecar')).toBe(true);
    });
    ```
    Run the tests. This new test fails.

7.  **Green**: Update the implementation to handle the new case.
    ```javascript
    function isPalindrome(str) {
      const lowercased = str.toLowerCase();
      const reversed = lowercased.split('').reverse().join('');
      return lowercased === reversed;
    }
    ```
    Run the tests. All tests pass.

...and the cycle continues.

---

## 5. Benefits of TDD

- **Improves Code Quality**: TDD forces you to think about the requirements of a function *before* you write it, leading to a better design.
- **Creates a Safety Net**: The comprehensive test suite acts as a "regression safety net". It allows you to refactor and add new features with confidence, knowing that if you break something, a test will fail immediately.
- **Leads to 100% Test Coverage**: By definition, every line of code you write is written in response to a failing test, which naturally leads to a very high level of test coverage.
- **Reduces Debugging Time**: When a test fails, you know that the bug was introduced in the very small amount of code you just wrote, which makes it much easier to find and fix.

---

## 6. Summary and Mastery Checklist

-   [ ] I can describe TDD as a "test-first" development process.
-   [ ] I can name and explain the three steps of the "Red-Green-Refactor" cycle.
-   [ ] I know that the first step is to write a test that fails.
-   [ ] I know that the "Green" step involves writing the simplest possible code to pass the test.
-   [ ] I understand that TDD is a design practice, not just a testing practice.
-   [ ] I can list at least one benefit of TDD (e.g., creating a regression safety net).

---

## 7. Research and References

-   **"Test Driven Development: By Example" by Kent Beck**: The original and definitive book on TDD, written by its creator.
-   **"The TDD Manifesto"**: A series of blog posts that lay out the philosophy of TDD.
-   **"TDD, Where Did It All Go Wrong" by Ian Cooper**: A popular talk that discusses common misunderstandings and misapplications of TDD.
-   **"Is TDD Dead?"**: A famous series of video debates between Kent Beck, Martin Fowler, and David Heinemeier Hansson that explores the pros and cons of TDD.
