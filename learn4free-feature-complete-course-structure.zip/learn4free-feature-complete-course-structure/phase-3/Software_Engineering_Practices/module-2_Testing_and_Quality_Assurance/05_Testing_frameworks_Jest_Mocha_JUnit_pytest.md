# Testing Frameworks (Jest, Mocha, JUnit, pytest)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a testing framework and explain its purpose.
- **Identify** the key components of a testing framework (test runner, assertion library).
- **Recognize** the names of popular testing frameworks for different languages.
- **Interpret** the output of a test runner to see which tests passed and which failed.
- **Understand** the purpose of common features like `describe` blocks, `it`/`test` blocks, and `beforeEach`/`afterEach` hooks.

---

## 2. Introduction to Testing Frameworks

A **testing framework** is a set of tools, conventions, and libraries that provides a standard way to write, structure, and run automated tests. You could, in theory, write a test by creating a separate file, running a function, and using an `if` statement to check the result, but this would be incredibly inefficient.

A testing framework automates this process and provides a rich set of features to make testing easier, more organized, and more powerful.

---

## 3. Core Components of a Testing Framework

### 1. Test Runner

- The **test runner** is the engine of the framework. It is a command-line tool that is responsible for:
  - **Test Discovery**: Automatically finding all the test files in your project (based on a naming convention, like `*.test.js`).
  - **Test Execution**: Running the tests.
  - **Reporting**: Displaying the results of the tests in a clear and readable format in the console.
  - **Watch Mode**: Many modern test runners have a "watch mode" that automatically re-runs the tests whenever you save a file, providing a very fast feedback loop.

### 2. Assertion Library

- An **assertion library** provides the functions that you use to verify the outcome of your code. An assertion is a statement that a certain condition must be true. If it is, the test passes. If it's not, the test fails, and the assertion library throws an error with a descriptive message.
- Assertions make your tests much more readable than using `if/else` statements.
- **Example Assertions (using a Jest-like `expect` syntax)**:
  - `expect(result).toBe(5);` (strict equality)
  - `expect(user.name).toEqual('Alice');` (deep object equality)
  - `expect(myArray).toContain('apple');`
  - `expect(myFunction).toThrow(Error);`

### 3. Test Structure

Testing frameworks provide functions to give your tests a clear and readable structure.

- **`describe(name, callback)`**: Creates a block that groups together several related tests. You can nest `describe` blocks.
- **`it(name, callback)`** or **`test(name, callback)`**: Defines an individual test case. The `name` should be a descriptive sentence in plain English that explains what the test is checking.
- **Setup and Teardown Hooks**: These are functions that run before or after your tests.
  - **`beforeEach(callback)`**: Runs before *every single* `it`/`test` block in a `describe` block. Useful for resetting state or creating a new object for each test.
  - **`afterEach(callback)`**: Runs after every test. Useful for cleanup.
  - **`beforeAll(callback)`** and **`afterAll(callback)`**: Run once, before all the tests in a `describe` block have started, and once after they have all finished.

---

## 4. Popular Testing Frameworks by Language

### JavaScript

- **Jest**: The most popular framework. It's an "all-in-one" solution that includes a test runner, an assertion library (`expect`), and built-in support for mocking and code coverage. Created by Facebook.
- **Mocha**: A mature and highly flexible test runner. It is *not* all-in-one; you have to choose your own assertion library (like **Chai**) and mocking library.
- **Vitest**: A newer framework that is designed to be a fast and modern replacement for Jest, especially for projects that use the Vite build tool.

### Python

- **pytest**: The de facto standard for testing in Python. It's known for its simple syntax (you can use the standard `assert` keyword) and its powerful features like "fixtures" for setup and teardown.
- **unittest**: Part of the Python standard library. It's more verbose and class-based, modeled after JUnit.

### Java

- **JUnit**: The standard testing framework for Java. JUnit 5 is the latest, modern version.
- **TestNG**: Another popular framework, often used for more complex, enterprise-level testing scenarios.

### C#

- **NUnit**: The most well-known testing framework for the .NET ecosystem.
- **xUnit.net**: A newer, popular framework that takes a more modern approach to testing.
- **MSTest**: Microsoft's built-in testing framework.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that a testing framework is a tool for writing and running automated tests.
-   [ ] I can name the two main components: a test runner and an assertion library.
-   [ ] I know that `describe` is for grouping tests and `it`/`test` is for a single test case.
-   [ ] I can name a popular testing framework for my language of choice (e.g., Jest for JS, pytest for Python, JUnit for Java).
-   [ ] I can look at the console output from a test runner and see how many tests passed and how many failed.
-   [ ] I understand that an assertion is a check that a certain condition is true.

---

## 6. Research and References

-   **Jest Official Docs**: [Link](https://jestjs.io/docs/getting-started)
-   **pytest Official Docs**: [Link](https://docs.pytest.org/en/stable/)
-   **JUnit 5 User Guide**: [Link](https://junit.org/junit5/docs/current/user-guide/)
-   **Mocha Official Docs**: [Link](https://mochajs.org/)
-   **Chai Assertion Library Docs**: [Link](https://www.chaijs.com/)
-   **"Modern Software Testing" by Alan Page**: A book that covers the broad landscape of modern testing practices and tools.
