# Code Coverage and Continuous Testing

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** code coverage as a metric.
- **Explain** what a 100% code coverage score means and, more importantly, what it *doesn't* mean.
- **Generate** a code coverage report using a testing framework.
- **Interpret** a code coverage report to identify untested parts of your codebase.
- **Define** continuous testing and its role in a CI/CD pipeline.
- **Understand** how "watch mode" in a test runner facilitates continuous testing during local development.

---

## 2. Introduction to Code Coverage

**Code coverage** is a metric that measures the percentage of your application's source code that is executed by your automated test suite. It is a quantitative measure of how much of your code is being tested.

When you run your tests with coverage enabled, the testing tool will:
1.  **Instrument** your code, adding tracking statements to each line, function, and branch.
2.  Run your tests.
3.  Keep track of which lines of code were executed during the tests.
4.  Generate a report that shows the percentage of executed lines, branches, functions, and statements.

---

## 3. Core Concepts

### Interpreting a Coverage Report

A typical coverage report will give you a breakdown per file and an overall total, with percentages for:
- **Lines**: What percentage of the executable lines of code were run?
- **Statements**: Similar to lines, but a single line can have multiple statements.
- **Functions**: What percentage of the functions you've defined were called?
- **Branches**: This is a very important metric. It checks if your tests have covered all the branches of your conditional logic (e.g., both the `if` and the `else` parts of a statement).

### The Goal of Code Coverage

- **Primary Goal**: To **identify untested code**. A coverage report is an excellent tool for finding parts of your application that have no test coverage at all.
- **Secondary Goal**: To set a minimum quality bar. Many teams set a rule in their CI/CD pipeline that a pull request cannot be merged if it causes the overall code coverage to drop below a certain threshold (e.g., 80%).

### What Code Coverage is NOT

**A high code coverage percentage does not mean your code is well-tested.** This is a critical point. Code coverage only tells you that a line of code was *executed*; it tells you nothing about the quality of your assertions.

You could have 100% line coverage and still have very poor tests.
**Example**:
```javascript
test('add function should run', () => {
  // This test executes the add function, so it counts for coverage.
  // But it has no assertion, so it doesn't actually test for correctness.
  add(2, 3);
});
```
**Conclusion**: Aiming for a reasonable coverage target (e.g., 80-90%) is a good practice, but it's just a starting point. The primary focus should always be on the quality and thoughtfulness of your tests, not just the percentage. Chasing 100% is often a waste of time.

---

## 4. Continuous Testing

**Continuous testing** is the practice of running your automated tests as frequently as possible as part of the software delivery pipeline. The goal is to get feedback on the quality of your code as early and as often as possible.

### Continuous Testing in Local Development

- **"Watch Mode"**: Most modern test runners (like Jest and Vitest) have a "watch mode".
- **How it works**: You start the test runner in watch mode. It runs all the tests once. Then, it "watches" your files for any changes. As soon as you save a file, it instantly re-runs only the tests that are relevant to the file you changed.
- **Benefit**: This provides an incredibly tight feedback loop. You know within a second of saving a file whether you have broken something. This is a core practice for developers who use TDD.

### Continuous Testing in the CI/CD Pipeline

- **On Every Commit/Pull Request**: Continuous Integration (CI) is the practice of automatically building and testing your code every time a change is pushed to the repository.
- **How it works**:
  1.  A developer pushes a commit or opens a pull request.
  2.  The CI server (e.g., GitHub Actions, Jenkins) automatically checks out the code.
  3.  It installs the dependencies.
  4.  It runs all the automated tests (unit tests, integration tests).
  5.  If the tests pass, the code is considered "good". If they fail, the build is marked as "broken," and the developer is notified.
- **Benefit**: This ensures that no code with failing tests ever gets merged into the main branch, maintaining the health and stability of the codebase. It's a critical safety net for team collaboration.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define code coverage as a measure of how much of my code is executed by my tests.
-   [ ] I can explain that the main benefit of a coverage report is to find untested code.
-   [ ] I understand that 100% coverage does not guarantee that my code is bug-free or well-tested.
-   [ ] I can describe "watch mode" as a tool for getting instant feedback during local development.
-   [ ] I can explain that continuous testing in a CI/CD pipeline means running all tests automatically on every pull request.

---

## 6. Research and References

-   **Martin Fowler - "Code Coverage"**: [Link](https://martinfowler.com/bliki/CodeCoverage.html)
-   **"The quest for 100% code coverage (and why it’s a stupid goal)"**: A common topic for blog posts with valuable insights.
-   **Jest Docs - Watch Mode**: [Link](https://jestjs.io/docs/cli#--watch)
-   **GitHub Actions Documentation**: To see how continuous testing is implemented in a real CI/CD system. [Link](https://docs.github.com/en/actions)
-   **Istanbul.js**: The code coverage tool that is used under the hood by many JavaScript testing frameworks.
