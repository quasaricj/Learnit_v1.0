# Code Coverage and Continuous Testing

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** code coverage as a measurement.
-   **Explain** what a 100% code coverage score means and, more importantly, what it *doesn't* mean.
-   **Generate** a code coverage report for your project using a testing framework.
-   **Analyze** a coverage report to identify untested parts of your codebase.
-   **Define** continuous testing and its role in a CI/CD pipeline.
-   **Understand** the value of running tests automatically on every commit.

---

## 2. Introduction to Code Quality Metrics

How do you know if your tests are good? How can you be sure you've tested enough? While there is no perfect answer, **code coverage** is a metric that can help. It measures the percentage of your production code that is executed by your automated tests.

**Continuous testing** is the practice of running these tests automatically as part of your development workflow, providing rapid feedback on whether a change has introduced a bug.

---

## 3. Core Concepts

### Code Coverage

Code coverage tools work by instrumenting your code. As your tests run, the tool keeps track of which lines, branches, and functions of your production code were executed.

-   **The Metric**: The result is a percentage. "This project has 85% code coverage" means that 85% of the code statements were executed by the test suite.
-   **Generating a Report**: Most testing frameworks have a built-in option to generate a coverage report. For example, in Jest, you would run `jest --coverage`. This produces a detailed HTML report that you can open in a browser, showing you line-by-line which parts of your code are not tested.

### What Coverage Tells You (and What It Doesn't)

-   **What it IS**: A useful tool for finding **untested code**. If a line of code has 0% coverage, you know for a fact that you have no tests for that logic. This is a great way to find gaps in your test suite.
-   **What it is NOT**: A measurement of test **quality**. 100% code coverage does *not* mean your code is bug-free. It's possible to execute every line of code without actually making any meaningful assertions about its behavior.

**Example**:
```javascript
function isAdult(age) {
  return age >= 18;
}

// Test
test('isAdult runs', () => {
  isAdult(20); // This test "covers" the code
  // But it doesn't actually CHECK if the output is correct!
  // An assertion is needed: expect(isAdult(20)).toBe(true);
});
```
This test would give you 100% coverage on the `isAdult` function, but it's a useless test because it doesn't verify the correctness of the result.

**The Goal**: Do not chase 100% coverage as a goal in itself. Use the coverage report as a **guide** to identify areas you've neglected to test. A healthy, well-tested project typically has a coverage level of 70-90%.

### Continuous Testing

Continuous testing is the process of integrating automated test execution into your development pipeline.

-   **How it works**:
    1.  A developer commits and pushes a change to a branch.
    2.  This automatically triggers a build on a **Continuous Integration (CI)** server.
    3.  The CI server runs all of the project's automated tests (unit, integration, etc.).
    4.  If the tests pass, the change is considered safe to merge. If they fail, the build is marked as "broken," and the developer is notified immediately.
-   **The Benefit**: **Rapid feedback**. Developers find out about regressions (bugs introduced in existing code) within minutes of pushing a change, not hours or days later. This makes bugs much easier and cheaper to fix. This is a core practice of modern DevOps.

---

## 4. Deliberate Practice

1.  **Generate a Coverage Report**:
    -   In the project where you wrote a unit test in the previous module, run your test command with the `--coverage` flag (or the equivalent for your test runner).
    -   Open the HTML report that is generated.
    -   Add a new, untested function to your code and re-run the report. See how the coverage percentage drops and the new function is highlighted in red.
2.  **Improve Coverage**: Write a test for the new function you just added and see the coverage percentage go back up.
3.  **Explore a CI Pipeline**: Look at an open-source project on GitHub. Go to the "Actions" tab. This shows the history of their Continuous Integration builds. Find a Pull Request and look at the "Checks" section. You can see the output of the automated tests that were run against that PR.

---

## 5. Active Recall Questions

-   What does code coverage measure?
-   What does 100% code coverage *not* guarantee?
-   What is the primary benefit of a code coverage report?
-   What is continuous testing?
-   What is the main benefit of running tests automatically on every commit?

---

## 12. Summary and Mastery Checklist

-   [ ] I can define code coverage as the percentage of code executed by tests.
-   [ ] I understand that high code coverage does not equal high-quality tests.
-   [ ] I know how to use a coverage report to find untested code.
-   [ ] I can define continuous testing as the practice of running tests automatically in a CI pipeline.
-   [ ] I can explain that the main benefit of continuous testing is rapid feedback to developers.

---

## 13. Research and References

-   **Martin Fowler - "Code Coverage"**: An article from a leading software design expert on the uses and misuses of coverage. [Link](https://martinfowler.com/bliki/CodeCoverage.html)
-   **"Continuous Testing" by Atlassian**: A good overview of the concept and its place in the development lifecycle.
-   **Coveralls / Codecov**: Popular online services that integrate with GitHub to track code coverage over time and display it in Pull Requests.
