# Test-Driven Development (TDD)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Test-Driven Development (TDD) and its purpose.
-   **Describe** the three phases of the "Red-Green-Refactor" cycle.
-   **Explain** the benefits of TDD (e.g., improved code quality, emergent design, regression safety net).
-   **Write** a failing test *before* writing the implementation code.
-   **Follow** the TDD workflow to implement a simple function.
-   **Differentiate** TDD from traditional "test-after" development.

---

## 2. Introduction to TDD

**Test-Driven Development (TDD)** is a software development process that inverts the traditional "write code, then test it" model. In TDD, you write an automated test case *before* you write the actual production code that the test is for. This may sound counter-intuitive, but it is a powerful discipline that can lead to higher-quality code and a more robust design.

TDD is not primarily a testing methodology; it is a **design methodology**. The goal is not just to produce tests, but to use the process of writing tests to help you design better, more focused, and more decoupled code.

---

## 3. The Red-Green-Refactor Cycle

TDD is a cyclical process that follows three simple steps:

### 1. RED

-   **Goal**: Write a failing test.
-   **Action**: Write a small, automated test for a single piece of functionality that you want to add. Since you haven't written the implementation code yet, this test **must fail**. If it passes, your test is wrong. This step is crucial because it forces you to clearly define the requirements for the new feature before you start implementing it.

### 2. GREEN

-   **Goal**: Make the test pass.
-   **Action**: Write the **absolute minimum amount of code** necessary to make the failing test pass. Do not write any more code than is needed. The goal here is not to write beautiful or perfect code; it is simply to get to a green, passing state as quickly as possible.

### 3. REFACTOR

-   **Goal**: Improve the code's design.
-   **Action**: Now that you have a passing test (a safety net), you can clean up the code you just wrote. This is where you focus on improving readability, removing duplication, and enhancing the design. Because you have a test that proves the functionality works, you can refactor with confidence, knowing that if you break something, the test will fail.

After refactoring, you start the cycle all over again for the next piece of functionality.

---

## 4. TDD vs. Traditional Testing

| Traditional ("Test-After")                                  | TDD ("Test-First")                                               |
| ----------------------------------------------------------- | ---------------------------------------------------------------- |
| 1. Write production code.                                   | 1. **Write a failing test.**                                     |
| 2. Write tests for the code.                                | 2. Write production code (just enough to make the test pass).    |
| 3. Run the tests and refactor if needed.                    | 3. **Refactor the code.**                                        |
| **Result**: Code is written to solve the problem. Tests are written to validate the code. | **Result**: Tests are written to define the problem. Code is written to satisfy the tests. |
| Often leads to code that is hard to test.                  | Naturally leads to code that is testable (decoupled, single-responsibility). |

---

## 5. Deliberate Practice

**Let's implement a `FizzBuzz` function using TDD.**

1.  **Cycle 1 (Input: 3)**
    -   **RED**: Write a test `test_fizzbuzz_returns_fizz_for_multiples_of_3()`. Assert that `fizzbuzz(3)` returns `"Fizz"`. Run the test; it will fail because the function doesn't exist.
    -   **GREEN**: Create the `fizzbuzz` function. Write the simplest possible code to make the test pass: `def fizzbuzz(n): return "Fizz"`. Run the test; it passes.
    -   **REFACTOR**: The code is simple enough. No refactoring needed.

2.  **Cycle 2 (Input: 5)**
    -   **RED**: Write a new test `test_fizzbuzz_returns_buzz_for_multiples_of_5()`. Assert that `fizzbuzz(5)` returns `"Buzz"`. Run the tests; this new test will fail.
    -   **GREEN**: Modify the code to make the new test pass without breaking the old one:
        ```python
        def fizzbuzz(n):
            if n == 5: return "Buzz"
            return "Fizz"
        ```
        This is not the final logic, but it makes the current tests pass.
    -   **REFACTOR**: The code now looks a bit strange. Let's refactor to the actual logic.
        ```python
        def fizzbuzz(n):
            if n % 5 == 0: return "Buzz"
            if n % 3 == 0: return "Fizz"
        ```
        Run the tests again to ensure your refactoring didn't break anything.

3.  **Cycle 3 (Input: 15)**
    -   **RED**: Write a test `test_fizzbuzz_returns_fizzbuzz_for_multiples_of_15()`. Assert that `fizzbuzz(15)` returns `"FizzBuzz"`. It fails.
    -   **GREEN / REFACTOR**: Add the final piece of logic. The `n % 15` case must come first.
        ```python
        def fizzbuzz(n):
            if n % 15 == 0: return "FizzBuzz"
            if n % 5 == 0: return "Buzz"
            if n % 3 == 0: return "Fizz"
        ```

4.  **Cycle 4 (Input: 1)**
    -   **RED**: Write a test for a non-multiple, e.g., `fizzbuzz(1)` should return `1`. It fails.
    -   **GREEN / REFACTOR**: Add the final `else` case to return the number itself.

Through this process, the tests *drive* the development of the final, correct implementation.

---

## 12. Summary and Mastery Checklist

-   [ ] I can describe TDD as the process of writing a failing test *before* the production code.
-   [ ] I can name and explain the three steps of the "Red-Green-Refactor" cycle.
-   [ ] I understand that the "Red" step is about defining the requirement.
-   [ ] I understand that the "Green" step is about making the test pass as simply as possible.
-   [ ] I understand that the "Refactor" step is about cleaning up the code while the tests provide a safety net.
-   [ ] I can see how TDD can lead to better-designed, more testable code.

---

## 13. Research and References

-   **"Test-Driven Development: By Example" by Kent Beck**: The original and definitive book on the subject.
-   **"The TDD Manifesto"**: A series of articles by Robert C. Martin.
-   **Fun Fun Function - "Test Driven Development"**: A great video series that walks through the TDD process.
-   **FreeCodeCamp - "What is TDD?"**: A good introductory article.
