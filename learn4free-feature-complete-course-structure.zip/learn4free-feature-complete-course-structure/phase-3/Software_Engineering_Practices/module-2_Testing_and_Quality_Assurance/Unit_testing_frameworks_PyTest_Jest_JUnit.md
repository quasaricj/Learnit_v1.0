# The Testing Pyramid: Unit, Integration, and E2E Tests

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** software testing and its importance for code quality.
-   **Describe** the Testing Pyramid and its three main layers.
-   **Differentiate** between Unit, Integration, and End-to-End (E2E) tests.
-   **Write** a simple unit test for a function.
-   **Explain** the purpose of a testing framework.
-   **Identify** popular testing frameworks for your chosen language (e.g., Jest for JavaScript, PyTest for Python, JUnit for Java).
-   **Understand** concepts like assertions and test runners.

---

## 2. Introduction to Software Testing

Software testing is the process of evaluating a software application to find bugs and ensure that it meets its requirements. Writing code without tests is like building a bridge without checking if it can support any weight. A comprehensive testing strategy is not an optional extra; it is a fundamental part of professional software engineering that leads to more robust, reliable, and maintainable code.

---

## 3. The Testing Pyramid

The Testing Pyramid is a model that helps to visualize a healthy testing strategy. It suggests grouping tests into different layers and writing more tests for the lower, faster, and cheaper layers.

-   **(Base) Unit Tests**: The largest part of the pyramid.
-   **(Middle) Integration Tests**: A smaller, more focused group.
-   **(Top) End-to-End (E2E) Tests**: The smallest and most selective group.

### 1. Unit Tests

-   **Scope**: Tests the smallest possible piece of testable code—a single function or method—in **complete isolation**.
-   **How**: Dependencies (like database connections or other classes) are "mocked" or "stubbed out". This means you replace the real dependency with a fake version that returns a predictable value.
-   **Goal**: To verify that the logic of a single unit of code works correctly.
-   **Speed**: Extremely fast (milliseconds).
-   **Example**: Given a function `add(a, b)`, a unit test would assert that `add(2, 3)` returns `5`.

### 2. Integration Tests

-   **Scope**: Tests how multiple units or modules work **together**.
-   **How**: Involves testing the interaction between several parts of your application, but still in a controlled environment. This might involve a real database connection to a test database, or checking that two of your classes interact correctly.
-   **Goal**: To find bugs in the "glue" that holds the different parts of your application together.
-   **Speed**: Slower than unit tests, as they involve more components.
-   **Example**: Testing that when you call your `UserService`'s `createUser` method, a corresponding record is actually created in the test database.

### 3. End-to-End (E2E) Tests

-   **Scope**: Tests the **entire application** from start to finish, simulating a real user's workflow.
-   **How**: Uses an automated tool (like Cypress or Selenium) to launch a browser, navigate to your application, click buttons, fill out forms, and assert that the UI behaves as expected.
-   **Goal**: To verify that the entire system works as a whole, from the frontend to the backend and the database.
-   **Speed**: Very slow (can take many seconds or even minutes per test).
-   **Example**: An E2E test for a login flow would automate the browser to: load the login page, type a username and password into the inputs, click the "Login" button, and then assert that the user is redirected to the dashboard page.

---

## 4. Testing Frameworks

You don't write tests from scratch. You use a testing framework that provides the necessary tools.

-   **Test Runner**: A program that discovers and runs your tests.
-   **Assertion Library**: A set of functions (`assert`, `expect`, `should`) that let you declare what the expected outcome of a test is. If an assertion fails, the test fails.
-   **Mocking/Spying Tools**: Utilities for creating fake versions of dependencies for your unit tests.

### Popular Frameworks

-   **JavaScript**: **Jest** is the most popular, "all-in-one" testing framework. It includes a test runner, assertion library, and mocking capabilities out of the box.
-   **Python**: **PyTest** is a powerful and flexible framework known for its simple syntax and rich plugin ecosystem. It is often used with the built-in `unittest.mock` library.
-   **Java**: **JUnit** is the standard testing framework for Java. It is often paired with a library like Mockito for mocking.

---

## 5. Deliberate Practice

1.  **Write a Unit Test**:
    -   Create a simple function, `isPasswordValid(password)`, that returns `true` if a password string is 8 characters or longer.
    -   Set up a testing framework in your project (e.g., `npm install --save-dev jest`).
    -   Write a test file for your function.
    -   Write test cases that assert that `isPasswordValid('12345678')` is `true` and `isPasswordValid('123')` is `false`.
    -   Run the tests using the test runner.
2.  **Explore Test Files**: Look at the source code of an open-source project and find its `tests` or `spec` directory. Read through the unit tests to see how they are structured.
3.  **Think about Integration**: For the blog platform project from Phase 2, what would be an example of an integration test? (e.g., testing that the `POST /api/posts` endpoint actually creates a row in the `posts` table).

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the purpose of the Testing Pyramid.
-   [ ] I can define a **unit test** as testing a single function in isolation.
-   [ ] I can define an **integration test** as testing how multiple modules work together.
-   [ ] I can define an **E2E test** as testing a full user workflow through the UI.
-   [ ] I know that unit tests should be fast and numerous, while E2E tests should be slow and few.
-   [ ] I can write a basic assertion to check if a function's output matches the expected value.

---

## 13. Research and References

-   **"The Practical Test Pyramid" by Martin Fowler**: The definitive article on the topic. [Link](https://martinfowler.com/articles/practical-test-pyramid.html)
-   **Jest Docs - Getting Started**: [Link](https://jestjs.io/docs/getting-started)
-   **PyTest Docs - Get Started**: [Link](https://docs.pytest.org/en/6.2.x/getting-started.html)
-   **"Test-Driven Development: By Example" by Kent Beck**: The classic book that introduced TDD.
