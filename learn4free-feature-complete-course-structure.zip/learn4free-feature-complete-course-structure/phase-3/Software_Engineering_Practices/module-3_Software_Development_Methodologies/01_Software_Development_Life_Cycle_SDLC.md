# Software Development Life Cycle (SDLC)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the Software Development Life Cycle (SDLC) and its purpose.
- **List** the key phases of a typical SDLC.
- **Describe** the goal of each phase (planning, analysis, design, implementation, testing, deployment, maintenance).
- **Understand** that the SDLC is a general process, not a specific, rigid methodology.
- **Differentiate** between an SDLC model and a software development methodology (like Agile or Waterfall).

---

## 2. Introduction to the SDLC

The **Software Development Life Cycle (SDLC)** is a conceptual framework that defines the process of creating and maintaining a software system. It provides a structured sequence of stages that a project goes through, from its initial conception to its final deployment and ongoing maintenance.

The purpose of the SDLC is to provide a systematic and disciplined approach to software development, helping to ensure that the final product is high-quality, meets the customer's requirements, and is completed within budget and on schedule.

---

## 3. The Seven Key Phases of the SDLC

While different models might name or group these phases slightly differently, they almost always include the following activities:

### 1. Planning and Requirement Analysis

- **Goal**: To understand the "why" and "what" of the project.
- **Activities**:
  - Gathering requirements from stakeholders (customers, users, business leaders).
  - Defining the project goals and scope.
  - Conducting a feasibility study (technical, economic).
  - Creating a high-level project plan.
- **Output**: A Software Requirement Specification (SRS) document.

### 2. Design

- **Goal**: To determine *how* the system will be built.
- **Activities**:
  - **High-Level Design**: Defining the overall system architecture, technology stack, and how different components will interact.
  - **Low-Level Design**: Designing the individual components, classes, and database schemas.
- **Output**: A Design Specification document, architecture diagrams, and database schemas.

### 3. Implementation (or Coding)

- **Goal**: To write the actual code.
- **Activities**:
  - Developers write code based on the design specifications.
  - The work is typically broken down into smaller modules or units.
- **Output**: The source code of the software.

### 4. Testing

- **Goal**: To verify that the software works as expected and is free of defects.
- **Activities**:
  - All levels of testing are performed: unit tests, integration tests, and end-to-end tests.
  - Quality Assurance (QA) engineers test the system to find bugs and ensure it meets the requirements.
- **Output**: A tested and verified software system, along with test reports and a list of bugs.

### 5. Deployment

- **Goal**: To release the software to users.
- **Activities**:
  - The software is packaged and deployed to a production environment (the live servers).
  - This can be a manual or an automated process.
- **Output**: The software is available for use by end-users.

### 6. Maintenance

- **Goal**: To support the software after it has been released.
- **Activities**:
  - **Corrective Maintenance**: Fixing bugs that are discovered in production.
  - **Adaptive Maintenance**: Updating the software to work in new environments (e.g., a new operating system).
  - **Perfective Maintenance**: Adding new features or improving the performance of the software based on user feedback.
- **Output**: New versions and updates of the software.

### 7. Disposal

- **Goal**: To end the life of the system. This phase may include system archiving, data migration to a new system, or a complete shutdown.

---

## 4. SDLC Models

The SDLC provides the "what" (the phases), while an **SDLC Model** provides the "how" (the specific order and way the phases are executed). The next module will cover these models in detail.

- **Waterfall Model**: A linear, sequential model where you complete one entire phase before moving to the next.
- **Agile Models (e.g., Scrum)**: An iterative and incremental model where you go through all the phases in small, repeated cycles.

The SDLC framework is flexible and can be adapted to fit the needs of any project. The choice of model depends on the project's complexity, the stability of its requirements, and the desired speed of delivery.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define the SDLC as a framework for the process of building software.
-   [ ] I can list the main phases of the SDLC in a logical order.
-   [ ] I can describe the main goal of the Requirement Analysis phase (what to build).
-   [ ] I can describe the main goal of the Design phase (how to build it).
-   [ ] I can describe the main goal of the Testing phase (verify it works).
-   [ ] I understand that methodologies like Waterfall and Agile are different ways of implementing the SDLC framework.

---

## 6. Research and References

-   **"Software Engineering: A Practitioner's Approach" by Roger S. Pressman**: A classic and comprehensive textbook on software engineering that covers the SDLC in depth.
-   **Wikipedia - Software development process**: [Link](https://en.wikipedia.org/wiki/Software_development_process)
-   **Guru99 - Software Development Life Cycle (SDLC)**: [Link](https://www.guru99.com/software-development-life-cycle-tutorial.html)
