# Waterfall vs. Agile Methodologies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Describe** the Waterfall model as a linear-sequential SDLC model.
- **Describe** Agile as an iterative and incremental approach.
- **Explain** the core values and principles of the Agile Manifesto.
- **Compare and contrast** the key differences between Waterfall and Agile in terms of process, flexibility, and customer involvement.
- **Identify** the types of projects where Waterfall might be suitable.
- **Identify** the types of projects where Agile is generally preferred.

---

## 2. The Waterfall Model

The Waterfall model is the oldest and most traditional SDLC model. It is a **linear-sequential** approach where each phase of the SDLC must be fully completed before the next phase can begin. The process flows steadily downwards (like a waterfall) through the phases of conception, initiation, analysis, design, construction, testing, deployment, and maintenance.

### The Waterfall Process

`Requirements -> Design -> Implementation -> Testing -> Deployment -> Maintenance`

- **Characteristics**:
  - Very rigid and structured.
  - All requirements are gathered and "frozen" at the beginning of the project.
  - There is a heavy emphasis on comprehensive documentation.
  - The customer is involved at the beginning (requirements) and the end (delivery), but not much in between.

- **Pros**:
  - Simple and easy to understand.
  - Disciplined and well-documented.
  - Good for projects where the requirements are very well understood, fixed, and stable (e.g., building a bridge, or a software project with unchanging legal requirements).

- **Cons**:
  - **Inflexible**: It is extremely difficult and expensive to make a change to the requirements once the project is underway.
  - **Slow Delivery**: The customer does not get to see a working version of the software until the very end of the project, which could be months or years.
  - **High Risk**: There is a high risk of the final product not meeting the customer's actual needs, as there is no feedback loop during the development process.

---

## 3. The Agile Methodology

**Agile** is not a single, specific methodology, but a **mindset** and a set of principles for developing software. Agile methodologies are **iterative and incremental**.

- **Iterative**: The project is broken down into small, repeated cycles (called "iterations" or "sprints").
- **Incremental**: A small piece of working software is delivered at the end of each cycle. The product is built up incrementally over time.

### The Agile Manifesto

The Agile mindset is best summarized by the four core values of the Agile Manifesto (2001):

1.  **Individuals and interactions** over processes and tools.
2.  **Working software** over comprehensive documentation.
3.  **Customer collaboration** over contract negotiation.
4.  **Responding to change** over following a plan.

This means that while there is value in the items on the right, Agile values the items on the left more.

### The Agile Process

- **Characteristics**:
  - The project is broken down into short iterations (typically 1-4 weeks).
  - A small, cross-functional, self-organizing team works on the project.
  - The customer is heavily involved throughout the entire process, providing constant feedback.
  - Requirements are expected to evolve and change. Change is welcomed.
  - A testable, working increment of the product is delivered at the end of each iteration.

- **Pros**:
  - **Flexible**: Can easily adapt to changing requirements.
  - **Fast Delivery**: The customer gets to see and use working software very early and at the end of every iteration.
  - **Lower Risk**: Constant feedback reduces the risk of building the wrong product.
  - **High Customer Satisfaction**: The customer is a partner in the development process.

- **Cons**:
  - Requires a high degree of customer involvement.
  - Can be less predictable in terms of a final, fixed deadline and budget.
  - Documentation can be de-prioritized.

**Popular Agile frameworks include Scrum, Kanban, and Extreme Programming (XP).**

---

## 4. Key Differences Summarized

| Feature                  | Waterfall                                     | Agile                                         |
| ------------------------ | --------------------------------------------- | --------------------------------------------- |
| **Approach**             | Linear, sequential                            | Iterative and incremental                     |
| **Requirements**         | Fixed and frozen at the start                 | Evolve and change throughout the project      |
| **Customer Involvement** | Low (at the start and end)                    | High and continuous                           |
| **Delivery**             | A single, final product at the end            | Small, working increments every 1-4 weeks     |
| **Flexibility**          | Very low; change is difficult and expensive   | Very high; change is expected and welcomed    |
| **Best for...**          | Projects with stable, well-defined requirements | Complex projects with uncertain requirements  |

---

## 5. Summary and Mastery Checklist

-   [ ] I can describe the Waterfall model as a rigid, sequential process.
-   [ ] I can describe the Agile approach as a flexible, iterative process.
-   [ ] I can name one of the four core values of the Agile Manifesto (e.g., "Working software over comprehensive documentation").
-   [ ] I can list a key difference between the two models (e.g., how they handle changing requirements).
-   [ ] I understand that most modern software development, especially for web applications, uses an Agile approach.

---

## 6. Research and References

-   **The Agile Manifesto**: The original source for the four values and twelve principles. [Link](https://agilemanifesto.org/)
-   **"The Scrum Guide" by Ken Schwaber and Jeff Sutherland**: The official guide to the most popular Agile framework.
-   **"Agile Software Development, Principles, Patterns, and Practices" by Robert C. Martin**: A classic book on the principles of Agile development.
-   **Atlassian - Agile Coach**: A comprehensive set of tutorials on all things Agile, from Scrum to Kanban. [Link](https://www.atlassian.com/agile)
