# Scrum Framework: Sprints, Stand-ups, Retrospectives

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Scrum as a framework for implementing Agile.
- **Describe** the concept of a Sprint.
- **Explain** the purpose of the key Scrum events (Sprint Planning, Daily Scrum, Sprint Review, Sprint Retrospective).
- **Identify** the main artifacts of Scrum (Product Backlog, Sprint Backlog, Increment).
- **Understand** that Scrum is a framework, not a rigid process, and is based on the principles of transparency, inspection, and adaptation.

---

## 2. Introduction to Scrum

**Scrum** is the most popular framework for implementing the Agile methodology. It is a lightweight yet powerful framework that helps teams work together to solve complex, adaptive problems, while creatively delivering products of the highest possible value.

Scrum is not a process or a technique for building products; rather, it is a framework within which you can employ various processes and techniques. Scrum makes clear the relative efficacy of your product management and work techniques so that you can continuously improve the product, the team, and the working environment.

The framework is built on the principles of **empiricism**: transparency, inspection, and adaptation.

---

## 3. The Core Components of Scrum

### Sprints

- The heart of Scrum is the **Sprint**, a time-box of one month or less (usually two weeks) during which a "Done," usable, and potentially releasable product **Increment** is created.
- Sprints are of a fixed length and a new Sprint starts immediately after the conclusion of the previous Sprint.
- During a Sprint:
  - No changes are made that would endanger the Sprint Goal.
  - Quality goals do not decrease.
  - The scope may be clarified and re-negotiated between the Product Owner and Development Team.

### Scrum Events (The "Meetings")

Each Sprint contains four formal events:

1.  **Sprint Planning**:
    - **Purpose**: To plan the work to be performed for the Sprint.
    - **Who**: The entire Scrum Team (Product Owner, Scrum Master, Development Team).
    - **What happens**: The team selects a set of items from the Product Backlog that they believe they can complete in the Sprint. This becomes the **Sprint Backlog**. They also craft a **Sprint Goal**.

2.  **Daily Scrum (or "Stand-up")**:
    - **Purpose**: To inspect progress toward the Sprint Goal and adapt the upcoming day's work. It is a planning meeting for the next 24 hours, not a status meeting.
    - **Who**: The Development Team.
    - **What happens**: A 15-minute, time-boxed event. Each developer often answers three questions:
      - What did I do yesterday that helped the team meet the Sprint Goal?
      - What will I do today to help the team meet the Sprint Goal?
      - Do I see any impediments that prevent me or the team from meeting the Sprint Goal?

3.  **Sprint Review**:
    - **Purpose**: To inspect the Increment and adapt the Product Backlog if needed.
    - **Who**: The Scrum Team and stakeholders (customers, management, etc.).
    - **What happens**: This is an informal meeting, not a status report. The Development Team demonstrates the work that they have "Done" during the Sprint. The group collaborates on what to do next, providing valuable input for the Product Backlog.

4.  **Sprint Retrospective**:
    - **Purpose**: To inspect the team's process and create a plan for improvements to be enacted during the next Sprint. It's about improving the "how," not the "what."
    - **Who**: The Scrum Team.
    - **What happens**: The team discusses what went well during the Sprint, what problems it ran into, and how those problems were (or were not) solved. The team identifies one or two key improvements to focus on in the next Sprint.

### Scrum Artifacts

1.  **Product Backlog**:
    - An ordered list of everything that is known to be needed in the product. It is the single source of requirements for any changes to be made to the product.
    - It is a living artifact, constantly being refined and reprioritized by the **Product Owner**.

2.  **Sprint Backlog**:
    - The set of Product Backlog items selected for the Sprint, plus a plan for delivering the product Increment and realizing the Sprint Goal.
    - It is a forecast by the Development Team about what functionality will be in the next Increment.

3.  **Increment**:
    - The sum of all the Product Backlog items completed during a Sprint and the value of the increments of all previous Sprints.
    - At the end of a Sprint, the new Increment must be "Done," which means it is in a usable condition and meets the Scrum Team's definition of "Done."

---

## 4. Summary and Mastery Checklist

-   [ ] I can define Scrum as a popular framework for implementing Agile.
-   [ ] I can explain that a Sprint is a short, time-boxed iteration (usually 2 weeks) where work gets done.
-   [ ] I can name the four main Scrum events (Planning, Daily Scrum, Review, Retrospective).
-   [ ] I can explain that the **Daily Scrum** is a short planning meeting for the team, not a status report for managers.
-   [ ] I can explain that the **Sprint Review** is for showing the working software to stakeholders.
-   [ ] I can explain that the **Sprint Retrospective** is for the team to reflect on and improve its own process.
-   [ ] I know that the **Product Backlog** is the master list of work for the project.

---

## 5. Research and References

-   **The Scrum Guide**: The official, definitive guide to the Scrum framework by its creators, Ken Schwaber and Jeff Sutherland. It is short and a must-read. [Link](https://scrumguides.org/)
-   **Scrum.org**: An organization founded by Ken Schwaber that provides resources, training, and certifications.
-   **"Scrum: The Art of Doing Twice the Work in Half the Time" by Jeff Sutherland**: A book from one of the co-creators that explains the "why" behind Scrum.
-   **Atlassian - "What is Scrum?"**: A great practical overview. [Link](https://www.atlassian.com/agile/scrum)
