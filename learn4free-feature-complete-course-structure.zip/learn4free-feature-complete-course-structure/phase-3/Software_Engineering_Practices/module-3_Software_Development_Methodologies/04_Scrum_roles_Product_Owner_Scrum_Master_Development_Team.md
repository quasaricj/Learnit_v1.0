# Scrum Roles: Product Owner, Scrum Master, Development Team

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Identify and describe** the three official roles in a Scrum Team.
- **Explain** the primary responsibilities of the Product Owner.
- **Explain** the primary responsibilities of the Scrum Master.
- **Explain** the primary responsibilities of the Development Team.
- **Understand** that the Scrum Team is a self-organizing, cross-functional unit.
- **Differentiate** Scrum roles from traditional project management roles.

---

## 2. Introduction to the Scrum Team

The Scrum Team is the fundamental unit in Scrum. It is a small, cohesive team of people, typically 10 or fewer, who work together to deliver the product Increment. A key characteristic of the Scrum Team is that it is **self-organizing** (the team chooses how best to accomplish its work) and **cross-functional** (the team has all the skills necessary to create the product Increment without depending on others not part of the team).

The Scrum Team consists of three specific roles: the Product Owner, the Scrum Master, and the Development Team. There are no sub-teams or hierarchies.

---

## 3. The Three Scrum Roles

### 1. The Product Owner (PO)

- **Primary Responsibility**: **Maximizing the value of the product** resulting from the work of the Development Team. The Product Owner is the "voice of the customer".
- **Key Activities**:
  - **Manages the Product Backlog**: This is their sole responsibility. This includes:
    - Clearly expressing Product Backlog items.
    - Ordering the items in the Product Backlog to best achieve goals and missions.
    - Ensuring that the Product Backlog is visible, transparent, and clear to all.
    - Ensuring the Development Team understands items in the Product Backlog to the level needed.
  - **Acts as a Single Point of Contact**: The PO is one person, not a committee. They are the single point of contact for stakeholders and are responsible for making the final decisions about the product's features and priority.
- **Analogy**: The captain of a ship, who is responsible for deciding the destination and the route.

### 2. The Scrum Master (SM)

- **Primary Responsibility**: **Promoting and supporting Scrum** as defined in the Scrum Guide. The Scrum Master is a "servant-leader" for the Scrum Team. They are not a project manager.
- **Key Activities**:
  - **Serves the Product Owner**: By helping them find techniques for effective Product Backlog management.
  - **Serves the Development Team**: By coaching them in self-organization and cross-functionality, and by **removing impediments** to the Development Team's progress.
  - **Serves the Organization**: By leading and coaching the organization in its Scrum adoption.
  - **Facilitates Scrum Events**: Ensures that the Scrum events (Daily Scrum, Sprint Planning, etc.) take place and are positive, productive, and kept within the time-box.
- **Analogy**: A coach for a sports team. The coach doesn't play the game, but they help the team perform at its best and remove anything that gets in their way.

### 3. The Development Team (or "Developers")

- **Primary Responsibility**: **Creating a "Done," usable Increment** of the product every Sprint.
- **Key Activities**:
  - **Builds the Product**: They are the professionals who do the work of designing, building, and testing the product.
  - **Manages the Sprint Backlog**: The Development Team is responsible for forecasting how much work they can take on in a Sprint and for tracking their progress toward the Sprint Goal during the Sprint.
  - **Self-organizing**: No one (not even the Scrum Master) tells the Development Team how to turn Product Backlog items into Increments of potentially releasable functionality.
  - **Cross-functional**: The team as a whole has all the skills needed to create the product Increment.
- **Analogy**: The players on the sports team. They are the ones who actually play the game and score the points.

---

## 4. Key Differences from Traditional Roles

- **No Project Manager**: The responsibilities of a traditional project manager are distributed among the three Scrum roles. The Product Owner manages the "what" (the product), the Development Team manages the "how" (the work), and the Scrum Master manages the process.
- **No Hierarchies**: The Scrum Team is a flat structure. All members of the Development Team are referred to as "Developers," regardless of their individual skills or experience.

---

## 5. Summary and Mastery Checklist

-   [ ] I can name the three roles in a Scrum Team: Product Owner, Scrum Master, and Development Team.
-   [ ] I can explain that the **Product Owner** is responsible for the Product Backlog and maximizing the product's value.
-   [ ] I can explain that the **Scrum Master** is a servant-leader responsible for promoting Scrum and removing impediments.
-   [ ] I can explain that the **Development Team** is a self-organizing team that builds the product Increment.
-   [ ] I understand that the Scrum Team is cross-functional and has no internal hierarchies.

---

## 6. Research and References

-   **The Scrum Guide**: The official guide is the primary source for the definitions of these roles. [Link](https://scrumguides.org/)
-   **Scrum.org - The Scrum Team**: [Link](https://www.scrum.org/resources/what-is-a-scrum-team)
-   **"Scrum: The Art of Doing Twice the Work in Half the Time" by Jeff Sutherland**: Provides great real-world stories that illustrate the roles in action.
-   **"The Professional Product Owner" by Don McGreal and Ralph Jocham**: A book focused on the critical role of the Product Owner.
