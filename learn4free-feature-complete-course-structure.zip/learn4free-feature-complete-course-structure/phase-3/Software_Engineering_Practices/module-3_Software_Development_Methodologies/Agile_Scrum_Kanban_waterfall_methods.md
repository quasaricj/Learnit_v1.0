# Software Development Methodologies: Waterfall vs. Agile, Scrum, and Kanban

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Software Development Life Cycle (SDLC).
-   **Describe** the Waterfall methodology and its linear, sequential nature.
-   **Define** Agile as an iterative and incremental approach.
-   **List** the core values and principles of the Agile Manifesto.
-   **Describe** the Scrum framework, including its key roles, events, and artifacts.
-   **Describe** the Kanban method and its focus on continuous flow and limiting work in progress.
-   **Compare and contrast** Waterfall and Agile, and know when each might be appropriate.

---

## 2. Introduction to SDLC and Methodologies

A **Software Development Life Cycle (SDLC)** is a process that a software development team follows to design, develop, test, and deploy high-quality software. A **development methodology** is a specific implementation of an SDLC.

Choosing the right methodology is crucial for a project's success. It affects how a team plans its work, responds to change, and delivers value to the customer. This module explores the major methodologies, contrasting the traditional Waterfall model with the modern Agile frameworks.

---

## 3. The Waterfall Model

The Waterfall model is a **linear, sequential** approach to software development. Each phase of the project must be fully completed before the next phase begins.

-   **Phases**:
    1.  **Requirements**: All project requirements are gathered and documented upfront.
    2.  **Design**: The system architecture and software design are created.
    3.  **Implementation**: The code is written.
    4.  **Testing**: The entire application is tested to find and fix bugs.
    5.  **Deployment**: The finished product is released to the customer.
    6.  **Maintenance**: The product is supported and updated.

-   **Pros**: Simple to understand and manage. Disciplined and well-documented.
-   **Cons**: **Extremely rigid**. It has a very difficult time accommodating change. If the requirements were wrong in the first phase, you might not find out until the testing phase, months or even years later, which is incredibly expensive to fix.
-   **Best for**: Projects where the requirements are fully known, fixed, and unlikely to change (e.g., building a bridge, some mission-critical systems). It is rarely used for modern web application development.

---

## 4. The Agile Manifesto

Agile is not a single methodology, but a **mindset** and a set of values and principles, captured in the Agile Manifesto (2001).

**We are uncovering better ways of developing software by doing it and helping others do it. Through this work we have come to value:**

-   **Individuals and interactions** over processes and tools
-   **Working software** over comprehensive documentation
-   **Customer collaboration** over contract negotiation
-   **Responding to change** over following a plan

That is, while there is value in the items on the right, we value the items on the left more.

The core idea of Agile is to work in **small, iterative cycles**, delivering incremental improvements to the software and getting regular feedback from the customer.

---

## 5. Agile Frameworks

### Scrum

Scrum is the most popular framework for implementing Agile. It is a prescriptive framework with specific roles, events, and artifacts.

-   **Core Idea**: Work is done in short, time-boxed iterations called **Sprints** (typically 1-4 weeks long). At the end of each Sprint, the team aims to deliver a potentially shippable increment of the product.

-   **Roles**:
    -   **Product Owner**: The voice of the customer. Responsible for managing the Product Backlog and prioritizing the work.
    -   **Scrum Master**: A servant-leader who facilitates the Scrum process and helps the team remove impediments.
    -   **Development Team**: A self-organizing, cross-functional group of people who do the actual work.

-   **Events (Ceremonies)**:
    -   **Sprint Planning**: The team plans the work to be done in the upcoming Sprint.
    -   **Daily Scrum (Stand-up)**: A short, daily meeting for the team to sync up on progress and impediments.
    -   **Sprint Review**: A demo of the work that was completed during the Sprint, shown to stakeholders.
    -   **Sprint Retrospective**: A private meeting for the team to reflect on what went well and what could be improved in the next Sprint.

-   **Artifacts**:
    -   **Product Backlog**: A prioritized list of all the features and work to be done on the product.
    -   **Sprint Backlog**: The subset of the Product Backlog that the team commits to completing in a Sprint.

### Kanban

Kanban is another popular Agile method that originated in manufacturing. It is less prescriptive than Scrum and focuses on visualizing workflow and improving efficiency.

-   **Core Idea**: **Visualize the workflow**, **limit work in progress (WIP)**, and **measure and optimize the flow**.
-   **The Kanban Board**: The central tool is the Kanban board, which has columns representing the stages of the workflow (e.g., `To Do`, `In Progress`, `In Review`, `Done`). Work items (tasks) are represented as cards that move from left to right across the board.
-   **WIP Limits**: The most important rule of Kanban. Each "in progress" column has a limit on the number of cards it can contain. This prevents the team from starting too many tasks at once and helps to identify bottlenecks in the process.
-   **Continuous Flow**: Unlike Scrum's Sprints, there are no fixed iterations. When a task is finished, the team simply pulls the next highest priority task from the "To Do" column.

-   **Best for**: Teams that have a continuous stream of incoming work with varying priorities, such as operations, support, or maintenance teams.

---

## 12. Summary and Mastery Checklist

-   [ ] I can describe the Waterfall model as a linear, sequential process.
-   [ ] I can explain that Agile is an iterative approach focused on customer feedback and responding to change.
-   [ ] I can name the four core values of the Agile Manifesto.
-   [ ] I can describe Scrum in terms of its Sprints, roles (Product Owner, Scrum Master, Dev Team), and key events (e.g., Daily Scrum, Sprint Review).
-   [ ] I can describe Kanban in terms of its visual board and its focus on limiting Work In Progress (WIP).
-   [ ] I understand that Waterfall is ill-suited for projects where requirements are likely to change.

---

## 13. Research and References

-   **The Agile Manifesto**: The original source document. [Link](https://agilemanifesto.org/)
-   **The Scrum Guide**: The official definition of the Scrum framework. [Link](https://scrumguides.org/)
-   **"Scrum: The Art of Doing Twice the Work in Half the Time" by Jeff Sutherland**: A book by one of the co-creators of Scrum.
-   **Atlassian - "What is Kanban?"**: A great introduction to the Kanban method.
