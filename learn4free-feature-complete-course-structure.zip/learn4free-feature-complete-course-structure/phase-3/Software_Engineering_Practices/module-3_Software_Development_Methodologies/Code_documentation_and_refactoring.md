# Code documentation and refactoring 
