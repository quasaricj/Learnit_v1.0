# Agile Requirements: User Stories and Backlog Management

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a User Story and its purpose.
-   **Write** a well-formed User Story using the "As a..., I want..., so that..." template.
-   **Explain** the INVEST criteria for a good User Story.
-   **Define** the Product Backlog and the Sprint Backlog.
-   **Describe** the process of Backlog Refinement (or Grooming).
-   **Understand** the role of the Product Owner in managing the backlog.

---

## 2. Introduction to Agile Requirements

Traditional development methodologies (like Waterfall) rely on extensive, upfront requirements documents that attempt to capture every detail of the system. In contrast, Agile methodologies use a more lightweight and dynamic approach to requirements. The most common format for Agile requirements is the **User Story**. User stories are managed in a prioritized list called the **Product Backlog**.

---

## 3. Core Concepts

### User Stories

A **User Story** is a short, simple description of a feature told from the perspective of the person who desires the new capability, usually a user or customer of the system. They are not detailed specifications; they are conversation starters.

-   **The Template**: User stories are often written in the following format:
    > **As a** [type of user],
    > **I want** [some goal],
    > **so that** [some reason].

-   **Example**:
    > **As a** registered user,
    > **I want** to be able to log in with my email and password,
    > **so that** I can access my personal dashboard.

-   **Acceptance Criteria**: Each user story should be accompanied by **acceptance criteria**, which are a set of testable conditions that must be met for the story to be considered "done".
    -   *Example Acceptance Criteria for the login story*:
        -   Given a valid email and password, the user is redirected to the dashboard.
        -   Given an invalid password, an error message is shown.
        -   Given a non-existent email, an error message is shown.

### The INVEST Criteria for Good User Stories

-   **I**ndependent: Stories should be as self-contained as possible.
-   **N**egotiable: A story is not a rigid contract. It's an invitation to a conversation between the team and the Product Owner.
-   **V**aluable: It must deliver value to the end-user or customer.
-   **E**stimable: The team must be able to estimate the effort required to complete the story.
-   **S**mall: The story should be small enough to be completed within a single Sprint.
-   **T**estable: You must be able to verify that the story is "done" (this is where acceptance criteria come in).

### The Product Backlog

-   **What it is**: The **single source of truth** for all work to be done on the project. It is a prioritized list of user stories, bug fixes, technical tasks, and other work items.
-   **Who owns it**: The **Product Owner** is solely responsible for managing the Product Backlog.
-   **Prioritization**: The backlog is a living document. The Product Owner is constantly re-prioritizing it based on customer feedback, business value, and strategic goals. The most important items are at the top.

### The Sprint Backlog

-   **What it is**: The set of Product Backlog items that the Development Team selects for a given Sprint. It is the team's plan for what they will deliver in the next Sprint and how they will do it.
-   **Who owns it**: The **Development Team** owns the Sprint Backlog. Once the team commits to the work in the Sprint Backlog, no one (not even the Product Owner) can add more work to the Sprint.

### Backlog Refinement (Grooming)

-   **What it is**: Backlog Refinement is an ongoing process where the Product Owner and the Development Team collaborate to review and improve the items in the Product Backlog.
-   **Activities**:
    -   Breaking down large stories ("epics") into smaller, more manageable stories.
    -   Clarifying requirements and adding details and acceptance criteria.
    -   Estimating the effort for upcoming stories (using techniques like story points).
-   **Goal**: To ensure that the stories at the top of the backlog are well-understood, estimated, and ready to be worked on in an upcoming Sprint.

---

## 4. Deliberate Practice

1.  **Write User Stories**: For the e-commerce project from Phase 2, write user stories for the following features:
    -   A user being able to add an item to their shopping cart.
    -   A user being able to view the contents of their cart.
    -   A user being able to remove an item from their cart.
2.  **Define Acceptance Criteria**: For the "add to cart" story, write at least three acceptance criteria.
3.  **Backlog Prioritization**: Imagine you are the Product Owner for a new blog platform. You have the following stories. In what order would you prioritize them, and why?
    -   "As a user, I want to be able to write and publish a new post."
    -   "As a user, I want to be able to register for an account."
    -   "As a reader, I want to see a list of all posts."
    -   "As a user, I want to be able to upload an image for my post."

---

## 12. Summary and Mastery Checklist

-   [ ] I can write a user story using the standard "As a..., I want..., so that..." template.
-   [ ] I know that a good user story should meet the INVEST criteria.
-   [ ] I can explain that the **Product Backlog** is a prioritized list of all work, owned by the Product Owner.
-   [ ] I can explain that the **Sprint Backlog** is the work selected for a single Sprint, owned by the Development Team.
-   [ ] I understand that Backlog Refinement is the process of preparing stories for future Sprints.

---

## 13. Research and References

-   **"User Stories Applied: For Agile Software Development" by Mike Cohn**: The definitive book on user stories.
-   **"Agile Estimating and Planning" by Mike Cohn**: A comprehensive guide to the "how" of Agile planning.
-   **Atlassian - "User Stories"**: A great collection of articles and examples.
-   **"Scrum: The Art of Doing Twice the Work in Half the Time" by Jeff Sutherland**: Provides great insight into the role of the Product Owner and the backlog.
