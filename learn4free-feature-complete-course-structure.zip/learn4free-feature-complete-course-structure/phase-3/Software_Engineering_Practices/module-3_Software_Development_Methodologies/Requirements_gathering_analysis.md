# Requirements gathering analysis 
