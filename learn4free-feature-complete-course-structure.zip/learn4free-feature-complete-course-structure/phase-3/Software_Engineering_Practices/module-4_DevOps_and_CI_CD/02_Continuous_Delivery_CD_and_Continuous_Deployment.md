# Continuous Delivery (CD) and Continuous Deployment

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Continuous Delivery (CD) and Continuous Deployment.
- **Differentiate** clearly between Continuous Integration, Continuous Delivery, and Continuous Deployment.
- **Describe** the concept of a deployment pipeline.
- **Explain** the purpose of different environments (e.g., development, testing, staging, production).
- **Understand** the role of feature flags in a CD process.

---

## 2. Introduction to Delivery and Deployment

Continuous Integration (CI) is the first step. It ensures that you always have a "green" build that has passed all your automated tests. But what happens next? How does that tested code get to your users? This is where Continuous Delivery and Continuous Deployment come in.

- **Continuous Delivery (CD)** is a software development practice where you automatically build and test your code and make sure that it is always in a **releasable state**. The final decision to push the code to production is a **manual** business decision.
- **Continuous Deployment** is the next step after Continuous Delivery. Every change that passes all stages of your production pipeline is **automatically** released to your customers. There is no human intervention.

---

## 3. The Deployment Pipeline

Both Continuous Delivery and Continuous Deployment are made possible by a **deployment pipeline** (or CI/CD pipeline). This is an automated manifestation of your process for getting software from version control into the hands of your users.

### Stages of a Typical Pipeline

1.  **Commit Stage** (The CI part):
    - **Trigger**: A developer pushes a commit.
    - **Actions**:
      - The CI server runs the build script.
      - It runs all the fast, automated tests (unit tests, some integration tests).
    - **Goal**: To get feedback to the developer as quickly as possible (under 5 minutes).

2.  **Acceptance Stage**:
    - **Trigger**: The Commit Stage passes.
    - **Actions**:
      - The system is automatically deployed to a dedicated testing or "staging" environment.
      - A broader suite of automated tests is run (e.g., more complex integration tests, end-to-end tests).
      - Performance and security scans might be run.
    - **Goal**: To verify that the system meets its acceptance criteria and is ready for release.

3.  **Release Stage**:
    - **Trigger**: The Acceptance Stage passes.
    - **What happens next depends on whether you are doing Continuous Delivery or Continuous Deployment.**

---

## 4. Continuous Integration vs. Continuous Delivery vs. Continuous Deployment

This is a common point of confusion.

| Practice                   | Description                                                                                             | Key Idea                                      |
| -------------------------- | ------------------------------------------------------------------------------------------------------- | --------------------------------------------- |
| **Continuous Integration** | Developers merge their changes to main frequently. Each merge triggers an automated build and test.     | Always have a tested, "green" `main` branch.  |
| **Continuous Delivery**    | Extends CI. Every change that passes the automated tests is automatically deployed to a "production-like" environment. | Every build is a **potential** release. The final release is a manual button push. |
| **Continuous Deployment**  | Extends Continuous Delivery. Every change that passes the entire pipeline is **automatically** released to production. | Every build **is** a release. No manual intervention. |

**In summary: CI is about the code, CD is about the release process.**

---

## 5. Advanced Concepts

### Environments

- **Development**: A developer's local machine.
- **Testing/QA**: A shared environment where Quality Assurance engineers can test the application.
- **Staging (or Pre-production)**: An environment that is an exact mirror of the production environment. This is where the final round of testing is done before release.
- **Production**: The live environment that your users interact with.

### Feature Flags (or Feature Toggles)

How can you practice Continuous Deployment if a new feature is not yet complete? You use **feature flags**.
- A feature flag is a technique that allows you to turn features on or off at runtime, without deploying new code.
- You can wrap a new, incomplete feature in a feature flag. The code will be deployed to production, but the feature will be "off" and invisible to users.
- This decouples "deployment" from "release". You can deploy your code at any time, but you only release the feature to users (by turning the flag on) when it is ready.

### Blue-Green Deployment / Canary Releases

These are advanced deployment strategies to reduce the risk of a bad release.
- **Blue-Green Deployment**: You have two identical production environments ("blue" and "green"). You deploy the new version to the inactive environment (e.g., green), run tests, and then switch the router to send all traffic to the green environment. This makes rollback instantaneous.
- **Canary Release**: You release the new version to a small subset of your users (the "canaries"). You monitor the system for errors. If it's stable, you gradually roll it out to the rest of your users.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define Continuous Delivery as the practice of keeping your application in a releasable state at all times.
-   [ ] I can define Continuous Deployment as the practice of automatically releasing every good build to production.
-   [ ] I can explain that the main difference is that Continuous Delivery has a manual "release" button, while Continuous Deployment does not.
-   [ ] I can describe a deployment pipeline as an automated process for getting code from commit to production.
-   [ ] I can explain that feature flags allow you to deploy incomplete features to production safely.

---

## 7. Research and References

-   **"Continuous Delivery: Reliable Software Releases through Build, Test, and Deployment Automation" by Jez Humble and David Farley**: The bible on this topic.
-   **"Accelerate: The Science of Lean Software and DevOps" by Nicole Forsgren, Jez Humble, and Gene Kim**: A book that presents the research proving that practices like CI/CD lead to higher-performing organizations.
-   **Atlassian - "CI vs. CD vs. CD"**: [Link](https://www.atlassian.com/continuous-delivery/ci-vs-cd-vs-cd)
-   **Martin Fowler - "Feature Toggle"**: [Link](https://martinfowler.com/bliki/FeatureToggle.html)
-   **"The State of DevOps Report"**: An annual report that provides data and insights into the practices of high-performing teams.
