# CI/CD Pipelines with Jenkins, GitHub Actions, or Azure DevOps

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a CI/CD pipeline and its purpose.
- **Identify** the key components of a CI/CD tool (e.g., build agents, pipeline configuration).
- **Recognize** the names of major CI/CD platforms.
- **Read and understand** a simple pipeline configuration file (e.g., in YAML).
- **Describe** a basic pipeline that builds, tests, and deploys an application.
- **Explain** the concept of "pipeline as code".

---

## 2. Introduction to CI/CD Tools

A **CI/CD pipeline** is the automated workflow that takes your code from a commit in version control all the way to deployment. The tool that runs this automated process is a **CI/CD server** or **platform**. These platforms are the engines of modern DevOps.

There are many tools available, but they all share the same core concepts.

### A Tour of Major CI/CD Platforms

- **Jenkins**:
  - The original and still one of the most popular open-source automation servers.
  - **Pros**: Extremely powerful and flexible, with a massive ecosystem of plugins for integrating with almost any tool imaginable. Can be self-hosted, giving you full control.
  - **Cons**: Can be complex to set up and manage. The user interface is considered dated by some.

- **GitHub Actions**:
  - A CI/CD platform built directly into GitHub.
  - **Pros**: Seamless integration with your GitHub repositories. A very generous free tier for public repositories. A huge marketplace of pre-built "actions" that you can easily drop into your pipeline. Uses a clean, YAML-based configuration.
  - **Cons**: Less mature than some of the older tools. Primarily tied to the GitHub ecosystem.

- **Azure DevOps**:
  - A suite of development tools from Microsoft, which includes a very powerful CI/CD component called **Azure Pipelines**.
  - **Pros**: Excellent for teams that are heavily invested in the Microsoft/Azure ecosystem. Has strong support for building, testing, and deploying both open-source and Windows-based applications.
  - **Cons**: Can be complex.

- **Other popular tools**: GitLab CI/CD (tightly integrated with GitLab), CircleCI, Travis CI, TeamCity.

---

## 3. Core Concepts

### Pipeline as Code

Modern CI/CD pipelines are not configured through a graphical user interface. Instead, the entire pipeline is defined in a text file that is stored in the same repository as the application code. This practice is called **Pipeline as Code**.

- **Configuration File**: This is typically a **YAML** file (e.g., `Jenkinsfile`, `.github/workflows/main.yml`, `azure-pipelines.yml`).
- **Benefits**:
  - **Version Controlled**: Your pipeline definition is versioned along with your code. You can see the history of changes to your pipeline.
  - **Reproducible**: You can easily set up the same pipeline in a new environment.
  - **Code Review**: Changes to the pipeline can be reviewed and approved through the same pull request process as your application code.

### Build Agents (or Runners)

The CI/CD server itself doesn't run your builds. It orchestrates the work and assigns it to **build agents** (or "runners").
- A build agent is a machine (physical or virtual) that has the necessary software installed (e.g., Node.js, Java JDK, Docker) to build and test your application.
- When a pipeline is triggered, the server finds an available agent, sends it the pipeline instructions, and the agent executes the steps.
- This allows for scaling; you can add more build agents to run more builds in parallel.

### A Simple Pipeline in YAML (GitHub Actions Example)

This example shows a simple pipeline for a Node.js application that is triggered on every push to the `main` branch.

```yaml
# .github/workflows/main.yml

name: Node.js CI

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Use Node.js 18
      uses: actions/setup-node@v3
      with:
        node-version: 18

    - name: Install dependencies
      run: npm install

    - name: Run tests
      run: npm test
```

**Breaking it down**:
- **`on`**: Defines the trigger for the pipeline.
- **`jobs`**: A pipeline is made up of one or more jobs. This pipeline has one job called `build`.
- **`runs-on`**: Specifies the type of build agent to use.
- **`steps`**: A sequence of tasks for the job to execute.
  - **`uses`**: Uses a pre-built "action" from the GitHub Marketplace.
  - **`run`**: Executes a command-line script.

---

## 4. Summary and Mastery Checklist

-   [ ] I know that a CI/CD tool (like GitHub Actions or Jenkins) is what automates a deployment pipeline.
-   [ ] I can explain that "Pipeline as Code" means defining the pipeline in a YAML file that is stored in my Git repository.
-   [ ] I can list at least two benefits of Pipeline as Code (e.g., version controlled, reproducible).
-   [ ] I can read a simple YAML pipeline file and understand the basic steps (e.g., checkout, install, test).
-   [ ] I can name at least two major CI/CD platforms.

---

## 5. Research and References

-   **GitHub Actions Documentation**: Excellent for learning the basics of a modern, YAML-based CI/CD system. [Link](https://docs.github.com/en/actions)
-   **Jenkins User Documentation**: [Link](https://www.jenkins.io/doc/)
-   **"Pipeline as Code with Jenkins" by Pishu Upreti**: A book focused on the Jenkins ecosystem.
-   **YAML Tutorial**: A quick guide to the YAML syntax. [Link](https://www.yamllint.com/)
