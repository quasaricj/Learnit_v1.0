# Infrastructure as Code (IaC) with Terraform

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Infrastructure as Code (IaC) and explain its benefits.
- **Differentiate** between the declarative ("what") and imperative ("how") approaches to IaC.
- **Describe** the role of Terraform as a declarative IaC tool.
- **Read and understand** a simple Terraform configuration file.
- **Explain** the basic Terraform workflow: `init`, `plan`, `apply`.
- **Understand** how IaC enables the creation of reproducible and version-controlled environments.

---

## 2. Introduction to Infrastructure as Code

In traditional IT, managing infrastructure (servers, databases, networks) was a manual process. An administrator would click through a web console or run a series of commands to set up a new server. This process was slow, error-prone, and difficult to reproduce consistently.

**Infrastructure as Code (IaC)** is the practice of managing and provisioning your infrastructure using **code and configuration files**, rather than through manual processes. Instead of clicking buttons, you write a file that defines the desired state of your infrastructure, and an IaC tool automatically makes it happen.

### Benefits of IaC

- **Automation**: Drastically reduces the time and effort required to provision and manage infrastructure.
- **Consistency and Reproducibility**: By defining your infrastructure in code, you can guarantee that you are creating the exact same environment every time. This eliminates the problem of "it works on my machine."
- **Version Control**: You can store your infrastructure configuration files in a Git repository, just like your application code. This gives you a full history of all changes to your infrastructure.
- **Collaboration**: Your infrastructure code can be reviewed and approved through the same pull request process as your application code.

---

## 3. Declarative vs. Imperative IaC

- **Imperative ("How")**:
  - You write a script that specifies the exact **steps** to take to get to the desired state.
  - *Example*: A shell script that runs `aws ec2 create-instance`, then `aws security-group create`, etc.
  - **Tools**: Chef, Puppet, Ansible, shell scripts.

- **Declarative ("What")**:
  - You write a configuration file that defines the **desired final state** of your infrastructure. You don't specify the steps.
  - The IaC tool is responsible for figuring out how to get from the current state to the desired state.
  - *Example*: A file that says "I want one server of this type and one database of this type."
  - **Tools**: **Terraform**, AWS CloudFormation.

The declarative approach is generally preferred for provisioning infrastructure, as it is more robust and easier to manage.

---

## 4. Terraform

**Terraform** is the most popular open-source, declarative IaC tool. It is "cloud-agnostic," meaning you can use it to manage infrastructure across all major cloud providers (AWS, Azure, Google Cloud) and other services with a single, consistent workflow.

### The Terraform Workflow

1.  **Write**: You define your infrastructure in Terraform configuration files using the HashiCorp Configuration Language (HCL).
2.  **`terraform init`**: You initialize your project, which downloads the necessary "providers" (like the AWS provider) for the services you want to manage.
3.  **`terraform plan`**: Terraform creates an **execution plan**. It compares the desired state defined in your configuration files with the current state of your real-world infrastructure and determines what changes need to be made (what needs to be created, updated, or destroyed). This is a "dry run" and is a critical safety step.
4.  **`terraform apply`**: If you approve the plan, Terraform executes the planned changes in the correct order to reach the desired state.

### A Simple Terraform Configuration File (`main.tf`)

This example defines the desired state for a single AWS EC2 virtual server.

```hcl
# Configure the AWS provider
provider "aws" {
  region = "us-west-2"
}

# Define a resource: an AWS EC2 instance
resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0" # An Amazon Machine Image
  instance_type = "t2.micro"             # The size of the server

  tags = {
    Name = "HelloWorld"
  }
}
```

- **`provider`**: Specifies the cloud provider you are using.
- **`resource`**: Defines a piece of infrastructure you want to create.
  - `aws_instance`: The resource type (an EC2 server).
  - `"web_server"`: A local name for this resource.
  - The block contains the configuration for the resource.

### State Management

Terraform needs to keep track of the infrastructure it manages. It does this by creating a **state file** (usually `terraform.tfstate`). This file is a JSON file that maps your configuration resources to the real-world resources that have been created. This is how Terraform knows what it's responsible for managing.

**Important**: The state file is critical. For team collaboration, it must be stored in a shared, remote location (like an AWS S3 bucket) to prevent conflicts.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define Infrastructure as Code as the practice of managing infrastructure with configuration files.
-   [ ] I can list a key benefit of IaC (e.g., automation, consistency, version control).
-   [ ] I can explain that a **declarative** tool (like Terraform) focuses on the "what" (the desired state), while an **imperative** tool focuses on the "how" (the steps).
-   [ ] I can name Terraform as a popular, cloud-agnostic, declarative IaC tool.
-   [ ] I can describe the three basic steps of the Terraform workflow: `init`, `plan`, and `apply`.
-   [ ] I understand that the `terraform plan` step is a crucial "dry run" to see what changes will be made.

---

## 6. Research and References

-   **Terraform Official "Getting Started" Guide**: The best place to start. It provides excellent, hands-on tutorials for different cloud providers. [Link](https://developer.hashicorp.com/terraform/tutorials/aws-get-started)
-   **"Terraform: Up & Running" by Yevgeniy Brikman**: A very practical and popular book.
-   **"Infrastructure as Code" by Kief Morris**: A foundational book on the patterns and practices of IaC.
-   **Terraform Registry**: A marketplace of pre-built "modules" and "providers" for Terraform. [Link](https://registry.terraform.io/)
