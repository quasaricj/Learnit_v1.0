# Monitoring and Logging Best Practices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Differentiate** between monitoring, logging, and observability.
- **Define** the "three pillars of observability": logs, metrics, and traces.
- **Explain** the purpose of application logging.
- **Describe** what constitutes a good, structured log message.
- **Understand** the concept of application performance monitoring (APM) and the key metrics to track (e.g., latency, error rate).
- **Recognize** the importance of a centralized logging and monitoring system.

---

## 2. Introduction: Understanding Your System in Production

Once your application is deployed, your job is not over. You need to be able to understand what is happening inside your application in the production environment. Is it healthy? Is it performing well? Are users encountering errors? **Monitoring** and **logging** are the practices that allow you to answer these questions.

- **Logging**: The practice of writing out event data (logs) from your application. Logs provide a detailed, event-by-event record of what happened.
- **Monitoring**: The practice of collecting, aggregating, and analyzing data about your system's performance over time (metrics). Monitoring is for identifying trends and being alerted to problems.
- **Observability**: A more modern and holistic term. A system is "observable" if you can understand its internal state from the outside. Observability is achieved by implementing good logging, monitoring, and tracing.

---

## 3. The Three Pillars of Observability

### 1. Logs

- **What they are**: A timestamped, immutable record of a discrete event that happened over time. A log entry is the most detailed piece of data.
- **Best Practices for Logging**:
  - **Log in a structured format (like JSON)**: Instead of plain text strings, log JSON objects. This makes your logs searchable and machine-readable.
    - **Bad**: `log.info("User logged in: alice")`
    - **Good**: `log.info({ event: "user_login", userId: "123", username: "alice" })`
  - **Don't log sensitive data**: Never log passwords, API keys, or personally identifiable information (PII).
  - **Log with context**: Include relevant contextual information in your logs, like a user ID or a request ID.
  - **Use Log Levels**: Use different log levels to indicate severity (`DEBUG`, `INFO`, `WARN`, `ERROR`, `FATAL`). This allows you to filter out noise in a production environment.
- **Centralized Logging**: In a distributed system with multiple servers, you don't want to have to SSH into each server to read log files. You should use a **log aggregator** (like the ELK Stack, Splunk, or Datadog) to collect all your logs in one central, searchable place.

### 2. Metrics

- **What they are**: A numerical representation of data measured over intervals of time. Metrics are aggregated and are good for building dashboards and alerts.
- **Key Application Metrics (The "Four Golden Signals")**:
  - **Latency**: The time it takes to serve a request. (e.g., the average response time for your API).
  - **Traffic**: A measure of how much demand is being placed on your system (e.g., requests per second).
  - **Errors**: The rate of requests that fail (e.g., the number of `500` status codes per minute).
  - **Saturation**: How "full" your service is. A measure of system utilization (e.g., CPU, memory usage).
- **Monitoring Tools**: Tools like **Prometheus** (open source) and **Datadog** (commercial) are used to collect, store, and visualize these metrics. You use these tools to create dashboards and to set up **alerts** (e.g., "send me a notification if the error rate goes above 1% for 5 minutes").

### 3. Traces (Distributed Tracing)

- **What they are**: A representation of the journey of a single request as it travels through all the different microservices in your application. A trace is made up of a series of "spans," where each span represents a single unit of work (e.g., one API call).
- **Purpose**: In a microservices architecture, a single user request might involve calls to half a dozen different services. If that request is slow, how do you know which service is the bottleneck? Distributed tracing allows you to visualize the entire request flow and pinpoint the source of latency or errors.
- **Tools**: OpenTelemetry, Jaeger, Datadog APM.

---

## 4. Summary and Mastery Checklist

-   [ ] I can explain that **logging** is about recording discrete events, while **monitoring** is about tracking aggregated metrics over time.
-   [ ] I can name the "three pillars of observability": logs, metrics, and traces.
-   [ ] I know that I should log in a structured format like **JSON**.
-   [ ] I can name one of the "four golden signals" for application monitoring (e.g., Latency or Error Rate).
-   [ ] I understand that in a production environment, logs and metrics should be sent to a **centralized** system.
-   [ ] I understand that **distributed tracing** is used to debug performance issues in a microservices architecture.

---

## 5. Research and References

-   **"Site Reliability Engineering: How Google Runs Production Systems"**: The book from Google that introduced the "four golden signals." Chapter 6 is a must-read.
-   **"The Twelve-Factor App - XI. Logs"**: The classic guide to application logging. [Link](https://12factor.net/logs)
-   **Observability 101**: A great introductory article.
-   **OpenTelemetry**: The open-source standard for instrumenting your applications to generate traces, metrics, and logs. [Link](https://opentelemetry.io/)
-   **Prometheus**: The leading open-source monitoring system. [Link](https://prometheus.io/)
-   **The ELK Stack (Elasticsearch, Logstash, Kibana)**: The most popular open-source stack for centralized logging.
