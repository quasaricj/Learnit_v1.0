# Automation scripting Bash YAML Groovy 
