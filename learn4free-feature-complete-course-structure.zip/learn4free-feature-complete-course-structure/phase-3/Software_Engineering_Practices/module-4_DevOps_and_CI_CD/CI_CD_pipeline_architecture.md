# CI/CD Pipeline Architecture (Jenkins, GitHub Actions)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a CI/CD pipeline and its purpose.
-   **List** the common stages of a CI pipeline (e.g., Build, Test, Lint).
-   **List** the common stages of a CD pipeline (e.g., Deploy to Staging, Deploy to Production).
-   **Describe** the role of a build server like Jenkins or a platform like GitHub Actions.
-   **Read and understand** a basic pipeline configuration file (e.g., in YAML).
-   **Explain** how a pipeline is triggered (e.g., on a push to a branch or a PR).
-   **Differentiate** between a pipeline and a workflow.

---

## 2. Introduction to CI/CD Pipelines

A **CI/CD pipeline** is the automated workflow that takes a developer's code from a version control system and delivers it to production. It is the practical implementation of the DevOps principles of automation and rapid feedback. By automating the build, testing, and deployment process, a pipeline ensures that every change is consistently and safely delivered, reducing manual errors and increasing the speed of releases.

---

## 3. Core Concepts

### What is a Pipeline?

A pipeline is a sequence of **stages** or **jobs**. Each stage in the pipeline is responsible for a specific task. If any stage fails, the pipeline stops, and the developer is notified.

### Common CI Pipeline Stages

The **Continuous Integration (CI)** part of the pipeline focuses on building and testing the code. It is typically triggered on every push to any branch, and especially on the creation of a Pull Request.

1.  **Source/Checkout**: The pipeline's first step is always to check out the specific commit from the version control system.
2.  **Install Dependencies**: The pipeline needs to install all the necessary libraries and packages for the project (e.g., `npm install`, `pip install`).
3.  **Lint**: A "linter" is run to check the code for stylistic errors and common programming mistakes. This ensures code consistency.
4.  **Unit Tests**: The fast-running unit tests are executed. This is the first and most important quality gate. Code coverage reports are often generated here.
5.  **Build**: For compiled languages (like Java) or frontend projects, this stage compiles the code or bundles the assets into a production-ready artifact.
6.  **Integration Tests**: The slower-running integration tests are executed. This might involve spinning up a temporary database.
7.  **Publish Artifact**: If all previous stages pass, the compiled code or a Docker image is published to a repository (like Docker Hub or a package registry) so it can be used in the deployment phase.

### Common CD Pipeline Stages

The **Continuous Delivery/Deployment (CD)** part of the pipeline focuses on releasing the artifact that was built by the CI pipeline.

1.  **Deploy to Staging**: The new version of the application is automatically deployed to a "staging" or "pre-production" environment. This environment should be as identical to production as possible.
2.  **Automated E2E Tests**: Automated end-to-end tests are run against the staging environment to simulate user workflows and catch any final integration issues.
3.  **Manual Approval (for Continuous Delivery)**: In a Continuous Delivery model, the pipeline pauses here for a human (e.g., a product manager or QA lead) to give final approval for the production release.
4.  **Deploy to Production**:
    -   In a **Continuous Deployment** model, this step runs automatically if the E2E tests pass.
    -   In a **Continuous Delivery** model, this step is triggered by the manual approval.
    -   Various deployment strategies can be used here, such as Blue-Green or Canary deployments, to minimize risk.

### Pipeline as Code

Modern CI/CD pipelines are defined as code. You write a configuration file (typically in **YAML**) that lives in your project's repository. This file defines all the stages, jobs, and steps of your pipeline.

-   **Benefits**:
    -   The pipeline is version-controlled along with your application code.
    -   It's easy to see how the pipeline works by reading the file.
    -   You can have different pipelines for different branches.

---

## 4. CI/CD Platforms

### GitHub Actions

-   A CI/CD platform built directly into GitHub.
-   **Workflows**: You define your pipelines in YAML files within a `.github/workflows` directory in your repository.
-   **Events**: Workflows can be triggered by a wide variety of events, such as a `push`, a `pull_request`, or a manual trigger.
-   **Runners**: The jobs are executed on "runners" (virtual machines). GitHub provides hosted runners for Linux, Windows, and macOS, or you can host your own.
-   **Extensibility**: Has a rich marketplace of pre-built "actions" that you can easily drop into your workflow for common tasks (e.g., logging into a cloud provider, sending a Slack notification).

### Jenkins

-   One of the oldest, most powerful, and most flexible open-source automation servers.
-   **Jenkinsfile**: Like GitHub Actions, modern Jenkins uses a "Pipeline as Code" model with a configuration file called a `Jenkinsfile`.
-   **Self-Hosted**: Jenkins is typically self-hosted, meaning you have to manage the server and the build agents (nodes) yourself. This gives you a huge amount of control and flexibility but also requires more maintenance.
-   **Plugins**: Jenkins has a massive ecosystem of plugins for integrating with virtually any tool imaginable.

---

## 5. Deliberate Practice

1.  **Analyze a Workflow File**: Go to an open-source project on GitHub that uses GitHub Actions (most modern ones do). Find their YAML workflow file in the `.github/workflows` directory. Read through it and try to identify the different stages of their CI pipeline.
2.  **Create a Simple CI Pipeline**:
    -   Create a new GitHub repository for a simple project (e.g., the one where you wrote unit tests).
    -   Go to the "Actions" tab. GitHub will suggest some starter workflows.
    -   Choose a starter workflow for your language (e.g., Node.js or Python).
    -   Commit the new YAML file.
    -   Watch the "Actions" tab as your first pipeline runs. See if it passes or fails.
3.  **Make a Test Fail**: In a new branch, intentionally break a unit test. Push the branch and create a Pull Request. Go to the PR on GitHub and observe how the CI checks fail, preventing you from merging the broken code.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define a CI/CD pipeline as an automated process for building, testing, and deploying code.
-   [ ] I can list the key stages of a CI pipeline, with **Test** being the most important.
-   [ ] I can explain the difference between Continuous Delivery (requires manual approval for production) and Continuous Deployment (fully automated).
-   [ ] I know that modern pipelines are defined as code, typically in a YAML file.
-   [ ] I can name at least two popular CI/CD platforms (e.g., GitHub Actions, Jenkins).

---

## 13. Research and References

-   **GitHub Actions Documentation**: [Link](https://docs.github.com/en/actions)
-   **Jenkins Documentation**: [Link](https://www.jenkins.io/doc/)
-   **"Continuous Delivery: Reliable Software Releases through Build, Test, and Deployment Automation" by Jez Humble and David Farley**: The definitive book on the principles and practices of CI/CD.
-   **Atlassian - "CI/CD"**: A great overview of the concepts.
