# DevOps Culture and Principles

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** DevOps and its primary goals.
-   **Explain** that DevOps is a cultural shift, not just a set of tools.
-   **Describe** the C.A.L.M.S. framework for DevOps (Culture, Automation, Lean, Measurement, Sharing).
-   **Explain** the core DevOps principle of "breaking down silos" between Development and Operations.
-   **Define** Continuous Integration, Continuous Delivery, and Continuous Deployment.
-   **Understand** the concept of "shifting left" and its impact on quality and security.

---

## 2. Introduction to DevOps

**DevOps** is a set of practices, tools, and a cultural philosophy that combine software development (Dev) and IT operations (Ops). The primary goal of DevOps is to shorten the systems development life cycle and provide continuous delivery with high software quality.

Historically, Development and Operations teams were often "siloed". Devs wanted to ship new features quickly, while Ops wanted to ensure stability and reliability. These conflicting goals often led to friction and slow release cycles. DevOps aims to break down these silos by creating a more collaborative and automated workflow.

---

## 3. The C.A.L.M.S. Framework

C.A.L.M.S. is a useful acronym for remembering the five pillars of the DevOps philosophy.

-   **C**ulture: This is the most important pillar. DevOps is about fostering a culture of **collaboration, shared responsibility, and blamelessness**. Instead of blaming the Ops team for a deployment failure, the whole team (Devs and Ops) works together to understand the root cause and improve the process.
-   **A**utomation: Automate everything you can: testing, builds, deployments, and infrastructure provisioning. Automation reduces manual errors, increases speed, and ensures repeatability.
-   **L**ean: Apply principles from lean manufacturing to software development. This means focusing on delivering value to the customer, eliminating waste (e.g., unnecessary features, manual processes), and continuously improving the workflow.
-   **M**easurement: You can't improve what you don't measure. DevOps teams constantly measure everything: deployment frequency, failure rates, time to recover from failures, application performance, etc. These metrics are used to drive improvements.
-   **S**haring: Foster a culture of open communication and knowledge sharing. Both Dev and Ops teams should share their tools, their expertise, and their understanding of the system.

---

## 4. Core DevOps Principles and Practices

### Breaking Down Silos

This is the foundational principle. It means creating cross-functional teams where developers and operations engineers work together on the entire application lifecycle, from development to deployment to production support.

### The "Three Ways" of DevOps

1.  **The First Way: Systems Thinking**: Focus on optimizing the entire flow of work from Development to Operations to the customer. Never pass a known defect downstream.
2.  **The Second Way: Amplify Feedback Loops**: Create fast and constant feedback loops from right to left. For example, developers should get immediate feedback from automated tests, and the whole team should get feedback from monitoring tools in production.
3.  **The Third Way: A Culture of Continual Experimentation and Learning**: Create a culture that is safe for experimentation and risk-taking. Understand that failure is a part of learning, and use "blameless postmortems" to learn from failures and improve the system.

### "Shift Left"

"Shifting left" means moving practices that were traditionally done late in the development cycle (like testing, security, and performance analysis) to as early in the process as possible. For example, instead of a security team reviewing the code right before release, developers are given automated security scanning tools to run on their own machines. This makes quality and security a shared responsibility and catches problems earlier when they are cheaper and easier to fix.

### CI/CD: The Engine of DevOps

-   **Continuous Integration (CI)**: The practice of developers merging their code changes into a central repository frequently (multiple times a day). Each merge automatically triggers a build and the execution of the test suite.
-   **Continuous Delivery (CD)**: An extension of CI. It's the practice of automatically deploying every change that passes the tests to a testing or "staging" environment. The goal is to have a codebase that is *always* in a deployable state.
-   **Continuous Deployment (CD)**: The final step. Every change that passes all the automated tests is automatically deployed to **production**. This requires a high degree of confidence in your automated test suite.

---

## 5. Deliberate Practice

1.  **"Silo" Discussion**: Think about a group project you've worked on (in school or at work). Were there "silos"? Was there a "handoff" from one person to another? How could that process have been more collaborative?
2.  **Identify Automation Opportunities**: Look at your personal development workflow. What manual steps do you repeat frequently? (e.g., manually running tests, manually deploying your project). How could you automate them?
3.  **Blameless Postmortem**: Think of a time a project or a piece of code failed. Write a "blameless postmortem". Focus not on *who* made the mistake, but on *what* in the process allowed the mistake to happen, and what could be changed to prevent it from happening again.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that DevOps is a cultural shift aimed at breaking down silos between Dev and Ops.
-   [ ] I can name the five pillars of the C.A.L.M.S. framework.
-   [ ] I can define Continuous Integration as the practice of frequently merging code and running automated tests.
-   [ ] I can differentiate between Continuous Delivery (deploying to a staging environment) and Continuous Deployment (deploying to production).
-   [ ] I can explain that "shifting left" means moving testing and security earlier in the development process.

---

## 13. Research and References

-   **"The Phoenix Project: A Novel About IT, DevOps, and Helping Your Business Win" by Gene Kim, Kevin Behr, and George Spafford**: The essential, foundational book for understanding the "why" of DevOps, told in the form of an engaging novel.
-   **"The DevOps Handbook" by Gene Kim et al.**: The practical guide that complements "The Phoenix Project".
-   **Google's DevOps Research and Assessment (DORA)**: Google's research group that studies the practices of high-performing technology organizations. Their findings are a great resource.
-   **Atlassian DevOps Guides**: A great collection of articles explaining DevOps concepts.
