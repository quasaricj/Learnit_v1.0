# Monitoring, Logging, and Alerting

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** monitoring, logging, and alerting and explain how they work together.
-   **Differentiate** between the "three pillars of observability": logs, metrics, and traces.
-   **Instrument** your application to emit structured logs.
-   **Identify** key metrics to monitor for a web application (e.g., latency, error rate, CPU utilization).
-   **Describe** the purpose of an alerting system.
-   **Understand** the value of dashboards for visualizing application health.
-   **Explain** how feedback from production monitoring is used to improve the development process.

---

## 2. Introduction to Observability

Once your application is deployed to production, how do you know if it's working correctly? How do you debug problems when they occur? **Observability** is the practice of instrumenting your application to provide data about its internal state, allowing you to understand and explain its behavior. It is a critical part of the DevOps feedback loop.

The three main components of observability are often called the "three pillars": Logs, Metrics, and Traces.

---

## 3. The Three Pillars of Observability

### 1. Logging

-   **What it is**: A **log** is a timestamped, immutable record of a discrete event that happened over time. You write logs from your application to record important events.
-   **Analogy**: A captain's log on a ship, recording every significant event.
-   **Best for**: Investigating the behavior of a single, specific request or user. It's the primary tool for **debugging** in production.
-   **Structured Logging**: Don't just log plain text strings. Log structured data (like JSON). This makes your logs searchable and analyzable by a log aggregation platform.
    -   *Bad*: `log.info("User logged in")`
    -   *Good*: `log.info({ "event": "user_login", "userId": 123, "ipAddress": "..." })`
-   **Tools**: Logs from multiple servers are shipped to a central location for analysis. Popular tools include the **ELK Stack** (Elasticsearch, Logstash, Kibana) and services like Splunk or Datadog.

### 2. Metrics

-   **What it is**: A **metric** is a numerical representation of data measured over intervals of time. Metrics are aggregated and summarized.
-   **Analogy**: The speedometer and temperature gauge in your car. They give you a high-level, real-time overview of the system's health.
-   **Best for**: **Monitoring** the overall health of your system. They are what you put on dashboards.
-   **The Four Golden Signals** (a set of key metrics defined by Google):
    1.  **Latency**: The time it takes to serve a request.
    2.  **Traffic**: The demand being placed on your system (e.g., requests per second).
    3.  **Errors**: The rate of requests that are failing.
    4.  **Saturation**: How "full" your service is (e.g., CPU, memory, disk space).
-   **Tools**: A time-series database is used to store and query metrics. **Prometheus** is the most popular open-source monitoring system, often paired with **Grafana** for building dashboards.

### 3. (Distributed) Tracing

-   **What it is**: A **trace** represents the end-to-end journey of a single request as it flows through a complex, distributed system (e.g., a microservices architecture).
-   **Analogy**: Tracking a package from the warehouse to your door, showing every stop it made along the way.
-   **Best for**: Pinpointing bottlenecks and understanding performance issues in a microservices environment.
-   **How it works**: Each service in the chain adds a "span" to the trace with timing information. These spans are collected and visualized as a timeline or a flame graph.
-   **Tools**: OpenTelemetry is the emerging open-source standard for tracing. Jaeger and Zipkin are popular open-source tracing systems.

### 4. Alerting

-   **What it is**: An **alert** is an automated notification that is triggered when a metric crosses a predefined threshold (e.g., "the API error rate has been above 5% for the last 10 minutes").
-   **The Goal**: To notify the on-call engineers that there is a problem that requires human intervention.
-   **Best Practices**:
    -   Alerts should be **actionable**. If you get an alert, you should know what to do about it.
    -   Avoid "flappy" alerts or alerts that are not important. This leads to "alert fatigue," where engineers start to ignore the notifications.
-   **Tools**: Alerting is usually a feature of a monitoring system like Prometheus (via its Alertmanager component) or a service like Datadog.

---

## 4. Deliberate Practice

1.  **Add Structured Logging**: In one of your backend projects, replace any simple `console.log` or `print` statements with a proper logging library (like `Winston` for Node.js or `Loguru` for Python). Add structured context to your log messages (e.g., the user ID).
2.  **Explore Grafana**: Check out the public, live demo of Grafana dashboards at [play.grafana.org](https://play.grafana.org/). Explore the different types of visualizations and imagine how you would use them to monitor a web application.
3.  **Design a Dashboard**: On paper, sketch out a dashboard for your e-commerce project. What are the 5-10 most important metrics you would want to see at a glance to know if the system is healthy?

---

## 12. Summary and Mastery Checklist

-   [ ] I can define the "three pillars of observability": logs, metrics, and traces.
-   [ ] I know that **logs** are for debugging specific events.
-   [ ] I know that **metrics** are for monitoring overall system health on dashboards.
-   [ ] I know that **traces** are for understanding request flows in a distributed system.
-   [ ] I can explain that **alerting** is the process of automatically notifying engineers of a problem.
-   [ ] I understand the importance of using structured (JSON) logging.

---

## 13. Research and References

-   **"The Three Pillars of Observability"**: A classic blog post on the topic.
-   **Grafana Labs - "What is monitoring?"**: A good introduction.
-   **Prometheus Documentation**: [Link](https://prometheus.io/docs/introduction/overview/)
-   **OpenTelemetry**: The open-source standard for observability. [Link](https://opentelemetry.io/)
-   **"Site Reliability Engineering" (the "SRE Book") by Google**: The definitive book on running large-scale, reliable systems. It has excellent chapters on monitoring and alerting. Available free online.
