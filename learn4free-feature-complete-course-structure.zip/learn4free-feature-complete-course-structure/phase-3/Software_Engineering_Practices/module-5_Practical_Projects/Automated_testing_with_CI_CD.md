# Practical Project: Set Up a Complete CI/CD Pipeline

## 1. Project Goal

To take a web application project (such as the blog or e-commerce site from Phase 2) and build a complete Continuous Integration and Continuous Delivery (CI/CD) pipeline for it. This project will be a hands-on implementation of all the theoretical DevOps concepts from this phase, creating an automated workflow from a `git push` all the way to a deployed application.

---

## 2. Learning Objectives (Project-Based)

-   **CI/CD Implementation**: Use a platform like GitHub Actions to create a multi-stage pipeline.
-   **Automated Testing**: Configure the pipeline to automatically run your linting, unit tests, and integration tests on every commit.
-   **Code Quality Gates**: Implement quality gates such as code coverage checks to enforce testing standards.
-   **Build and Package**: Create a production-ready artifact from your application (e.g., a bundled set of frontend assets, or a Docker container for the backend).
-   **Deployment Automation**: Write a script to automatically deploy your application to a hosting service.
-   **Team Collaboration**: Use the CI pipeline as a collaboration tool within the Pull Request workflow.

---

## 3. Core Requirements

Choose one of your full-stack projects from Phase 2 to work with.

### Part 1: Continuous Integration (CI) Pipeline

Create a CI pipeline (e.g., a GitHub Actions workflow) that is triggered on every push to a Pull Request. This pipeline must perform the following stages:

1.  **Checkout Code**: Checks out the latest commit.
2.  **Install Dependencies**: Installs all necessary packages for both the frontend and backend.
3.  **Lint**: Runs a linter on your entire codebase. The pipeline must fail if the linter finds errors.
4.  **Run Backend Tests**: Executes all the unit and integration tests for your backend API.
    -   **Code Coverage**: Configure this stage to generate a code coverage report. You can optionally add a step that fails the build if coverage drops below a certain threshold (e.g., 70%).
5.  **Run Frontend Tests**: Executes all the unit tests for your frontend components.
6.  **Build**: If all tests pass, run the production build process for your frontend and/or backend.

### Part 2: Continuous Delivery (CD) Pipeline

Extend your pipeline so that when a Pull Request is merged into the `main` branch, it automatically deploys the new version of the application.

1.  **Trigger**: The CD workflow should only run on pushes to the `main` branch.
2.  **Build and Package**: Re-run the build steps from the CI pipeline to create a production artifact. A great extension here is to build a **Docker container**.
3.  **Deploy**: Write a script that deploys this artifact to a cloud hosting provider.
    -   **For the Frontend**: Deploy the static build assets to a service like Netlify, Vercel, or AWS S3.
    -   **For the Backend**: Deploy the application (or its Docker container) to a service like Heroku, Railway, or AWS Elastic Beanstalk.

---

## 4. Step-by-Step Implementation Guide

1.  **Ensure You Have Tests**: Your project must have an automated test suite. If it doesn't, go back and write some unit tests for both your frontend and backend. The pipeline is useless without them.
2.  **Choose a Platform**: **GitHub Actions** is recommended as it's integrated directly into your repository.
3.  **Create the CI Workflow File**:
    -   In your repository, create the `.github/workflows` directory.
    -   Create a YAML file like `ci.yml`.
    -   Define the `on: [pull_request]` trigger.
    -   Add jobs for your backend and frontend. Within each job, add the `steps` for checking out code, installing dependencies, linting, and running tests.
4.  **Test the CI Pipeline**:
    -   Push your new workflow file.
    -   Create a new branch, make a small change, and open a Pull Request.
    -   Go to the "Checks" section of the PR on GitHub to watch your pipeline run. Debug any issues in the YAML file.
    -   Intentionally push a change that breaks a test to see the pipeline fail.
5.  **Create the CD Workflow File**:
    -   Create a new workflow file, `cd.yml`.
    -   Set the trigger to `on: push: branches: [main]`.
    -   Copy the build and test stages from your CI pipeline.
    -   Choose a hosting provider for your frontend and backend. Most providers have excellent tutorials on how to deploy from GitHub Actions. You will typically need to add a "secret" (like an API token) to your GitHub repository's settings to allow the pipeline to authenticate with the hosting provider.
    -   Add the deployment step to your YAML file using the provider's recommended Action or script.
6.  **Merge and Deploy**: Merge your PR into `main` and watch the "Actions" tab. If everything is configured correctly, your CD pipeline will trigger and your application will be deployed to the internet.

---

## 5. Other Related Projects

The other files in this module represent smaller, related tasks.

-   **Team Collaboration on an Open Source Project**:
    -   **Goal**: Practice the full collaborative workflow on a real project.
    -   **Task**: Find an open-source project on GitHub that is beginner-friendly. Find a small bug or a typo in their documentation. Fork the repository, create a branch, fix the issue, and submit a high-quality Pull Request. Engage with the maintainers in the code review process.
-   **Bug Tracking System**:
    -   **Goal**: Understand the process of formal bug reporting.
    -   **Task**: Use the "Issues" tab on GitHub for your own project. When you find a bug, don't just fix it. First, write a good bug report using the issue template. Describe the bug, the steps to reproduce it, and the expected behavior. Then, create a branch and a PR that references that issue number.

---

## 13. Research and References

-   **GitHub Actions Quickstart**: [Link](https://docs.github.com/en/actions/quickstart)
-   **"Patterns for CI/CD"**: A talk by Sam Guckenheimer.
-   **Hosting Provider Documentation**: The deployment guides from providers like Netlify, Vercel, and Heroku are your best resource for the final deployment step.
