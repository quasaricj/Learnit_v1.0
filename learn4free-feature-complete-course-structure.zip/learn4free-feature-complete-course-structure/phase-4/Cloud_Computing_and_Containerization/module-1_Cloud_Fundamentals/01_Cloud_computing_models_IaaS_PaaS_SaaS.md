# Cloud Computing Models: IaaS, PaaS, SaaS

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** cloud computing.
- **Explain** the key benefits of cloud computing (e.g., cost, scalability, reliability).
- **Define and differentiate** between the three main cloud service models: IaaS, PaaS, and SaaS.
- **Provide** a real-world example of each service model.
- **Understand** the "shared responsibility model" for security in the cloud.

---

## 2. Introduction to Cloud Computing

**Cloud computing** is the on-demand delivery of IT resources over the internet with pay-as-you-go pricing. Instead of buying, owning, and maintaining your own physical data centers and servers, you can access technology services, such as computing power, storage, and databases, from a cloud provider like Amazon Web Services (AWS), Microsoft Azure, or Google Cloud.

### Key Benefits of the Cloud

- **Agility**: The cloud allows you to spin up new resources in minutes, enabling you to innovate and experiment much faster.
- **Elasticity and Scalability**: You can "scale up" or "scale out" your resources to meet demand, and then scale back down when the demand subsides.
- **Cost Savings**: The cloud allows you to trade capital expense (buying hardware) for variable expense (paying only for what you use).
- **Global Reach**: You can easily deploy your application in multiple geographic regions around the world with just a few clicks.
- **Reliability and Performance**: Cloud providers have massive, redundant infrastructure, which provides a level of reliability that is very difficult and expensive for a single company to achieve on its own.

---

## 3. The Three Main Service Models

The service models are often explained using the "Pizza as a Service" analogy. They define the level of abstraction and management that the cloud provider offers.

### 1. IaaS (Infrastructure as a Service)

- **What it is**: The most basic category of cloud computing services. IaaS provides you with the fundamental building blocks of computing infrastructure: virtual servers, storage, and networking. It's the closest to a traditional, on-premises data center.
- **You manage**: The operating system, middleware, runtime, and the application itself.
- **The provider manages**: The physical servers, storage, and networking hardware.
- **Analogy**: **Take and Bake Pizza**. The pizza place provides you with the raw ingredients and the oven (the infrastructure), but you are responsible for assembling, baking, and serving the pizza.
- **Examples**:
  - **AWS**: EC2 (Elastic Compute Cloud) - virtual servers.
  - **Azure**: Virtual Machines.
  - **Google Cloud**: Compute Engine.

### 2. PaaS (Platform as a Service)

- **What it is**: PaaS provides a platform that allows you to build, run, and manage applications without the complexity of building and maintaining the underlying infrastructure. The cloud provider manages the operating system, the runtime (e.g., the Node.js or Java runtime), and the database.
- **You manage**: The application code and data.
- **The provider manages**: Everything that IaaS manages, plus the OS, middleware, and runtime.
- **Analogy**: **Pizza Delivery**. You just order the pizza you want. The pizza place handles all the infrastructure and preparation. You just have to serve it.
- **Examples**:
  - **AWS**: Elastic Beanstalk.
  - **Azure**: App Service.
  - **Heroku**: A very popular PaaS provider.

### 3. SaaS (Software as a Service)

- **What it is**: SaaS provides you with a completed software product that is run and managed by the service provider. You simply use the software over the internet, usually with a subscription.
- **You manage**: Nothing. You just use the software.
- **The provider manages**: The entire stack, from the hardware to the application code.
- **Analogy**: **Dining Out at a Pizzeria**. You don't have to do anything except show up and eat the pizza. Everything is handled for you.
- **Examples**:
  - Google Workspace (Gmail, Google Docs).
  - Microsoft Office 365.
  - Salesforce.
  - Dropbox.

### The Shared Responsibility Model

Security in the cloud is a shared responsibility.
- The **cloud provider** is responsible for the security **of** the cloud (the physical infrastructure).
- You, the **customer**, are responsible for security **in** the cloud (how you configure your services, manage user access, and secure your application code).
The level of your responsibility depends on the service model. With IaaS, you have more responsibility (e.g., patching the operating system) than with PaaS.

---

## 4. Summary and Mastery Checklist

-   [ ] I can explain that cloud computing is the on-demand delivery of IT resources over the internet.
-   [ ] I can list a key benefit of the cloud, such as cost savings or scalability.
-   [ ] I can define **IaaS** as providing the basic building blocks (virtual servers, storage).
-   [ ] I can define **PaaS** as providing a platform to run your application without managing the servers.
-   [ ] I can define **SaaS** as a complete software product delivered over the internet.
-   [ ] I can give a real-world example of each model (e.g., AWS EC2 for IaaS, Heroku for PaaS, Gmail for SaaS).

---

## 5. Research and References

-   **AWS - What is Cloud Computing?**: [Link](https://aws.amazon.com/what-is-cloud-computing/)
-   **Azure - What are IaaS, PaaS, and SaaS?**: [Link](https://azure.microsoft.com/en-us/resources/cloud-computing-dictionary/what-are-iaas-paas-saas/)
-   **"The NIST Definition of Cloud Computing"**: The formal, academic definition.
-   **"Cloud Computing For Dummies" by Judith S. Hurwitz, Robin Bloor, Marcia Kaufman, and Fern Halper**: A good introductory book.
