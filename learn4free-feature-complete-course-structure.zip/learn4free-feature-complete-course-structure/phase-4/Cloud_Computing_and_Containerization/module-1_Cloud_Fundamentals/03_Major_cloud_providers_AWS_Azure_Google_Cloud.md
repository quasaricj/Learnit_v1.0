# Major Cloud Providers: AWS, Azure, Google Cloud

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Identify** the "big three" public cloud providers.
- **Describe** the key characteristics and market position of Amazon Web Services (AWS).
- **Describe** the key characteristics and market position of Microsoft Azure.
- **Describe** the key characteristics and market position of Google Cloud Platform (GCP).
- **Recognize** the names of the core IaaS services (compute, storage, networking) for each provider.
- **Understand** that while the names are different, the core services offered by all providers are conceptually very similar.

---

## 2. Introduction to the Cloud Market

The public cloud market is dominated by three major players, often referred to as the "big three" hyperscalers. While there are other smaller and more specialized cloud providers, AWS, Azure, and GCP account for the vast majority of the market share. Each has its own strengths and is a viable choice for building modern applications.

---

## 3. Amazon Web Services (AWS)

- **History**: Launched in 2006, AWS was the first major player in the public cloud space and is the undisputed market leader. It has the most extensive global infrastructure and the broadest and deepest set of services.
- **Market Position**: The dominant leader in terms of market share. It is used by a huge number of startups and enterprises alike.
- **Strengths**:
  - **Maturity and Reliability**: The longest track record and a reputation for being very reliable.
  - **Breadth of Services**: Offers over 200 fully-featured services, far more than any other provider. If you can think of a service, AWS probably has it.
  - **Strong Community and Ecosystem**: A massive community, extensive documentation, and a huge number of third-party tools and integrations.

- **Core Services (IaaS)**:
  - **Compute**: **EC2 (Elastic Compute Cloud)** - Virtual Servers.
  - **Storage**: **S3 (Simple Storage Service)** - Object Storage.
  - **Networking**: **VPC (Virtual Private Cloud)** - Isolated cloud networks.
  - **Database**: **RDS (Relational Database Service)**, **DynamoDB** (NoSQL).

---

## 4. Microsoft Azure

- **History**: Launched in 2010, Azure is Microsoft's cloud platform and the second-largest player in the market. It has grown rapidly, leveraging Microsoft's strong position in the enterprise software market.
- **Market Position**: The clear number two, and the fastest growing of the big three.
- **Strengths**:
  - **Enterprise and Windows Integration**: The top choice for large enterprises that are already heavily invested in Microsoft products (Windows Server, Office 365, etc.). It offers excellent hybrid cloud capabilities.
  - **Strong PaaS Offerings**: Azure's Platform as a Service (PaaS) offerings, like App Service, are very strong and easy to use.
  - **.NET Ecosystem**: The best cloud for running .NET and Windows-based workloads.

- **Core Services (IaaS)**:
  - **Compute**: **Azure Virtual Machines**.
  - **Storage**: **Azure Blob Storage**.
  - **Networking**: **Azure Virtual Network**.
  - **Database**: **Azure SQL Database**, **Cosmos DB** (NoSQL).

---

## 5. Google Cloud Platform (GCP)

- **History**: Google has been running its own massive cloud infrastructure for years to power its own services (Search, YouTube, Gmail). GCP is the commercial offering of that infrastructure, launched in 2008.
- **Market Position**: A strong number three, but with a smaller market share than AWS and Azure.
- **Strengths**:
  - **Expertise in Data and AI**: GCP is widely considered to have the best services in the areas of data analytics, machine learning (AI/ML), and container orchestration (Google originally created Kubernetes).
  - **Networking**: Google's global network is considered by many to be the best and most performant of the three.
  - **Open Source Focus**: Deep expertise and strong commitment to open-source technologies like Kubernetes.

- **Core Services (IaaS)**:
  - **Compute**: **Google Compute Engine**.
  - **Storage**: **Google Cloud Storage**.
  - **Networking**: **Google Virtual Private Cloud**.
  - **Database**: **Cloud SQL**, **Bigtable** / **Spanner** (NoSQL).

---

## 6. Which one to choose?

For a developer, the skills you learn on one cloud are highly transferable to the others. The core concepts of virtual machines, object storage, and managed databases are the same everywhere; only the names and the specific APIs are different.

- **AWS** is the safe bet with the largest community and the most job opportunities.
- **Azure** is a great choice if you are working in a large enterprise or in the .NET ecosystem.
- **GCP** is an excellent choice if your application is heavily focused on data analytics, AI/ML, or Kubernetes.

The best way to learn is to pick one and start building.

---

## 7. Summary and Mastery Checklist

-   [ ] I can name the "big three" public cloud providers: AWS, Azure, and GCP.
-   [ ] I know that **AWS** is the market leader and has the broadest set of services.
-   [ ] I know that **Azure** is strong in the enterprise and for Windows-based workloads.
-   [ ] I know that **GCP** is strong in data analytics, AI/ML, and Kubernetes.
-   [ ] For at least one provider, I can name their core virtual machine service (e.g., EC2 for AWS).
-   [ ] I understand that the fundamental concepts are the same across all three providers.

---

## 8. Research and References

-   **AWS in Plain English**: A helpful guide that explains AWS services in simple terms. [Link](https://www.expeditedssl.com/aws-in-plain-english)
-   **Azure in Plain English**: A similar guide for Azure services.
-   **Gartner Magic Quadrant for Cloud Infrastructure**: An annual report from the industry analyst firm Gartner that compares the major cloud providers.
-   **A Cloud Guru / Pluralsight / Coursera**: All of these platforms offer excellent, in-depth training courses for all three major clouds.
