# Virtual Machines and Compute Instances

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a Virtual Machine (VM) and explain its purpose.
- **Describe** the role of a hypervisor in virtualization.
- **Explain** how cloud providers use virtualization to offer IaaS compute services.
- **Recognize** the names of the core VM services for the major cloud providers (EC2, Azure VMs, Compute Engine).
- **Understand** the key configuration options for a cloud VM (e.g., instance type, storage, networking).
- **Connect** to a cloud VM using SSH.

---

## 2. Introduction to Virtualization and VMs

**Virtualization** is the technology that allows you to create a virtual representation of a physical computer. A **Virtual Machine (VM)** is a software-based emulation of a physical computer. It has a virtual CPU, memory, hard drive, and network interface, and it runs a full copy of an operating system (like Linux or Windows).

The software that creates and runs VMs is called a **hypervisor**. The hypervisor runs on a physical "host" machine and allocates a portion of the host's physical resources (CPU, RAM, storage) to each "guest" VM.

Virtualization is the fundamental technology that underpins all modern cloud computing.

---

## 3. Cloud Compute Services (IaaS)

Cloud compute services are the IaaS offering that provides you with virtual machines on demand. These are the workhorses of the cloud, allowing you to run any application you could run on a physical server.

### Major Compute Services

- **AWS**: **EC2 (Elastic Compute Cloud)**
- **Azure**: **Azure Virtual Machines**
- **Google Cloud**: **Google Compute Engine**

### Key Configuration Options

When you launch a new VM in the cloud, you have to make several configuration choices:

1.  **Region and Availability Zone (AZ)**:
    - **Region**: A geographic area in the world where the cloud provider has data centers (e.g., `us-east-1` in North Virginia).
    - **Availability Zone**: An isolated data center within a region. For high availability, you should run your application across multiple AZs.

2.  **Amazon Machine Image (AMI) or Image**:
    - A pre-configured template for your VM. It contains the operating system (e.g., Ubuntu, Windows Server) and may also include pre-installed software.

3.  **Instance Type (or VM Size)**:
    - This determines the hardware resources allocated to your VM:
      - The number of virtual CPUs (vCPUs).
      - The amount of memory (RAM).
      - The type and speed of the attached storage.
      - The networking performance.
    - Cloud providers offer a huge variety of instance types, optimized for different workloads (e.g., general-purpose, compute-optimized, memory-optimized).

4.  **Storage**:
    - You attach a virtual hard drive to your VM. This is a **block storage** volume (e.g., AWS EBS). You can choose the size and the performance characteristics (e.g., SSD vs. HDD).

5.  **Networking**:
    - You launch the VM into a **Virtual Private Cloud (VPC)**, which is your own logically isolated section of the cloud provider's network.
    - You can configure firewall rules (called **Security Groups** in AWS) to control what network traffic is allowed to and from your VM.

### Connecting to a Cloud VM

- For a **Linux** VM, you connect to it securely over the internet using the **SSH (Secure Shell)** protocol. You authenticate using a cryptographic key pair instead of a password.
- For a **Windows** VM, you typically connect using the **RDP (Remote Desktop Protocol)**.

---

## 4. When to Use VMs

Virtual machines are the most flexible of all cloud computing models. You have full control over the operating system and can install any software you want.

**Use Cases**:
- **Lifting and Shifting**: Moving an existing application from an on-premises data center to the cloud without redesigning it.
- **Running legacy applications** that are not designed for the cloud.
- **Applications that require a specific OS or custom configuration**.
- **Hosting a traditional relational database** (like MySQL or PostgreSQL) that you manage yourself.

However, this flexibility comes at a cost. With a VM, **you are responsible** for managing everything from the operating system up: patching the OS, installing security updates, and configuring all your software. This can be a significant operational burden, which is why PaaS and serverless models are often preferred for new, cloud-native applications.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define a Virtual Machine as a software emulation of a physical computer.
-   [ ] I know that the software that runs VMs is called a hypervisor.
-   [ ] I can name the core VM service for AWS (**EC2**).
-   [ ] I can list at least two key configuration options for a VM (e.g., instance type, storage).
-   [ ] I know that I must configure firewall rules (**Security Groups**) to allow network traffic to my VM.
-   [ ] I know that I connect to a Linux VM using **SSH**.
-   [ ] I understand that with a VM, I am responsible for managing and patching the operating system.

---

## 6. Research and References

-   **AWS EC2 Documentation**: [Link](https://aws.amazon.com/ec2/)
-   **Azure Virtual Machines Documentation**: [Link](https://azure.microsoft.com/en-us/services/virtual-machines/)
-   **"What is a Virtual Machine?"**: A good overview from a major provider.
-   **SSH Essentials**: A tutorial on how to use SSH.
