# Cloud Service Models: IaaS, PaaS, SaaS

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** cloud computing.
-   **Explain** the difference between on-premise infrastructure and cloud infrastructure.
-   **Define and differentiate** between the three main cloud service models: Infrastructure as a Service (IaaS), Platform as a Service (PaaS), and Software as a Service (SaaS).
-   **Provide** examples of services for each model.
-   **Analyze** a business need and recommend the appropriate service model.
-   **Understand** the "shared responsibility" model for security in the cloud.

---

## 2. Introduction to Cloud Computing

**Cloud computing** is the on-demand delivery of IT resources over the Internet with pay-as-you-go pricing. Instead of buying, owning, and maintaining your own physical data centers and servers, you can access technology services, such as computing power, storage, and databases, from a cloud provider like Amazon Web Services (AWS), Microsoft Azure, or Google Cloud.

This shifts the IT model from a **Capital Expenditure (CapEx)** model, where you invest heavily in physical infrastructure upfront, to an **Operational Expenditure (OpEx)** model, where you pay for what you use.

---

## 3. The Three Main Service Models

The service models are often explained with the "Pizza as a Service" analogy. They represent different levels of abstraction and management provided by the cloud vendor.

### 1. Infrastructure as a Service (IaaS)

-   **What it is**: IaaS provides the fundamental building blocks of computing infrastructure. The cloud provider manages the physical hardware (servers, storage, networking), but you are responsible for managing everything else, including the operating system, middleware, and your application code.
-   **Analogy (Take and Bake Pizza)**: The pizza place provides you with the raw ingredients and the oven (the infrastructure), but you have to assemble the pizza, cook it, and serve it yourself.
-   **Key Features**:
    -   Maximum flexibility and control.
    -   You rent IT infrastructure.
    -   You are responsible for patching and maintaining the OS.
-   **Examples**:
    -   **AWS**: Elastic Compute Cloud (EC2) - Virtual Servers
    -   **Azure**: Virtual Machines
    -   **Google Cloud**: Compute Engine

### 2. Platform as a Service (PaaS)

-   **What it is**: PaaS provides a platform that allows you to build, run, and manage applications without the complexity of building and maintaining the underlying infrastructure. The cloud provider manages the hardware, the operating system, and the runtime environment. You just manage your application code and data.
-   **Analogy (Pizza Delivery)**: You order a pizza. The pizza place handles making the pizza and cooking it. You just have to provide the table and drinks and serve it.
-   **Key Features**:
    -   Focus on application development, not infrastructure management.
    -   Faster time-to-market.
    -   The provider handles OS patching, scaling, and runtime updates.
-   **Examples**:
    -   **Heroku**: A classic PaaS that makes it incredibly easy to deploy web applications.
    -   **AWS Elastic Beanstalk**, **Azure App Service**, **Google App Engine**.
    -   Serverless computing platforms like **AWS Lambda** and **Azure Functions** are an evolution of PaaS.

### 3. Software as a Service (SaaS)

-   **What it is**: SaaS provides you with a completed software product that is run and managed by the service provider. You don't have to worry about the infrastructure or the application code; you just use the software, typically through a web browser.
-   **Analogy (Dining Out at a Restaurant)**: You go to a restaurant and order a pizza. Everything is handled for you: the ingredients, the cooking, the serving, and the cleanup. You just eat the pizza.
-   **Key Features**:
    -   No infrastructure or application management.
    -   Accessed via the internet.
    -   Typically sold on a subscription basis.
-   **Examples**:
    -   **Google Workspace** (Gmail, Google Docs)
    -   **Microsoft Office 365**
    -   **Salesforce**
    -   **Dropbox**

---

## 4. Shared Responsibility Model

Security in the cloud is a shared responsibility. The level of responsibility depends on the service model.

-   **IaaS**: The cloud provider is responsible for the security *of* the cloud (the physical infrastructure). You are responsible for security *in* the cloud (securing your operating system, network configuration, and application).
-   **PaaS**: The provider's responsibility extends to securing the operating system and runtime. You are still responsible for your application's security and data.
-   **SaaS**: The provider is responsible for securing almost everything. Your responsibility is primarily to manage your users and their access rights.

![Shared Responsibility Model Diagram](https://d1.awsstatic.com/security-center/Shared_Responsibility_Model_V2.59d43c273292138c22f225016194a20b77209c21.png)

---

## 5. Deliberate Practice

**Scenario Analysis**: For each of the following scenarios, which cloud service model would be the best fit and why?

1.  A startup wants to quickly deploy a standard web application written in Node.js. They have a small team and want to focus on writing code, not managing servers.
2.  A large enterprise needs to migrate its existing, complex on-premise application to the cloud. They need fine-grained control over the network configuration and operating system to match their current setup.
3.  A small business needs a customer relationship management (CRM) system to track its sales leads. They don't have a development team.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that cloud computing is the on-demand delivery of IT resources over the internet.
-   [ ] **IaaS**: I can describe this as providing the basic building blocks (virtual machines) where I manage the OS.
-   [ ] **PaaS**: I can describe this as a platform where I manage my application code and the provider manages the OS and runtime.
-   [ ] **SaaS**: I can describe this as a complete software product that I use over the internet.
-   [ ] I can provide a real-world example service for each of the three models.
-   [ ] I understand that as you move from IaaS to PaaS to SaaS, you gain convenience but give up control.

---

## 13. Research and References

-   **AWS - What is Cloud Computing?**: [Link](https://aws.amazon.com/what-is-cloud-computing/)
-   **Azure - What are IaaS, PaaS, and SaaS?**: [Link](https://azure.microsoft.com/en-us/overview/what-is-iaas-paas-saas/)
-   **"Pizza as a Service"**: The classic, widely-used analogy for explaining the service models.
