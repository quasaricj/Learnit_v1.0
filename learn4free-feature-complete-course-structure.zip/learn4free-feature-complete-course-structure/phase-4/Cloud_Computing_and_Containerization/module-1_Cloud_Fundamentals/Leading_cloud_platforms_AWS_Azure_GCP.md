# Leading Cloud Platforms: AWS, Azure, and GCP

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Identify** the three major global cloud providers: AWS, Microsoft Azure, and Google Cloud Platform (GCP).
-   **Describe** the core compute service for each platform (EC2, Azure VMs, Compute Engine).
-   **Describe** the core object storage service for each platform (S3, Azure Blob Storage, Google Cloud Storage).
-   **Explain** the concept of a "region" and an "availability zone" (AZ).
-   **Understand** the high-level strengths and weaknesses of each platform.
-   **Navigate** the web console of at least one cloud provider and identify the core services.

---

## 2. Introduction to the Cloud Giants

While there are many cloud providers, the market is dominated by three major players, often called the "hyperscalers". Understanding their core services is fundamental to modern cloud computing, as most other cloud services are built on top of these basic building blocks.

1.  **Amazon Web Services (AWS)**: The oldest and most dominant player. Launched in 2006, it has the largest market share and the most extensive portfolio of services.
2.  **Microsoft Azure**: The second-largest player. It is very popular in the enterprise space, especially with companies that already have a significant investment in Microsoft products.
3.  **Google Cloud Platform (GCP)**: The third-largest player. It is known for its strengths in networking, data analytics, machine learning, and containerization (it created Kubernetes).

---

## 3. Core IaaS Services: Compute and Storage

### Virtual Machines (The Core Compute Service)

This is the quintessential **IaaS** offering. A virtual machine (VM) is an emulation of a physical computer that you can rent from the cloud provider. You choose the OS, CPU, RAM, and storage, and you have full control over it.

-   **AWS**: **Elastic Compute Cloud (EC2)**
-   **Azure**: **Azure Virtual Machines**
-   **GCP**: **Compute Engine**

**Use Cases**:
-   Running a traditional web server (like Apache or Nginx).
-   Hosting a database.
-   Migrating an existing on-premise application to the cloud.
-   Running any software that requires a full operating system.

### Object Storage

Object storage is a technology that manages data as "objects," as opposed to a file system's hierarchy. Each object consists of the data itself, a variable amount of metadata, and a globally unique identifier.

-   **Key Features**:
    -   Massively scalable (virtually infinite storage).
    -   Highly durable and available (data is typically replicated across multiple physical locations).
    -   Accessed via an API over HTTP.
    -   "Pay-for-what-you-use" pricing.
-   **AWS**: **Simple Storage Service (S3)**
-   **Azure**: **Azure Blob Storage**
-   **GCP**: **Google Cloud Storage**

**Use Cases**:
-   Storing and serving static website assets (images, CSS, JavaScript).
-   Storing user-generated content (e.g., photos for an Instagram clone).
-   Backup and disaster recovery.
-   Data lakes for big data analytics.

---

## 4. Global Infrastructure: Regions and Availability Zones

-   **Region**: A physical location in the world where a cloud provider has a cluster of data centers. Examples: `us-east-1` (Northern Virginia), `eu-west-2` (London). You choose a region to host your services, usually one that is geographically close to your users to reduce latency.
-   **Availability Zone (AZ)**: An AZ is one or more discrete data centers with redundant power, networking, and cooling, housed in separate facilities within a Region.
-   **High Availability**: By deploying your application across **multiple AZs** within a region, you can protect it from the failure of a single data center. If one AZ goes down, your application can continue to run in the others. This is a fundamental principle of cloud architecture.

---

## 5. Deliberate Practice

1.  **Create a Free Tier Account**: Sign up for a free tier account with one of the major cloud providers (AWS is a great place to start).
2.  **Launch a Virtual Machine**: Follow a "getting started" tutorial to launch a small Linux (e.g., Ubuntu) virtual machine (an EC2 instance in AWS).
    -   Connect to your VM using SSH.
    -   Run a simple command like `ls` or `uname -a`.
    -   **Important**: Remember to **stop or terminate** your instance after you are done to avoid unexpected charges.
3.  **Use Object Storage**:
    -   Create an S3 bucket (in AWS).
    -   Upload a simple `index.html` file to your bucket.
    -   Configure the bucket for public access and enable static website hosting.
    -   Access your simple website using the public URL provided by the cloud provider.

---

## 12. Summary and Mastery Checklist

-   [ ] I can name the "big three" cloud providers (AWS, Azure, GCP).
-   [ ] I can explain that a virtual machine (like an AWS EC2 instance) is a rentable server in the cloud that I can control.
-   [ ] I can explain that object storage (like AWS S3) is a highly scalable service for storing files and static assets.
-   [ ] I can define a "Region" as a geographical location and an "Availability Zone" as a set of data centers within that region.
-   [ ] I understand that deploying an application across multiple AZs is a key strategy for high availability.

---

## 13. Research and References

-   **AWS in 10 Minutes**: A video that gives a high-level overview of the core AWS services.
-   **Azure Fundamentals**: Microsoft's official learning path for Azure basics.
-   **Google Cloud Fundamentals**: Google's official learning path for GCP basics.
-   **"Cloud Computing For Dummies" by Judith Hurwitz, Robin Bloor, et al.**: A good, high-level introductory book.
