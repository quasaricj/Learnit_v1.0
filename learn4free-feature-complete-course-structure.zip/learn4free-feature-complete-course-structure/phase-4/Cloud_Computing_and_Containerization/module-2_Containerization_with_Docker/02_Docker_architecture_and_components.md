# Docker Architecture and Components

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Describe** the client-server architecture of Docker.
- **Define** the three main components of the Docker platform: the Docker Daemon, the Docker Client, and the Docker Registry.
- **Explain** the relationship between a Docker Image and a Docker Container.
- **Differentiate** between the `docker build` command and the `docker run` command.
- **Understand** the basic workflow of building an image and running a container.

---

## 2. Docker's Client-Server Architecture

Docker uses a client-server architecture.

1.  **Docker Daemon (`dockerd`)**:
    - This is the Docker server. It is a long-running background process that is responsible for building, running, and managing Docker objects (images, containers, volumes, networks).
    - The daemon listens for API requests from the Docker client.

2.  **Docker Client (`docker`)**:
    - This is the command-line tool that you, the user, interact with.
    - When you type a command like `docker run`, the client translates this command into an HTTP API request and sends it to the Docker daemon.
    - The client and daemon can run on the same machine, or you can configure a client to connect to a daemon running on a remote machine.

3.  **Docker Registry**:
    - A registry is a place where Docker **images** are stored. It can be public or private.
    - **Docker Hub** is the main public, default registry. It contains thousands of official and community-contributed images (e.g., `node`, `python`, `postgres`).
    - Other examples include AWS ECR, Google GCR, and Azure ACR.

---

## 3. The Core Docker Objects

### Docker Image

- **What it is**: An **image** is a lightweight, standalone, executable package that includes everything needed to run a piece of software, including the code, a runtime, libraries, environment variables, and config files. It is a read-only **blueprint** or **template**.
- **Layers**: Images are built up from a series of layers. Each instruction in a `Dockerfile` (which you'll learn about next) creates a new layer. This layer-based system is very efficient for storage and distribution.
- **How it's created**: You build an image using the `docker build` command, based on the instructions in a `Dockerfile`.

### Docker Container

- **What it is**: A **container** is a **running instance** of an image. If the image is the blueprint (the class), the container is the actual object in memory.
- **What it does**: When you run an image, Docker creates a container. The container has its own isolated filesystem and runs its own processes, but it shares the host machine's OS kernel.
- **How it's created**: You create and run a container using the `docker run` command. You can create many containers from the same image.

**The key relationship to remember**: A container is a runnable instance of an image.

---

## 4. The Basic Docker Workflow

This is the fundamental workflow for a developer using Docker.

1.  **Write a `Dockerfile`**: You write a `Dockerfile` that defines the steps to create an image for your application.
2.  **`docker build`**: You run the `docker build` command. Docker reads your `Dockerfile`, executes the instructions, and creates a Docker **image**. This image is now stored on your local machine.
3.  **`docker run`**: You run the `docker run` command, telling Docker which image to use. Docker creates and starts a **container** from that image. Your application is now running inside the container.
4.  **`docker push`**: (Optional, for sharing) You can push your locally built image to a **registry** (like Docker Hub) to share it with your team or to use it in a production environment.
5.  **`docker pull`**: Other developers or your production servers can then pull the image from the registry and run it.

---

## 5. Summary and Mastery Checklist

-   [ ] I can describe Docker's architecture as a **client** (the command-line tool) talking to a **daemon** (the server).
-   [ ] I know that a Docker **Registry** (like Docker Hub) is where images are stored.
-   [ ] I can explain the key difference: an **image** is a read-only template, and a **container** is a running instance of an image.
-   [ ] I know that `docker build` is used to create an image from a Dockerfile.
-   [ ] I know that `docker run` is used to create and start a container from an image.

---

## 6. Research and References

-   **Docker Docs - Docker overview**: A great explanation of the underlying architecture. [Link](https://docs.docker.com/get-started/overview/)
-   **"The Docker Book" by James Turnbull**: Provides a very clear, step-by-step guide to the Docker workflow.
-   **Play with Docker**: A free, in-browser playground that gives you a Docker environment to experiment with. [Link](https://labs.play-with-docker.com/)
-   **Docker Hub**: Explore the official images for popular software like Node.js, Python, and Postgres. [Link](https://hub.docker.com/)
