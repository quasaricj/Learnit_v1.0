# Creating and Managing Docker Images

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a Dockerfile and explain its purpose.
- **Write** a simple Dockerfile for a web application.
- **Use** the `docker build` command to build an image from a Dockerfile.
- **Understand** the concept of layers in a Docker image and the importance of layer caching.
- **Use** the `docker images` command to list local images.
- **Use** `docker push` and `docker pull` to share images via a registry.
- **Tag** an image with a version number.

---

## 2. The Dockerfile

A **Dockerfile** is a text document that contains all the commands a user could call on the command line to assemble an image. It is the recipe for creating a Docker image. When you run `docker build`, the Docker daemon reads and executes the instructions in the Dockerfile, one by one, to create the final image.

### Common Dockerfile Instructions

- **`FROM`**:
  - **Purpose**: Specifies the base image to start from. Every Dockerfile must start with a `FROM` instruction.
  - **Example**: `FROM node:18-alpine` (Start from the official Node.js version 18 image, using the lightweight "alpine" variant).
- **`WORKDIR`**:
  - **Purpose**: Sets the working directory for any subsequent `RUN`, `CMD`, `COPY`, and `ADD` instructions.
  - **Example**: `WORKDIR /app`
- **`COPY`**:
  - **Purpose**: Copies files and directories from your local machine (the "build context") into the filesystem of the image.
  - **Example**: `COPY package.json .` (Copy the `package.json` file to the current working directory, `/app`).
- **`RUN`**:
  - **Purpose**: Executes a command in a new layer on top of the current image. This is used for installing packages, running build scripts, etc.
  - **Example**: `RUN npm install`
- **`EXPOSE`**:
  - **Purpose**: Informs Docker that the container listens on the specified network ports at runtime. This is primarily for documentation; it does not actually publish the port.
  - **Example**: `EXPOSE 3000`
- **`CMD`**:
  - **Purpose**: Provides the default command to execute when a container is run from the image.
  - A Dockerfile can only have one `CMD`. If you specify multiple, only the last one will take effect.
  - **Example**: `CMD [ "node", "server.js" ]`

---

## 3. Building an Image (`docker build`)

The `docker build` command builds an image from a Dockerfile.

- **`docker build -t <image-name>:<tag> <path-to-build-context>`**
  - **`-t`**: The "tag" flag. This allows you to give your image a memorable name and a version tag.
  - **`<image-name>:<tag>`**: e.g., `my-node-app:1.0`. If you don't specify a tag, it defaults to `latest`.
  - **`<path-to-build-context>`**: The directory on your local machine that contains the Dockerfile and the application code. `.` is used for the current directory.

**Example**: `docker build -t my-app:v1 .`

### Layer Caching

When Docker builds an image, it builds it in **layers**. Each instruction in the Dockerfile creates a new layer. Docker is smart about this: if you haven't changed the files or the command for a specific layer, Docker will use a **cache** from the previous build instead of re-running the instruction.

This is why the order of your Dockerfile instructions is important for performance. You should put the instructions that change most frequently (like `COPY . .` for your source code) at the end of the file, and the instructions that change least frequently (like `RUN npm install`) at the beginning.

---

## 4. Managing Images

### Listing Images

- **`docker images`**: This command lists all the Docker images that are stored on your local machine.

### Tagging Images

- A single image can have multiple tags. You can add a new tag to an existing image using the `docker tag` command.
- This is most often used to prepare an image for pushing to a registry, as the tag needs to be in the format `<registry-hostname>/<username>/<image-name>:<tag>`.
- **Example**: `docker tag my-app:v1 your-username/my-app:v1`

### Sharing Images (Registry)

1.  **`docker login`**: Log in to a Docker registry (defaults to Docker Hub).
2.  **`docker push <image-name>:<tag>`**: Uploads your image to the registry.
    - **Example**: `docker push your-username/my-app:v1`
3.  **`docker pull <image-name>:<tag>`**: Downloads an image from a registry to your local machine.

---

## 5. Deliberate Practice

1.  **Create a Simple Web App**: Create a very simple Node.js/Express or Python/Flask web server in a directory.
2.  **Write a Dockerfile**: In the same directory, create a `Dockerfile` with the `FROM`, `WORKDIR`, `COPY`, `RUN`, `EXPOSE`, and `CMD` instructions needed to run your app.
3.  **Build the Image**: Use `docker build` to build an image of your application and tag it as `my-first-app:1.0`.
4.  **Verify**: Run `docker images` to see your newly created image.
5.  **Push to Docker Hub**:
    -   Create a free account on [Docker Hub](https://hub.docker.com/).
    -   Tag your image with your Docker Hub username.
    -   Log in with `docker login`.
    -   Push your image to Docker Hub.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that a **Dockerfile** is the recipe for building a Docker image.
-   [ ] I can name and explain the purpose of at least three Dockerfile instructions (e.g., `FROM`, `COPY`, `RUN`, `CMD`).
-   [ ] I can use the `docker build -t my-app:1.0 .` command to build a tagged image.
-   [ ] I understand that ordering my Dockerfile instructions correctly is important for build performance because of layer caching.
-   [ ] I can use `docker images` to see the images on my machine.
-   [ ] I can use `docker push` to share an image and `docker pull` to download one.

---

## 7. Research and References

-   **Docker Docs - Dockerfile reference**: The definitive guide to every instruction. [Link](https://docs.docker.com/engine/reference/builder/)
-   **Docker Docs - Best practices for writing Dockerfiles**: Essential reading for creating optimized and secure images. [Link](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)
-   **"The Docker Book" by James Turnbull**
