# Writing Dockerfiles and Best Practices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Structure** a Dockerfile for a typical web application.
- **Apply** best practices for optimizing the Docker build process.
- **Use** a `.dockerignore` file to exclude unnecessary files from the build context.
- **Implement** a multi-stage build to create smaller and more secure production images.
- **Understand** the importance of using official and minimal base images.
- **Run** containers as a non-root user for improved security.

---

## 2. Introduction to Dockerfile Optimization

Writing a Dockerfile that works is easy. Writing a Dockerfile that is efficient, secure, and creates a small, production-ready image is a craft. This module covers the most important best practices for writing professional-grade Dockerfiles. The goal is to create images that are:
- **Smaller**: Smaller images are faster to pull from a registry and have a smaller attack surface.
- **More Secure**: Images should not contain unnecessary tools or run as the `root` user.
- **Faster to Build**: By using the build cache effectively, you can dramatically speed up your development workflow.

---

## 3. Best Practices

### 1. Use a `.dockerignore` file

- **Problem**: When you run `docker build .`, the Docker client sends the entire "build context" (the current directory) to the Docker daemon. This can include large, unnecessary files and directories like `node_modules`, `build` artifacts, `.git`, and log files, making your build slow and potentially leaking secrets.
- **Solution**: Create a `.dockerignore` file in your root directory with the same syntax as a `.gitignore` file. List all the files and directories that should be excluded from the build context.

  ```
  # .dockerignore
  .git
  node_modules
  npm-debug.log
  ```

### 2. Optimize Layer Caching

- **Problem**: If you copy all your source code in one go (`COPY . .`) and then run `npm install`, any change to *any* file will invalidate the cache for the `COPY` layer *and* the expensive `RUN npm install` layer, even if your dependencies haven't changed.
- **Solution**: Copy the files you need for dependency installation first, run the installation, and *then* copy the rest of your source code.

  **Bad**:
  ```dockerfile
  WORKDIR /app
  COPY . .
  RUN npm install
  CMD ["node", "server.js"]
  ```

  **Good**:
  ```dockerfile
  WORKDIR /app
  # Copy the files that define the dependencies
  COPY package.json package-lock.json ./
  # Run install. This layer will only be re-run if package.json changes.
  RUN npm install
  # Now copy the rest of the source code.
  COPY . .
  CMD ["node", "server.js"]
  ```

### 3. Use Minimal Base Images

- **Problem**: Starting your image with `FROM ubuntu` gives you a full-blown operating system with many tools and libraries that your application doesn't need. This makes your image larger and less secure.
- **Solution**: Use the official, minimal base images for your language.
  - **`alpine`**: Images with the `-alpine` tag (e.g., `node:18-alpine`) are based on the Alpine Linux distribution, which is incredibly small (around 5MB). They are a great choice for production.
  - **`slim`**: Images with the `-slim` tag are a good compromise, offering a smaller footprint than the default image but with more common tools included than `alpine`.

### 4. Implement Multi-Stage Builds

- **Problem**: Your build process often requires tools that are not needed to run your application in production (e.g., a compiler, a test framework, development dependencies). Including these in your final image makes it unnecessarily large.
- **Solution**: A multi-stage build uses multiple `FROM` instructions in a single Dockerfile. You can use a "build" stage with all the development tools to compile your code or build your assets, and then a final, clean "production" stage that copies *only the necessary artifacts* from the build stage.

  **Example (for a compiled language like Go or a frontend app)**:
  ```dockerfile
  # ---- Build Stage ----
  FROM node:18 AS build
  WORKDIR /app
  COPY package.json .
  RUN npm install
  COPY . .
  RUN npm run build # Creates a 'build' directory with static files

  # ---- Production Stage ----
  FROM nginx:alpine
  # Copy only the built assets from the 'build' stage
  COPY --from=build /app/build /usr/share/nginx/html
  EXPOSE 80
  CMD ["nginx", "-g", "daemon off;"]
  ```
  The final image is based on `nginx:alpine` and contains only the static HTML/JS/CSS files, not the entire Node.js environment.

### 5. Run as a Non-Root User

- **Problem**: By default, containers run as the `root` user. If an attacker were to compromise your application, they would gain `root` access inside the container, which is a serious security risk.
- **Solution**: Create a dedicated, unprivileged user in your Dockerfile and switch to it before running your application.

  ```dockerfile
  # ... after installing dependencies

  # Create a non-root user and switch to it
  RUN addgroup -S appgroup && adduser -S appuser -G appgroup
  USER appuser

  COPY . .
  CMD ["node", "server.js"]
  ```

---

## 4. Summary and Mastery Checklist

-   [ ] I use a `.dockerignore` file to keep my build context small.
-   [ ] I structure my Dockerfile to take advantage of layer caching by copying `package.json` before copying the rest of my code.
-   [ ] I prefer using minimal base images like `-alpine` for my production images.
-   [ ] I can explain that a **multi-stage build** is a technique for creating smaller production images by separating the build environment from the runtime environment.
-   [ ] I understand that running my container as a **non-root user** is an important security best practice.

---

## 5. Research and References

-   **Docker Docs - Best practices for writing Dockerfiles**: The definitive guide. [Link](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)
-   **Docker Docs - Multi-stage builds**: [Link](https://docs.docker.com/develop/develop-images/multistage-build/)
-   **"Docker Deep Dive" by Nigel Poulton**: A book that goes into great detail on the inner workings of Docker.
-   **Google Cloud - Best practices for building containers**: [Link](https://cloud.google.com/architecture/best-practices-for-building-containers)
