# Docker Compose for Multi-Container Applications

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Docker Compose and explain its purpose.
- **Understand** the role of a `docker-compose.yml` file.
- **Define** a multi-service application using Docker Compose.
- **Start and stop** a multi-container application using the `docker-compose up` and `docker-compose down` commands.
- **Describe** how Docker Compose creates a network for your application's services to communicate.
- **Use** Docker Compose to run a local development environment.

---

## 2. Introduction to Docker Compose

Modern applications are often made up of multiple, interconnected services. For example, a typical web application consists of:
- A backend API service.
- A frontend web server.
- A database service.
- A caching service (like Redis).

While you could run each of these services in a separate Docker container, you would have to manually manage the networking between them, start and stop them individually, and deal with a lot of complex `docker run` commands.

**Docker Compose** is a tool for defining and running multi-container Docker applications. It allows you to use a single **YAML** file (`docker-compose.yml`) to configure all of your application's services. Then, with a single command, you can create and start all the services from your configuration.

---

## 3. The `docker-compose.yml` File

This YAML file is the heart of Docker Compose. It defines the services, networks, and volumes for your application.

### A Simple `docker-compose.yml` Example

Imagine a simple web app with a Node.js backend and a Redis cache.

```yaml
# docker-compose.yml
version: '3.8' # Specifies the file format version

services:
  # The backend API service
  api:
    build: . # Build the image from the Dockerfile in the current directory
    ports:
      - "3000:3000" # Map port 3000 on the host to port 3000 in the container
    environment:
      - REDIS_HOST=cache
    depends_on:
      - cache

  # The Redis caching service
  cache:
    image: redis:alpine # Pull the official Redis image from Docker Hub
    ports:
      - "6379:6379"
```

**Breaking it down**:
- **`version`**: The version of the Compose file format.
- **`services`**: The main section where you define your containers.
  - **`api`** and **`cache`**: These are the names of our two services. Compose will use these as the hostnames for service discovery.
  - **`build: .`**: Tells Compose to build the image for the `api` service using the `Dockerfile` in the current directory.
  - **`image: redis:alpine`**: Tells Compose to pull the `redis:alpine` image from Docker Hub for the `cache` service.
  - **`ports`**: Maps ports from the host machine to the container. `HOST:CONTAINER`.
  - **`environment`**: Sets environment variables inside the container.
  - **`depends_on`**: Tells Compose the startup order. The `api` service will not be started until the `cache` service is running.

---

## 4. Core Docker Compose Commands

These commands are run from the same directory as your `docker-compose.yml` file.

- **`docker-compose up`**:
  - This is the main command. It builds the images if they don't exist, and then creates and starts all the containers defined in your `docker-compose.yml` file.
  - By default, it runs in the foreground and shows the logs from all the containers.
  - **`docker-compose up -d`**: The `-d` (detached) flag runs the containers in the background.

- **`docker-compose down`**:
  - This command stops and removes all the containers, networks, and volumes created by `docker-compose up`. It's the "cleanup" command.

- **`docker-compose ps`**:
  - Lists all the containers that are part of your Compose application, along with their status.

- **`docker-compose logs`**:
  - Shows the logs from all the services in your application.
  - **`docker-compose logs -f <service-name>`**: Follow the logs for a specific service.

### Networking

A key feature of Docker Compose is that it automatically creates a **private virtual network** for your application.
- All the services defined in your `docker-compose.yml` file are attached to this network.
- They can communicate with each other using their **service names as hostnames**.
- In the example above, the Node.js application can connect to Redis using the hostname `cache` (e.g., `redis.createClient({ host: 'cache' })`). You don't need to worry about IP addresses.

---

## 5. Deliberate Practice

1.  **Compose a Web App**: Take the simple web application and Dockerfile you created in the previous module.
2.  **Add a Database**: Add a database service to your application (e.g., `postgres` or `mysql`).
3.  **Create a `docker-compose.yml` file**:
    -   Define your web app as one service (`api`).
    -   Define the database as another service (`db`).
    -   Use an official database image from Docker Hub.
    -   Use `environment` variables to pass the database password to both the `db` service and your `api` service.
    -   Use `depends_on` to make sure the `db` service starts before the `api` service.
4.  **Run it**: Use `docker-compose up` to launch your two-container application.
5.  **Verify**: Use `docker-compose ps` to see that both containers are running. Check the logs with `docker-compose logs`.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that Docker Compose is a tool for running multi-container applications.
-   [ ] I know that the application's services are defined in a `docker-compose.yml` file.
-   [ ] I can use `docker-compose up` to start an application and `docker-compose down` to stop and remove it.
-   [ ] I understand that Compose creates a private network and that I can use the service names (e.g., `db`) as hostnames for communication between containers.
-   [ ] I can define a simple two-service (e.g., web app and database) application in a `docker-compose.yml` file.

---

## 7. Research and References

-   **Docker Docs - Overview of Docker Compose**: [Link](https://docs.docker.com/compose/)
-   **Docker Docs - Compose file version 3 reference**: The definitive guide to all the options in the YAML file. [Link](https://docs.docker.com/compose/compose-file/compose-file-v3/)
-   **"Docker Deep Dive" by Nigel Poulton**
-   **Awesome Compose**: A GitHub repository with a curated list of Docker Compose samples for various application stacks. [Link](https://github.com/docker/awesome-compose)
