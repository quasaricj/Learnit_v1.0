# Dockerfile and Image Basics

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Differentiate** between a Docker image and a Docker container.
-   **Define** a Dockerfile and its purpose.
-   **Write** a simple Dockerfile for a web application.
-   **Understand** and use common Dockerfile instructions (`FROM`, `WORKDIR`, `COPY`, `RUN`, `CMD`, `EXPOSE`).
-   **Build** a Docker image from a Dockerfile using the `docker build` command.
-   **Run** a Docker container from an image using the `docker run` command.
-   **Explain** the concept of layers in a Docker image.

---

## 2. Introduction: Images and Containers

**Docker** is the most popular container engine that allows you to package and run an application in a loosely isolated environment called a container. To do this, you first need a **Docker image**.

-   **Image**: An image is a **read-only template** with instructions for creating a Docker container. It is a blueprint that includes your application code, a runtime (like Node.js or Python), libraries, and environment variables. Images are built from a set of instructions in a file called a `Dockerfile`.
-   **Container**: A container is a **runnable instance of an image**. You can create, start, stop, move, or delete a container using the Docker API or CLI. When you run an image, it becomes a container.

**Analogy**: An image is like a class in OOP, and a container is like an instance (an object) of that class. You can create many containers from the same image.

---

## 3. The Dockerfile

A `Dockerfile` is a text document that contains all the commands a user could call on the command line to assemble an image. It is a step-by-step recipe for building your image.

### Common Dockerfile Instructions

-   **`FROM`**: Specifies the **base image** for your new image. This is the first instruction in a Dockerfile. You typically start from an official image from Docker Hub (e.g., `node:18-alpine`, `python:3.10-slim`).
-   **`WORKDIR`**: Sets the working directory for any subsequent `RUN`, `CMD`, `COPY`, and `ADD` instructions.
-   **`COPY`**: Copies new files or directories from your host machine into the filesystem of the image.
-   **`RUN`**: Executes a command in a new layer on top of the current image and commits the results. This is used for installing packages (e.g., `RUN npm install`, `RUN pip install -r requirements.txt`).
-   **`EXPOSE`**: Informs Docker that the container listens on the specified network ports at runtime. This is documentation; it does not actually publish the port.
-   **`CMD`**: Provides the default command to execute when a container is run. There can only be one `CMD` instruction in a Dockerfile.

### Example Dockerfile for a Node.js App

```dockerfile
# 1. Use an official Node.js runtime as a parent image
FROM node:18-alpine

# 2. Set the working directory in the container
WORKDIR /usr/src/app

# 3. Copy package.json and package-lock.json to the working directory
COPY package*.json ./

# 4. Install application dependencies
RUN npm install

# 5. Copy the rest of the application source code
COPY . .

# 6. Expose the port the app runs on
EXPOSE 3000

# 7. Define the command to run the application
CMD [ "node", "server.js" ]
```

### Image Layers

Each instruction in a Dockerfile creates a read-only **layer**. These layers are stacked on top of each other. When you change an instruction, Docker only rebuilds that layer and the ones after it. This makes builds very fast and efficient. This is why the `COPY package*.json ./` and `RUN npm install` steps are done *before* copying the rest of the source code. The dependencies (which change infrequently) are put in a layer that is less likely to be rebuilt.

---

## 4. Building and Running

### `docker build`

This command builds a Docker image from a Dockerfile.

-   `docker build -t my-node-app .`
    -   `-t my-node-app`: This **tags** (names) the image `my-node-app`.
    -   `.`: This tells Docker to look for the `Dockerfile` in the current directory.

### `docker run`

This command creates and starts a new container from an image.

-   `docker run -p 8080:3000 --name my-app-container my-node-app`
    -   `-p 8080:3000`: This **publishes** the port. It maps port `8080` on the host machine to port `3000` inside the container (the one we `EXPOSE`d).
    -   `--name my-app-container`: Gives the running container a human-readable name.
    -   `my-node-app`: The name of the image to run.
-   `docker ps`: Lists all running containers.
-   `docker stop my-app-container`: Stops the running container.

---

## 5. Deliberate Practice

1.  **Install Docker**: Install Docker Desktop on your machine.
2.  **Dockerize an Application**:
    -   Take one of the web server applications you built in Phase 2 (e.g., the Node.js/Express "Hello World" server).
    -   Write a `Dockerfile` for it, similar to the example above.
    -   Create a `.dockerignore` file to exclude `node_modules` and other local files from being copied into the image.
3.  **Build and Run**:
    -   Use `docker build` to build an image from your `Dockerfile`.
    -   Use `docker run` to start a container from your new image, making sure to map the ports correctly.
    -   Visit `http://localhost:<host-port>` in your browser to see your application running, served from inside a Docker container.
4.  **Explore Docker Hub**: Go to [Docker Hub](https://hub.docker.com/) and search for official images for your favorite programming languages and databases (e.g., `python`, `postgres`).

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that a Docker **image** is a read-only template and a **container** is a running instance of an image.
-   [ ] I know that a `Dockerfile` is the recipe for building an image.
-   [ ] I can describe the purpose of the `FROM`, `COPY`, `RUN`, and `CMD` instructions.
-   [ ] I can use the `docker build` command to create an image.
-   [ ] I can use the `docker run` command to start a container.
-   [ ] I understand that the `-p` flag is required to map a port from my host machine to the container.

---

## 13. Research and References

-   **Docker's Official "Get Started" Guide**: The best place to start. It's a comprehensive, hands-on tutorial. [Link](https://docs.docker.com/get-started/)
-   **"The Docker Handbook" by Madhu Kumar**: A free e-book that covers the fundamentals.
-   **Play with Docker**: A free, in-browser playground for experimenting with Docker commands without needing to install anything locally. [Link](https://labs.play-with-docker.com/)
-   **Dockerfile Best Practices**: [Link](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)
