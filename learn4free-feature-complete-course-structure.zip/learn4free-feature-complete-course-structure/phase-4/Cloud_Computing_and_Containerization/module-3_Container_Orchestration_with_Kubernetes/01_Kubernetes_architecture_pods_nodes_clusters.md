# Kubernetes Architecture: Pods, Nodes, Clusters

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** container orchestration and explain the problems it solves.
- **Describe** Kubernetes as a container orchestration platform.
- **Define** the three main components of the Kubernetes architectural hierarchy: Cluster, Node, and Pod.
- **Explain** the relationship between a container and a Pod.
- **Differentiate** between the control plane and the data plane (worker nodes) in a Kubernetes cluster.

---

## 2. Introduction to Container Orchestration

You can run a few Docker containers on a single machine using Docker Compose. But what happens when you need to run a large, distributed application with hundreds of containers across a fleet of servers in production? This is where a **container orchestrator** comes in.

A container orchestrator is a tool that automates the deployment, scaling, and management of containerized applications. It is the "operating system for the cloud."

Key responsibilities of an orchestrator:
- **Scheduling**: Automatically choosing the best server to run a container on.
- **Scaling**: Automatically scaling the number of containers up or down based on demand.
- **Self-healing**: Automatically restarting or replacing containers that fail.
- **Service Discovery and Load Balancing**: Automatically routing network traffic to the correct containers.
- **Rolling Updates**: Managing the process of updating your application to a new version with zero downtime.

**Kubernetes** (often abbreviated as **K8s**) is the world's most popular open-source container orchestration platform. It was originally developed by Google.

---

## 3. The Kubernetes Architectural Hierarchy

### 1. Cluster

- **What it is**: A **Cluster** is the highest-level component. It is a set of machines, called **nodes**, that run containerized applications. A Kubernetes cluster consists of a control plane and one or more worker nodes.

### 2. Node (or Worker Machine)

- **What it is**: A **Node** is a worker machine in a Kubernetes cluster. It can be a virtual machine (e.g., an AWS EC2 instance) or a physical server. Each node has the services necessary to run containers, managed by the control plane.
- **Key Components on a Node**:
  - **Kubelet**: An agent that runs on each node and communicates with the control plane to ensure that containers are running as they should be.
  - **Container Runtime**: The software that is responsible for running containers (e.g., Docker, containerd).

### 3. Pod

- **What it is**: A **Pod** is the **smallest and simplest deployable unit** in Kubernetes. It is a group of one or more tightly coupled containers that share storage and network resources.
- **Pod vs. Container**: While you can run a single container within a Pod (which is the most common use case), a Pod can contain multiple containers if they need to be co-located on the same machine and share resources. A Pod is a wrapper around your container(s).
- **You do not run containers directly in Kubernetes; you run Pods.**
- **Ephemeral Nature**: Pods are designed to be ephemeral, disposable entities. When a Pod "dies," it is not brought back to life. Instead, a new, identical Pod is created to replace it. This is a key principle of a self-healing system.

---

## 4. The Control Plane

The **control plane** is the brain of the Kubernetes cluster. It is a set of services that manage the state of the cluster. It's responsible for making global decisions about the cluster (e.g., scheduling) and for detecting and responding to cluster events.

Key components of the control plane:
- **API Server (`kube-apiserver`)**: The frontend of the control plane. It exposes the Kubernetes API. All communication, both from external users and from other cluster components, goes through the API server.
- **etcd**: A consistent and highly-available key-value store used as Kubernetes' backing store for all cluster data.
- **Scheduler (`kube-scheduler`)**: Watches for newly created Pods that have no node assigned, and selects a node for them to run on based on resource requirements and other constraints.
- **Controller Manager (`kube-controller-manager`)**: Runs the controller processes that are the "control loops" of Kubernetes (e.g., the Node Controller, Replication Controller).

In a managed Kubernetes service (like AWS EKS, Azure AKS, or Google GKE), the cloud provider manages the entire control plane for you. You are only responsible for managing your worker nodes and your applications.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that a **container orchestrator** (like Kubernetes) automates the deployment, scaling, and management of containers.
-   [ ] I can describe the Kubernetes hierarchy: You have a **Cluster**, which is made up of **Nodes** (machines), and on those nodes, you run **Pods**.
-   [ ] I can explain that a **Pod** is the smallest deployable unit in Kubernetes and that it contains one or more containers.
-   [ ] I understand that Pods are ephemeral and can be replaced at any time.
-   [ ] I can differentiate between the **control plane** (the "brain") and the **worker nodes** (the "muscle").
-   [ ] I know that in a managed Kubernetes service (EKS, AKS, GKE), the cloud provider manages the complex control plane.

---

## 6. Research and References

-   **Kubernetes Documentation - Components of Kubernetes**: The official guide to the architecture. [Link](https://kubernetes.io/docs/concepts/overview/components/)
-   **"Kubernetes in Action" by Marko Luksa**: A comprehensive and highly-regarded book.
-   **"The Illustrated Children's Guide to Kubernetes"**: A fun and surprisingly effective cartoon that explains the core concepts of Kubernetes. [Link](https://www.cncf.io/the-childrens-illustrated-guide-to-kubernetes/)
-   **Katakoda**: In-browser, interactive scenarios for learning Kubernetes. [Link](https://www.katacoda.com/courses/kubernetes)
