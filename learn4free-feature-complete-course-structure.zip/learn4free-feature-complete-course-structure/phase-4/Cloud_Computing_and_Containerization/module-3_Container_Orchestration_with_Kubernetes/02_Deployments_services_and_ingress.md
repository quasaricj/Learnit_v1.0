# Kubernetes: Deployments, Services, and Ingress

## 1. Clear Learning Objectives

By a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a- **`ReplicaSet`** to ensure that the desired number of Pods are always running. If a Pod dies, the ReplicaSet will automatically create a new one to replace it.
- **Rolling Updates**: When you update the image version in your Deployment, it will automatically perform a **rolling update**. It gradually replaces old Pods with new ones, ensuring that your application remains available during the update.

### 2. Service

- **Problem**: Pods are ephemeral. They can be created and destroyed, and each new Pod gets a new IP address. So, how can other Pods (or the outside world) reliably communicate with your application?
- **Solution**: A **Service** is a Kubernetes object that provides a stable, abstract endpoint for a set of Pods.
- **How it works**:
  1.  A Service is defined to target a set of Pods using **labels** (e.g., all Pods with the label `app: my-api`).
  2.  The Service gets its own stable IP address and DNS name.
  3.  When traffic is sent to the Service, Kubernetes automatically **load balances** that traffic to one of the healthy Pods that match the label selector.
- **Types of Services**:
  - **`ClusterIP`**: The default type. The Service is only reachable from *inside* the cluster. This is used for internal, backend-to-backend communication.
  - **`NodePort`**: Exposes the Service on a static port on each Node's IP address.
  - **`LoadBalancer`**: The most common type for public-facing services. It provisions an external load balancer from your cloud provider (e.g., an AWS Elastic Load Balancer) and assigns it a public IP address.

### 3. Ingress

- **Problem**: A `LoadBalancer` Service is great, but it works at Layer 4 (TCP). It's expensive because you need a separate load balancer for each service you want to expose. How can you expose multiple services under a single IP address, with HTTP routing based on the URL path or hostname?
- **Solution**: An **Ingress** is an API object that manages external access to the services in a cluster, typically HTTP. It acts as a "smart router" or an application layer (Layer 7) load balancer.
- **How it works**:
  1.  You deploy an **Ingress Controller** in your cluster (this is a separate piece of software, like Nginx or Traefik).
  2.  You then create `Ingress` resources that define the routing rules.
- **Example Ingress Rules**:
  - `host: foo.com, path: /api -> service: api-service`
  - `host: bar.com, path: / -> service: frontend-service`
- An Ingress allows you to use a single cloud load balancer to expose dozens of services, which is much more cost-effective.

---

## 4. An Example YAML Configuration

In Kubernetes, you define the desired state of your objects using **YAML** files.

```yaml
# my-app-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app-deployment
spec:
  replicas: 3 # I want 3 replicas of my Pod
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-app-container
        image: your-username/my-app:v1 # The Docker image to run
        ports:
        - containerPort: 80

---
# my-app-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: my-app-service
spec:
  type: LoadBalancer # Expose this service to the internet
  selector:
    app: my-app # Route traffic to Pods with this label
  ports:
  - protocol: TCP
    port: 80 # The port the service is available on
    targetPort: 80 # The port the containers are listening on
```

You would apply these files to your cluster using the `kubectl apply -f <filename>` command.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that a **Deployment** manages a set of replica Pods and handles rolling updates.
-   [ ] I can explain that a **Service** provides a stable IP address and load balancing for a set of ephemeral Pods.
-   [ ] I know that a `ClusterIP` Service is for internal communication, and a `LoadBalancer` Service is for exposing a service to the internet.
-   [ ] I can explain that an **Ingress** is a smart router that manages HTTP traffic from outside the cluster to the correct services inside the cluster.
-   [ ] I know that Kubernetes objects are defined in **YAML** files.
-   [ ] I understand the role of **labels** and **selectors** in connecting Deployments and Services.

---

## 6. Research and References

-   **Kubernetes Documentation - Kubernetes Objects**: The official documentation is the best reference.
    -   [Deployments](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/)
    -   [Services](https://kubernetes.io/docs/concepts/services-networking/service/)
    -   [Ingress](https://kubernetes.io/docs/concepts/services-networking/ingress/)
-   **"Kubernetes in Action" by Marko Luksa**
-   **"Kubernetes: Up and Running" by Kelsey Hightower, Brendan Burns, and Joe Beda**: A practical guide by some of the creators of Kubernetes.
-   **"What is Ingress?"**: A good article from the Nginx Ingress Controller documentation.
