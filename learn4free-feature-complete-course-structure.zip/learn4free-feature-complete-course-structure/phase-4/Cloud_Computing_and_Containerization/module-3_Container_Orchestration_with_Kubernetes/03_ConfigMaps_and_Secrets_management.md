# Kubernetes: ConfigMaps and Secrets Management

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** the importance of decoupling configuration from your application image.
- **Define** a ConfigMap and its purpose: to manage non-sensitive configuration data.
- **Define** a Secret and its purpose: to manage sensitive data like passwords and API keys.
- **Create** a simple ConfigMap and a Secret.
- **Provide** configuration data to a Pod using environment variables or mounted files.
- **Understand** the security implications of how Kubernetes stores Secrets.

---

## 2. The Problem: Configuration in Container Images

A core principle of containerization is that your container image should be **immutable** and **portable**. You should be able to run the exact same image in your development, staging, and production environments.

This creates a problem: what about configuration? Your application needs to connect to a different database in development than it does in production. If you bake the database connection string into your image, you would need to build a separate image for each environment. This violates the "build once, run anywhere" principle.

The solution is to **decouple your configuration from your application image**. Kubernetes provides two main objects for this: **ConfigMaps** for non-sensitive data and **Secrets** for sensitive data.

---

## 3. ConfigMaps

- **What it is**: A **ConfigMap** is a Kubernetes object used to store non-confidential configuration data as key-value pairs.
- **Purpose**: To make your application configuration portable. You can write your application to read from the ConfigMap, and then you can apply a different ConfigMap in each environment.
- **How to create a ConfigMap**:
  - **From a literal**:
    `kubectl create configmap my-app-config --from-literal=API_URL=https://api.myapp.com --from-literal=LOG_LEVEL=info`
  - **From a file**:
    `kubectl create configmap my-app-config --from-file=app-config.properties`
  - **From a YAML manifest**: (The "GitOps" way)
    ```yaml
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: my-app-config
    data:
      API_URL: "https://api.myapp.com"
      LOG_LEVEL: "info"
    ```

---

## 4. Secrets

- **What it is**: A **Secret** is a Kubernetes object that is very similar to a ConfigMap, but it is intended for storing sensitive information, such as passwords, OAuth tokens, and SSH keys.
- **Purpose**: To provide a more secure way to manage confidential data and to separate it from your application's pod definition.
- **How to create a Secret**:
  - **From a literal** (Note: The value is base64 encoded by `kubectl`):
    `kubectl create secret generic db-secret --from-literal=DB_PASSWORD=supersecret`
  - **From a YAML manifest**:
    The values in the YAML file must be **manually base64 encoded**.
    ```yaml
    apiVersion: v1
    kind: Secret
    metadata:
      name: db-secret
    type: Opaque # The default type
    data:
      DB_PASSWORD: c3VwZXJzZWNyZXQ= # "supersecret" encoded in base64
    ```

### An Important Note on Secret Security

By default, Kubernetes stores Secrets as base64-encoded plain text in `etcd`. Base64 is an encoding, **not an encryption**. Anyone who has access to the `etcd` database can easily decode the secrets.

Therefore, Kubernetes Secrets are not a complete security solution on their own. They are a mechanism for securely *delivering* secrets to your Pods. To secure your secrets "at rest," you need to use additional tools like an encrypted `etcd` or an external secret management system like **HashiCorp Vault** or **AWS Secrets Manager**.

---

## 5. Consuming ConfigMaps and Secrets in Pods

There are two main ways to make the data from a ConfigMap or a Secret available to your containers:

### 1. As Environment Variables

This is the most common method. You can inject the key-value pairs from a ConfigMap or a Secret directly into a container as environment variables.

```yaml
# In your Deployment's Pod template
spec:
  containers:
  - name: my-app-container
    image: my-app
    envFrom: # An array of sources to populate environment variables
    - configMapRef:
        name: my-app-config
    - secretRef:
        name: db-secret
```
Your application can then read `process.env.API_URL` or `process.env.DB_PASSWORD` just like any other environment variable.

### 2. As Mounted Files (Volumes)

You can also mount a ConfigMap or a Secret as a volume, where each key becomes a file in the specified directory, and the value becomes the content of the file.

```yaml
# In your Deployment's Pod template
spec:
  containers:
  - name: my-app-container
    image: my-app
    volumeMounts:
    - name: config-volume
      mountPath: /etc/config
  volumes:
  - name: config-volume
    configMap:
      name: my-app-config
```
This would create a directory `/etc/config` inside the container with files named `API_URL` and `LOG_LEVEL`. This is useful for applications that are designed to read their configuration from files.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain why configuration should be kept separate from the application image.
-   [ ] I know that a **ConfigMap** is used for non-sensitive configuration data.
-   [ ] I know that a **Secret** is used for sensitive data like passwords.
-   [ ] I understand that Kubernetes Secrets are base64 encoded, **not encrypted**, by default.
-   [ ] I can describe the two main ways to provide a ConfigMap/Secret to a Pod (as environment variables or as a mounted volume).

---

## 7. Research and References

-   **Kubernetes Docs - Configuration**:
    -   [ConfigMaps](https://kubernetes.io/docs/concepts/configuration/configmap/)
    -   [Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)
-   **"Kubernetes in Action" by Marko Luksa**
-   **"Managing Kubernetes Secrets"**: A common topic for blog posts that cover the security implications and best practices.
-   **HashiCorp Vault**: The most popular open-source tool for secrets management. [Link](https://www.vaultproject.io/)
