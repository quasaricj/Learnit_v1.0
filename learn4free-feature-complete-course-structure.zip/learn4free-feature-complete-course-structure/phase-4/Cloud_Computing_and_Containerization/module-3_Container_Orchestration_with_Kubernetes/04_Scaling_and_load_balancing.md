# Kubernetes: Scaling and Load Balancing

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Differentiate** between scaling up (vertical scaling) and scaling out (horizontal scaling).
- **Explain** how Kubernetes facilitates horizontal scaling.
- **Manually scale** a Deployment using `kubectl scale`.
- **Define** the Horizontal Pod Autoscaler (HPA) and its purpose.
- **Describe** how the HPA works based on metrics like CPU utilization.
- **Recap** how a Kubernetes Service provides load balancing across multiple Pods.

---

## 2. Introduction to Scaling

One of the primary reasons for using a container orchestrator like Kubernetes is to achieve **scalability**. As the traffic to your application increases, you need a way to handle the additional load.

There are two main ways to scale an application:

1.  **Vertical Scaling (Scaling Up)**:
    - **What it is**: You give an existing machine more resources. You increase the CPU, memory, or storage of your server.
    - **Analogy**: Swapping the engine in your car for a more powerful one.
    - **Limitations**: There is a physical limit to how much you can scale up a single machine. It is also very expensive.

2.  **Horizontal Scaling (Scaling Out)**:
    - **What it is**: You add more machines to your pool of resources. For a Kubernetes application, this means adding more **Pods**.
    - **Analogy**: Adding more cars to your fleet.
    - **Benefits**: This is the model that the cloud and Kubernetes are built for. It allows for massive, "on-demand" scalability with no theoretical limit.

**Kubernetes is designed for horizontal scaling.**

---

## 3. How Kubernetes Scales Your Application

### The Role of the Deployment

- As you learned previously, a **Deployment** manages a **ReplicaSet**.
- The `replicas` field in your Deployment's YAML file tells Kubernetes the **desired state**: how many identical copies of your Pod you want to be running at all times.

### Manual Scaling

- You can manually change the number of replicas for a Deployment at any time using the `kubectl scale` command.
- **Command**: `kubectl scale deployment <deployment-name> --replicas=<new-number>`
- **Example**: `kubectl scale deployment my-app-deployment --replicas=5`
- **What happens**: When you run this command, you are changing the "desired state" of the Deployment. The ReplicaSet controller will see that the current state (e.g., 3 Pods) does not match the new desired state (5 Pods), and it will automatically start 2 new Pods to match the desired count.

### Automatic Scaling: The Horizontal Pod Autoscaler (HPA)

- Manually scaling your application is not efficient. You want the application to scale automatically in response to changes in traffic.
- The **Horizontal Pod Autoscaler (HPA)** is a Kubernetes controller that automatically scales the number of Pods in a Deployment based on observed metrics.
- **How it works**:
  1.  You create an HPA resource and link it to a specific Deployment.
  2.  You define the scaling parameters:
      - **Metric**: The metric to monitor. The most common metric is **CPU utilization**.
      - **Target**: The desired average value for that metric (e.g., "I want to keep the average CPU utilization across all my Pods at 50%").
      - **Min/Max Replicas**: The minimum and maximum number of replicas the HPA can scale to (e.g., between 3 and 10).
  3.  The HPA continuously monitors the metric.
  4.  If the average CPU utilization goes above your target (e.g., to 75%), the HPA will automatically increase the number of `replicas` on the Deployment to scale out.
  5.  If the average CPU utilization drops below the target, the HPA will scale the Deployment back down.

---

## 4. Load Balancing

Scaling out is useless if you don't have a way to distribute traffic to your new Pods. This is where the Kubernetes **Service** object comes in.

### The Role of the Service

- As a recap, a **Service** provides a single, stable endpoint (a virtual IP address and a DNS name) for a set of Pods.
- **Load Balancing**: The Service has a built-in load balancer. When a request comes in to the Service's IP address, the `kube-proxy` component on each node intercepts that request and distributes it to one of the healthy backend Pods in a round-robin fashion.
- **Service Discovery**: Because the Service's name is registered in the cluster's internal DNS, other Pods can easily find and communicate with it using its name, without needing to know the individual IP addresses of the backend Pods.

**Together, Deployments, HPAs, and Services provide a complete, automated, and self-healing system for running and scaling your applications.**

1.  The **Deployment** ensures your Pods are running and handles updates.
2.  The **HPA** automatically adjusts the number of Pods based on load.
3.  The **Service** provides a stable endpoint and load balances traffic across all the Pods.

---

## 5. Summary and Mastery Checklist

-   [ ] I can explain that **horizontal scaling** (adding more Pods) is the standard approach in Kubernetes.
-   [ ] I can use the `kubectl scale` command to manually change the number of replicas for a Deployment.
-   [ ] I can define the **Horizontal Pod Autoscaler (HPA)** as the Kubernetes component that automatically scales Deployments.
-   [ ] I can explain that the HPA works by monitoring a metric (like CPU utilization) and adjusting the replica count to meet a target.
-   [ ] I understand that a Kubernetes **Service** is responsible for load balancing the traffic across all the available Pods in a Deployment.

---

## 6. Research and References

-   **Kubernetes Docs - Scaling Your Application**:
    -   [Horizontal Pod Autoscaling](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/)
-   **"Kubernetes in Action" by Marko Luksa**
-   **"The Art of Scalability" by Martin L. Abbott and Michael T. Fisher**: A book on the general principles of building scalable systems.
-   **Kubernetes Metrics Server**: A cluster-wide aggregator of resource usage data that the HPA uses.
