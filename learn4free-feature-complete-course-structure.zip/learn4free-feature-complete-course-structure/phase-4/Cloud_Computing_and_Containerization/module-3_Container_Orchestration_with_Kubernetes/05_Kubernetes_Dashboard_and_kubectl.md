# Kubernetes Dashboard and kubectl

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** `kubectl` as the primary command-line tool for interacting with a Kubernetes cluster.
- **Use** basic `kubectl` commands to inspect cluster resources (e.g., `get pods`, `describe deployment`).
- **Use** `kubectl` to apply a YAML manifest and to delete resources.
- **Access** the logs of a running Pod using `kubectl logs`.
- **Open a shell** inside a running container using `kubectl exec`.
- **Describe** the Kubernetes Dashboard as a web-based UI for the cluster.

---

## 2. `kubectl`: The Kubernetes Command-Line Tool

**`kubectl`** (pronounced "koob-control" or "koob-cuddle") is the official and most important command-line tool for interacting with the Kubernetes API server. It allows you to run commands against your Kubernetes clusters to deploy applications, inspect and manage cluster resources, and view logs.

`kubectl` works by reading a **kubeconfig file** (usually located at `~/.kube/config`), which contains the credentials and endpoint information for one or more clusters.

### The Most Common `kubectl` Commands

These are the essential, day-to-day commands for any developer working with Kubernetes.

#### Inspecting Resources

- **`kubectl get <resource-type>`**: Lists resources.
  - `kubectl get pods`: List all Pods in the current namespace.
  - `kubectl get services`: List all Services.
  - `kubectl get deployments`: List all Deployments.
  - `kubectl get all`: List all common resource types.
- **`kubectl describe <resource-type> <resource-name>`**: Get detailed information about a specific resource. This is great for debugging.
  - `kubectl describe pod my-app-pod-xyz`: Shows the Pod's status, events, IP address, and the containers within it.
  - `kubectl describe deployment my-app-deployment`: Shows the status of the deployment, the number of replicas, and any recent events.

#### Applying Changes

- **`kubectl apply -f <filename>`**: Applies a configuration from a YAML file. If the resource doesn't exist, it will be created. If it already exists, it will be updated. This is the **declarative** way to manage your resources and the heart of the "GitOps" workflow.
  - `kubectl apply -f my-deployment.yaml`

#### Deleting Resources

- **`kubectl delete <resource-type> <resource-name>`**: Deletes a resource.
  - `kubectl delete deployment my-app-deployment`
- **`kubectl delete -f <filename>`**: Deletes all the resources defined in a YAML file.

#### Debugging and Interacting with Pods

- **`kubectl logs <pod-name>`**: Prints the logs from a container in a Pod.
  - **`kubectl logs -f <pod-name>`**: Follows the log stream in real-time.
- **`kubectl exec -it <pod-name> -- <command>`**: Executes a command inside a running container. The `-it` flags make it an interactive terminal.
  - **`kubectl exec -it my-app-pod-xyz -- /bin/sh`**: Opens a shell session inside the container, which is incredibly useful for debugging.
- **`kubectl port-forward <pod-name> <local-port>:<container-port>`**: Forwards a local port to a port on a Pod. This allows you to connect to an application running inside the cluster from your local machine, even if it's not exposed by a Service.

---

## 3. The Kubernetes Dashboard

The **Kubernetes Dashboard** is a general purpose, web-based UI for Kubernetes clusters. It allows cluster operators and developers to manage and troubleshoot their applications running in the cluster.

### What can you do with it?

- **Get an overview** of your cluster's health and the resources running in it.
- **View and manage** all your Kubernetes objects (Deployments, Pods, Services, etc.) in a graphical interface.
- **Create and deploy** applications using a simple wizard.
- **View log files** and resource usage (CPU/memory) for your Pods.

### How to access it?

- The Dashboard is an add-on and is not always installed by default, especially in managed Kubernetes services.
- Accessing it securely can be complex and often involves using `kubectl proxy` or setting up an Ingress.

### `kubectl` vs. Dashboard

- **`kubectl`**: The preferred tool for automation, scripting, and for experienced developers who are comfortable with the command line. It is faster and more powerful for most tasks.
- **Dashboard**: Great for getting a visual overview of the cluster, for monitoring, and for users who are new to Kubernetes and prefer a graphical interface.

Most experienced Kubernetes developers live in the command line and use `kubectl` for the majority of their work, but will use the Dashboard for a high-level visual check.

---

## 4. Summary and Mastery Checklist

-   [ ] I know that **`kubectl`** is the primary command-line tool for managing a Kubernetes cluster.
-   [ ] I can use `kubectl get pods` to see what Pods are running.
-   [ ] I can use `kubectl describe pod <name>` to get detailed information about a Pod for debugging.
-   [ ] I know that `kubectl apply -f <filename.yaml>` is the declarative way to create or update resources.
-   [ ] I can use `kubectl logs <pod-name>` to view the logs of a container.
-   [ ] I can use `kubectl exec` to get a shell inside a running container.
-   [ ] I know that the Kubernetes Dashboard is a web-based UI that provides a visual overview of the cluster.

---

## 5. Research and References

-   **Kubernetes Docs - Overview of kubectl**: [Link](https://kubernetes.io/docs/reference/kubectl/overview/)
-   **Kubernetes Docs - `kubectl` Cheat Sheet**: A very handy reference for all the common commands. [Link](https://kubernetes.io/docs/reference/kubectl/cheatsheet/)
-   **Kubernetes Docs - Deploy and Access the Kubernetes Dashboard**: [Link](https://kubernetes.io/docs/tasks/access-application-cluster/web-ui-dashboard/)
-   **"Kubernetes: Up and Running" by Kelsey Hightower, Brendan Burns, and Joe Beda**
-   **`k9s`**: A popular, terminal-based UI for Kubernetes that provides a faster and more powerful alternative to the web dashboard.
