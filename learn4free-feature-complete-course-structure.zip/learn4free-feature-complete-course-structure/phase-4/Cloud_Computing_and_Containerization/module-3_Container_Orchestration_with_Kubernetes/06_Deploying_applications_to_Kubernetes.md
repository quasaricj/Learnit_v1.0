# Deploying Applications to Kubernetes

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Outline** the complete workflow for deploying a containerized application to Kubernetes.
- **Write** the necessary YAML files for a simple web application (Deployment and Service).
- **Use** `kubectl` to apply the YAML files and deploy the application.
- **Verify** that the application has been deployed successfully.
- **Access** the running application, either via a `LoadBalancer` Service or `kubectl port-forward`.
- **Understand** the "GitOps" philosophy of managing Kubernetes applications.

---

## 2. The Deployment Workflow

Deploying an application to Kubernetes involves taking your containerized application and creating the necessary Kubernetes "object" definitions to run, scale, and expose it. The entire process is a combination of everything you've learned in the last two modules.

**The process from code to a running application:**

1.  **Write Your Application Code**.
2.  **Write a `Dockerfile`** for your application.
3.  **Build a Docker Image** from the Dockerfile (`docker build`).
4.  **Push the Docker Image** to a container registry (like Docker Hub, AWS ECR, etc.).
5.  **Write Kubernetes YAML Manifests** (at a minimum, a `Deployment` and a `Service`).
6.  **Apply the Manifests** to your cluster (`kubectl apply -f .`).
7.  **Verify the Deployment** (`kubectl get pods`, `kubectl get services`).
8.  **Access Your Application**.

---

## 3. Creating the Kubernetes Manifests (YAML)

Let's assume you have a simple web application that listens on port 8080. You have already built an image and pushed it to `your-username/my-app:v1`.

### 1. The Deployment (`deployment.yaml`)

This file tells Kubernetes how to run your application Pods.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app-deployment
spec:
  replicas: 3 # Start with 3 replicas
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app # The label that the Service will use to find these Pods
    spec:
      containers:
      - name: my-app
        image: your-username/my-app:v1 # Your image from the registry
        ports:
        - containerPort: 8080 # The port your app listens on inside the container
```

### 2. The Service (`service.yaml`)

This file tells Kubernetes how to expose your application and load balance traffic to your Pods.

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-app-service
spec:
  type: LoadBalancer # Use a cloud load balancer to get a public IP
  selector:
    app: my-app # Select the Pods managed by our Deployment
  ports:
  - protocol: TCP
    port: 80 # The port that the public load balancer will listen on
    targetPort: 8080 # The port to forward traffic to on the Pods
```

---

## 4. Deploying and Verifying

### Applying the Manifests

You can apply these files to your cluster with `kubectl`.
`kubectl apply -f deployment.yaml`
`kubectl apply -f service.yaml`

Or, if they are all in one directory:
`kubectl apply -f .`

### Checking the Status

- **Check the Deployment**:
  `kubectl get deployment my-app-deployment`
  You can watch it roll out with:
  `kubectl rollout status deployment/my-app-deployment`

- **Check the Pods**:
  `kubectl get pods`
  You should see three Pods with names like `my-app-deployment-xyz...` in the `Running` state.

- **Check the Service**:
  `kubectl get service my-app-service`
  If you are using `type: LoadBalancer` on a cloud provider, you will see an `EXTERNAL-IP` address. It may take a few minutes for the cloud provider to provision the load balancer and assign the IP.

### Accessing the Application

Once the `EXTERNAL-IP` is available for your Service, you can access your application by navigating to that IP address in your web browser.

---

## 5. The "GitOps" Philosophy

The best practice for managing Kubernetes applications is a workflow called **GitOps**.

- **The Principle**: Your Git repository is the **single source of truth** for the desired state of your application.
- **The Workflow**:
  1.  You do not use `kubectl` to make changes directly to the cluster.
  2.  Instead, to make a change (e.g., to update an image version or scale a deployment), you change the **YAML file** in your Git repository.
  3.  You commit the change and open a pull request.
  4.  Once the pull request is approved and merged, an automated tool (like **Argo CD** or **Flux**) detects that the state defined in Git has changed.
  5.  This tool then automatically runs `kubectl apply` to synchronize the cluster's state with the desired state defined in the Git repository.

This gives you a full, version-controlled audit trail of every change ever made to your production environment.

---

## 6. Summary and Mastery Checklist

-   [ ] I can list the main steps for deploying an application, from `docker build` to `kubectl apply`.
-   [ ] I know that a **Deployment** YAML file is needed to define how to run my Pods.
-   [ ] I know that a **Service** YAML file is needed to expose my Deployment.
-   [ ] I can use `kubectl apply -f .` to apply all the YAML files in a directory.
-   [ ] I can use `kubectl get pods` and `kubectl get services` to check the status of my deployment.
-   [ ] I can describe the basic idea of "GitOps": Git is the single source of truth for the cluster's state.

---

## 7. Research and References

-   **Kubernetes Docs - Deploy an Application**: A hands-on tutorial.
-   **"GitOps: What you need to know"**: An article from Red Hat.
-   **Argo CD**: A popular open-source GitOps continuous delivery tool for Kubernetes. [Link](https://argo-cd.readthedocs.io/en/stable/)
-   **Flux**: Another popular CNCF project for GitOps. [Link](https://fluxcd.io/)
