# Managing Configuration: ConfigMaps and Secrets

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** why you should decouple configuration from your application image.
-   **Define** a ConfigMap and describe its use cases for non-sensitive configuration data.
-   **Define** a Secret and describe its use cases for sensitive data like passwords and API keys.
-   **Describe** the different ways to mount ConfigMaps and Secrets into a Pod (as environment variables or as files).
-   **Explain** the security implications of using Secrets and the importance of RBAC.

---

## 2. Introduction: Decoupling Configuration

A core principle of building portable, scalable applications (as outlined in the [Twelve-Factor App methodology](https://12factor.net/)) is to **strictly separate configuration from code**.

You should never bake configuration values like database URLs or feature flags directly into your container image. Why?
-   An image should be immutable and identical across all environments (dev, staging, prod).
-   You don't want to rebuild your image just to change a configuration value.
-   You must not store sensitive data like API keys in your image, where it could be exposed.

Kubernetes provides two primary objects for managing this external configuration: **ConfigMaps** for non-sensitive data and **Secrets** for sensitive data.

---

## 3. ConfigMaps: For Non-Sensitive Data

A **ConfigMap** is an API object used to store non-confidential data in key-value pairs. Pods can consume this data as environment variables, command-line arguments, or as configuration files in a volume.

-   **Use Cases**:
    -   Application settings (e.g., `log_level: "debug"`, `ui_theme: "dark"`).
    -   Feature flags.
    -   Database hostnames or other service connection details.
    -   The entire contents of a configuration file, like `nginx.conf`.

-   **Creating a ConfigMap**:
    You can create one imperatively from the command line...
    ```bash
    kubectl create configmap my-app-config --from-literal=LOG_LEVEL=info --from-literal=API_URL=http://my-api
    ```
    ...or declaratively using a YAML file, which is the recommended approach for GitOps.
    ```yaml
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: my-app-config
    data:
      LOG_LEVEL: "info"
      API_URL: "http://my-api"
    ```

---

## 4. Secrets: For Sensitive Data

A **Secret** is an object that stores a small amount of sensitive data such as a password, a token, or a key.

-   **How it's different from a ConfigMap**:
    -   **Intent**: Using a Secret communicates that the data is sensitive.
    -   **Storage**: On the `etcd` cluster, Secrets are stored as Base64 encoded values. **This is encoding, NOT encryption.** It offers no real protection. True protection comes from configuring encryption-at-rest for your etcd data and using Role-Based Access Control (RBAC) to limit who can read Secret objects.
    -   **Auto-mounting**: Kubernetes can automatically create and mount secrets for its own internal components (e.g., for accessing the Kubernetes API from a Pod).

-   **Use Cases**:
    -   Database passwords.
    -   API keys and tokens.
    -   TLS/SSL certificates for HTTPS.

-   **Creating a Secret**:
    ```bash
    # Note: the string values must be base64 encoded first
    # echo -n 'admin' | base64 -> YWRtaW4=
    # echo -n 'supersecret' | base64 -> c3VwZXJzZWNyZXQ=
    ```
    ```yaml
    apiVersion: v1
    kind: Secret
    metadata:
      name: my-db-credentials
    type: Opaque # The default type, for arbitrary user-defined data
    data:
      username: YWRtaW4=
      password: c3VwZXJzZWNyZXQ=
    ```

---

## 5. Using ConfigMaps and Secrets in Pods

There are two primary ways to expose this data to your application containers inside a Pod.

### 1. As Environment Variables

You can inject key-value pairs from a ConfigMap or Secret directly into the container as environment variables. This is the most common method.

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
spec:
  containers:
    - name: my-container
      image: my-app-image
      envFrom: # An array of sources
        - configMapRef:
            name: my-app-config # Injects LOG_LEVEL and API_URL
        - secretRef:
            name: my-db-credentials # Injects username and password
```

### 2. As a Volume Mount

You can mount an entire ConfigMap or Secret as a volume. Each key becomes a file in the mount directory, and the value becomes the content of that file. This is useful when your application expects a configuration file (e.g., `nginx.conf`).

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
spec:
  containers:
    - name: my-container
      image: my-app-image
      volumeMounts:
      - name: config-volume
        mountPath: /etc/config
  volumes:
    - name: config-volume
      configMap:
        name: my-app-config
```
After this, a file named `LOG_LEVEL` with the content `info` would appear at `/etc/config/LOG_LEVEL` inside the container.

---

## 6. Deliberate Practice

1.  **Create a ConfigMap**: Create a `ConfigMap` named `app-settings` with two keys: `environment` set to `development` and `features.beta.enabled` set to `true`.
2.  **Create a Secret**: Create a Secret named `api-keys` with a key `google-maps-api-key` and a fictional secret value (remember to Base64 encode it).
3.  **Create a Pod**: Write a Pod manifest for a simple `busybox` container.
4.  **Mount as Env Vars**: Configure the Pod to mount both the `environment` key from the ConfigMap and the `google-maps-api-key` from the Secret as environment variables.
5.  **Verify**: Use `kubectl exec -it <pod-name> -- env` to shell into the container and run the `env` command to confirm that the environment variables are set correctly.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain why configuration should be kept outside of my container image.
-   [ ] I know to use a **ConfigMap** for non-sensitive, plain-text configuration data.
-   [ ] I know to use a **Secret** for sensitive data like passwords and tokens.
-   [ ] I understand that Secrets are only Base64 encoded by default and rely on RBAC and at-rest encryption for true security.
-   [ ] I can describe the two ways to consume this data in a Pod: as **environment variables** or as **volume-mounted files**.

---

## 13. Research and References

-   **Kubernetes Documentation - ConfigMaps**: [Link](https://kubernetes.io/docs/concepts/configuration/configmap/)
-   **Kubernetes Documentation - Secrets**: [Link](https://kubernetes.io/docs/concepts/configuration/secret/)
-   **"The Twelve-Factor App" - Config**: [Link](https://12factor.net/config)
