# Helm and Resource Management in Kubernetes

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** the importance of managing container resources (CPU and Memory).
-   **Define** `requests` and `limits` in a Pod specification and explain the difference between them.
-   **Describe** the three Kubernetes Quality of Service (QoS) classes.
-   **Define** Helm and its role as a package manager for Kubernetes.
-   **Explain** the core concepts of Helm: Charts, Repositories, and Releases.
-   **Use** the `helm` CLI to install, upgrade, and manage a third-party application.

---

## Part 1: Resource Management

### 2. Introduction: Why Manage Resources?

When you run a Pod on a node, it consumes resources like CPU and memory. By default, a Pod can consume as many resources as it wants, up to the node's limit. This can cause problems:

-   **Resource Starvation**: A single, runaway Pod could consume all the CPU on a node, starving other critical applications.
-   **Scheduling Problems**: The `kube-scheduler` needs to know how much resource a Pod requires to find a suitable node to place it on. Without this information, it can't make smart decisions.

To solve this, Kubernetes allows you to specify **resource requests** and **resource limits** for each container in your Pods.

### 3. Requests and Limits

In your container spec, you can add a `resources` block:

```yaml
spec:
  containers:
  - name: my-container
    image: my-image
    resources:
      requests:
        memory: "64Mi" # 64 Mebibytes
        cpu: "250m"   # 250 millicores (0.25 of a core)
      limits:
        memory: "128Mi"
        cpu: "500m"
```

-   **`requests`**: This is the amount of resource that is **guaranteed** for the container. The scheduler uses this value to find a node with enough available capacity to run the Pod.
-   **`limits`**: This is the **maximum** amount of resource the container is allowed to use. If a container tries to exceed its memory limit, it will be terminated (OOMKilled). If it tries to exceed its CPU limit, it will be throttled.

### 4. Quality of Service (QoS) Classes

Based on the `requests` and `limits` you set, Kubernetes categorizes Pods into one of three QoS classes, which affects how they are scheduled and prioritized.

1.  **Guaranteed**:
    -   *Condition*: Every container in the Pod has a memory and CPU `limit` that is equal to its `request`.
    -   *Priority*: Highest. These Pods are the last to be killed if the node runs out of resources. Ideal for critical workloads like databases.

2.  **Burstable**:
    -   *Condition*: The Pod has at least one container with a memory or CPU `request` that is less than its `limit`.
    -   *Priority*: Medium. These Pods are allowed to "burst" and use more resources up to their limit if available, but they have fewer guarantees than `Guaranteed` Pods.

3.  **BestEffort**:
    -   *Condition*: The Pod has no memory or CPU `requests` or `limits` set at all.
    -   *Priority*: Lowest. These Pods are the first to be killed if the node is under pressure. Suitable for low-priority, interruptible tasks.

---

## Part 2: Helm - The Package Manager

### 5. The Problem with Many YAML Files

As your applications grow, so does the number of Kubernetes objects you need to manage (Deployments, Services, ConfigMaps, Secrets, etc.). Managing all these individual YAML files for different environments can become incredibly complex and repetitive.

### 6. Helm: The Solution

**Helm** is the de facto package manager for Kubernetes. It allows you to package all your related Kubernetes resources into a single unit called a **Chart**, which can then be versioned, shared, and deployed as a single entity.

-   **Chart**: A collection of files that describe a related set of Kubernetes resources. It's like a `yum` or `apt` package, but for Kubernetes. Charts use a powerful templating engine, so you can customize your application for different environments without duplicating files.
-   **Repository**: A place where Charts can be collected and shared. Helm comes pre-configured with a stable repository, and you can add others.
-   **Release**: An instance of a Chart running in a Kubernetes cluster. You can install the same chart multiple times into the same cluster, and each one will be a separate `release`.

### 7. Using Helm

Here is a typical workflow for using Helm to install a popular application like `prometheus` (a monitoring tool).

```bash
# 1. Add the repository that contains the prometheus chart
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts

# 2. Update your local list of charts
helm repo update

# 3. Search for the chart to see available versions
helm search repo prometheus-community/prometheus

# 4. Install the chart into your cluster. This creates a new "release".
# We'll name the release "my-monitor" and put it in a new "monitoring" namespace.
helm install my-monitor prometheus-community/prometheus --namespace monitoring --create-namespace

# 5. List your releases
helm list -n monitoring

# 6. Upgrade the release (e.g., to a new version or with a new configuration)
# (This would typically involve changing a values.yaml file)
helm upgrade my-monitor prometheus-community/prometheus -n monitoring

# 7. Uninstall the release
helm uninstall my-monitor -n monitoring
```

---

## 8. Deliberate Practice

1.  **Resource Management**:
    -   Take an existing Deployment YAML (e.g., for `nginx`).
    -   Add a `resources` block to the container spec.
    -   Set `requests` for CPU to `100m` and memory to `50Mi`.
    -   Set `limits` for CPU to `200m` and memory to `100Mi`.
    -   Apply the change. What QoS class does this Pod belong to? (Answer: Burstable).
2.  **Helm**:
    -   Install the Helm CLI on your local machine.
    -   Add the `bitnami` repository: `helm repo add bitnami https://charts.bitnami.com/bitnami`.
    -   Install a `wordpress` chart from the bitnami repo. Give it a release name of your choice.
    -   Use `kubectl get pods` to see all the different Pods that the chart created.
    -   Use `helm list` to see your release.
    -   Uninstall the release using `helm uninstall`.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that `resources.requests` guarantees a certain amount of resources for a container and is used for scheduling.
-   [ ] I know that `resources.limits` sets a maximum ceiling for resource consumption.
-   [ ] I can name the three QoS classes: **Guaranteed, Burstable, BestEffort**.
-   [ ] I can explain that **Helm** helps manage the complexity of deploying applications by packaging resources into **Charts**.
-   [ ] I can use the `helm install`, `helm list`, and `helm uninstall` commands.

---

## 13. Research and References

-   **Kubernetes Documentation - Resource Management**: [Link](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/)
-   **Helm Documentation**: [Link](https://helm.sh/docs/)
-   **Artifact Hub**: A web-based application for finding, installing, and publishing Kubernetes packages. [Link](https://artifacthub.io/)
