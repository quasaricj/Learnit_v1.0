# Kubernetes Architecture and Components

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** container orchestration and explain the problems it solves (e.g., fault tolerance, scaling).
-   **Define** Kubernetes (K8s) and its role as a container orchestrator.
-   **Describe** the high-level architecture of a Kubernetes cluster: Control Plane and Worker Nodes.
-   **List** the main components of the Control Plane (API Server, etcd, Scheduler, Controller Manager).
-   **List** the main components of a Worker Node (Kubelet, Kube-Proxy).
-   **Explain** that Kubernetes is a declarative system.
-   **Interact** with a Kubernetes cluster using `kubectl`.

---

## 2. Introduction: The Need for Orchestration

Docker and Docker Compose are great for running containers on a single machine. But what happens in a production environment with hundreds of containers running across a cluster of dozens of servers?
-   How do you handle a server crashing?
-   How do you scale a service to handle more traffic?
-   How do you perform a rolling update to a new version of your application without downtime?

This is the job of a **container orchestrator**. A container orchestrator is a system that automates the deployment, scaling, and management of containerized applications. **Kubernetes** (often abbreviated as **K8s**) is the open-source, de facto standard for container orchestration.

---

## 3. Kubernetes: A Declarative System

The core idea of Kubernetes is that it is a **declarative** system.
-   You don't tell Kubernetes *how* to do something (imperative).
-   You write a configuration file (in YAML) that describes the **desired state** of your application (declarative). For example: "I want to be running 3 instances of my web server image."
-   You apply this configuration to the Kubernetes cluster.
-   Kubernetes's job is to work continuously to make the **actual state** of the cluster match your **desired state**. If you asked for 3 instances and one of them crashes, Kubernetes will automatically start a new one to get the state back to 3.

---

## 4. High-Level Architecture: The Cluster

A Kubernetes cluster consists of a set of machines, called **nodes**, that run your containerized applications. Every cluster has at least one **Worker Node** and at least one **Control Plane** (formerly known as the Master Node).

### The Control Plane: The Brains

The Control Plane's components make global decisions about the cluster (e.g., scheduling) and detect and respond to cluster events.

-   **`kube-apiserver` (API Server)**: The **frontend** for the Kubernetes control plane. It exposes the Kubernetes API. This is the component you interact with when you use the `kubectl` command-line tool.
-   **`etcd`**: A consistent and highly-available key-value store used as Kubernetes's backing store for all cluster data. It is the **single source of truth** for the cluster's state.
-   **`kube-scheduler` (Scheduler)**: Watches for newly created Pods (the smallest deployable unit) that have no assigned node, and selects a node for them to run on based on resource requirements, policies, etc.
-   **`kube-controller-manager` (Controller Manager)**: Runs controller processes. A controller is a control loop that watches the shared state of the cluster through the API server and makes changes to move the current state towards the desired state. (e.g., the "Replication Controller" ensures that the correct number of replicas for a service are running).

### Worker Nodes: The Brawn

Worker nodes are the machines (VMs or physical servers) where your applications actually run.

-   **`kubelet`**: An agent that runs on each worker node. It makes sure that containers are running in a Pod as described by the Control Plane.
-   **`kube-proxy`**: A network proxy that runs on each node in your cluster, implementing part of the Kubernetes Service concept (enabling network communication to your Pods from inside or outside the cluster).
-   **Container Runtime**: The software that is responsible for running containers. Docker is the most famous, but others like `containerd` and `CRI-O` are also common.

![Kubernetes Architecture Diagram](https://d33wubrfki0l68.cloudfront.net/2c892435165d79752f127e19b1689b78dbe83f8d/a31b2/images/docs/components-of-kubernetes.svg)

---

## 5. Interacting with Kubernetes: `kubectl`

`kubectl` is the command-line tool for interacting with the Kubernetes API Server. It allows you to deploy applications, inspect and manage cluster resources, and view logs.

-   `kubectl get nodes`: List all the nodes in the cluster.
-   `kubectl get pods`: List all the Pods.
-   `kubectl apply -f my-app.yaml`: Apply a configuration file to the cluster.
-   `kubectl describe pod <pod-name>`: Get detailed information about a specific Pod.
-   `kubectl logs <pod-name>`: View the logs from a container in a Pod.

---

## 6. Deliberate Practice

1.  **Set Up a Local Cluster**:
    -   Install `kubectl`.
    -   Install a local Kubernetes cluster tool. Options include:
        -   **Docker Desktop**: Has a built-in, single-node Kubernetes cluster you can enable.
        -   **Minikube**: A tool that runs a single-node Kubernetes cluster inside a VM on your laptop.
2.  **Explore Your Cluster**:
    -   Start your local cluster.
    -   Run `kubectl get nodes` to see your single node.
    -   Run `kubectl get pods -A` to see all the system pods that make up the Control Plane running in the `kube-system` namespace.
3.  **Analyze a YAML file**: Look up a simple "nginx deployment" YAML file for Kubernetes. Try to identify the "desired state" it is defining.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that a container orchestrator like Kubernetes automates the deployment, scaling, and management of containers.
-   [ ] I know that Kubernetes is a **declarative** system where I define the "desired state".
-   [ ] I can describe the two main parts of a cluster: the **Control Plane** (the brain) and the **Worker Nodes** (where apps run).
-   [ ] I can name the **API Server** as the main entry point to the Control Plane.
-   [ ] I can name the **Kubelet** as the agent that runs on each worker node.
-   [ ] I know that `kubectl` is the command-line tool for talking to a Kubernetes cluster.

---

## 13. Research and References

-   **Kubernetes Documentation - Components of Kubernetes**: [Link](https://kubernetes.io/docs/concepts/overview/components/)
-   **"The Illustrated Children's Guide to Kubernetes"**: A famous, surprisingly effective and simple explanation of what Kubernetes is.
-   **"Kubernetes by Example" by the Red Hat team**: Hands-on examples for learning Kubernetes concepts.
-   **Katacoda**: An interactive, in-browser platform with scenarios for learning Kubernetes without installing anything. [Link](https://www.katacoda.com/courses/kubernetes)
