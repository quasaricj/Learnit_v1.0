# Kubernetes Workloads: Pods, ReplicaSets, Deployments, and Services

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a Pod and its role as the smallest deployable unit in Kubernetes.
-   **Define** a ReplicaSet and explain how it ensures a specific number of Pod replicas are running.
-   **Define** a Deployment and explain how it manages ReplicaSets to provide declarative updates and rollbacks.
-   **Define** a Service and explain how it provides a stable network endpoint for a set of Pods.
-   **Explain** the relationship between these four objects.
-   **Write** a basic YAML manifest for a Deployment and a Service.

---

## 2. Introduction: From Container to Application

In the last section, we learned about the Kubernetes architecture. Now, we'll learn about the fundamental objects you create to run an application. While containers are the building blocks, Kubernetes doesn't run containers directly. Instead, it wraps them in a higher-level structure called a **Pod**.

---

## 3. Pods: The Atomic Unit of Kubernetes

A **Pod** is the smallest and simplest unit in the Kubernetes object model that you create or deploy.

-   **What it is**: A Pod represents a single instance of a running process in your cluster. It encapsulates one or more containers (like Docker containers), storage resources, a unique network IP, and options that govern how the container(s) should run.
-   **The "one container per Pod" model**: While a Pod *can* hold multiple containers, it's most common to have just one. You'd only use multiple containers if they are tightly coupled and need to share resources like networking and storage (e.g., a web server and a "sidecar" container that pulls logs from it).
-   **Pods are Ephemeral**: This is a critical concept. Pods are mortal. They are created, and when they are no longer needed, they are destroyed. If a node fails, the Pods on that node are lost. Each Pod gets its own unique IP address, but that IP address is not stable. You should **never** connect to a Pod directly by its IP address from another part of your application.

---

## 4. ReplicaSets: Ensuring Availability

Since Pods are ephemeral, what happens if one dies? We need a way to ensure that a specified number of Pods are always running. This is the job of a **ReplicaSet**.

-   **What it is**: A ReplicaSet's purpose is to maintain a stable set of replica Pods running at any given time. It guarantees the availability of a specified number of identical Pods.
-   **How it works**: You define a Pod template and the number of desired replicas (e.g., `replicas: 3`). The ReplicaSet controller will then work to ensure there are always 3 Pods matching that template running in the cluster. If one dies, the controller creates a new one.
-   **Direct Usage**: You will rarely, if ever, create a ReplicaSet directly. Instead, you will use Deployments, which manage ReplicaSets for you.

---

## 5. Deployments: Managing Your Application

The **Deployment** is the workload object you will interact with most frequently. It provides a high-level, declarative way to manage your application's lifecycle.

-   **What it is**: A Deployment controller provides declarative updates for Pods and ReplicaSets. You describe a desired state in a Deployment object, and the Deployment controller changes the actual state to the desired state at a controlled rate.
-   **Key Feature: Rolling Updates**: This is the killer feature. When you want to update your application to a new version (e.g., a new container image), you just update your Deployment's YAML file. The Deployment will:
    1.  Create a new ReplicaSet for the new version.
    2.  Slowly scale up the new ReplicaSet (creating new Pods) while simultaneously scaling down the old ReplicaSet.
    3.  This ensures your application is updated with **zero downtime**.
-   **Rollbacks**: If something goes wrong with the new version, you can easily tell the Deployment to roll back to the previous version.

**Relationship so far:** A `Deployment` manages a `ReplicaSet`. The `ReplicaSet`'s job is to create and manage a specific number of `Pods`.

---

## 6. Services: Stable Networking

We have a problem. Deployments create and destroy Pods, and each Pod has its own temporary IP address. How can other parts of your application (or external users) reliably connect to your app? This is solved by a **Service**.

-   **What it is**: A Service is an abstract way to expose an application running on a set of Pods as a network service. It provides a **stable, single endpoint** (a single IP address and DNS name) for a group of Pods.
-   **How it works**: A Service uses a "selector" to find all Pods that match certain labels (e.g., `app: my-web-server`). Any traffic sent to the Service's IP address will be automatically load-balanced across all the matching Pods. Even as Pods are created and destroyed by the Deployment, the Service stays the same, and it keeps track of which Pods are currently healthy and available.

---

## 7. Putting It All Together

![Deployment, Service, ReplicaSet, Pods](https://i.stack.imgur.com/9n5lR.png)

1.  You create a **Deployment** to define the desired state of your application (e.g., "run 3 replicas of my web server using this image").
2.  The Deployment creates a **ReplicaSet**.
3.  The ReplicaSet creates and monitors the **Pods**, ensuring the correct number are always running.
4.  You create a **Service** that uses labels to select those Pods and expose them at a single, stable network address.

---

## 8. Deliberate Practice

1.  **Write a Deployment YAML**:
    -   Find a simple tutorial for creating an `nginx` Deployment.
    -   Create a file named `nginx-deployment.yaml`.
    -   Define a Deployment that runs 2 replicas of the `nginx:latest` image.
    -   Apply it to your cluster: `kubectl apply -f nginx-deployment.yaml`.
    -   Check the status: `kubectl get deployments`, `kubectl get replicasets`, `kubectl get pods`.
2.  **Write a Service YAML**:
    -   Create a file named `nginx-service.yaml`.
    -   Define a `NodePort` Service that exposes the nginx Pods on port 80.
    -   Apply it: `kubectl apply -f nginx-service.yaml`.
    -   Check the service: `kubectl get services`. Find the port it is exposed on and try to access it in your browser.
3.  **Perform a Rolling Update**:
    -   Edit your `nginx-deployment.yaml` and change the image to a different version, e.g., `nginx:1.21.6`.
    -   Apply the change: `kubectl apply -f nginx-deployment.yaml`.
    -   Watch the update happen: `kubectl get pods -w`. You will see new pods being created and old ones being terminated.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that a **Pod** is the smallest unit and is ephemeral.
-   [ ] I understand that a **ReplicaSet** ensures a specific number of Pods are running, but I won't create them directly.
-   [ ] I know that a **Deployment** is what I will use to manage my application, perform rolling updates, and handle rollbacks.
-   [ ] I understand that a **Service** provides a stable IP address and DNS name to access a group of Pods.
-   [ ] I can sketch the relationship: Deployment -> ReplicaSet -> Pods, with a Service sitting in front.

---

## 13. Research and References

-   **Kubernetes Documentation - Workloads**: [Link](https://kubernetes.io/docs/concepts/workloads/)
-   **Kubernetes Documentation - Services**: [Link](https://kubernetes.io/docs/concepts/services-networking/service/)
-   **"Kubernetes Up & Running" by Kelsey Hightower et al.**: An excellent book that covers these concepts in depth.
