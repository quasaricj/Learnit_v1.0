# Scaling and Auto-Scaling in Kubernetes

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** scaling and explain its importance for application availability and performance.
-   **Differentiate** between Vertical Scaling and Horizontal Scaling.
-   **Perform** manual scaling of a Deployment using `kubectl`.
-   **Define** the role of the Horizontal Pod Autoscaler (HPA).
-   **Explain** how the HPA uses metrics (like CPU utilization) to automatically scale Deployments.
-   **Define** the role of the Cluster Autoscaler (CA) in scaling the number of nodes in a cluster.

---

## 2. Introduction: Why Scaling Matters

One of the primary reasons to use an orchestrator like Kubernetes is for **scaling**. In production, application traffic is rarely constant. You have peak periods and quiet periods. Scaling is the process of adjusting your application's capacity to meet the current demand.

-   **Scaling Out** (increasing capacity) ensures your application remains responsive and available during high traffic.
-   **Scaling In** (decreasing capacity) is equally important, as it allows you to save costs by not running unnecessary resources during quiet periods.

---

## 3. Vertical vs. Horizontal Scaling

There are two fundamental ways to scale an application:

-   **Vertical Scaling (Scaling Up)**: This means adding more resources (like CPU or memory) to your *existing* machines.
    -   *Analogy*: Swapping the engine in your car for a more powerful one.
    -   *In Kubernetes*: This involves increasing the resource `requests` and `limits` for your Pods. This is less common for stateless applications and has physical limits.

-   **Horizontal Scaling (Scaling Out)**: This means adding *more machines* (or Pods) to your pool of resources.
    -   *Analogy*: Adding more cars to your fleet.
    -   *In Kubernetes*: This means increasing the number of replicas in your Deployment. This is the most common and powerful scaling model for stateless applications, as it allows for massive scale.

Kubernetes is primarily designed for **horizontal scaling**.

---

## 4. Manual Scaling

You can manually scale a Deployment at any time using `kubectl`. This is useful for responding to anticipated events, like a planned marketing campaign.

Let's say you have a Deployment named `my-web-app` running 2 replicas.

```bash
# Check the current number of replicas
kubectl get deployment my-web-app

# Scale the deployment up to 5 replicas
kubectl scale deployment my-web-app --replicas=5

# Verify the change
kubectl get deployment my-web-app # Will show 5/5 ready
kubectl get pods # You will see 5 pods running
```
To scale back down, you simply run the command again with a lower number of replicas.

---

## 5. Auto-Scaling: The Horizontal Pod Autoscaler (HPA)

Manual scaling is useful, but the real power of Kubernetes comes from **auto-scaling**. The **Horizontal Pod Autoscaler (HPA)** automatically scales the number of Pods in a Deployment, ReplicaSet, or StatefulSet based on observed metrics.

-   **How it works**:
    1.  The HPA is a controller that periodically checks metrics from a source called the **Metrics Server**.
    2.  The most common metric to use is **CPU utilization**.
    3.  You create an HPA object and define a target utilization, for example, "keep the average CPU utilization across all Pods at 50%".
    4.  If the average CPU usage climbs to 75%, the HPA will tell the Deployment to scale out (add more Pods) to bring the average back down.
    5.  If the average CPU usage drops to 25%, the HPA will tell the Deployment to scale in (remove Pods) to save resources.

-   **Creating an HPA**:
    You can create an HPA for an existing deployment with a single command:
    ```bash
    # This will create an HPA that maintains between 2 and 10 pods
    # for the my-web-app deployment, targeting 50% CPU utilization.
    kubectl autoscale deployment my-web-app --cpu-percent=50 --min=2 --max=10
    ```

---

## 6. Auto-Scaling the Cluster: The Cluster Autoscaler (CA)

The HPA adds and removes Pods. But what happens if you scale out so much that you run out of space on your existing nodes?

This is the job of the **Cluster Autoscaler (CA)**. This is a component (specific to your cloud provider, e.g., AWS, GCP, Azure) that automatically adjusts the number of **nodes** in your cluster.

-   **How it works**:
    -   **Scaling Up**: If the CA sees Pods that are "Pending" because there are no nodes with enough resources to run them, it will provision a new node from the cloud provider.
    -   **Scaling Down**: If the CA notices that a node has been underutilized for a period of time and its Pods can be safely moved elsewhere, it will drain the node and terminate it to save costs.

**HPA and CA work together**: The HPA creates more Pods in response to application load. If those Pods can't be scheduled, the CA creates more nodes to accommodate them.

---

## 7. Deliberate Practice

1.  **Deploy an App**: Deploy a simple application, like the `nginx` deployment from the previous lesson.
2.  **Manual Scaling**:
    -   Scale the deployment to 3 replicas using `kubectl scale`.
    -   Verify that 3 pods are running.
    -   Scale the deployment back down to 1 replica.
3.  **Set up the Metrics Server**: For HPA to work, you need the Metrics Server installed. If you are using Minikube, you can enable it with `minikube addons enable metrics-server`. For other clusters, you may need to install it manually.
4.  **Create an HPA**:
    -   Create an HPA for your `nginx` deployment, targeting 80% CPU utilization, with a min of 1 and max of 5 replicas. `kubectl autoscale deployment ...`
    -   Check its status with `kubectl get hpa`.
5.  **(Advanced) Generate Load**: To see the HPA in action, you need to generate load. One way is to run a temporary pod and send a loop of requests: `kubectl run -it --rm load-generator --image=busybox /bin/sh` and then `while true; do wget -q -O- http://<nginx-service-ip>; done`. Watch the HPA and see the pod count increase.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain the difference between **Horizontal Scaling** (more pods) and **Vertical Scaling** (more powerful pods).
-   [ ] I know that Kubernetes excels at Horizontal Scaling.
-   [ ] I can use the `kubectl scale` command to manually change the number of replicas in a Deployment.
-   [ ] I understand that the **Horizontal Pod Autoscaler (HPA)** automatically scales the number of *Pods* based on metrics like CPU.
-   [ ] I understand that the **Cluster Autoscaler (CA)** automatically scales the number of *Nodes* in the cluster if there is not enough capacity.

---

## 13. Research and References

-   **Kubernetes Documentation - Horizontal Pod Autoscaler**: [Link](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/)
-   **Kubernetes Documentation - Cluster Autoscaler**: [Link](https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler) (Note: this is a GitHub link as it's a separate project)
-   **"Kubernetes Patterns" by Bilgin Ibryam & Roland Huß**: Discusses scaling patterns in detail.
