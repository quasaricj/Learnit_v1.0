# Deploying Applications to AWS (EC2, ECS, Lambda)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Identify** the three main compute deployment models on AWS: IaaS (EC2), Containers (ECS), and Serverless (Lambda).
- **Describe** the process of deploying an application to an EC2 instance.
- **Define** ECS (Elastic Container Service) and differentiate it from EKS (Elastic Kubernetes Service).
- **Describe** the process of deploying a containerized application using ECS.
- **Define** serverless computing and the role of AWS Lambda.
- **Describe** the process of deploying a function using AWS Lambda.
- **Compare** the three models based on control, cost, and operational overhead.

---

## 2. Introduction: "Where do I run my code?"

Once you have a working application, you need to decide where and how to run it in the cloud. AWS, like other major cloud providers, offers a spectrum of "compute" services, ranging from a raw virtual machine that you fully control to a "serverless" model where you only provide your code and the cloud provider handles everything else.

The three primary models are:
1.  **IaaS (Virtual Machines)**: AWS EC2
2.  **Containers as a Service**: AWS ECS
3.  **Functions as a Service (Serverless)**: AWS Lambda

---

## 3. Model 1: Deploying to AWS EC2 (IaaS)

- **Concept**: You provision a virtual server (an EC2 instance) and treat it like a traditional, physical server. You are responsible for everything from the operating system up.
- **Deployment Workflow**:
  1.  Launch a new EC2 instance from the AWS console or using an IaC tool.
  2.  Choose your operating system (e.g., Ubuntu).
  3.  Configure your security groups (firewall rules) to allow traffic (e.g., on port 80 for HTTP).
  4.  **SSH** into the instance.
  5.  **Manually install** all your application's dependencies (e.g., Node.js, your database, a web server like Nginx).
  6.  Copy your application code to the instance.
  7.  Start your application.
  8.  Configure a tool (like `pm2`) to run your application as a service and restart it if it crashes.
- **Pros**:
  - **Maximum Control and Flexibility**: You can install and configure anything you want.
- **Cons**:
  - **High Operational Overhead**: You are responsible for patching the OS, managing security, installing dependencies, and configuring the server. This is a lot of work.
  - **Difficult to Scale**: Scaling requires you to manually launch and configure new instances.

---

## 4. Model 2: Deploying with AWS ECS (Containers)

- **Concept**: A fully managed container orchestration service from AWS. It is a simpler, AWS-native alternative to Kubernetes.
- **Key Components**:
  - **Task Definition**: A blueprint that describes your application. It specifies the Docker image to use, the CPU and memory requirements, and other configuration.
  - **Service**: Manages the running of your Tasks. It is responsible for maintaining the desired number of tasks and for auto-scaling.
  - **Cluster**: A logical grouping of resources (either EC2 instances you manage, or a "serverless" backend managed by AWS called **Fargate**).
- **Deployment Workflow (with Fargate)**:
  1.  Containerize your application with a `Dockerfile`.
  2.  Push your Docker image to a registry (AWS ECR - Elastic Container Registry).
  3.  Create a **Task Definition** that points to your image.
  4.  Create a **Service** that uses your Task Definition and specifies the desired number of tasks to run.
  5.  ECS will then automatically provision the underlying infrastructure and run your containers for you.
- **Pros**:
  - **Manages the Servers for You (with Fargate)**: You just provide a container, and AWS handles the rest. No need to patch operating systems.
  - **Scalable and Resilient**: The ECS Service will automatically handle scaling and self-healing.
- **Cons**:
  - **Vendor Lock-in**: ECS is an AWS-specific technology.

---

## 5. Model 3: Deploying with AWS Lambda (Serverless)

- **Concept**: **Serverless computing** (or Functions as a Service - FaaS). You upload your code as a **Function**, and the cloud provider automatically runs it in response to an event. You do not manage any servers, containers, or runtimes.
- **Events**: A Lambda function can be triggered by many things:
  - An HTTP request from an **API Gateway**.
  - A new file being uploaded to an S3 bucket.
  - A message being added to a queue.
- **Deployment Workflow**:
  1.  Write your application logic as a single function (e.g., a Node.js function that takes an `event` object as input).
  2.  Package your function and its dependencies into a zip file.
  3.  Upload the package to Lambda and configure the event trigger (e.g., set up an API Gateway to trigger the function on a `GET` request to `/my-api`).
- **Pros**:
  - **Zero Server Management**: The ultimate "pay-as-you-go" model. You pay only for the compute time you consume, down to the millisecond. If your function is not running, you are paying nothing.
  - **Infinite Scalability**: The cloud provider will automatically scale your function to handle any amount of traffic, from one request per day to thousands per second.
- **Cons**:
  - **Constraints**: Functions are typically short-lived and have time limits on their execution. Not suitable for all workloads.
  - **Statelessness**: Functions are stateless, meaning you cannot store data in memory between executions. All state must be stored in an external database or cache.
  - **Cold Starts**: There can be a small amount of latency for the first request as the provider spins up an environment for your function.

---

## 6. Comparison

| Feature                 | EC2 (IaaS)                       | ECS with Fargate (Containers)       | Lambda (Serverless)                  |
| ----------------------- | -------------------------------- | ----------------------------------- | ------------------------------------ |
| **Unit of Deployment**  | Virtual Machine                  | Container                           | Function                             |
| **You Manage**          | OS, Runtimes, App Code           | App Code (as a container)           | Just the App Code                    |
| **Scaling**             | Manual / Complex Auto-Scaling    | Automated Container Scaling         | Automatic and "Infinite"             |
| **Cost Model**          | Pay per hour/second for the VM   | Pay per hour/second for containers  | Pay per execution and duration (ms)  |
| **Best for**            | Legacy apps, full control        | Microservices, modern applications  | Event-driven, APIs, spiky workloads  |

---

## 7. Summary and Mastery Checklist

-   [ ] I can name the three main AWS compute models: **EC2** (VMs), **ECS** (Containers), and **Lambda** (Serverless).
-   [ ] I understand that deploying to **EC2** gives me the most control but also the most operational responsibility.
-   [ ] I understand that **ECS with Fargate** is a managed service where I just provide a Docker container and AWS runs it for me.
-   [...][ ] I can define **serverless** (Lambda) as a model where I only provide my code as a function, and I pay only when it runs.

---

## 8. Research and References

-   **AWS - Types of Cloud Computing**: [Link](https://aws.amazon.com/types-of-cloud-computing/)
-   **"What is serverless?"**: A great overview.
-   **The Serverless Framework**: A popular open-source tool for building and deploying serverless applications.
-   **AWS Getting Started Guides**: AWS provides excellent hands-on tutorials for deploying applications to all three of these services.
