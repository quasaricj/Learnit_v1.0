# Deploying Applications to Azure (App Service, AKS, Functions)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Identify** the three main compute deployment models on Azure: PaaS (App Service), Containers (AKS), and Serverless (Functions).
- **Describe** Azure App Service as a PaaS offering for web applications.
- **Define** AKS (Azure Kubernetes Service) as a managed Kubernetes service.
- **Describe** Azure Functions as a serverless, event-driven compute service.
- **Draw parallels** between the core compute services of Azure and AWS.

---

## 2. Introduction: Azure's Compute Spectrum

Similar to AWS, Microsoft Azure offers a spectrum of compute services that allow you to choose the level of abstraction and control that is right for your application. The three primary models map very closely to the ones offered by AWS.

1.  **PaaS (Platform as a Service)**: Azure App Service
2.  **Containers as a Service**: Azure Kubernetes Service (AKS)
3.  **Functions as a Service (Serverless)**: Azure Functions

---

## 3. Model 1: Deploying to Azure App Service (PaaS)

- **Concept**: **Azure App Service** is a fully managed **Platform as a Service (PaaS)** for building, deploying, and scaling web apps and APIs. It is one of Azure's most popular services. You provide your code or a container, and App Service handles the rest.
- **Key Features**:
  - **Excellent Language Support**: Built-in support for .NET, .NET Core, Java, Ruby, Node.js, PHP, and Python.
  - **Deployment Slots**: You can deploy your app to a "staging" slot, run tests, and then "swap" it into the production slot with zero downtime. This makes releases very safe and easy.
  - **Built-in CI/CD**: Seamless integration with Azure DevOps, GitHub, and other CI/CD tools.
- **Deployment Workflow**:
  1.  Create an App Service Plan (which defines the underlying VM size and pricing).
  2.  Create a new Web App.
  3.  Configure a deployment source (e.g., your GitHub repository).
  4.  Push a change to your repository, and App Service will automatically pull the code, build it, and deploy it.
- **Pros**:
  - **Easy to Use**: A very gentle learning curve and a great developer experience.
  - **Fully Managed**: Azure handles all the OS patching, security, and infrastructure management.
- **AWS Parallel**: **AWS Elastic Beanstalk**. App Service is generally considered more modern and flexible.

---

## 4. Model 2: Deploying with Azure Kubernetes Service (AKS)

- **Concept**: **AKS** is Azure's **managed Kubernetes service**. It simplifies the process of deploying and managing a production-ready Kubernetes cluster.
- **Key Features**:
  - **Managed Control Plane**: Just like other managed K8s offerings, Azure manages the complex Kubernetes control plane for free. You only pay for your worker nodes.
  - **Deep Azure Integration**: Tightly integrated with other Azure services like Azure Active Directory for authentication, Azure Monitor for logging, and Azure Policy for governance.
- **Deployment Workflow**:
  1.  Provision an AKS cluster.
  2.  Connect to the cluster using `kubectl` (Azure's CLI makes it easy to download the correct kubeconfig).
  3.  The rest of the workflow is standard Kubernetes:
      - Push your Docker images to a registry (like Azure Container Registry - ACR).
      - Write your YAML manifests for your Deployments, Services, etc.
      - Apply the manifests using `kubectl apply`.
- **Pros**:
  - **Industry Standard**: Gives you the full power and portability of the open-source Kubernetes ecosystem.
- **AWS Parallel**: **AWS EKS (Elastic Kubernetes Service)**.

---

## 5. Model 3: Deploying with Azure Functions (Serverless)

- **Concept**: **Azure Functions** is Azure's serverless, event-driven compute platform. It is the direct equivalent of AWS Lambda.
- **Events (Triggers)**:
  - **HTTP Trigger**: Run a function in response to an HTTP request (for building APIs).
  - **Timer Trigger**: Run a function on a schedule.
  - **Blob Storage Trigger**: Run a function when a new file is uploaded to Azure Blob Storage.
  - Many other triggers for queues, databases, etc.
- **Deployment Workflow**:
  1.  Write your application logic as a function in your chosen language.
  2.  Use the Azure Functions Core Tools or the VS Code extension to create, test, and deploy your function.
  3.  The deployment package (a zip file) is uploaded to Azure, and the trigger is configured.
- **Pros**:
  - **Pay-per-execution**: The cost model is extremely efficient for event-driven or spiky workloads.
  - **Scalable**: Automatically scales to meet demand.
- **AWS Parallel**: **AWS Lambda**.

---

## 6. Comparison Table (AWS vs. Azure)

| Concept                      | AWS                               | Azure                                    |
| ---------------------------- | --------------------------------- | ---------------------------------------- |
| **Virtual Machines (IaaS)**  | EC2 (Elastic Compute Cloud)       | Azure Virtual Machines                   |
| **PaaS for Web Apps**        | Elastic Beanstalk                 | **App Service**                          |
| **Managed Kubernetes**       | EKS (Elastic Kubernetes Service)  | **AKS** (Azure Kubernetes Service)       |
| **Proprietary Orchestrator** | ECS (Elastic Container Service)   | Azure Service Fabric / Container Apps    |
| **Serverless (FaaS)**        | **Lambda**                        | **Azure Functions**                      |
| **Object Storage**           | S3                                | Blob Storage                             |
| **Container Registry**       | ECR (Elastic Container Registry)  | ACR (Azure Container Registry)           |

---

## 7. Summary and Mastery Checklist

-   [ ] I can name the three main Azure compute models: **App Service** (PaaS), **AKS** (Containers), and **Azure Functions** (Serverless).
-   [ ] I can describe **App Service** as a fully managed platform for web apps where I just provide my code.
-   [ ] I can define **AKS** as Azure's managed Kubernetes service.
-   [ ] I can define **Azure Functions** as a serverless, event-driven service similar to AWS Lambda.
-   [ ] I can identify the AWS equivalent for each of the core Azure compute services.

---

## 8. Research and References

-   **Azure Documentation - "Choose an Azure compute service"**: A guide from Microsoft on how to select the right service for your workload. [Link](https://docs.microsoft.com/en-us/azure/architecture/guide/technology-choices/compute-decision-tree)
-   **Azure App Service Documentation**: [Link](https://docs.microsoft.com/en-us/azure/app-service/)
-   **Azure Kubernetes Service (AKS) Documentation**: [Link](https://docs.microsoft.com/en-us/azure/aks/)
-   **Azure Functions Documentation**: [Link](https://docs.microsoft.com/en-us/azure/azure-functions/)
