# Automating cloud infrastructure with Terraform 
