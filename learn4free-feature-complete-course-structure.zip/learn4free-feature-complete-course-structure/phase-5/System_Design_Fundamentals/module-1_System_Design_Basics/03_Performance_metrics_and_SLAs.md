# Performance Metrics and SLAs

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** latency and throughput as key performance metrics.
- **Explain** the difference between average and percentile response times.
- **Understand** why high-percentile latencies (like p99) are important.
- **Define** an SLA (Service Level Agreement), SLI (Service Level Indicator), and SLO (Service Level Objective).
- **Interpret** a simple SLO, such as "99.9% of requests will be served in under 200ms".
- **Understand** that performance is about more than just the average case.

---

## 2. Introduction: Measuring Performance

"Performance" is a broad term. To design and operate a system effectively, we need to be able to measure it with specific, quantitative **metrics**. When we talk about the performance of a web service, we are usually concerned with two main metrics: **latency** and **throughput**.

These metrics are then used to define formal goals for the system's performance, which are captured in Service Level Objectives (SLOs) and Service Level Agreements (SLAs).

---

## 3. Core Performance Metrics

### Latency

- **What it is**: The time it takes for a single request to be processed. It is the duration between a client sending a request and receiving a response.
- **Also known as**: **Response Time**.
- **User Impact**: This is what the end-user directly experiences as the "speed" of your application.

### Throughput

- **What it is**: The number of requests that the system can handle in a given amount of time.
- **Also known as**: **Requests Per Second (RPS)** or Queries Per Second (QPS).
- **System Impact**: This is a measure of the system's total capacity.

Latency and throughput are related, but they are not the same. You can have a system with low latency for a single user, but low throughput (it can't handle many users at once).

### Averages vs. Percentiles

It is very common to measure the "average" response time of a system. However, the **average can be very misleading**.

- **Example**: Imagine 10 requests with the following latencies (in milliseconds): `[100, 110, 90, 105, 95, 115, 120, 100, 95, 2000]`.
- The **average** latency is `293ms`. This looks okay.
- But 9 out of 10 requests were fast (around 100ms), and one request was extremely slow (2000ms). The average hides this bad user experience.

**Percentiles** provide a much more accurate picture of the user experience.

- **`p50` (The Median)**: 50% of requests are faster than this value. (In the example above, the median is around 105ms).
- **`p95`**: 95% of requests are faster than this value. This is a common metric for the "typical" user experience.
- **`p99` (The 99th percentile)**: 99% of requests are faster than this value. This represents the experience of your "unluckiest" users.
- **`p99.9`**: The 99.9th percentile.

**High-percentile latencies (often called "tail latencies") are critical.** In a complex application, a single user request might involve calls to dozens of backend services. A user's request will be slow if *any one* of those backend calls is slow. Your worst-case performance is what defines your user's experience.

---

## 4. SLAs, SLOs, and SLIs

These are terms, popularized by Google's Site Reliability Engineering (SRE) practice, for defining and managing the reliability of a service.

- **SLI (Service Level Indicator)**:
  - **What it is**: A quantitative **measure** of some aspect of the level of service that is provided.
  - **It is the metric you are tracking.**
  - **Example**: The request latency, the error rate, or the system's throughput.

- **SLO (Service Level Objective)**:
  - **What it is**: A **target** value or range of values for an SLI.
  - **It is the goal you are trying to hit.** An SLO is a statement of your desired performance.
  - **Example**:
    - "99.9% of `GET /api/users` requests over a 28-day window will be served in under 200ms."
    - "The system will have 99.95% availability over a 28-day window."

- **SLA (Service Level Agreement)**:
  - **What it is**: A formal **contract** between a service provider and a customer. It defines the SLOs, and what happens if they are not met (e.g., the customer gets a refund).
  - **SLAs are about business and legal promises.**

As a developer or system designer, you are primarily concerned with **SLIs** (what to measure) and **SLOs** (what goals to set).

---

## 5. Summary and Mastery Checklist

-   [ ] I can define **Latency** as the time to serve a single request (response time).
-   [ ] I can define **Throughput** as the number of requests a system can handle per second.
-   [ ] I can explain why the **average** response time can be misleading.
-   [ ] I understand that **high-percentile** latencies (like p99) are important because they represent the worst-case user experience.
-   [ ] I can define an **SLI** as the metric, an **SLO** as the target for that metric, and an **SLA** as a business contract.
-   [ ] I can read and understand a simple SLO like "99.9% of requests should be faster than 200ms".

---

## 6. Research and References

-   **"Site Reliability Engineering: How Google Runs Production Systems"**: Chapter 4, "Service Level Objectives," is the definitive guide to this topic.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: The first chapter has an excellent discussion of latency percentiles.
-   **"The SRE Book - SLOs"**: The chapter from the Google SRE book is available online.
-   **"Everything You Know About Latency Is Wrong" by Gil Tene**: A famous talk that goes deep into the problems with using averages to measure performance.
