# High-Level vs. Low-Level Design

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Differentiate** between High-Level Design (HLD) and Low-Level Design (LLD).
- **Describe** the scope and purpose of High-Level Design.
- **Describe** the scope and purpose of Low-Level Design.
- **Identify** the typical artifacts produced during HLD and LLD.
- **Understand** the relationship between HLD and LLD in the system design process.
- **Relate** HLD and LLD to a real-world analogy.

---

## 2. Introduction: The Two Lenses of System Design

System design is the process of creating a blueprint for a software system. This process is typically viewed through two different "lenses" or levels of abstraction: High-Level Design and Low-Level Design. Both are essential for creating a successful system.

- **High-Level Design (HLD)** is about the **architecture** and the big picture. It's the "macro" view.
- **Low-Level Design (LLD)** is about the **implementation details** of a specific component. It's the "micro" view.

**Analogy: Building a House**
- **HLD** is the work of the **architect**. They create the overall floor plan, decide how many rooms there will be, where the kitchen and bathrooms will go, and how the different parts of the house connect. They are concerned with the structure and the overall flow.
- **LLD** is the work of the **contractor or engineer**. For a single room (like the kitchen), they create the detailed plans for the electrical wiring, the plumbing, the exact placement of the cabinets, and the specific materials to be used.

---

## 3. High-Level Design (HLD)

- **Purpose**: To define the overall architecture of the system and break it down into its major components. HLD focuses on the "what," not the "how."
- **Scope**: The entire system or a major sub-system.
- **Key Questions Answered by HLD**:
  - What is the overall architectural pattern (e.g., monolith, microservices, event-driven)?
  - What are the main components and services? (e.g., web server, application server, database, cache, message queue, authentication service).
  - How do these components interact with each other? What are the high-level API contracts?
  - Which technology stack will be used? (e.g., Node.js with a PostgreSQL database, or Java with a NoSQL database).
  - How will the system scale? How will it achieve reliability?
  - What are the major third-party integrations?

- **Typical Artifacts**:
  - **Architecture Diagrams**: High-level "box and arrow" diagrams showing the major components and data flows.
  - **Technology Stack Selection**: A document justifying the choice of languages, frameworks, and databases.
  - **Data Flow Diagrams**.

- **Who is involved**: System Architects, Senior/Principal Engineers.

---

## 4. Low-Level Design (LLD)

- **Purpose**: To provide a detailed, implementation-level design for a single component, module, or service that was identified during HLD. LLD focuses on the "how."
- **Scope**: A single, specific part of the system.
- **Key Questions Answered by LLD**:
  - What are the specific classes and modules needed for this component?
  - What are the attributes and methods of each class?
  - What are the detailed relationships between the classes (e.g., inheritance, composition)?
  - What is the detailed database schema for this component's data? This includes table names, column names, data types, and indexes.
  - What are the specific algorithms that will be used?
  - What are the exact request and response formats for the API endpoints?

- **Typical Artifacts**:
  - **UML Diagrams**: Class diagrams, sequence diagrams.
  - **Database Schema Diagrams**.
  - **API Specification**: A detailed contract for the API, often written using the OpenAPI/Swagger specification.
  - **Code Pseudocode**.

- **Who is involved**: The developers on the team that will be building the component.

---

## 5. The Relationship

HLD and LLD are not separate, independent processes. They are two ends of a spectrum.

`Requirements -> High-Level Design -> Low-Level Design -> Code`

1.  The HLD is created first to establish the overall structure and to break the large, complex problem into smaller, more manageable components.
2.  The LLD then takes one of these components and fleshes out all the details needed for a developer to actually start writing the code.

A good HLD makes the LLD easier by providing clear boundaries and responsibilities for each component. A good LLD then turns that architectural vision into a concrete and actionable plan for implementation.

---

## 6. Summary and Mastery Checklist

-   [ ] I can use the "architect vs. contractor" analogy to explain the difference between HLD and LLD.
-   [ ] I know that **High-Level Design** is about the overall **architecture** and major components.
-   [ ] I know that **Low-Level Design** is about the **implementation details** of a single component.
-   [ ] I can name an artifact of HLD (e.g., architecture diagram).
-   [ ] I can name an artifact of LLD (e.g., database schema, class diagram).
-   [ ] I understand that HLD comes first and provides the input for the LLD.

---

## 7. Research and References

-   **"System Design Interview – An insider's guide" by Alex Xu**: This book primarily focuses on High-Level Design, which is the main subject of system design interviews.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: A masterclass in the trade-offs involved in High-Level Design.
-   **"Clean Architecture" by Robert C. Martin**: A book that provides strong opinions on how to structure the components of your system (HLD).
-   **"Design Patterns: Elements of Reusable Object-Oriented Software" by the "Gang of Four"**: The classic book on design patterns, which are a key tool for Low-Level Design.
