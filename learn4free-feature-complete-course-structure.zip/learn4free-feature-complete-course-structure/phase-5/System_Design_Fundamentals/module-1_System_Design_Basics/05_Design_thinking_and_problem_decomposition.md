# Design Thinking and Problem Decomposition

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** design thinking as a user-centric approach to problem-solving.
- **List** the key phases of the design thinking process.
- **Define** problem decomposition and explain its importance in software engineering.
- **Apply** a structured framework to break down a large, ambiguous system design problem into smaller, manageable parts.
- **Understand** the importance of clarifying requirements and asking questions before starting a design.

---

## 2. Introduction: How to Approach a Vague Problem

In the real world and in system design interviews, you are rarely given a perfectly defined problem. You are more likely to get a vague, high-level request like:
- "Design a photo-sharing service."
- "Design a ride-sharing app."
- "Design a URL shortener."

How do you go from this ambiguous starting point to a concrete technical design? The answer lies in two key skills: **Design Thinking** to understand the user and the problem, and **Problem Decomposition** to break the technical challenge down.

---

## 3. Design Thinking: A User-Centric Approach

**Design thinking** is a process for creative problem-solving that puts the focus on the **user**. It's about understanding the people you're designing for and their needs, so that you can create a solution that is not just technically functional, but also desirable and useful.

### The Phases of Design Thinking

1.  **Empathize**: Understand your users. What are their goals? What are their pain points? This is about gathering requirements from the user's perspective.
2.  **Define**: Clearly articulate the problem you are trying to solve based on your understanding of the user.
3.  **Ideate**: Brainstorm a wide range of potential solutions.
4.  **Prototype**: Build a simple, low-fidelity version of your solution.
5.  **Test**: Get feedback from users on your prototype.

While you won't go through this full process in a 45-minute interview, the *mindset* is critical. **Always start by thinking about the user and the core features they need.**

---

## 4. Problem Decomposition: Breaking It Down

**Problem decomposition** is the process of breaking down a large, complex problem into smaller, more manageable, and well-defined subproblems. This is the single most important skill for tackling a system design question. It allows you to take an overwhelming problem and turn it into a structured conversation.

### A Framework for Decomposing a System Design Problem

This is a structured approach you can use in an interview or a real-world design session.

**Step 1: Clarify Requirements and Scope (Empathize & Define)**
- **Functional Requirements**: What are the core features the system must have?
  - *Example (for a photo-sharing app)*:
    - Users can upload photos.
    - Users can view photos in a feed.
    - Users can follow other users.
- **Non-Functional Requirements**: What are the constraints? This is where you ask about scale, performance, and availability.
  - How many users? (e.g., 10 million daily active users)
  - How many photo uploads per day?
  - What is the latency requirement for loading the feed?
- **Out of Scope**: What features are we *not* building for now? (e.g., video uploads, messaging). This is crucial for managing the scope of the problem.

**Step 2: Back-of-the-Envelope Estimation**
- Use the scale requirements to do some rough calculations. This will help you make informed decisions about your technology choices.
  - *Example*:
    - If you have 1 million photo uploads per day, how much storage do you need per year?
    - If you have 10 million users reading feeds, how many requests per second (RPS) will your feed service need to handle?

**Step 3: High-Level Design (System Architecture)**
- Draw a high-level "box and arrow" diagram.
- Identify the main services and components (e.g., Load Balancer, Web Servers, Application Servers, Database, Object Storage for photos).
- Identify the APIs between the components.

**Step 4: Deep Dive into a Specific Component**
- Choose one interesting or complex part of your design and flesh it out in more detail.
  - *Example*:
    - **Data Model**: Design the database schema for your core tables (`users`, `photos`, `followers`).
    - **API Design**: Define the specific API endpoints for uploading a photo or fetching the feed.
    - **Component Design**: How would you design the feed generation service?

**Step 5: Identify Bottlenecks and Discuss Trade-offs**
- Talk about the potential weak points of your design.
  - Where are the single points of failure?
  - What will happen when a database gets too large?
  - How will you handle caching?
- Discuss the trade-offs you made (e.g., "I chose a NoSQL database for the feed to optimize for read performance and scalability, at the cost of some consistency").

---

## 5. Summary and Mastery Checklist

-   [ ] I know that **Design Thinking** is about putting the user first to understand the problem.
-   [ ] I know that **Problem Decomposition** is about breaking a large problem into smaller parts.
-   [ ] I understand that the **first and most important step** in any system design problem is to clarify the functional and non-functional requirements.
-   [ ] I can list the main steps of a structured approach to system design (Clarify -> Estimate -> High-Level Design -> Deep Dive -> Discuss Trade-offs).
-   [ ] I understand the importance of defining what is **out of scope**.

---

## 6. Research and References

-   **"System Design Interview – An insider's guide" by Alex Xu**: This book provides a great framework for approaching system design problems.
-   **Donne Martin - "System Design Primer"**: The "System Design Interview Questions, a Step-by-Step Guide" section is excellent. [Link](https://github.com/donnemartin/system-design-primer#system-design-interview-questions-a-step-by-step-guide)
-   **IDEO - "What is Design Thinking?"**: IDEO is a famous design firm that popularized the concept.
