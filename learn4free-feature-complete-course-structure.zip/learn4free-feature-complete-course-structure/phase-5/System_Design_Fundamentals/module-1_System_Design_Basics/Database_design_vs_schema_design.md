# Database Design vs. Schema Design: From Blueprint to Floor Plan

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Differentiate** between the holistic process of Database Design and the specific implementation task of Schema Design.
-   **Describe** the key phases of Database Design: requirements analysis, conceptual, logical, and physical design.
-   **Define** a database schema and identify its core components for both SQL and NoSQL databases.
-   **Explain** how schema design is a crucial *part* of the overall database design process.
-   **Articulate** why a good high-level database design is critical before starting on the low-level schema.

---

## 2. Introduction: The House Analogy

Building a data storage system is like building a house.

-   **Database Design** is the entire architectural process. It's asking the big questions: What is the purpose of the house? How many rooms? What kind of foundation do we need for this terrain (e.g., SQL or NoSQL)? What are the overall utility plans for plumbing and electricity (data flow and access patterns)? It's the **master blueprint**.
-   **Schema Design** is the detailed **floor plan**. It's deciding the exact dimensions of each room, the type of materials for the walls (data types like `VARCHAR` or `INT`), where the doors and windows go (relationships and constraints), and where to put light switches and outlets (indexes).

You can't create a detailed floor plan without the master blueprint. The schema is the implementation of the design.

---

## 3. The Process of Database Design

Database design is a systematic process of designing, developing, implementing, and maintaining a data management system. It's a high-level, strategic process that goes through several stages:

1.  **Requirements Analysis**:
    -   This is the "why". You work with stakeholders to understand the system's goals.
    -   What data needs to be stored? (e.g., users, products, orders).
    -   What are the most common questions the database will have to answer? (e.g., "Find all orders for a given user"). This defines the **access patterns**.
    -   What are the performance, scalability, and consistency requirements? (e.g., Does this need to handle millions of users? Is it more important for data to be strongly consistent or highly available?).

2.  **Conceptual Design**:
    -   Creates a high-level model of the data, independent of any specific database system.
    -   Focuses on identifying the main **entities** (e.g., `User`, `Product`) and the **relationships** between them (e.g., a `User` *places* an `Order`).
    -   The most common tool here is the **Entity-Relationship (ER) Diagram**.

3.  **Logical Design**:
    -   Translates the conceptual model into a more detailed model that is tied to a specific data model (e.g., relational, document, graph) but not a specific database technology.
    -   For a relational database, this is where you decide on tables and columns. For a document database, you'd design the structure of your JSON documents.
    -   Normalization rules are applied here (for relational databases) to reduce data redundancy.

4.  **Physical Design**:
    -   This is the final stage where you decide on the actual implementation details for a specific Database Management System (DBMS), like PostgreSQL or MongoDB.
    -   This includes choosing data types, creating indexes, and planning partitioning and storage strategies. **Schema design is a primary output of this phase.**

---

## 4. The Practice of Schema Design

Schema design is the concrete implementation of the logical and physical phases of database design. It is the formal blueprint of the database.

### SQL Schema Example (Relational)

For a SQL database, the schema defines the structure of tables, columns, data types, relationships, and constraints.

```sql
CREATE TABLE Users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    order_date DATE,
    total_amount DECIMAL(10, 2),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) -- Defines the relationship
);

-- An index to speed up lookups by username
CREATE INDEX idx_username ON Users(username);
```

### NoSQL Schema Example (Document - MongoDB)

For a document database, the "schema" is often more flexible but still requires careful design. It defines the structure of documents within a collection.

```json
// A User document in the 'users' collection
{
  "_id": "ObjectId('...')",
  "username": "jules_dev",
  "email": "jules@example.com",
  "createdAt": "ISODate('...')"
}

// An Order document in the 'orders' collection
// Note the embedded user information (denormalization) for faster reads
{
  "_id": "ObjectId('...')",
  "orderDate": "ISODate('...')",
  "totalAmount": 199.99,
  "user": {
    "userId": "ObjectId('...')", // Reference to the user
    "username": "jules_dev"      // Embedded data
  },
  "items": [
    { "productId": "ObjectId('...')", "quantity": 2, "price": 49.99 },
    { "productId": "ObjectId('...')", "quantity": 1, "price": 100.01 }
  ]
}
```

---

## 5. Key Differences Summarized

| Aspect           | Database Design                                        | Schema Design                                                  |
| ---------------- | ------------------------------------------------------ | -------------------------------------------------------------- |
| **Scope**        | Holistic, end-to-end process (from idea to maintenance) | A specific phase/output of the database design process         |
| **Abstraction**  | High-level (conceptual, logical)                       | Low-level (physical implementation)                            |
| **Focus**        | The "Why" and "What" (requirements, data model choice) | The "How" (tables, columns, types, indexes, document structures) |
| **Output**       | ER Diagrams, data model choice, physical tuning plans  | `CREATE TABLE` statements, JSON document structures, index plans   |

---

## 6. Deliberate Practice

**Scenario**: You are designing a simple blogging platform.

1.  **Database Design Thinking**:
    -   What are the main entities? (Hint: `Users`, `Posts`, `Comments`).
    -   What are the relationships? (A `User` writes a `Post`, a `Post` has many `Comments`).
    -   Would a relational (SQL) or document (NoSQL) database be a better fit, and why? Consider how you would retrieve a post and all its comments.

2.  **Schema Design Task**:
    -   Based on your choice, sketch out a schema.
    -   If SQL: Define the `CREATE TABLE` statements for `Users`, `Posts`, and `Comments`. What columns, data types, and foreign keys would you need?
    -   If NoSQL: Design the JSON structure for a `Post` document. Would you embed the comments directly in the post, or store them in a separate collection and reference them? What are the trade-offs?

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that **Database Design** is the complete process of planning a database, while **Schema Design** is the specific task of defining its structure.
-   [ ] I can list the four main phases of database design: Requirements, Conceptual, Logical, and Physical.
-   [ ] I can identify the core components of a SQL schema (tables, keys, indexes) and a NoSQL schema (collections, documents, fields).
-   [ ] I understand that you cannot properly design a schema without first going through the higher-level stages of database design.

---

## 13. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: An industry-standard book that covers the principles behind database design in great depth.
-   **"Database Design and Relational Theory" by C. J. Date**: A classic text on the fundamentals of relational database design.
-   **MongoDB Documentation on Data Modeling**: [Link](https://www.mongodb.com/docs/manual/core/data-modeling-introduction/)
