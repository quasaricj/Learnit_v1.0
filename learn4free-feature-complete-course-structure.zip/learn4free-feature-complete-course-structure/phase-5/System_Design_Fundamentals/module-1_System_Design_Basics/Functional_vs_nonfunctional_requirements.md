# Functional vs. Non-Functional Requirements: The "What" vs. The "How Well"

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** functional requirements and provide clear examples.
-   **Define** non-functional requirements (NFRs) and provide clear examples.
-   **Clearly distinguish** between the two types of requirements.
-   **Explain** why non-functional requirements are the primary drivers of system architecture.
-   **Analyze** a system prompt and extract both functional and non-functional requirements.

---

## 2. Introduction: The Foundation of Design

Every system design interview and every real-world project begins with the same critical step: **understanding the requirements**. If you don't know what you're building and what constraints you're under, you cannot design an effective system. Requirements are broadly divided into two categories: functional and non-functional.

-   **Functional Requirements** define **what** the system does. They are the features.
-   **Non-Functional Requirements** define **how well** the system does it. They are the qualities, constraints, and characteristics of the system.

Getting this right is crucial because the functional requirements tell you what features to build, but the non-functional requirements tell you what the architecture needs to look like.

---

## 3. Functional Requirements (The "What")

Functional requirements describe the specific behaviors or functions of the system. They are the features that users directly interact with. Think of them as verbs or actions the system must perform.

If a requirement describes a specific piece of business logic, it's a functional requirement.

### Examples for an E-commerce Website:

-   A user **must be able to search** for products.
-   A user **must be able to add** an item to a shopping cart.
-   The system **shall allow users to checkout** and pay for the items in their cart.
-   The system **shall send an order confirmation email** after a purchase is complete.
-   A user **must be able to view their order history**.

These are unambiguous, testable features. You can verify if they have been implemented correctly.

---

## 4. Non-Functional Requirements (NFRs) (The "How Well")

Non-functional requirements, often called "quality attributes" or "the -ilities," describe the operational characteristics of a system. They don't change what the system *does*, but they dictate the architectural choices needed to achieve its goals.

NFRs are critical because they have a massive impact on cost and complexity.

### Key Categories and Examples:

1.  **Scalability**:
    -   How much can the system grow?
    -   *Example*: The system must support 1 million concurrent users.

2.  **Availability**:
    -   What percentage of the time is the system operational? Usually measured in "nines."
    -   *Example*: The system must have 99.99% availability ("four nines"). This means it can only be down for about 52 minutes per year.

3.  **Performance / Latency**:
    -   How fast is the system?
    -   *Example*: The product search API must return results in under 200 milliseconds for 99% of requests (p99 latency).

4.  **Reliability**:
    -   How well does the system tolerate failures?
    -   *Example*: The system should not lose any user order data in the event of a database failure.

5.  **Consistency**:
    -   How up-to-date is the data users see?
    -   *Example*: After a user updates their profile, the changes must be immediately visible to them on all devices (strong consistency). Or, it's acceptable if inventory counts take a few seconds to be globally consistent (eventual consistency).

6.  **Security**:
    -   How is the system protected against threats?
    -   *Example*: All user passwords must be hashed and salted. All communication must use TLS encryption.

7.  **Maintainability**:
    -   How easy is it to operate and modify the system?
    -   *Example*: The system should be well-monitored, with dashboards for key business and operational metrics.

---

## 5. Why the Distinction Matters

Imagine two requests to build an image hosting service:

-   **System A**: A site for a user to upload and share photos with a few friends.
    -   *Functional*: Upload photos, view photos, delete photos.
    -   *NFRs*: Low traffic, low availability is okay.
-   **System B**: A site for a company like Instagram.
    -   *Functional*: Upload photos, view photos, delete photos. (The same!)
    -   *NFRs*: Must handle millions of uploads per day, must have 99.999% availability, must be extremely low latency worldwide.

The **functional** requirements are identical. But the **non-functional** requirements are wildly different. System A could be a single server. System B requires a globally distributed, massively scalable architecture. **The NFRs dictate the architecture.**

---

## 6. Deliberate Practice

**Scenario**: You are asked to design a "URL Shortening Service" like Bitly.

1.  **Identify Functional Requirements**:
    -   List at least three core functions the service must perform. Think about the user's journey.

2.  **Identify Non-Functional Requirements**:
    -   List at least four critical NFRs. Consider the nature of the service. Which qualities would be most important for its success? (Hint: what happens if a shortened URL is slow or doesn't work?). Be specific with numbers where possible (e.g., "latency should be under X ms").

---

## 12. Summary and Mastery Checklist

-   [ ] I can define **Functional Requirements** as the specific features of a system (the "what").
-   [ ] I can define **Non-Functional Requirements** as the qualities and constraints of a system (the "how well").
-   [ ] I can provide examples of each, such as "user login" (functional) vs. "99.9% uptime" (non-functional).
-   [ ] I understand that NFRs like scalability, availability, and latency are the primary drivers that shape the system's architecture.

---

## 13. Research and References

-   **"System Design Interview – An Insider's Guide" by Alex Xu**: Provides an excellent breakdown of this topic in the context of interviews.
-   **Software Requirements (3rd Edition) by Karl Wiegers and Joy Beatty**: A comprehensive book on the practice of software requirements engineering.
-   **Google SRE Book - Chapter 2, "The Production Environment at Google"**: Discusses the NFRs that shape Google's infrastructure.
