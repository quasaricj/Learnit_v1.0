# Networking and Load Balancing in System Design

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a load balancer and explain its critical role in creating scalable and reliable systems.
-   **Differentiate** between Layer 4 (L4) and Layer 7 (L7) load balancing.
-   **Describe** common load balancing algorithms like Round Robin, Least Connections, and IP Hash.
-   **Identify** common networking topologies for web services, including the use of multiple load balancer layers.
-   **Explain** the concept of a "sticky session" and when it might be necessary.

---

## 2. Introduction: The Traffic Cop of the Internet

In a small system, a user might connect directly to a single web server. But what happens when you have millions of users and dozens or hundreds of servers? How do you distribute the traffic evenly? How do you handle a server crashing without the user noticing?

This is the job of a **load balancer**. A load balancer is a device or service that acts as a "traffic cop" sitting in front of your servers. It accepts incoming network traffic from clients and distributes it across multiple backend servers. Every major web service in the world relies on load balancing. It is a fundamental building block for both scalability and reliability.

---

## 3. The Two Main Types: L4 vs. L7 Load Balancing

Load balancers can operate at different layers of the OSI networking model. The two most common types in system design are Layer 4 and Layer 7.

### Layer 4 (Transport Layer) Load Balancer

-   **How it works**: An L4 load balancer makes routing decisions based on information from the transport layer, primarily the source/destination IP addresses and ports. It doesn't inspect the content of the traffic itself.
-   **Analogy**: It's like a mail sorter that only looks at the street address on an envelope. It doesn't know or care what's written in the letter inside.
-   **Pros**: Very fast and efficient because it does very little work.
-   **Cons**: Not very "smart." It can't make decisions based on what the user is trying to do (e.g., routing `/api` traffic to one set of servers and `/images` to another).

### Layer 7 (Application Layer) Load Balancer

-   **How it works**: An L7 load balancer can inspect the application-level data, such as HTTP headers, URLs, and cookies. This allows for much more intelligent routing decisions.
-   **Analogy**: It's like a mail sorter that opens the envelope and reads the letter to decide where to send it.
-   **Pros**: Very "smart" and flexible. It can implement features like:
    -   **Path-based routing**: Send requests for `example.com/api` to the API servers and `example.com/app` to the web app servers.
    -   **Host-based routing**: Send requests for `api.example.com` and `www.example.com` to different backends.
    -   SSL termination, request rewriting, and more.
-   **Cons**: Slower than an L4 load balancer because it has to do more work to inspect each request.

---

## 4. Common Load Balancing Algorithms

How does the load balancer choose which backend server to send a request to? It uses an algorithm.

1.  **Round Robin**:
    -   This is the simplest method. The load balancer cycles through the list of servers in order. The first request goes to Server A, the second to Server B, the third to C, the fourth back to A, and so on.
    -   *Best for*: Servers with roughly equal capacity.
    -   *Problem*: If one server is slower or more burdened than the others, Round Robin doesn't care and can keep sending it traffic.

2.  **Least Connections**:
    -   This is a more intelligent algorithm. The load balancer keeps track of how many active connections each server has and sends the next request to the server with the fewest connections.
    -   *Best for*: Situations where requests might have very different completion times, leading to an uneven load across servers.

3.  **IP Hash**:
    -   The load balancer calculates a hash of the client's IP address and uses that hash to select a server.
    -   *Why it's useful*: This ensures that requests from the same user (same IP) will consistently go to the same server. This is necessary for "sticky sessions," where user session data is stored on the local web server (though this is generally an anti-pattern for scalable systems).

---

## 5. Common Networking Topologies

1.  **Single Load Balancer**:
    -   The most basic setup: `User -> DNS -> Load Balancer -> App Servers`.
    -   *Problem*: The load balancer itself can become a single point of failure.

2.  **High-Availability (HA) Pair**:
    -   To solve the single point of failure problem, load balancers are often deployed in a redundant pair (active-passive or active-active). If one fails, the other takes over automatically.

3.  **DNS Load Balancing**:
    -   This happens before the user even hits your data center. When a user types `example.com`, DNS can be configured to return the IP address of a load balancer in the user's nearest geographic region (e.g., a user in Europe gets the IP for the EU data center). This is used for global traffic distribution.

4.  **Multi-Tier Load Balancing**:
    -   A very common topology for large-scale systems combines L4 and L7.
    -   `User -> DNS -> L4 Load Balancer -> L7 Load Balancers -> App Servers`
    -   *Why*: The fast L4 load balancer handles the initial wave of traffic and distributes it to a fleet of L7 load balancers. The L7 load balancers then perform the "smart" routing (path-based, etc.) to the correct application servers. This gives you the best of both worlds: performance and intelligent routing.

---

## 6. Deliberate Practice

**Scenario**: You are designing a system with three distinct services: a user authentication service (`/auth`), a REST API (`/api`), and a frontend web app (`/`).

1.  What kind of load balancer (L4 or L7) would you need to route traffic to the correct service? Why?
2.  Imagine the API service is much more resource-intensive than the others. Which load balancing algorithm would be most appropriate to ensure the API servers are not overloaded relative to each other?
3.  How would you make your load balancing layer itself reliable and prevent it from being a single point of failure?

---

## 12. Summary and Mastery Checklist

-   [ ] I know that a **Load Balancer** distributes traffic across multiple servers to improve scalability and reliability.
-   [ ] I can explain that **L4** is fast but simple (IP/port based), while **L7** is smarter but slower (HTTP-aware).
-   [ ] I can name and describe three common load balancing algorithms (e.g., Round Robin, Least Connections).
-   [ ] I can sketch a multi-tier load balancing topology and explain why it's used.

---

## 13. Research and References

-   **NGINX Blog: "What is Layer 4 Load Balancing?"**: [Link](https://www.nginx.com/resources/glossary/layer-4-load-balancing/)
-   **AWS Documentation on Elastic Load Balancing**: Provides great insight into how cloud providers implement load balancing. [Link](https://aws.amazon.com/elasticloadbalancing/features/)
-   **"System Design Interview – An Insider's Guide" by Alex Xu**: Contains excellent chapters on load balancing and other core concepts.
