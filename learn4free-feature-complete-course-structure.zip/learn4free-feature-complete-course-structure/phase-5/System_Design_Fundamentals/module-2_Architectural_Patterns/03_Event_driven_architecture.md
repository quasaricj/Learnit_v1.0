# Event-Driven Architecture

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Event-Driven Architecture (EDA).
- **Differentiate** between synchronous and asynchronous communication.
- **Describe** the three key components of an EDA: event producers, event consumers, and an event broker.
- **Explain** the concept of "loose coupling" and how EDA promotes it.
- **List** the benefits of an event-driven approach (e.g., scalability, resilience).
- **List** the challenges of an event-driven approach (e.g., complexity, debugging).
- **Identify** a use case where an event-driven architecture would be a good fit.

---

## 2. Introduction to Event-Driven Architecture

In the architectures we've discussed so far (monoliths and many microservices), communication is often **synchronous**. Service A calls Service B and then waits for a response. This is a simple and familiar model, but it has a major drawback: the services are **tightly coupled**. If Service B is slow or unavailable, Service A is blocked and may also fail.

**Event-Driven Architecture (EDA)** is an architectural pattern that is built around **asynchronous** communication. In an EDA, services do not communicate directly with each other through requests. Instead, they communicate by producing and consuming **events**.

- An **event** is a message that represents a significant change in state. It's a "fact" that has happened in the past (e.g., `OrderPlaced`, `UserRegistered`, `PaymentProcessed`).

---

## 3. Core Components of an EDA

### 1. Event Producer

- A component that detects a state change, creates an event, and sends it to the event broker.
- The producer's only responsibility is to announce that something has happened. It does not know or care who is listening for that event.

### 2. Event Broker (or Message Broker)

- The central hub of the architecture. It is an intermediary that receives all events from producers and routes them to the interested consumers.
- The broker acts as a buffer, allowing producers and consumers to operate at different speeds.
- **Popular Event Brokers**: RabbitMQ, Apache Kafka, AWS SQS/SNS, Google Pub/Sub.

### 3. Event Consumer (or Subscriber)

- A component that subscribes to certain types of events.
- When the event broker delivers an event, the consumer is activated and performs some action.
- A consumer does not know or care who produced the event.

### The Flow

`Producer -> Event -> Broker -> Event -> Consumer(s)`

This model creates a **loosely coupled** system. The producer and the consumer(s) are completely decoupled from each other; their only common link is the event broker and the structure of the event itself.

---

## 4. Benefits of Event-Driven Architecture

1.  **Loose Coupling and High Cohesion**:
    - Services can be developed, deployed, and scaled independently. You can add a new consumer service without having to change the producer at all.

2.  **Improved Scalability and Resilience**:
    - The event broker acts as a buffer, so if a consumer service is slow or crashes, the events will just queue up in the broker. The producer is not affected.
    - You can easily scale the number of consumers to handle a high volume of events in parallel.

3.  **Asynchronous Workflows**:
    - EDA is perfect for long-running or complex workflows that don't require an immediate response. For example, when an order is placed, you can fire an `OrderPlaced` event. Separate consumer services can then handle sending a confirmation email, updating the inventory, and notifying the shipping department, all in parallel and asynchronously.

4.  **Enhanced Evolvability**:
    - It is very easy to add new functionality to an event-driven system. You just create a new consumer that subscribes to an existing event. This doesn't require any changes to the existing services.

---

## 5. Drawbacks of Event-Driven Architecture

1.  **Complexity**:
    - EDA is a distributed, asynchronous system, which is inherently more complex to reason about than a synchronous, monolithic system.

2.  **Difficult to Debug**:
    - Tracing a "request" through the system is very difficult, as there is no single, end-to-end request path. You have to follow a chain of causally-related but independent events. (This is the problem that **distributed tracing** is designed to solve).

3.  **Data Consistency**:
    - Achieving "exactly-once" processing of an event can be very challenging. You have to handle cases where a consumer might process the same event twice (e.g., if it crashes after processing but before acknowledging the event).

4.  **Dependency on the Broker**:
    - The event broker is a critical piece of infrastructure. If the broker goes down, the entire system stops communicating.

---

## 6. When to Use EDA

EDA is a powerful pattern, but it's not the right choice for every problem.

**Good Use Cases**:
- **Microservices Integration**: As a way for microservices to communicate asynchronously and avoid tight coupling.
- **Asynchronous Workflows**: For tasks where the user does not need an immediate response (e.g., placing an order on an e-commerce site).
- **Real-time Data Processing**: For processing high-volume streams of data (e.g., from IoT devices or user activity logs).
- **Fan-out Scenarios**: When a single event needs to trigger many different actions in parallel.

It is **not** a good fit for simple, synchronous request-response interactions, where a REST API is a much simpler and more direct solution. Many complex systems use a **hybrid architecture**, combining synchronous REST APIs for user-facing interactions with an event-driven approach for backend processing.

---

## 7. Summary and Mastery Checklist

-   [ ] I can define an **event** as a message that signifies a state change.
-   [ ] I know that EDA is an **asynchronous** pattern, which is different from synchronous REST calls.
-   [ ] I can name the three main components: **Producer**, **Consumer**, and **Broker**.
-   [ ] I can explain that the main benefit of EDA is **loose coupling**, which improves scalability and resilience.
-   [ ] I can list a major challenge of EDA, such as the complexity of debugging.
-   [ ] I can identify a good use case for EDA, like an e-commerce order processing pipeline.

---

## 8. Research and References

-   **"Designing Event-Driven Systems" by Ben Stopford**: A free and excellent book from Confluent (the creators of Kafka).
-   **Martin Fowler - "What do you mean by 'Event-Driven?'"**: A foundational article that clarifies the different patterns of event-driven architecture. [Link](https://martinfowler.com/articles/201701-event-driven.html)
-   **"Enterprise Integration Patterns" by Gregor Hohpe and Bobby Woolf**: The classic book on messaging patterns.
-   **Microsoft - "Event-Driven Architecture Style"**: A great overview from the Azure documentation.
