# Client-Server Architecture

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the client-server architecture.
- **Identify** the roles and responsibilities of the client and the server.
- **Describe** the request-response model of communication.
- **Differentiate** between a thin client and a thick client.
- **Understand** that client-server is the foundational architectural pattern for the entire web.
- **Relate** client-server architecture to the other architectural patterns you've learned.

---

## 2. Introduction: The Foundation of the Web

The **client-server architecture** is the most fundamental architectural pattern for distributed systems and the web. It is a model that separates the responsibilities of a system into two distinct roles: the **client** and the **server**.

- The **server** is a powerful computer or process that provides a service. It is a **provider** of resources or data. It is always on, listening for requests.
- The **client** is a computer or process that requests a service from a server. It is a **consumer** of resources or data. It initiates the communication.

This separation of concerns is the basis for almost every application you use, from browsing a website to sending an email.

---

## 3. Core Concepts

### Roles and Responsibilities

- **The Server**:
  - **Always-on**: Runs continuously, waiting for requests from clients.
  - **Manages Resources**: Controls access to the application's data, business logic, and other resources.
  - **Serves Multiple Clients**: A single server is designed to serve requests from many different clients.
  - **Examples**: A web server (like Apache or Nginx), an application server (your backend API), a database server (like PostgreSQL).

- **The Client**:
  - **Initiates Requests**: The client always starts the conversation by sending a request to the server.
  - **Manages the User Interface**: The client is responsible for presenting the data and the user interface to the user.
  - **Examples**: A web browser, a mobile application, a desktop application.

### The Request-Response Model

Communication in a client-server architecture follows a strict **request-response** cycle.
1.  The client establishes a connection with the server and sends a **request** for a specific service or resource.
2.  The server processes the request.
3.  The server sends a **response** back to the client.
4.  The client receives and processes the response.

This is the same HTTP request-response cycle you learned about in the backend development modules.

### Thin Client vs. Thick Client

This distinction refers to how much of the application's logic resides on the client versus the server.

- **Thin Client**:
  - A client that has very little application logic. Its primary job is to display data provided by the server.
  - Most of the work (business logic, data processing) is done on the **server**.
  - **Example**: A traditional, server-rendered web application where the browser is just responsible for rendering HTML sent by the server.
  - **Pros**: Easier to update (you just update the server), more secure (logic is not on the client).

- **Thick Client (or Fat Client)**:
  - A client that has a significant amount of application logic. It does a lot of the processing itself and only communicates with the server to get or save data.
  - **Example**: A modern Single-Page Application (SPA) built with a framework like React or Vue. The browser downloads a large amount of JavaScript, which then handles the UI, routing, and business logic on the client-side. The client only makes API calls to the server for data.
  - **Pros**: More responsive and interactive user experience, can work offline.

---

## 4. Relationship to Other Architectures

Client-server is a very high-level, foundational pattern. The other architectural patterns you've learned about are often specific ways of implementing the "server" part of the client-server model.

- **Monolithic Architecture**: The entire server-side application is a single, monolithic client-server system.
- **Microservices Architecture**: The server-side is broken down into multiple, independent services. From the client's perspective, it may still look like it's talking to a single "server" (often an API Gateway), but that server is itself a distributed system.
- **Event-Driven Architecture**: This describes *how* the server-side components communicate with each other (asynchronously), but the overall interaction with the end-user's client is still typically a synchronous, request-response API call.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define the client-server architecture as a model that separates the **provider** of a service (the server) from the **consumer** (the client).
-   [ ] I know that the **server** is always on and waits for requests, while the **client** initiates the requests.
-   [ ] I can describe the **request-response** model of communication.
-   [ ] I can explain the difference between a **thin client** (most logic on the server) and a **thick client** (most logic on the client).
-   [ ] I understand that a modern Single-Page Application (SPA) is an example of a thick client.
-   [ ] I understand that client-server is the fundamental pattern of the web, and that other patterns like microservices are ways of organizing the server-side.

---

## 6. Research and References

-   **Wikipedia - Client–server model**: [Link](https://en.wikipedia.org/wiki/Client%E2%80%93server_model)
-   **"Computer Networks" by Andrew S. Tanenbaum**: A classic textbook that covers the client-server model in great detail.
-   **MDN Web Docs - "An overview of HTTP"**: Reinforces the request-response cycle that is the heart of the client-server web. [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview)
