# Service-Oriented Architecture (SOA)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Service-Oriented Architecture (SOA).
- **Describe** the concept of a "service" as a fundamental building block in SOA.
- **Explain** the role of an Enterprise Service Bus (ESB) in a traditional SOA.
- **Differentiate** between SOA and Microservices.
- **Understand** that SOA was the philosophical predecessor to microservices.
- **Recognize** the key principles of SOA, such as service reusability and loose coupling.

---

## 2. Introduction to SOA

**Service-Oriented Architecture (SOA)** is an architectural style for building enterprise-level software applications. It is a predecessor to the more modern microservices architecture and shares many of the same goals.

SOA structures an application as a collection of discrete, loosely coupled **services**. A "service" in SOA is a self-contained, coarse-grained software component that performs a specific business function (e.g., `CheckCredit`, `ProcessPayment`, `CreateCustomer`). These services are designed to be reusable and discoverable across the entire enterprise.

---

## 3. Core Concepts

### Services

- **Business-Oriented**: A service is defined by a business function, not a technical one.
- **Discoverable**: SOA emphasizes a formal "service contract" and a central registry where services can be discovered.
- **Reusable**: The primary goal of SOA is to promote reusability. Once a `ProcessPayment` service is built, it can be reused by many different applications within the enterprise.
- **Loosely Coupled**: Services are designed to be independent of each other.

### The Enterprise Service Bus (ESB)

In many traditional SOA implementations, services do not communicate with each other directly. Instead, they communicate through a central component called an **Enterprise Service Bus (ESB)**.

- **What it is**: An ESB is a piece of middleware that acts as a central "bus" for all communication between services.
- **Responsibilities of an ESB**:
  - **Routing**: Routes messages from one service to another.
  - **Transformation**: Can transform a message from one format to another (e.g., from XML to JSON).
  - **Orchestration**: Can coordinate a complex business process that involves multiple services.
- **Analogy**: An ESB is like a central, smart postal hub for a large company. All inter-departmental mail goes to the central hub, which then figures out how to translate it, enrich it, and route it to the correct destination.

### Communication Protocols

- Traditional SOA often relied on heavier, standards-based protocols like **SOAP (Simple Object Access Protocol)** and WSDL (Web Services Description Language).
- Modern SOA implementations are more likely to use REST APIs, just like microservices.

---

## 4. SOA vs. Microservices

SOA and microservices are very similar in their philosophy (building systems from independent services). However, there are some key differences in their typical implementation.

| Feature                 | SOA                                                | Microservices                                      |
| ----------------------- | -------------------------------------------------- | -------------------------------------------------- |
| **Scope**               | Enterprise-wide. Aims for reuse across the company. | Application-specific. Bounded to a single product. |
| **Service Size**        | Coarse-grained (large services, e.g., "Finance").   | Fine-grained (small services, e.g., "Payment").      |
| **Communication**       | Often uses a central ESB ("smart pipes").            | Uses simple, direct API calls ("dumb pipes").        |
| **Data Storage**        | Often shares a single, large enterprise database.  | Each service has its own private database.         |
| **Deployment**          | Services are often deployed as part of a larger, coordinated release. | Each service is deployed independently.            |

In essence, **microservices can be seen as a more refined, opinionated, and modern way of doing SOA**. It takes the good ideas of SOA (loose coupling, business-focused services) and gets rid of the problematic ideas (the central ESB, shared databases).

---

## 5. Why Learn About SOA?

While most new, cloud-native development uses a microservices approach, many large enterprises still have and maintain large-scale SOA systems. Understanding the concepts of SOA is important for:
- Working in a large enterprise environment.
- Understanding the historical evolution of software architecture.
- Appreciating the reasons why microservices were developed as a response to the challenges of traditional SOA.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define SOA as an architectural style that structures an application as a collection of reusable business services.
-   [ ] I know that the goal of SOA is to promote reusability and loose coupling across an enterprise.
-   [ ] I can describe the role of a central **Enterprise Service Bus (ESB)** as a "smart pipe" for communication.
-   [ ] I can list a key difference between SOA and microservices (e.g., service size, communication style, data storage).
-   [ ] I understand that microservices are a modern evolution of the ideas of SOA.

---

## 7. Research and References

-   **"Enterprise Integration Patterns" by Gregor Hohpe and Bobby Woolf**: The definitive book on the messaging patterns that underpin ESBs.
-   **"SOA vs. Microservices: What's the Difference?"**: A common topic for blog posts that provide good summaries.
-   **"Microservices" by Martin Fowler**: The article makes a point of comparing the new microservices style to the older SOA style. [Link](https://martinfowler.com/articles/microservices.html)
-   **Wikipedia - Service-oriented architecture**: [Link](https://en.wikipedia.org/wiki/Service-oriented_architecture)
