# Layered Architecture Patterns

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the layered architecture pattern.
- **Describe** the concept of "separation of concerns."
- **Identify** the common layers in a typical application (Presentation, Application/Business, Persistence, Database).
- **Explain** the rule of communication in a layered architecture (layers can only talk to the layer directly below them).
- **List** the benefits and drawbacks of a layered architecture.
- **Understand** that this pattern can be applied *within* a monolith or a single microservice.

---

## 2. Introduction to Layered Architecture

The **layered architecture pattern** (also known as the **n-tier architecture**) is one of the most common and fundamental architectural patterns. It is based on the principle of **separation of concerns**.

The core idea is to break down the code of an application into distinct **layers**, where each layer has a specific responsibility. The layers are arranged in a hierarchy, and there are strict rules about how they can communicate with each other.

This pattern is not a high-level architecture for a whole system (like monolith vs. microservices), but rather a way to organize the code *within* a single application or service.

---

## 3. The Common Layers

A typical web application is often structured into four main layers.

### 1. Presentation Layer (or UI Layer)

- **Responsibility**: To display the user interface and handle user interaction.
- **Concerns**: HTML, CSS, JavaScript, UI components.
- **Example**: In a server-rendered web app, this layer is responsible for generating the HTML. In a Single-Page Application (SPA), this is the code that runs in the user's browser (e.g., your React or Vue components).

### 2. Application Layer (or Business Logic Layer / Service Layer)

- **Responsibility**: To execute the application's core business logic. It orchestrates the business workflows and coordinates the work.
- **Concerns**: Business rules, validation, and workflows.
- **Example**: A `UserService` that contains the logic for creating a new user, including validating the input, checking for duplicates, and coordinating with the persistence layer.

### 3. Persistence Layer (or Data Access Layer / Repository Layer)

- **Responsibility**: To handle all communication with the database. It provides an abstraction over the data store.
- **Concerns**: CRUD (Create, Read, Update, Delete) operations, SQL queries, or calls to a NoSQL database.
- **Example**: A `UserRepository` with methods like `findById`, `save`, and `delete`. This layer contains the actual SQL code or ORM (Object-Relational Mapper) logic.

### 4. Database Layer

- **Responsibility**: To provide the actual data storage.
- **Concerns**: The database management system itself (e.g., PostgreSQL, MongoDB).

---

## 4. The Rules of Communication

- **Strict Hierarchy**: The layers are arranged in a strict hierarchy. `Presentation -> Application -> Persistence -> Database`.
- **Downward Communication Only**: A layer can only communicate with the layer directly below it. For example:
  - The Presentation Layer can call the Application Layer.
  - The Application Layer **cannot** call the Presentation Layer.
  - The Application Layer can call the Persistence Layer.
  - The Persistence Layer **cannot** call the Application Layer.
- This creates a one-way flow of dependencies.

### Closed vs. Open Layers

- In a **strictly layered** system (a "closed" layered architecture), a layer can *only* call the layer immediately below it. The Presentation Layer cannot skip the Application Layer and call the Persistence Layer directly.
- This is the recommended approach as it ensures a clear separation of concerns.

---

## 5. Benefits of Layered Architecture

1.  **Separation of Concerns**: This is the primary benefit. Each layer focuses on a specific responsibility, which makes the code easier to understand, develop, and maintain.
2.  **Testability**: Because the layers are separate, you can test them in isolation. You can test the business logic in the Application Layer without needing a real UI or a real database (you can use mocks).
3.  **Reusability**: You can change the implementation of one layer without affecting the others. For example:
    - You could swap your UI from a server-rendered web application to a desktop application, and the Application and Persistence layers would remain the same.
    - You could swap your database from PostgreSQL to MySQL, and only the Persistence Layer would need to change.

---

## 6. Drawbacks

1.  **Can Lead to Unnecessary Boilerplate**: For very simple applications, creating separate classes and files for all the layers can feel like overkill.
2.  **Potential for Performance Overhead**: Each layer of abstraction can add a small amount of performance overhead.

---

## 7. Relationship to Other Architectures

- A **monolithic application** is typically structured internally using a layered architecture.
- A single **microservice** is also often structured internally using a layered architecture.

This pattern is a fundamental tool for organizing the codebase of any non-trivial application or service. The popular **Model-View-Controller (MVC)** pattern is a specific type of layered architecture.

---

## 8. Summary and Mastery Checklist

-   [ ] I can define the layered architecture as a pattern that organizes code based on the **separation of concerns**.
-   [ ] I can name the three main application layers: **Presentation** (UI), **Application** (Business Logic), and **Persistence** (Data Access).
-   [ ] I can explain the main rule of communication: a layer should only talk to the layer directly below it.
-   [ ] I can list a key benefit of this pattern, such as improved testability or maintainability.
-   [ ] I understand that this pattern is used to structure the code *inside* of a monolith or a microservice.

---

## 9. Research and References

-   **"Patterns of Enterprise Application Architecture" by Martin Fowler**: The classic book that describes many of these patterns in detail.
-   **Microsoft - "Layered Architecture Style"**: A great overview from the Azure documentation. [Link](https://docs.microsoft.com/en-us/azure/architecture/guide/architecture-styles/n-tier)
-   **"Clean Architecture" by Robert C. Martin**: A book that presents a more modern and sophisticated evolution of the layered architecture, often called "Hexagonal" or "Onion" architecture.
