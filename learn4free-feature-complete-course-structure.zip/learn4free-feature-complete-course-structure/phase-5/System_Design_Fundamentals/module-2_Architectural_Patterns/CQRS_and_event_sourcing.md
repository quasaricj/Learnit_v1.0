# CQRS and Event Sourcing: Advanced Architectural Patterns

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Command Query Responsibility Segregation (CQRS) and explain its core principle.
-   **Define** Event Sourcing (ES) and explain how it differs from traditional state-based persistence.
-   **Explain** how CQRS and Event Sourcing can be used together to create a powerful architectural pattern.
-   **Identify** the benefits of this combined pattern, such as scalability, auditability, and temporal queries.
-   **Recognize** the complexity and trade-offs involved, particularly regarding eventual consistency.

---

## 2. Introduction: Beyond CRUD

In most traditional applications, we use a single model to handle both reading and writing data (Create, Read, Update, Delete - CRUD). We might have a `User` object that we use to fetch a user from the database, update their email, and save them back. This works well for simple systems, but can become a bottleneck in complex ones.

What if the way you need to *write* data is fundamentally different from the way you need to *read* it? CQRS and Event Sourcing are two advanced patterns that address this problem. They are often used together, but they are distinct concepts.

---

## 3. CQRS: Separating Reads from Writes

**Command Query Responsibility Segregation (CQRS)** is a simple pattern with a profound impact. It states that you should separate your application into two distinct parts:

-   **The Command Side**: This part of your application handles all the requests that change state (Create, Update, Delete). These are the **Commands**. Its goal is to process transactions efficiently and robustly.
-   **The Query Side**: This part of your application handles all the requests that only read data. These are the **Queries**. Its goal is to provide data to the UI in the most efficient way possible, often using denormalized data models called "read models" or "projections."

![CQRS Diagram](https://martinfowler.com/bliki/images/cqrs/cqrs.png)

### Key Benefits of CQRS:

-   **Optimized Data Models**: You can have a highly normalized model on the write side to ensure consistency, and a highly denormalized, view-specific model on the read side for fast queries. No more complex `JOIN`s!
-   **Independent Scaling**: The read and write workloads of an application are often very different. For example, a social media site has many more reads than writes. CQRS allows you to scale the number of read servers independently from the write servers.
-   **Simpler Logic**: The command side only has to worry about business logic and validation. The query side only has to worry about fetching data.

### Key Challenge:

-   **Eventual Consistency**: Because the read and write models are separate, there is a delay between when data is written and when it becomes available to read. The read model is **eventually consistent** with the write model. This is a trade-off you must be willing to make.

---

## 4. Event Sourcing: Storing the Changes, Not the State

**Event Sourcing** is a radical departure from traditional data persistence.

-   **Traditional approach**: When we save a user's profile, we store their *current state* in the database. If they change their name, we `UPDATE` the `username` column. The old name is lost forever.
-   **Event Sourcing approach**: We never delete or update data. Instead, we store a log of every single thing that happened as a sequence of immutable **events**.
    -   `UserRegistered` (name: "Alex", email: "a@b.c")
    -   `UserNameChanged` (name: "Alex Smith")
    -   `UserEmailChanged` (email: "alex.smith@b.c")

The **current state** of the user is derived by starting with a blank slate and replaying all the events in order. The event log itself is the **source of truth**.

### Key Benefits of Event Sourcing:

-   **Complete Audit Trail**: You have a complete, immutable history of everything that ever happened in the system. This is invaluable for debugging, auditing, and business intelligence.
-   **Temporal Queries**: You can reconstruct the state of any entity at any point in time. "What did this user's profile look like on January 1st?"
-   **Flexibility**: You can create new read models (projections) at any time by replaying the event log from the beginning.

### Key Challenges:

-   **Complexity**: It's a different way of thinking about data and can be unfamiliar to many developers.
-   **Event Versioning**: What happens if you change the structure of an event? You need a strategy for handling old versions of events.

---

## 5. Combining CQRS and Event Sourcing

This is where the magic happens. The two patterns complement each other perfectly.

![CQRS with Event Sourcing](https://docs.microsoft.com/en-us/azure/architecture/patterns/media/cqrs-event-sourcing.png)

-   **The Command Side**:
    1.  A user action sends a **Command** (e.g., `ChangeUserEmailCommand`).
    2.  The command handler validates the command against the current state of the entity (which it gets by replaying its events).
    3.  If valid, it produces a new **Event** (`UserEmailChanged`).
    4.  This event is appended to the **Event Store** (the source of truth). This is the **Event Sourcing** part.
-   **The Query Side**:
    1.  A separate process, a "projector," subscribes to the stream of events from the Event Store.
    2.  When it sees a `UserEmailChanged` event, it updates its own local **Read Model** (e.g., a simple SQL table or a document in Elasticsearch).
    3.  The UI sends **Queries** directly to this optimized read model. This is the **CQRS** part.

---

## 6. Deliberate Practice

**Scenario**: You are designing a shopping cart for an e-commerce site.

1.  **Event Storming**: Think about the lifecycle of a shopping cart. What are the key events that can happen to it?
    -   (Hint: `CartCreated`, `ItemAddedToCart`, `ItemRemovedFromCart`, `CartCheckedOut`).
2.  **Command vs. Query**:
    -   Give an example of a **Command** you would send to the system. (e.g., `AddItemCommand`).
    -   Give an example of a **Query**. (e.g., `GetCartContentsQuery`).
3.  **Read Model Design**: What would the schema for your "cart contents" read model look like? How would it be updated when an `ItemAddedToCart` event occurs?

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that **CQRS** separates the model for writing data (Commands) from the model for reading data (Queries).
-   [ ] I can explain that **Event Sourcing** persists the full history of an entity as a sequence of immutable events, rather than just its current state.
-   [ ] I understand that the primary benefit of CQRS is the ability to independently scale and optimize read/write workloads.
-   [ ] I understand that the primary benefit of Event Sourcing is having a complete and auditable history.
-   [ ] I can sketch how a Command leads to an Event, which is then used to update a separate Read Model.

---

## 13. Research and References

-   **Martin Fowler - "CQRS"**: [Link](https://martinfowler.com/bliki/CQRS.html)
-   **Martin Fowler - "Event Sourcing"**: [Link](https://martinfowler.com/eaaDev/EventSourcing.html)
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 11 discusses these patterns in the context of data systems.
-   **Greg Young - "CQRS and Event Sourcing"**: A famous and highly influential talk on the topic. [Link on YouTube](https://www.youtube.com/watch?v=JHGkaS8g2VE)
