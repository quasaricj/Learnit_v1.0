# Architectural Patterns: MVC, MVVM, and Event-Driven

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** the Model-View-Controller (MVC) pattern and describe the responsibility of each component.
-   **Define** the Model-View-ViewModel (MVVM) pattern and explain how it differs from MVC, particularly regarding data binding.
-   **Define** Event-Driven Architecture (EDA) and contrast it with a traditional request-response model.
-   **Identify** the types of applications where each pattern is most commonly used.
-   **Explain** how these patterns help in creating modular, testable, and maintainable applications.

---

## 2. Introduction: Structuring Your Application

An architectural pattern is a general, reusable solution to a commonly occurring problem within a given context in software design. It's a blueprint for how to structure your code. This lesson covers three influential patterns: MVC and MVVM are primarily used for structuring code within a single application (especially one with a graphical user interface), while Event-Driven Architecture is a broader pattern for how components or services communicate.

---

## 3. MVC: Model-View-Controller

MVC is one of the oldest and most well-known architectural patterns for building user interfaces. It aims to separate concerns by dividing the application into three interconnected components.

![MVC Diagram](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/MVC-Process.svg/1200px-MVC-Process.svg.png)

1.  **Model**:
    -   **Responsibility**: The central component that represents the application's data and business logic. It manages the state of the application.
    -   **Analogy**: The "brains" of the operation. It's the part that knows what the data is and what can be done with it. It knows nothing about the UI.

2.  **View**:
    -   **Responsibility**: The user interface (UI) of the application. It displays the data from the Model to the user.
    -   **Analogy**: The "face" of the application. Its job is to present data and send user actions (like button clicks) to the Controller. It is generally "dumb" and has no business logic.

3.  **Controller**:
    -   **Responsibility**: Acts as the intermediary between the Model and the View. It receives user input from the View and translates it into actions to be performed by the Model. After the Model's state changes, the Controller tells the View to update itself.
    -   **Analogy**: The "traffic cop" or "middle-man." It handles the user's requests and orchestrates the interaction between the other two parts.

-   **Workflow**: A user interacts with the **View**, which triggers an action in the **Controller**. The **Controller** updates the **Model**. The **Model** notifies the **Controller** (or the **Controller** observes the **Model**), which then updates the **View**.

-   **Commonly Used In**: Web frameworks like Ruby on Rails, Django, and ASP.NET MVC.

---

## 4. MVVM: Model-View-ViewModel

MVVM is a more modern pattern, particularly popular in modern UI frameworks (like WPF, Angular, Vue.js, and React with Hooks). It is an evolution of MVC that is designed to make the connection between the View and the data it displays more seamless.

![MVVM Diagram](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/MVVMPattern.png/1024px-MVVMPattern.png)

1.  **Model**:
    -   Same as in MVC: Represents the application's data and business logic.

2.  **View**:
    -   The UI. However, in MVVM, the View is responsible for its own state and is more independent. It is bound to the ViewModel.

3.  **ViewModel**:
    -   **Responsibility**: The key innovation. The ViewModel is a "model for the View." It exposes data from the Model in a way that is easy for the View to consume. It also handles user actions via commands.
    -   **Key Feature: Data Binding**: The View and ViewModel are connected via **two-way data binding**. This means that when data in the ViewModel changes, the View automatically updates itself. And when the user interacts with the View (e.g., typing in a text box), the data in the ViewModel is automatically updated. This eliminates much of the manual UI update logic that the Controller in MVC is responsible for.

-   **Workflow**: The **View** and **ViewModel** are data-bound. A user's interaction with the **View** automatically updates the **ViewModel**. The **ViewModel** updates the **Model**. Changes in the **Model** are propagated back to the **ViewModel**, which in turn are automatically reflected in the **View** via data binding.

-   **Commonly Used In**: Modern frontend frameworks (React, Angular, Vue), mobile development (Android Jetpack Compose, Swift UI).

---

## 5. Event-Driven Architecture (EDA)

This is a different kind of pattern. It's not about separating Model and View; it's a pattern for building systems where components communicate by sending and receiving messages (or **events**). This promotes loose coupling and is a cornerstone of modern distributed systems.

-   **Core Concepts**:
    -   **Event**: A significant change in state. For example, `OrderPlaced`, `UserRegistered`, `PaymentProcessed`. An event is an immutable fact that happened in the past.
    -   **Producer (or Publisher)**: A component that generates and publishes an event. It doesn't know or care who is listening.
    -   **Consumer (or Subscriber)**: A component that subscribes to and reacts to an event.
    -   **Event Bus / Message Broker**: The central infrastructure that receives events from producers and delivers them to interested consumers.

![Event-Driven Architecture](https://martinfowler.com/articles/eda/orders-arch.png)
*(Image from MartinFowler.com)*

-   **How it works**: Instead of one service calling another directly (a request-response model), a producer service simply emits an `OrderPlaced` event to a message broker. The `EmailService`, the `InventoryService`, and the `ShippingService` all subscribe to this event and react accordingly, without the producer needing to know anything about them.

-   **Pros**:
    -   **Loose Coupling**: Services are highly decoupled. You can add new consumers without changing the producer.
    -   **Resilience**: If the `EmailService` is down, the events can queue up in the message broker, and they will be processed when the service comes back online. The producer is unaffected.
    -   **Scalability**: You can easily scale the number of consumers to handle a high volume of events.

-   **Commonly Used In**: Microservices, serverless applications, real-time data processing systems.

---

## 12. Summary and Mastery Checklist

-   [ ] I can describe **MVC** as a pattern that separates an application into a Model (data), a View (UI), and a Controller (logic).
-   [ ] I can describe **MVVM** as a variation of MVC that uses a ViewModel and two-way data binding to simplify UI development.
-   [ ] I know that MVC is common in traditional web frameworks, while MVVM is prevalent in modern frontend and mobile frameworks.
-   [ ] I can define an **Event-Driven Architecture** as a system where components communicate asynchronously by producing and consuming events via a message broker.
-   [ ] I understand that EDA promotes loose coupling and resilience, making it ideal for microservices.

---

## 13. Research and References

-   **MDN Web Docs - "MVC"**: [Link](https://developer.mozilla.org/en-US/docs/Glossary/MVC)
-   **Microsoft Docs - "The MVVM Pattern"**: [Link](https://docs.microsoft.com/en-us/dotnet/architecture/maui/mvvm)
-   **Martin Fowler - "What do you mean by Event-Driven?"**: [Link](https://martinfowler.com/articles/201701-event-driven.html)
