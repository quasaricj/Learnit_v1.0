# Asynchronous Communication: Message Queues and Event Buses

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** asynchronous communication and contrast it with synchronous, request-response communication.
-   **Explain** the role of a message broker in facilitating asynchronous communication.
-   **Describe** the Point-to-Point messaging model used by a traditional Message Queue.
-   **Describe** the Publish/Subscribe (Pub/Sub) messaging model used by an Event Bus.
-   **Identify** the key benefits of using message queues, such as improved scalability, resilience, and decoupling.
-   **List** popular message broker technologies like RabbitMQ, Kafka, and AWS SQS.

---

## 2. Introduction: Breaking Up the Monolith's Communication

In a synchronous world, when a service wants another service to do something, it makes a direct request (like an HTTP call) and waits for a response. This is simple but creates tight coupling. If the receiving service is slow or down, the calling service is stuck waiting.

**Asynchronous communication** breaks this tight coupling. The sending service (the **Producer**) sends a message to a middleman (a **Message Broker**) and immediately moves on, not waiting for a response. Later, the receiving service (the **Consumer**) picks up that message from the broker and processes it. This pattern is essential for building scalable and resilient distributed systems.

The **Message Broker** is the central piece of infrastructure (like RabbitMQ, Apache Kafka, or AWS SQS) that makes this possible. It acts as a reliable post office for messages between services.

---

## 3. Message Queues (Point-to-Point Model)

A traditional message queue implements a **point-to-point** communication model.

-   **How it works**:
    -   A producer sends a message to a specific **queue**.
    -   Multiple consumers can be listening to that queue, but **only one consumer will receive and process any given message**.
    -   Once a message is successfully processed, it is removed from the queue.
-   **Analogy**: A single checkout line at a store. Many customers (producers) place their orders on the conveyor belt (the queue). A cashier (consumer) takes one order, processes it, and it's done. If you have multiple cashiers, they work together to clear the same line, but any given order is only handled by one cashier.
-   **Purpose**: This model is used to distribute a workload or a set of tasks across a pool of workers (consumers). The goal is to ensure that every task is completed exactly once.

![Message Queue Diagram](https://www.cloudamqp.com/img/blog/thumb-m.jpg)

-   **Use Case**: A user uploads a video that needs to be compressed. The web server (producer) sends a `VideoCompressionJob` message to a `video-processing` queue. A fleet of worker servers (consumers) listens to this queue, and one of them will pick up the job and perform the compression.

---

## 4. Event Buses (Publish/Subscribe Model)

An event bus (or a message broker configured for this pattern) implements a **publish/subscribe (pub/sub)** communication model.

-   **How it works**:
    -   A producer (now called a **publisher**) sends a message, called an **event**, to a **topic**. The publisher has no knowledge of who, if anyone, is listening.
    -   Multiple consumers (now called **subscribers**) can subscribe to that topic.
    -   **Every subscriber receives its own copy of the event**. The event is broadcast to all interested parties.
-   **Analogy**: A newspaper subscription. A journalist (publisher) writes an article and sends it to the printing press (the topic/broker). Every single subscriber (the consumers) gets their own copy of the newspaper to read.
-   **Purpose**: This model is used to broadcast information about something that has happened. The goal is to notify multiple, disparate parts of a system about a state change so they can all react independently. This is the backbone of Event-Driven Architecture.

![Pub/Sub Diagram](https://www.cloudamqp.com/img/blog/pub-sub-2.svg)

-   **Use Case**: An `OrderPlaced` event is published to an `orders` topic. The `EmailService` subscribes to this topic to send a confirmation email. The `InventoryService` subscribes to it to decrement the stock count. The `ShippingService` subscribes to it to prepare the shipment. All three services get a copy of the event and do their own work in parallel.

---

## 5. Key Benefits of Using Message Brokers

1.  **Decoupling**: The producer and consumer don't need to know about each other. They only need to know about the message broker. This means you can change, add, or remove consumers without affecting the producer at all.

2.  **Resilience / Fault Tolerance**: If a consumer service is down, the messages simply pile up in the queue. When the service comes back online, it can resume processing from where it left off. This prevents data loss and makes the system more robust.

3.  **Scalability**: You can easily scale the number of consumers. If the video processing queue is getting too long, you can just spin up more worker instances to increase the processing throughput.

4.  **Load Leveling / Buffering**: Message queues are excellent for smoothing out spikes in traffic. If you get a sudden burst of requests, the queue can absorb them, and the consumers can process them at a steady rate, protecting your backend services from being overwhelmed.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that **asynchronous communication** decouples services by using a **message broker** as an intermediary.
-   [ ] I can describe a **message queue** as a point-to-point system where a message is processed by **only one** consumer, ideal for distributing tasks.
-   [ ] I can describe an **event bus** as a publish/subscribe system where an event is broadcast to **all** subscribers, ideal for event-driven architectures.
-   [ ] I can list key benefits of this approach, including decoupling, resilience, and scalability.
-   [ ] I can name common broker technologies like RabbitMQ (traditional queue/bus) and Kafka (distributed log, often used as a bus).

---

## 13. Research and References

-   **"Enterprise Integration Patterns" by Gregor Hohpe and Bobby Woolf**: The definitive book on messaging patterns.
-   **AWS SQS (Queue) vs. SNS (Pub/Sub)**: The AWS documentation provides a very clear, practical distinction between the two models.
-   **Kafka is not a Queue**: A famous article explaining the architectural differences of Kafka's log-based approach. [Link](https://www.confluent.io/blog/kafka-is-not-a-queue/)
