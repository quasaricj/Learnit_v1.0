# Service Discovery and Registration in Microservices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** the "service discovery problem" in a microservices architecture.
-   **Define** Service Registration and Service Discovery as the two parts of the solution.
-   **Describe** the role of a Service Registry as a central component.
-   **Differentiate** between the Client-Side Discovery and Server-Side Discovery patterns.
-   **List** examples of popular service discovery tools (e.g., Consul, Eureka, Kubernetes).
-   **Explain** the importance of health checks in a service discovery system.

---

## 2. The Problem: Where Are You?

In a monolithic application, components call each other through in-memory function calls. In a microservices architecture, they must call each other over the network. This introduces a fundamental question: **How does Service A find the network location (IP address and port) of Service B?**

You can't just use a static config file. In a modern, cloud-native environment:
-   Services are ephemeral. They can crash and be restarted.
-   Services are elastic. They can be scaled up or down, meaning new instances are constantly being created and destroyed.
-   Instances are assigned dynamic IP addresses by the platform (like Kubernetes or a cloud provider).

Relying on static IP addresses is brittle and unworkable. The solution is a dynamic, automated process called **Service Discovery**.

---

## 3. The Solution: A Dynamic Phone Book

The solution consists of three parts:

1.  **Service Registry**: This is a central database or "phone book" for all your services. It contains the real-time network locations of every healthy, available service instance.
2.  **Service Registration**: When a new service instance starts up, it must register itself with the Service Registry, telling it: "Hi, I'm an instance of the `PaymentService`, and you can find me at `10.1.2.3:8080`." The instance is also responsible for de-registering itself when it shuts down gracefully.
3.  **Service Discovery**: When Service A wants to call Service B, it queries the Service Registry: "Where can I find a healthy instance of the `PaymentService`?" The registry returns a list of available addresses, and Service A can then choose one to make its request.

![Service Discovery Diagram](https.krakend.io/images/blog/service-discovery.png)

A crucial part of this is **health checking**. The service instances must periodically send a heartbeat signal to the registry to prove they are still alive and healthy. If the registry stops receiving heartbeats from an instance, it will remove it from the list of available services so that no more traffic is sent to the dead instance.

---

## 4. Pattern 1: Client-Side Discovery

In this pattern, the client service (Service A) is responsible for the discovery logic.

-   **How it works**:
    1.  A `PaymentService` instance starts and registers with the Service Registry (e.g., Eureka, Consul).
    2.  The `OrderService` (the client) needs to call the `PaymentService`.
    3.  It directly queries the Service Registry and gets a list of available `PaymentService` instances.
    4.  The `OrderService` then uses a client-side load-balancing algorithm (like Round Robin) to choose one of the instances from the list and makes a direct network request to it.

![Client-Side Discovery](https://docs.microsoft.com/en-us/dotnet/architecture/microservices/net-core-net-framework-microservices/media/client-side-discovery-pattern.png)

-   **Pros**: Simple architecture, as the client has all the information and can make intelligent load-balancing choices.
-   **Cons**: The discovery logic must be implemented in a library and included in *every* client service. This creates a tight coupling between your services and the service registry.

-   **Common Tools**: Netflix Eureka, HashiCorp Consul.

---

## 5. Pattern 2: Server-Side Discovery

In this pattern, the discovery logic is handled by a piece of infrastructure, typically a router or load balancer. The client service is unaware of the discovery process.

-   **How it works**:
    1.  A `PaymentService` instance starts and registers itself (this process is often handled automatically by the infrastructure, like Kubernetes).
    2.  The `OrderService` needs to call the `PaymentService`.
    3.  It makes a request to a well-known, stable endpoint (a "virtual IP" or a DNS name), like `http://payment-service/`.
    4.  A router or load balancer (which is integrated with the service registry) intercepts this request. It looks up a healthy instance of the `PaymentService` in the registry and forwards the request to it.

![Server-Side Discovery](https://docs.microsoft.com/en-us/dotnet/architecture/microservices/net-core-net-framework-microservices/media/server-side-discovery-pattern.png)

-   **Pros**: The client is completely dumb; it doesn't need any special library or knowledge of the registry. This makes the client code much simpler. The logic is centralized in the routing layer.
-   **Cons**: The router/load balancer becomes another piece of infrastructure that needs to be managed and made highly available.

-   **Common Tools**: This is the default model in modern container orchestrators. **Kubernetes** is the prime example. Its built-in DNS and Service objects provide server-side discovery out of the box. Cloud provider load balancers (like AWS ALB) also implement this pattern.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that service discovery is needed because service instances in a microservices environment have dynamic IP addresses.
-   [ ] I know the three components of the solution: the **Service Registry**, the **Service Registration** process, and the **Service Discovery** process.
-   [ ] I understand that **health checks** are critical for keeping the registry up-to-date.
-   [ ] I can describe **Client-Side Discovery**, where the client queries the registry and chooses an instance.
-   [ ] I can describe **Server-Side Discovery**, where the client calls a virtual address and a router handles the lookup.
-   [ ] I know that Kubernetes provides a powerful implementation of Server-Side Discovery.

---

## 13. Research and References

-   **"Microservices Patterns" by Chris Richardson**: Has an excellent chapter on service discovery.
-   **NGINX Blog: "Service Discovery in a Microservices Architecture"**: [Link](https://www.nginx.com/blog/service-discovery-in-a-microservices-architecture/)
-   **Kubernetes Documentation - "Service"**: [Link](https://kubernetes.io/docs/concepts/services-networking/service/)
