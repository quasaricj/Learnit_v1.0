# Horizontal vs. Vertical Scaling

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** scalability in the context of system design.
- **Define** and **differentiate** between vertical scaling and horizontal scaling.
- **Provide** a real-world analogy for each scaling approach.
- **List** the main pros and cons of vertical scaling.
- **List** the main pros and cons of horizontal scaling.
- **Understand** why horizontal scaling is the preferred approach for modern, cloud-native applications.

---

## 2. Introduction: The Need to Handle More Load

**Scalability** is a measure of a system's ability to handle a growing amount of work. As your application becomes more popular, you will have more users, more data, and more requests. A scalable system can adapt to this increased load without any degradation in performance.

When you need to scale your system, there are two fundamental approaches you can take: scaling up (vertically) or scaling out (horizontally).

---

## 3. Vertical Scaling (Scaling Up)

- **What it is**: Increasing the resources of a single server. You are making one machine more powerful.
- **How it's done**:
  - Adding more CPU cores.
  - Increasing the amount of RAM.
  - Using faster, more powerful storage (like a faster SSD).
- **Analogy**: **Replacing the engine in your car with a bigger, more powerful one.** Your car is still the same car, but it's now much faster.

### Pros of Vertical Scaling

1.  **Simplicity**: It is often the easiest way to improve the performance of an application. You don't have to change your application's code or architecture.
2.  **Performance for Certain Applications**: Some applications, like large, monolithic relational databases, are very difficult to distribute and can benefit more from running on a single, extremely powerful machine.

### Cons of Vertical Scaling

1.  **Hard Upper Limit**: There is a physical limit to how much you can scale up a single machine. You can't add an infinite amount of CPU or RAM.
2.  **Expensive**: The cost of high-end hardware increases exponentially. A server that is twice as powerful is often much more than twice the price.
3.  **No Improved Fault Tolerance**: It creates a single point of failure. If your one, giant, powerful server fails, your entire application goes down.

---

## 4. Horizontal Scaling (Scaling Out)

- **What it is**: Adding more servers to your pool of resources. You are distributing the load across multiple, smaller machines.
- **How it's done**:
  - You add more web servers behind a load balancer.
  - You add more nodes to your database cluster.
- **Analogy**: **Adding more cars to your delivery fleet.** Instead of one super-fast delivery truck, you have a fleet of 100 normal vans.

### Pros of Horizontal Scaling

1.  **Effectively "Infinite" Scalability**: You can, in theory, add an unlimited number of machines. This is the model that cloud computing is built on.
2.  **Cost-effective**: You can use cheaper, commodity hardware (or virtual machines). The cost scales more linearly with the capacity.
3.  **High Fault Tolerance and Resilience**: If one of your 100 servers fails, the other 99 can continue to handle the traffic. A single failure does not cause a total outage.

### Cons of Horizontal Scaling

1.  **Increased Complexity**: This is the major drawback.
    - **Application Architecture**: Your application must be designed to be **stateless** and to run in a distributed environment.
    - **Operational Overhead**: You need tools to manage this fleet of servers, such as a **load balancer** to distribute the traffic and an orchestrator (like Kubernetes) to manage the containers.

---

## 5. Which one to choose?

For most modern, cloud-native applications, the answer is clear: **design your application for horizontal scalability.**

The ability to scale out on demand and the inherent resilience of a distributed system are the primary benefits of the cloud. While you might do a small amount of vertical scaling (choosing a slightly larger instance type), your primary scaling strategy should be horizontal.

Even a database, which is traditionally scaled vertically, can be scaled horizontally through techniques like **sharding** and **replication**, which will be covered in a later module.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define **Vertical Scaling** as making a single server more powerful (adding more CPU/RAM).
-   [ ] I can define **Horizontal Scaling** as adding more servers to a pool of resources.
-   [ ] I can use the "bigger engine vs. more cars" analogy to explain the difference.
-   [ ] I know that vertical scaling has a hard limit and is expensive, while horizontal scaling is more flexible and cost-effective.
-   [ ] I know that horizontal scaling is more complex and requires a stateless application architecture.
-   [ ] I understand that **horizontal scaling is the standard** for modern, cloud-native applications.

---

## 7. Research and References

-   **"The Art of Scalability" by Martin L. Abbott and Michael T. Fisher**: The definitive book on the topic.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**
-   **AWS Well-Architected Framework - Performance Efficiency Pillar**: [Link](https://aws.amazon.com/architecture/well-architected/)
-   **"Scale Up vs Scale Out"**: A common topic for introductory blog posts and articles.
