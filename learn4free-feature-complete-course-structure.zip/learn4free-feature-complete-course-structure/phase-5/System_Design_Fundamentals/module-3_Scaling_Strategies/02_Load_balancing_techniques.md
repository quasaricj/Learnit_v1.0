# Load Balancing Techniques

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a load balancer and explain its purpose in a distributed system.
- **Explain** how a load balancer enables horizontal scaling and improves availability.
- **Describe** common load balancing algorithms (Round Robin, Least Connections).
- **Differentiate** between Layer 4 (Transport Layer) and Layer 7 (Application Layer) load balancing.
- **Identify** the role of health checks in a load balancing setup.
- **Recognize** that cloud providers offer load balancing as a managed service.

---

## 2. Introduction: The Need for a Traffic Cop

Horizontal scaling is the practice of adding more servers to handle an increased load. But once you have a fleet of servers, how do you distribute the incoming traffic among them? This is the job of a **load balancer**.

A **load balancer** is a device or a piece of software that acts as a "traffic cop" sitting in front of your servers. It accepts all incoming client requests and distributes them across a pool of backend servers in a way that maximizes speed and capacity utilization and ensures that no one server is overworked.

---

## 3. Core Functions of a Load Balancer

1.  **Distributes Traffic**: Spreads incoming requests across multiple servers (your "server farm" or "backend pool").
2.  **Improves Availability and Resilience**:
    - Load balancers perform periodic **health checks** on the backend servers.
    - If a health check fails (meaning a server is down or unhealthy), the load balancer will **automatically stop sending traffic to that server**.
    - This ensures that user requests are only sent to healthy, operational servers, which dramatically improves the fault tolerance of your application.
3.  **Enables Horizontal Scaling**: A load balancer is the key component that makes horizontal scaling possible. When you need to handle more traffic, you can simply add a new server to the backend pool, and the load balancer will start sending traffic to it. The process is seamless to the end-user.

---

## 4. Common Load Balancing Algorithms

The algorithm determines how the load balancer chooses which backend server to send a request to.

- **Round Robin**:
  - **How it works**: This is the simplest algorithm. The load balancer cycles through the list of servers and sends each new request to the next server in the list.
  - **Use Case**: Works well when all the servers in the pool are of roughly equal capacity.

- **Least Connections**:
  - **How it works**: The load balancer keeps track of how many active connections each server has. It sends the next new request to the server that currently has the fewest active connections.
  - **Use Case**: A more intelligent algorithm that is useful when requests might take a variable amount of time to complete.

- **IP Hash**:
  - **How it works**: The load balancer calculates a hash of the client's IP address and uses this hash to determine which server to send the request to.
  - **Use Case**: This ensures that all requests from a specific user will always be sent to the **same server**. This is important for older, stateful applications that store session data in the server's memory (this is called "session persistence" or "sticky sessions"). For modern, stateless applications, this is generally not needed.

---

## 5. Layer 4 vs. Layer 7 Load Balancing

Load balancers can operate at different layers of the OSI networking model.

### Layer 4 (Transport Layer) Load Balancer

- **How it works**: Operates at the transport layer (TCP/UDP). It makes its routing decisions based only on the source and destination IP addresses and ports. It does not inspect the content of the request.
- **Pros**: Very fast and simple.
- **Analogy**: A simple mail sorter that only looks at the "To" and "From" addresses on an envelope.
- **Cloud Services**: AWS Network Load Balancer (NLB).

### Layer 7 (Application Layer) Load Balancer

- **How it works**: Operates at the application layer (HTTP/HTTPS). It is "smarter" because it can inspect the content of the request, such as the URL path, the HTTP headers, and cookies.
- **Pros**:
  - **Content-Based Routing**: Can make much more intelligent routing decisions.
    - Send requests for `/api` to the backend API servers.
    - Send requests for `/images` to a pool of image servers.
  - **SSL Termination**: The load balancer can handle the expensive process of decrypting HTTPS traffic, so your backend servers receive unencrypted HTTP traffic.
- **Analogy**: A smart mail room that opens the envelope, reads the content of the letter, and routes it to the correct department based on what it's about.
- **Cloud Services**: AWS Application Load Balancer (ALB), Nginx, Traefik. A Kubernetes Ingress is a Layer 7 load balancer.

For most web applications, a **Layer 7 Application Load Balancer is the preferred choice**.

---

## 6. Load Balancers as a Managed Service

All major cloud providers (AWS, Azure, GCP) offer highly available, scalable, and fully managed load balancers as a service. You almost never need to set up and manage your own load balancing software. You simply provision a load balancer from your cloud provider's console or via an IaC tool, configure your backend pool, and it works.

---

## 7. Summary and Mastery Checklist

-   [ ] I can define a load balancer as a "traffic cop" that distributes requests across multiple backend servers.
-   [ ] I can explain that load balancers improve **availability** by using **health checks** to route traffic away from failed servers.
-   [ ] I can describe the **Round Robin** algorithm.
-   [ ] I can explain that a **Layer 7** load balancer is "smarter" than a Layer 4 load balancer because it can inspect the HTTP request content (like the URL path).
-   [ ] I know that a Kubernetes **Service** and **Ingress** are both types of load balancers.
-   [ ] I understand that cloud providers offer load balancing as a managed service.

---

## 8. Research and References

-   **AWS - What is a Load Balancer?**: [Link](https://aws.amazon.com/what-is/load-balancing/)
-   **Nginx - What is Load Balancing?**: A great overview from the creators of one of the most popular load balancing software. [Link](https://www.nginx.com/resources/glossary/load-balancing/)
-   **"High Performance Browser Networking" by Ilya Grigorik**: An online book that goes deep into the networking protocols that underpin the web.
-   **HAProxy**: Another very popular and high-performance open-source load balancer.
