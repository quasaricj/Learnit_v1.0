# Caching Strategies (CDN, Redis, Memcached)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** caching and explain its purpose: to improve performance and reduce load.
- **Describe** the trade-offs of caching (performance vs. potential for stale data).
- **Explain** what a Content Delivery Network (CDN) is and its use case.
- **Differentiate** between an in-memory cache (like Redis) and a CDN.
- **Describe** common caching strategies like cache-aside.
- **Define** Time to Live (TTL) and its role in cache eviction.
- **Identify** what kind of data is a good candidate for caching.

---

## 2. Introduction: The Principle of Locality

The **principle of locality** is a concept in computer science which states that we tend to access the same small set of data or resources much more frequently than the rest. For example, on a news website, the top 10 articles on the homepage will be accessed millions of times, while an article from a year ago might be accessed only a few times.

**Caching** is a powerful technique that takes advantage of this principle. A **cache** is a high-speed data storage layer which stores a subset of data, typically the most frequently accessed data, so that future requests for that data are served up faster than is possible by accessing the data's primary storage location.

The goal of caching is to:
1.  **Reduce Latency**: Reading from a fast, in-memory cache is much faster than reading from a slow, disk-based database.
2.  **Reduce Load**: By serving a request from the cache, you avoid hitting your database or application servers, which reduces their load and can save you money.

---

## 3. Types of Caches

### 1. Content Delivery Network (CDN)

- **What it is**: A CDN is a geographically distributed network of proxy servers. It is a cache for your **static assets** (images, videos, CSS, JavaScript files).
- **How it works**:
  1.  When a user in London requests an image from your website for the first time, the request goes all the way to your origin server (e.g., in the US).
  2.  The CDN's "edge server" in London also caches a copy of this image.
  3.  The next time a user in London requests the same image, the request is served directly from the nearby edge server, which is much faster.
- **Use Case**: Caching static files. This is one of the easiest and most effective performance optimizations you can make for a website.
- **Examples**: Cloudflare, Amazon CloudFront, Akamai.

### 2. Application-Level Cache (In-Memory Data Grid)

- **What it is**: A distributed, in-memory, key-value data store. It is a cache for your **dynamic data** (the results of database queries, API calls, etc.).
- **How it works**: The cache is a separate service that runs in your backend. Your application code is responsible for managing the cache.
- **Examples**: **Redis**, **Memcached**.

---

## 4. Caching Strategies (for Application-Level Caching)

How does your application code interact with the cache?

### Cache-Aside (or Lazy Loading)

This is the most common caching strategy.

1.  When your application receives a request for some data, it first checks the **cache**.
2.  **Cache Hit**: If the data is in the cache, it's returned directly to the client.
3.  **Cache Miss**: If the data is *not* in the cache:
    a. The application fetches the data from the **database** (the "source of truth").
    b. It stores a copy of this data in the **cache**.
    c. It returns the data to the client.

Subsequent requests for the same data will now be a cache hit.

### Cache Eviction and TTL

A cache has a limited amount of memory. **Cache eviction** is the process of deciding which items to remove from the cache to make room for new ones.

- **Time to Live (TTL)**: This is the simplest eviction policy. When you store an item in the cache, you set an expiration time (a TTL). After that time has passed, the cache will automatically remove the item. This also helps to ensure that stale data doesn't live in your cache for too long.
- **Other Policies**: More complex policies include Least Recently Used (LRU) and Least Frequently Used (LFU).

### The Hardest Problem: Cache Invalidation

The biggest challenge with caching is what to do when the original data in the database changes. How do you make sure the data in your cache is not **stale**? This is famously one of the "two hard things in computer science".

- **TTL**: The simplest solution. You accept that your data might be stale for the duration of the TTL.
- **Write-Through Cache**: The application writes the change to the cache first, and the cache is responsible for writing it to the database.
- **Explicit Invalidation**: When you update the database, you also explicitly send a command to the cache to delete the old entry. This is effective but can be complex to manage.

---

## 5. What Should You Cache?

- **Data that is read frequently and written infrequently.** The homepage of a news site is a perfect example.
- **The results of expensive computations or database queries.**
- **Static assets.** (Use a CDN for this).

**What Should You NOT Cache?**
- Data that changes very frequently.
- Data that must always be 100% up-to-date (e.g., a bank account balance).

---

## 6. Redis vs. Memcached

- **Memcached**: A simple, fast, multi-threaded in-memory key-value store. It is just a cache.
- **Redis**: Often called a "data structures server". It is also an in-memory key-value store, but the "values" can be more complex data structures like lists, sets, and sorted sets. It also supports persistence. Redis can be used as a cache, a message broker, or even a primary database. **Redis is generally the more popular and flexible choice today.**

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain that **caching** is about storing a copy of frequently accessed data in a faster storage layer.
-   [ ] I know that the two main goals of caching are to **reduce latency** and **reduce load**.
-   [ ] I can define a **CDN** as a geographically distributed cache for **static assets**.
-   [ ] I can define **Redis** as an in-memory cache for **dynamic data**.
-   [ ] I can describe the **Cache-Aside** strategy (look in the cache first, if it's not there, get it from the database and put it in the cache).
-   [ ] I understand that **cache invalidation** (dealing with stale data) is the hardest part of caching.

---

## 8. Research and References

-   **"System Design Interview – An insider's guide" by Alex Xu**: Has an excellent, visual chapter on caching.
-   **AWS - Caching**: An overview of caching strategies from a cloud provider.
-   **Redis Official Website**: [Link](https://redis.io/)
-   **Cloudflare - What is a CDN?**: [Link](https://www.cloudflare.com/learning/cdn/what-is-a-cdn/)
