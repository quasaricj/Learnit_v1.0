# Database Sharding and Partitioning

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** database partitioning and sharding as techniques for horizontal scaling.
- **Differentiate** between vertical and horizontal partitioning.
- **Explain** the purpose of sharding: to distribute a database across multiple machines.
- **Describe** common sharding strategies (e.g., algorithmic sharding).
- **List** the main benefits of sharding (scalability, availability).
- **List** the main drawbacks of sharding (complexity, operational overhead).
- **Understand** that sharding is a technique of last resort.

---

## 2. Introduction: The Limits of a Single Database

As an application grows, its database can become a major bottleneck. A single, monolithic database running on a powerful server (vertical scaling) can only handle so much load. At a certain point, you will hit the limits of a single machine's CPU, memory, or storage.

To scale the database beyond a single machine, you need to **partition** it. **Sharding** is the most common form of database partitioning.

---

## 3. Partitioning

**Partitioning** is the general term for breaking up a large database or a large table into smaller, more manageable pieces, or "partitions".

### Vertical Partitioning

- **What it is**: Dividing a table into smaller tables by **columns**.
- **How it works**: You might put your most frequently accessed, narrow columns in one table and your less frequently accessed, wide (e.g., text blob) columns in another. Both tables would share the same primary key.
- **Analogy**: Splitting a large spreadsheet into two separate spreadsheets, but keeping the same number of rows.
- **Benefit**: Can improve query performance if your queries only need to access a subset of the columns.

### Horizontal Partitioning (Sharding)

- **What it is**: Dividing a table into smaller tables by **rows**. Each smaller table (a "shard") has the same columns, but only a subset of the data.
- **This is what is commonly referred to as sharding.**
- **Analogy**: Taking a massive, 10-million-row spreadsheet and splitting it into ten separate spreadsheets, each with 1 million rows.

---

## 4. Sharding

**Sharding** is the process of horizontally partitioning a database, where each partition (a **shard**) is stored on a separate physical server. Each shard is an independent database.

The goal of sharding is to distribute a very large database across a cluster of smaller, cheaper servers, allowing the database to scale horizontally.

### Sharding Strategy: Choosing a Shard Key

To implement sharding, you need a **shard key**. This is a column (or set of columns) that the application uses to determine which shard a particular row of data should be stored in.

**Algorithmic Sharding (or Hashed Sharding)** is a common strategy:
1.  Choose a shard key. The `user_id` is a very common choice.
2.  Create a hash of the shard key (e.g., `hash(user_id)`).
3.  Take the result of the hash modulo the number of shards to determine which shard to use.
    `shard_id = hash(user_id) % number_of_shards`
- **Benefit**: This strategy distributes the data evenly across the shards.
- **Drawback**: When you need to add more shards (a "resharding" operation), you have to remap all your data, which is a very complex and painful process.

---

## 5. Benefits of Sharding

1.  **Massive Scalability**: Sharding is the primary way to scale a relational database beyond the limits of a single machine. It allows you to store a virtually unlimited amount of data and handle a very high volume of read and write traffic.
2.  **Improved Performance**: By distributing the data, you are also distributing the load. Queries can be faster because they are only scanning a smaller shard instead of a massive table.
3.  **Higher Availability**: If one shard goes down, it only affects a subset of your data. The other shards (and the users whose data is on them) can remain operational.

---

## 6. Drawbacks of Sharding

Sharding is extremely powerful, but it adds a huge amount of complexity to your system. It is a technique of **last resort**, to be used only when you have exhausted all other options for scaling your database.

1.  **Application Complexity**:
    - The application logic now needs to be aware of the sharding. It needs to know how to connect to the correct shard to find the data it's looking for. This logic can be moved into a separate routing layer.
2.  **Loss of ACID Guarantees**:
    - Cross-shard transactions are not supported. You cannot perform a single, ACID-compliant transaction that touches data on two different shards.
3.  **Difficult Cross-Shard Joins**:
    - Performing a `JOIN` on data that lives in two different shards is very difficult and inefficient. This is why the choice of shard key is so important; you want to co-locate data that is frequently accessed together on the same shard.
4.  **Operational Overhead**:
    - You now have a distributed database system, which is much more complex to manage, back up, and monitor.
    - **Resharding** (adding or removing shards) is a notoriously difficult and risky operation.

### Alternatives to Sharding

Before you decide to shard your relational database, you should consider:
- **Query Optimization and Indexing**: Can you make your queries faster?
- **Caching**: Can you reduce the read load on your database with a cache like Redis?
- **Read Replicas**: (Covered in the next module).
- **Switching to a NoSQL Database**: Some NoSQL databases, like Cassandra and DynamoDB, are designed to be distributed and scalable from the ground up, and they handle the sharding process for you automatically.

---

## 7. Summary and Mastery Checklist

-   [ ] I can define **Sharding** as the process of horizontally partitioning a database across multiple servers.
-   [ ] I know that the goal of sharding is to achieve **horizontal scalability** for a database.
-   [ ] I can explain that a **shard key** (like `user_id`) is used to determine which shard a piece of data belongs to.
-   [ ] I can list a major benefit of sharding (e.g., massive scalability).
-   [ ] I can list a major drawback of sharding (e.g., application complexity, no cross-shard joins).
-   [ ] I understand that sharding is a complex, last-resort scaling strategy.

---

## 8. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Has an excellent chapter on partitioning and sharding.
-   **"Database Sharding - The No-BS Guide"**: A good blog post with practical examples.
-   **Vitess**: An open-source database clustering system for MySQL that handles sharding. [Link](https://vitess.io/)
-   **DigitalOcean - "Understanding Database Sharding"**: [Link](https://www.digitalocean.com/community/tutorials/understanding-database-sharding)
