# Database Replication and Redundancy

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** database replication and its purpose.
- **Differentiate** between the primary (master) and replica (slave) databases.
- **Explain** how replication improves read scalability and availability.
- **Describe** the concept of replication lag.
- **Differentiate** between synchronous and asynchronous replication.
- **Understand** how automatic failover works in a replicated setup.
- **Distinguish** between replication (copying data) and sharding (splitting data).

---

## 2. Introduction: Beyond a Single Database

Running a single database instance creates two major problems:
1.  **It is a single point of failure (SPOF)**. If that database server crashes, your entire application goes down.
2.  **It can become a performance bottleneck**. A single server can only handle so many read and write requests.

**Database replication** is a technique that addresses both of these problems. Replication is the process of continuously copying data from a primary database to one or more replica databases.

---

## 3. The Primary-Replica (Master-Slave) Model

This is the most common model for database replication.

- **The Primary (or Master) Database**:
  - This is the main database. It is the **single source of truth**.
  - It accepts all the **write** operations (`INSERT`, `UPDATE`, `DELETE`).
  - It keeps a log of all the changes it makes.

- **The Replica (or Slave) Databases**:
  - These are read-only copies of the primary database.
  - They receive the log of changes from the primary and apply them to their own copy of the data to stay in sync.
  - They do **not** accept write operations directly from the application.

### The Replication Process

1.  The application sends a write request to the **Primary** database.
2.  The Primary database executes the write and records the change in its transaction log.
3.  The Primary then sends this change to its **Replicas**.
4.  The Replicas receive the change and apply it to their own data.

---

## 4. Benefits of Replication

### 1. Improved Read Scalability

- The biggest benefit of replication is that it allows you to **scale your read traffic**.
- Instead of sending all your database queries (both reads and writes) to the single primary database, you can configure your application to:
  - Send all **writes** to the **Primary**.
  - Distribute all **reads** (`SELECT` queries) across the multiple **Replicas**.
- This is extremely effective for read-heavy applications (which is the vast majority of web applications). You can easily scale your read capacity by simply adding more read replicas.

### 2. Higher Availability and Fault Tolerance

- Replication provides a **hot standby** for your database.
- **Automatic Failover**: You can configure a system where, if the **Primary** database fails a health check, one of the **Replicas** is automatically **promoted** to become the new Primary.
- This process can happen in seconds or minutes, meaning your application can recover from a database failure with minimal downtime.

---

## 5. Key Concepts and Challenges

### Replication Lag

- In most setups, replication is **asynchronous**. The Primary sends the changes to the Replicas but does not wait for them to confirm that they have applied the change.
- This means there is a small delay, called **replication lag**, between the time a write happens on the Primary and the time it is visible on the Replicas. This lag is usually milliseconds, but it can grow under heavy load.
- This can lead to **eventual consistency** issues. If you write a piece of data and then immediately try to read it back, you might be routed to a Replica that hasn't received the update yet, and you will get back the old, stale data. Your application needs to be designed to handle this.

### Synchronous vs. Asynchronous Replication

- **Asynchronous Replication** (most common): Fast writes, but the potential for replication lag and data loss if the primary crashes before its changes have been sent to the replicas.
- **Synchronous Replication**: The Primary waits for at least one Replica to confirm that it has received the change before it acknowledges the write to the application.
  - **Pros**: Guarantees no data loss.
  - **Cons**: Makes the write operation much slower.

### Replication vs. Sharding

- **Replication** is about **copying** data. You have multiple, identical copies of the *entire* dataset. It is primarily used to improve read scalability and availability.
- **Sharding** is about **splitting** data. You have multiple servers, but each one holds only a *subset* of the data. It is primarily used to scale *write* traffic and to handle datasets that are too large for a single machine.

These two techniques are not mutually exclusive. A large, complex database system will often use both: it will be sharded, and each shard will itself be a replicated set of a primary and one or more replicas.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define **Replication** as the process of keeping multiple copies of a database in sync.
-   [ ] I know that in a primary-replica setup, all **writes** go to the **primary**, and **reads** can be distributed across the **replicas**.
-   [ ] I can list the two main benefits of replication: **read scalability** and **high availability**.
-   [ ] I can define **replication lag** as the delay between a write on the primary and its visibility on a replica.
-   [ ] I can explain the high-level difference between **replication (copying)** and **sharding (splitting)**.

---

## 7. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 5 is a deep dive into replication.
-   **PostgreSQL Documentation - Replication**: [Link](https://www.postgresql.org/docs/current/replication.html)
-   **MySQL Documentation - Replication**: [Link](https://dev.mysql.com/doc/refman/8.0/en/replication.html)
-   **"Scaling your Database: Sharding vs. Replication"**: A common topic for blog posts and articles.
