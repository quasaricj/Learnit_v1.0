# Content Delivery Networks (CDNs)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a Content Delivery Network (CDN).
- **Explain** the primary goal of a CDN: to reduce latency for global users.
- **Describe** how a CDN works by caching content at edge locations.
- **Identify** the types of content that are best suited for a CDN (static assets).
- **Differentiate** between the origin server and an edge server.
- **List** other benefits of using a CDN, such as reduced load on the origin and improved security.
- **Recognize** the names of major CDN providers.

---

## 2. Introduction: The Problem of Global Latency

The speed of light is a fundamental physical limit. When a user in Australia requests a piece of content from a server in North America, the data has to travel thousands of miles across undersea fiber optic cables. This round-trip time, known as **latency**, can take hundreds of milliseconds and makes the website feel slow for the user, no matter how fast your server is.

A **Content Delivery Network (CDN)** is a globally distributed network of proxy servers that is designed to solve this problem. Its primary goal is to serve content to end-users with high availability and high performance by bringing the content **physically closer** to them.

---

## 3. How a CDN Works

1.  **Origin Server**: This is your main web server where your application and its original, definitive content reside.
2.  **Edge Locations (or Points of Presence - PoPs)**: The CDN provider has hundreds of data centers located all over the world. These are the "edge locations".
3.  **Caching at the Edge**: The CDN makes copies of your content (it **caches** it) and stores these copies on its edge servers.

**The User's Experience**:
1.  A user in Germany tries to download an image from your website.
2.  Instead of their request going all the way to your origin server in the US, the user's browser is transparently redirected by DNS to the **nearest CDN edge server**, for example, in Frankfurt.
3.  **Cache Hit**: If the edge server in Frankfurt already has a cached copy of the image, it serves it directly to the user. This is extremely fast because the server is geographically close.
4.  **Cache Miss**: If this is the first time a user in that region has requested the image, the edge server does not have it. The edge server will then make a request to your **origin server**, get the image, save a copy of it for future requests, and then serve it to the user.

---

## 4. What Should You Put on a CDN?

CDNs are most effective for content that is the same for all users. This is called **static content**.

- **Ideal Candidates for a CDN**:
  - **Images** (`.jpg`, `.png`, `.gif`)
  - **Videos**
  - **CSS stylesheets** (`.css`)
  - **JavaScript files** (`.js`)
  - Other large files (e.g., software downloads, PDF documents).

You generally do **not** cache **dynamic content** on a CDN. Dynamic content is content that is personalized for a specific user, like the contents of their shopping cart or their personal profile page. This data must be fetched from your origin server on every request.

---

## 5. Benefits of Using a CDN

1.  **Improved Performance (Lower Latency)**: This is the primary benefit. By serving content from a server that is physically closer to the user, you can dramatically reduce the page load time.
2.  **Reduced Load on the Origin Server**: Because the CDN is handling the vast majority of requests for your static assets, your origin server is free to focus on its real job: serving dynamic content and executing business logic. This can significantly reduce your server costs.
3.  **Increased Availability and Reliability**: A CDN distributes your content across many servers. If your origin server goes down, the CDN may still be able to serve the cached content to users.
4.  **Improved Security**: Modern CDNs often include security features that can help protect your site from attacks like **Distributed Denial of Service (DDoS)**. They can absorb a massive amount of malicious traffic at the "edge" before it ever reaches your origin server.

### Major CDN Providers

- **Cloudflare**: A hugely popular provider, known for its excellent free tier and its security features.
- **Amazon CloudFront**: The CDN service that is part of AWS and is tightly integrated with other AWS services like S3.
- **Akamai**: One of the oldest and largest CDN providers in the world.
- **Fastly**: A modern CDN focused on performance and configurability.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define a CDN as a **globally distributed network of cache servers**.
-   [ ] I can explain that the main purpose of a CDN is to **reduce latency** by serving content from a server that is geographically closer to the user.
-   [ ] I can differentiate between the **origin server** (where my application lives) and an **edge server** (part of the CDN).
-   [ ] I know that CDNs are primarily used for caching **static content** like images, CSS, and JavaScript.
-   [ ] I can list another benefit of a CDN, such as **reducing the load** on my origin server or improving security.
-   [ ] I can name a major CDN provider, like Cloudflare or Amazon CloudFront.

---

## 7. Research and References

-   **"High Performance Browser Networking" by Ilya Grigorik**: Chapter 1 has a great explanation of latency and the speed of light.
-   **Cloudflare - What is a CDN?**: A fantastic and easy-to-understand overview. [Link](https://www.cloudflare.com/learning/cdn/what-is-a-cdn/)
-   **AWS CloudFront Documentation**: [Link](https://aws.amazon.com/cloudfront/)
-   **How CDNs Work**: A good technical deep dive.
