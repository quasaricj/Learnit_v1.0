# Scaling with Content Delivery Networks (CDNs)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a Content Delivery Network (CDN) and its primary purpose.
-   **Explain** that the speed of light is a fundamental bottleneck in web performance (i.e., network latency).
-   **Describe** how a CDN mitigates latency by caching content at geographically distributed "edge locations."
-   **Differentiate** between static and dynamic content and explain which is traditionally best suited for a CDN.
-   **List** the key benefits of using a CDN, including improved performance, reduced origin server load, and enhanced security.

---

## 2. The Problem: The Unbeatable Speed of Light

Imagine your web servers are all located in a data center in Virginia, USA. This is your **origin server**. Now, a user from Tokyo, Japan, tries to load your website.

Every single HTTP request for your website's assets—the HTML, the CSS, the JavaScript, the images—must travel thousands of miles across undersea cables from Tokyo to Virginia and then back again. This round trip, governed by the physical speed of light, introduces a significant delay called **network latency**. Even with the fastest servers in the world, your site will feel slow to that user in Tokyo simply because of the physical distance.

This is a massive scalability problem. How do you serve a global audience with low latency? You can't make the speed of light faster, so you have to **reduce the distance**.

---

## 3. The Solution: Bring the Content Closer

A **Content Delivery Network (CDN)** is a globally distributed network of proxy servers, deployed in multiple data centers around the world. These locations are called **Points of Presence (PoPs)** or **edge locations**.

The core idea of a CDN is to cache copies of your content at these edge locations, bringing the data physically closer to your end-users.

### How a CDN Works:

1.  **The First Request (Cache Miss)**:
    -   A user in Tokyo requests an image, `my-photo.jpg`, from your website.
    -   DNS intelligently routes the user to the nearest CDN edge location (the PoP in Tokyo).
    -   The Tokyo edge server doesn't have the image yet (a "cache miss").
    -   It forwards the request to your origin server in Virginia, downloads the image, **saves a copy of it**, and then serves it to the user.

2.  **Subsequent Requests (Cache Hit)**:
    -   A new user in Seoul, South Korea, requests the same image.
    -   DNS routes this user to the same Tokyo PoP (as it's the closest).
    -   This time, the image is already in the edge server's cache (a "cache hit").
    -   The Tokyo server serves the image directly and instantly, without ever contacting your origin server in Virginia.

![CDN Workflow Diagram](https://www.imperva.com/learn/wp-content/uploads/sites/13/2019/01/CDN.png.pagespeed.ce.53jhCo2pY-.png)

The percentage of requests that can be served directly from the CDN's edge cache is called the **cache hit ratio**. A high cache hit ratio is the primary goal of using a CDN.

---

## 4. What Content is Best for a CDN?

### Static Content (The Perfect Use Case)

This is content that does not change, regardless of the user. It is the primary use case for a CDN.
-   Images (`.jpg`, `.png`)
-   Videos
-   CSS files
-   JavaScript files
-   Fonts

### Dynamic Content (A More Advanced Use Case)

This is content that is personalized for each user, like the contents of a shopping cart or a user's timeline. Traditionally, this could not be cached. However, modern CDNs are increasingly able to cache certain types of dynamic content or at least accelerate the connection between the user and the origin using techniques like connection optimization and API caching.

---

## 5. The Key Benefits of Using a CDN

1.  **Improved Performance (Lower Latency)**: By serving content from a server physically closer to the user, you reduce the round-trip time, making your website load much faster. This is the main benefit.

2.  **Reduced Load on the Origin Server**: By offloading the serving of static assets to the CDN, you dramatically reduce the amount of traffic your origin servers have to handle. This saves you money on bandwidth and allows your servers to focus on their real job: running your application logic.

3.  **Increased Availability and Reliability**: A CDN's distributed nature makes your application more resilient. If your origin server goes down, the CDN may still be able to serve content from its cache. Its massive scale can also help absorb traffic spikes.

4.  **Enhanced Security**: Most modern CDNs offer security features at the edge, such as protection against Distributed Denial of Service (DDoS) attacks and a Web Application Firewall (WAF). They can filter out malicious traffic before it ever reaches your origin server.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that **latency** caused by physical distance is a major performance bottleneck.
-   [ ] I can define a **CDN** as a network of geographically distributed servers that cache content close to users.
-   [ ] I can describe the process of a user being routed to an **edge location** and the difference between a **cache hit** and a **cache miss**.
-   [ ] I know that **static assets** (images, CSS, JS) are the ideal content to be served by a CDN.
-   [ ] I can list the four main benefits of a CDN: lower latency, reduced origin load, higher availability, and better security.

---

## 13. Research and References

-   **Cloudflare Learning Center: "What is a CDN?"**: [Link](https://www.cloudflare.com/learning/cdn/what-is-a-cdn/)
-   **AWS CloudFront Documentation**: Understanding the features of a major CDN provider is a great way to learn. [Link](https://aws.amazon.com/cloudfront/)
-   **"High Performance Browser Networking" by Ilya Grigorik**: An excellent book that covers CDNs and many other topics related to network performance.
