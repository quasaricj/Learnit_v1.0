# Database Scaling: Sharding and Partitioning

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** database partitioning and its purpose.
-   **Differentiate** between Vertical Partitioning and Horizontal Partitioning (Sharding).
-   **Define** a Shard Key and explain its critical role in a sharding strategy.
-   **Describe** common sharding strategies, such as Hashed/Algorithmic and Range-Based sharding.
-   **Identify** the major challenges and complexities introduced by sharding, such as cross-shard joins and rebalancing.
-   **Explain** why sharding is considered a method of last resort for scaling databases.

---

## 2. The Problem: The Single Database Bottleneck

For many applications, the database eventually becomes the ultimate bottleneck. You can add read replicas to scale read traffic, but what happens when your write traffic becomes too intense for a single server to handle? Or what if your dataset grows so large (terabytes of data) that a single machine can't store it or back it up efficiently?

When you reach the limits of what a single database server can do (a limit of vertical scaling), you need a way to distribute the data and the workload across multiple machines. This is achieved through **partitioning**.

---

## 3. What is Partitioning?

**Partitioning** is the general term for breaking up a large database into smaller, more manageable pieces. There are two main ways to do this.

### Vertical Partitioning

This involves splitting a table by its **columns**. You put groups of columns that are frequently used together into their own, smaller tables.

-   **Example**: Imagine a `Users` table with columns `(user_id, name, email, last_login, bio, profile_picture_blob)`. The `bio` and `profile_picture_blob` columns are large and not accessed as frequently as the others.
-   **Solution**: You could split this into two tables:
    -   `Users` (`user_id`, `name`, `email`, `last_login`)
    -   `UserProfiles` (`user_id`, `bio`, `profile_picture_blob`)
-   **Benefit**: Queries for user login information are now faster because they are scanning a much "thinner" table. It also allows you to store the large, less-frequently-accessed data on cheaper, slower storage if needed.

### Horizontal Partitioning (Sharding)

This is the most common and powerful form of partitioning for scalability. It involves splitting a table by its **rows**. You put different groups of rows onto different database servers. Each server, which holds a subset of the data, is called a **shard**.

-   **Sharding** is just another name for **horizontal partitioning**.
-   **Example**: You have a `Users` table with a billion rows.
-   **Solution**: You could split this into 4 shards:
    -   **Shard 1**: Contains users with IDs 1 - 250,000,000.
    -   **Shard 2**: Contains users with IDs 250,000,001 - 500,000,000.
    -   And so on.
-   **Benefit**: Both the data storage and the query workload are distributed across multiple machines. This allows you to scale your database's write capacity almost infinitely by adding more shards.

---

## 4. The Shard Key: The Most Important Decision

To implement sharding, you must choose a **shard key**. This is a column (or a set of columns) in your table whose value will determine which shard a particular row belongs to. The choice of a shard key is the single most important decision in a sharding strategy.

A **good shard key** distributes data and query load evenly across all shards. A **bad shard key** creates "hot spots," where one shard gets a disproportionate amount of traffic, defeating the purpose of sharding.

---

## 5. Common Sharding Strategies

### 1. Hashed / Algorithmic Sharding

-   **How it works**: You apply a hash function to the shard key, and the output of the hash determines which shard the data goes to. (e.g., `shard_id = hash(user_id) % number_of_shards`).
-   **Pros**: Tends to distribute data very evenly, as the hash function randomizes the placement.
-   **Cons**: Makes range queries impossible. You can't ask for "all users with IDs between 100 and 200" because their data has been scattered across all shards by the hash function.

### 2. Range-Based Sharding

-   **How it works**: You divide the data based on a range of values in the shard key.
-   **Example**: Users A-F go to Shard 1, G-M go to Shard 2, etc. Or User IDs 1-1M go to Shard 1, 1M-2M go to Shard 2.
-   **Pros**: Easy to implement. Makes range queries efficient, as you only have to query the relevant shard(s).
-   **Cons**: Can easily lead to hot spots. If you are sharding by `creation_date`, all your new user signups will hammer the last shard.

---

## 6. The Immense Challenges of Sharding

Sharding is extremely powerful, but it introduces significant complexity. It should be a last resort after you have exhausted all other options (caching, read replicas, query optimization).

-   **Cross-Shard Joins**: Performing a `JOIN` on two tables that are on different shards is incredibly difficult and inefficient. It often requires querying all shards and then combining the results in your application code. This is why data is often denormalized in sharded systems.

-   **Rebalancing**: What happens when you need to add a new shard to your database? You need to move a massive amount of data from the existing shards to the new one, all while the system is live and serving traffic. This is a complex and risky operational task.

-   **Transactions**: Distributed transactions across multiple shards are very complex to implement and are often avoided in favor of eventually consistent models like the Saga pattern.

-   **Complexity**: Your application logic now needs to be aware of the sharding topology. A routing layer is required to direct queries to the correct shard(s).

---

## 12. Summary and Mastery Checklist

-   [ ] I can differentiate between **Vertical Partitioning** (splitting by columns) and **Horizontal Partitioning / Sharding** (splitting by rows).
-   [ ] I know that sharding is used to scale a database's write capacity and storage beyond a single server.
-   [ ] I can define a **Shard Key** and explain why its choice is critical for avoiding hot spots.
-   [ ] I can describe the difference between Hashed sharding (even distribution) and Range-based sharding (good for range queries).
-   [ ] I can list at least two major challenges of sharding, such as cross-shard joins or rebalancing.

---

## 13. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Provides an in-depth look at partitioning and its complexities.
-   **The Uber Engineering Blog**: Has several excellent articles on how and why they sharded their databases.
-   **DigitalOcean - "Understanding Database Sharding"**: [Link](https://www.digitalocean.com/community/tutorials/understanding-database-sharding)
