# Horizontal vs. Vertical Scaling: Scaling Up vs. Scaling Out

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** scalability and the need for scaling computer systems.
-   **Define** Vertical Scaling (Scaling Up) and provide a clear analogy.
-   **Define** Horizontal Scaling (Scaling Out) and provide a clear analogy.
-   **List** the key advantages and disadvantages of each scaling approach.
-   **Explain** why horizontal scaling is the preferred method for building massively scalable, fault-tolerant web applications.

---

## 2. Introduction: The Need to Grow

When you first launch an application, a single server might be enough to handle all the user traffic. But as your user base grows, that single server will become overwhelmed. It will run out of resources—CPU, memory, or network bandwidth—and your application's performance will suffer, or it will crash altogether.

**Scalability** is the measure of a system's ability to handle a growing amount of work. To handle this growth, you need to add more capacity to your system. There are two fundamental ways to do this: scaling vertically or scaling horizontally.

---

## 3. Vertical Scaling (Scaling Up)

Vertical scaling means increasing the resources of a single server. You are making your existing server more powerful.

-   **Analogy**: "The Super Saiyan." You take your one fighter and make them stronger. You're not adding more fighters; you're just powering up the one you have.
-   **How it's done**:
    -   Adding more RAM.
    -   Upgrading to a faster CPU.
    -   Adding more or faster disk storage.
    -   In the cloud, this means shutting down your instance and restarting it on a larger instance type (e.g., moving from an AWS `t2.micro` to an `m5.large`).

![Vertical Scaling](https://www.researchgate.net/profile/Redowan-Mahmud/publication/320409059/figure/fig1/AS:631622340608012@1527599551461/A-visual-representation-of-vertical-and-horizontal-scaling-Vertical-scaling-is-done-by.png)

### Pros of Vertical Scaling:

-   **Simplicity**: It's often the easiest way to add capacity. Your software doesn't need to change. There's no distributed systems complexity. You just run the same code on a bigger box.
-   **Performance**: Since all communication happens within a single machine (in-process), it can be extremely fast. There is no network latency.

### Cons of Vertical Scaling:

-   **Hard Upper Limit**: There is a physical limit to how powerful a single machine can be. You can't add RAM or CPU cores indefinitely.
-   **Expensive**: High-end, powerful servers are disproportionately more expensive than commodity hardware. The cost increases exponentially, not linearly.
-   **No Fault Tolerance**: It creates a single point of failure (SPOF). If that one, super-powerful server fails, your entire application is down.

---

## 4. Horizontal Scaling (Scaling Out)

Horizontal scaling means adding more servers to your system to distribute the load among them. You are adding more machines to your pool of resources.

-   **Analogy**: "The Clone Army." Instead of making one fighter stronger, you add thousands of identical fighters to your army.
-   **How it's done**:
    -   Adding more web servers behind a load balancer.
    -   Adding more nodes to a database cluster.
    -   Adding more workers to a processing queue.
    -   In the cloud, this means spinning up more instances of the same size.

![Horizontal Scaling](https://www.researchgate.net/profile/Redowan-Mahmud/publication/320409059/figure/fig1/AS:631622340608012@1527599551461/A-visual-representation-of-vertical-and-horizontal-scaling-Vertical-scaling-is-done-by.png)

### Pros of Horizontal Scaling:

-   **Virtually Unlimited Scalability**: You can, in theory, scale almost infinitely by simply adding more commodity servers.
-   **Fault Tolerance and High Availability**: If one server in your pool of 100 servers fails, the load balancer simply stops sending traffic to it. The other 99 servers continue to run, and the application stays online.
-   **Cost-Effective**: It is much cheaper to buy and operate a fleet of smaller, commodity machines than a single, monolithic high-end server.

### Cons of Horizontal Scaling:

-   **Architectural Complexity**: This is the biggest challenge. Your application must be designed to be distributed. This introduces a host of new problems:
    -   How do you distribute traffic? (Load Balancing)
    -   How do services find each other? (Service Discovery)
    -   How do you manage state? (Services must be stateless).
    -   How do you ensure data consistency across a distributed database? (Sharding, eventual consistency).

---

## 5. Which One Should You Choose?

In the modern era of cloud computing and large-scale web services, **horizontal scaling is the dominant paradigm**. The benefits of fault tolerance and near-infinite scalability are essential for building the reliable, global applications we use today.

However, that doesn't mean vertical scaling is useless. A common pattern is to:
1.  **Scale vertically to a certain point** where the cost-performance ratio is optimal (e.g., finding the most efficient instance size for your workload).
2.  **Then, scale horizontally** by adding more of those optimally-sized instances.

For stateful systems like databases, vertical scaling is often the first step because it's simpler. Scaling a database horizontally (sharding) is far more complex than simply moving it to a bigger machine.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define **Vertical Scaling** as adding more resources to a single server ("scaling up").
-   [ ] I can define **Horizontal Scaling** as adding more servers to a pool of resources ("scaling out").
-   [ ] I know the primary benefit of vertical scaling is its simplicity.
-   [ ] I know the primary limitation of vertical scaling is its hard upper limit and single point of failure.
-   [ ] I know the primary benefit of horizontal scaling is its near-infinite scalability and built-in fault tolerance.
-   [ ] I know the primary challenge of horizontal scaling is the need for an architecture that supports distributed systems.

---

## 13. Research and References

-   **AWS Well-Architected Framework - "Horizontal vs. Vertical Scaling"**: A good overview from a cloud provider's perspective.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: The book discusses the trade-offs in great detail, especially in the context of databases.
