# A Deeper Dive into Load Balancing Strategies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Recap** the role of a load balancer in enabling horizontal scaling and high availability.
-   **Describe and contrast** at least three common load balancing algorithms: Round Robin, Least Connections, and IP Hash.
-   **Define** a "weighted" load balancing algorithm (e.g., Weighted Round Robin) and its use case.
-   **Explain** the concept of "sticky sessions" (session affinity), its pros, and its significant cons for scalability.
-   **Explain** the critical importance of active and passive health checks for a load balancing setup.

---

## 2. Introduction: Beyond Just Forwarding Traffic

We've established that a load balancer is a "traffic cop" that distributes requests across a pool of backend servers. But how does it *decide* where to send the next request? This decision is governed by a configured **algorithm** or **strategy**.

Choosing the right strategy is crucial for optimizing your resource utilization, ensuring fairness, and maintaining application state when necessary. A sophisticated load balancing strategy does more than just prevent servers from being overloaded; it intelligently manages the flow of traffic based on the desired behavior of the application.

---

## 3. Common Load Balancing Algorithms

### 1. Round Robin

This is the simplest and most common algorithm. The load balancer maintains a list of servers and sends each new request to the next server in the list, cycling back to the beginning when it reaches the end.

-   **Pros**: Extremely simple, predictable, and easy to implement.
-   **Cons**: It assumes all backend servers are equal in capacity and are processing requests of similar difficulty. It can easily overload a server that gets a few slow, resource-intensive requests in a row.

### 2. Weighted Round Robin

A variation of Round Robin where an administrator assigns a "weight" to each server. A server with a higher weight will receive a proportionally larger number of requests.

-   **Use Case**: You have a mix of powerful and less-powerful servers in your pool. You could assign a weight of `3` to a new, powerful server and a weight of `1` to an older one, and the new server would receive three times the traffic.
-   **Pros**: Allows you to utilize servers of different capacities effectively.

### 3. Least Connections

This is a more dynamic and intelligent algorithm. The load balancer actively tracks the number of open connections to each backend server and sends the next new request to the server with the fewest active connections.

-   **Pros**: Adapts to the current load on each server. It's a much better choice than Round Robin if requests have varying levels of complexity and completion times, as it prevents piling new requests onto an already-busy server.
-   **Cons**: Requires the load balancer to maintain a state table of connection counts, which adds a small amount of overhead.

### 4. IP Hash (or Source IP Hash)

The load balancer calculates a hash of the client's source IP address and uses this hash to consistently select a specific backend server for that client.

-   **Pros**: Ensures that requests from a particular user will always be directed to the same server.
-   **Cons**: Can lead to uneven load distribution if some IPs send significantly more requests than others. It can also cause problems if the user's IP address changes (e.g., on a mobile network).
-   **Use Case**: This is primarily used to implement **sticky sessions**, which we'll discuss next.

---

## 4. The Sticky Session Dilemma (Session Affinity)

**What it is**: A sticky session is a configuration that forces a user's requests to always go to the same server they started on. This is achieved using a strategy like IP Hash or by having the load balancer issue a cookie.

**Why would you use it?**: You might need this if you are running a **stateful** application where the user's session data is stored in the local memory of a specific web server. If a subsequent request from that user lands on a different server, that server won't have the session data, and the application will break.

**Why you should avoid it**:
-   **It hinders scalability**: If a popular user gets "stuck" to one server, that server can become a hot spot.
-   **It reduces fault tolerance**: If the server a user is "stuck" to fails, their session is lost, and they will likely be logged out or have their shopping cart emptied.

**The modern solution**: The best practice for scalable web applications is to design them to be **stateless**. All session data should be externalized to a shared data store, like a Redis cache or a database. This way, any server can handle any request from any user at any time, eliminating the need for sticky sessions and allowing for true horizontal scalability.

---

## 5. The Importance of Health Checks

A load balancer's job isn't just to distribute traffic; it's also to ensure that traffic is only sent to *healthy* servers.

-   **Passive Health Checks**: The load balancer can detect if a server is unhealthy based on its response to real user traffic. For example, if a server fails to respond or returns a `500` error multiple times in a row, the load balancer can temporarily remove it from the pool.
-   **Active Health Checks**: This is more robust. The load balancer is configured to periodically and proactively send its own, separate request to a specific health check endpoint on the backend servers (e.g., `/health`). If a server fails to return a `200 OK` status from this endpoint, the load balancer will mark it as "down" and immediately stop sending traffic to it, often before users even notice a problem.

A robust health check mechanism is a critical component of any highly available, load-balanced system.

---

## 12. Summary and Mastery Checklist

-   [ ] I can contrast **Round Robin** (simple, even rotation) with **Least Connections** (dynamic, based on current load).
-   [ ] I can explain that a **Weighted** algorithm is used to distribute traffic unevenly to servers of different capacities.
-   [ ] I can define **Sticky Sessions** (session affinity) and explain that they are a solution for stateful applications but an anti-pattern for scalable, stateless design.
-   [ ] I know that **IP Hash** is a common algorithm for implementing sticky sessions.
-   [ ] I understand that **active health checks** are essential for a load balancer to quickly identify and remove failed servers from the pool.

---

## 13. Research and References

-   **NGINX Plus - "Load Balancing Algorithms"**: [Link](https://docs.nginx.com/nginx/admin-guide/load-balancer/http-load-balancer/)
-   **HAProxy Documentation**: HAProxy is another extremely popular and powerful open-source load balancer.
-   **AWS Elastic Load Balancing - "Sticky Sessions"**: [Link](https://docs.aws.amazon.com/elasticloadbalancing/latest/classic/elb-sticky-sessions.html)
