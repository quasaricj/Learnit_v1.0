# The CAP Theorem: Consistency, Availability, Partition Tolerance

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the CAP Theorem and its importance in distributed systems.
- **Define** each of the three guarantees: Consistency, Availability, and Partition Tolerance.
- **Explain** why, in a modern distributed system, you must choose Partition Tolerance.
- **Describe** the trade-off between Consistency and Availability (CP vs. AP).
- **Provide** an example of a CP system and an AP system.
- **Understand** that the CAP theorem is a simplification, but a very useful one.

---

## 2. Introduction: The Fundamental Trade-off of Distributed Systems

In a single-node system (like a single database server), life is relatively simple. But when you distribute your data across multiple nodes (machines) to achieve scalability and reliability, you introduce a new set of fundamental challenges. The network connecting these nodes is not reliable; messages can be lost or delayed.

The **CAP Theorem**, published by Eric Brewer in 2000, is a foundational principle in distributed systems design. It states that it is **impossible for a distributed data store to simultaneously provide more than two out of the following three guarantees**.

---

## 3. The Three Guarantees

### 1. Consistency (C)

- **Definition**: **Every read receives the most recent write or an error.**
- **Explanation**: This means that all the nodes in the cluster have the same, up-to-date view of the data. When you write a piece of data to the system, a subsequent read from *any* node is guaranteed to see that new data. This is often called "strong consistency" or "linearizability".

### 2. Availability (A)

- **Definition**: **Every request receives a (non-error) response, without the guarantee that it contains the most recent write.**
- **Explanation**: The system is always available to answer requests. It will never return an error just because it can't guarantee the data is the absolute latest version.

### 3. Partition Tolerance (P)

- **Definition**: **The system continues to operate despite an arbitrary number of messages being dropped (or delayed) by the network between nodes.**
- **Explanation**: A "network partition" is a failure where the nodes in the cluster are split into two or more groups that cannot communicate with each other. Partition Tolerance means that the system must be able to function even if this happens.
- **In a modern, distributed system, you cannot choose to sacrifice Partition Tolerance.** Network failures are a fact of life. Therefore, the theorem effectively means that in the face of a network partition, you must make a choice between Consistency and Availability.

---

## 4. The Choice: CP vs. AP

Imagine a simple, two-node database cluster (Node 1 and Node 2). A network partition occurs, and they can no longer communicate. A user tries to write new data to Node 1. What should the system do?

### The CP Choice (Consistency over Availability)

- To guarantee **Consistency**, the system must ensure that if a write happens on Node 1, it is replicated to Node 2 before the write is acknowledged as successful.
- But there is a network partition, so Node 1 cannot reach Node 2.
- Therefore, to maintain consistency, Node 1 must **reject the write** and return an error.
- **The system chooses to be unavailable rather than risk inconsistency.**
- **Examples**:
  - Traditional **relational databases** (like PostgreSQL, MySQL) in their default configurations are CP.
  - Locking mechanisms.

### The AP Choice (Availability over Consistency)

- To guarantee **Availability**, the system must accept the write, even if it can't replicate it to the other node.
- Node 1 accepts the write and acknowledges it as successful.
- The system is now in an **inconsistent state**. Node 1 has the new data, and Node 2 has the old data.
- Once the network partition is healed, the system will need a way to resolve this conflict and get back to a consistent state (this is called "eventual consistency").
- **The system chooses to be available and to serve potentially stale data, rather than fail the request.**
- **Examples**:
  - Many **NoSQL databases** are designed to be AP. Amazon's **DynamoDB** and **Cassandra** are classic examples.
  - DNS (the Domain Name System).

---

## 5. CAP is a Simplification

The CAP theorem is a powerful mental model, but it's a simplification.
- It only applies in the specific (but important) case of a network partition. When the network is healthy, a system can provide both C and A.
- "Consistency" in CAP means strong consistency. Many systems choose weaker forms of consistency that are a practical compromise.

The real-world decision is not a binary choice, but a spectrum of trade-offs. However, the core question that the CAP theorem forces you to ask is critical: **"When a network failure occurs, what is more important for my application: to return the most correct data, or to return some data?"** The answer depends entirely on your use case.

---

## 6. Summary and Mastery Checklist

-   [ ] I can name the three guarantees of the CAP Theorem: **Consistency**, **Availability**, and **Partition Tolerance**.
-   [ ] I can explain that **Consistency** means every read gets the most recent write.
-   [ ] I can explain that **Availability** means the system always returns a response.
-   [ ] I can explain that **Partition Tolerance** means the system must work despite network failures.
-   [ ] I understand that because network partitions are a given, the real trade-off is between **Consistency (CP)** and **Availability (AP)**.
-   [ ] I can give an example of a CP system (like a relational database) and an AP system (like a NoSQL database).

---

## 7. Research and References

-   **"A Plain English Introduction to CAP Theorem"**: A very clear and accessible article.
-   **"Brewer's CAP Theorem"**: The original paper and a retrospective article from Eric Brewer.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 9 is a masterclass on the nuances of consistency and consensus in distributed systems.
-   **"Please explain the CAP theorem to me like I'm a 5-year-old"**: A common question on forums with many helpful analogies.
