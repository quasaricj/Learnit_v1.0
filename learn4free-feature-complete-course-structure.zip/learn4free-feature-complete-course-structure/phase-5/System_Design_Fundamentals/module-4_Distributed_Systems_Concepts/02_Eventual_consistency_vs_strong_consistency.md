# Eventual Consistency vs. Strong Consistency

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a consistency model in the context of a distributed system.
- **Define** Strong Consistency and explain its guarantees.
- **Define** Eventual Consistency and explain its guarantees.
- **Provide** a real-world analogy for each consistency model.
- **Describe** the trade-off between consistency, latency, and availability.
- **Identify** use cases that require strong consistency and use cases where eventual consistency is acceptable.

---

## 2. Introduction: The Consistency Spectrum

In a distributed system, where the same piece of data is replicated across multiple nodes, we need a **consistency model**. A consistency model is a contract that the data store provides to the application. It defines the rules about how and when a write to one node becomes visible to a read from another node.

Consistency is not a binary choice. It is a spectrum, with **Strong Consistency** at one end and **Eventual Consistency** at the other.

---

## 3. Strong Consistency

- **Definition**: **All reads are guaranteed to see the most recent committed write.**
- **How it works**: When you write a piece of data, the system ensures that this write is replicated to all (or a quorum of) the replicas *before* it acknowledges the write as successful. This is often achieved using **synchronous replication**.
- **User Experience**: The system behaves as if it were a single, non-distributed system. The data is always up-to-date and correct, regardless of which replica you read from.
- **Analogy**: A bank transaction. When you deposit money into your account, you expect to see the updated balance immediately, no matter how you check it (on your phone, on the web, at an ATM). The system is strongly consistent.

### The Trade-off

- **Pros**:
  - **Simplicity**: The easiest model to reason about for the application developer. The data is always correct.
- **Cons**:
  - **High Latency**: The write operation has to wait for confirmation from other nodes, which is slow.
  - **Lower Availability**: If the system cannot reach enough replicas to form a quorum, it must reject the write to avoid inconsistency. This is the "CP" choice from the CAP theorem.

### When to use it?

- Systems that require absolute data correctness and cannot tolerate stale data, even for a short time.
- Examples: Financial systems, e-commerce transaction processing, inventory management.

---

## 4. Eventual Consistency

- **Definition**: If no new updates are made to a given data item, **all accesses to that item will *eventually* return the last updated value.**
- **How it works**: When you write a piece of data, the system acknowledges the write as successful as soon as it's committed to one node. The replication to other nodes happens **asynchronously** in the background.
- **User Experience**: There is a short window of time (the "inconsistency window" or "replication lag") during which a read from a different replica might return the old, stale data.
- **Analogy**: The Domain Name System (DNS). When you update a DNS record, it can take minutes or even hours for that change to propagate across the entire internet. The system is eventually consistent. Another example is your social media feed; if you post an update, your friend in another country might not see it for a few seconds.

### The Trade-off

- **Pros**:
  - **Low Latency**: Write operations are extremely fast because they don't have to wait for replication.
  - **High Availability**: The system can continue to accept writes even if some of its nodes are temporarily partitioned from the network. This is the "AP" choice from the CAP theorem.
- **Cons**:
  - **Complexity for the Developer**: The application developer must be aware of and handle the possibility of reading stale data.

### When to use it?

- Systems where high availability and low latency are more important than perfect, up-to-the-millisecond consistency.
- The vast majority of large-scale web applications.
- Examples: Social media posts and comments, "likes", user profile updates, product catalog updates. For most of these use cases, it is acceptable if a user sees a slightly out-of-date value for a few seconds.

---

## 5. The Consistency Spectrum

Between these two extremes, there are many other "weaker" consistency models, such as:
- **Read-your-writes consistency**: A user is guaranteed to see their *own* writes immediately.
- **Monotonic reads**: If you perform a series of reads, you are guaranteed to see a state of the data that is moving forward in time, never backward.

The choice of consistency model is a critical architectural decision that depends entirely on the business requirements of your specific use case. A complex system might even use different consistency models for different parts of the application.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define **Strong Consistency** as a model where all reads are guaranteed to see the most recent write.
-   [ ] I can define **Eventual Consistency** as a model where the system will eventually become consistent, but there is a short period of potential staleness.
-   [ ] I can use the "bank transaction vs. social media feed" analogy to explain the difference.
-   [ ] I know that strong consistency provides a simpler programming model but has higher latency and lower availability.
-   [ ] I know that eventual consistency provides lower latency and higher availability but is more complex for the developer to handle.
-   [ ] I understand that the right choice of consistency model depends on the business requirements of the feature.

---

## 7. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 9 is a deep and comprehensive discussion of consistency models.
-   **"A Plain English Introduction to CAP Theorem"**: Provides good context for the consistency vs. availability trade-off.
-   **Jepsen.io**: A series of blog posts and analyses from Kyle Kingsbury that tests the consistency claims of various distributed databases in the real world.
-   **AWS DynamoDB - Consistency Models**: The documentation for DynamoDB has a good, practical explanation of its consistency options.
