# Distributed Transactions and ACID Properties

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Recap** the ACID properties of a traditional, single-node database transaction.
- **Define** a distributed transaction.
- **Explain** why traditional ACID transactions are difficult or impossible to achieve in a distributed system.
- **Describe** the Two-Phase Commit (2PC) protocol and its limitations.
- **Understand** that most modern distributed systems sacrifice strong transactional guarantees for higher availability and performance.
- **Recognize** that patterns like the Saga pattern are used to manage consistency in distributed systems.

---

## 2. Recap: ACID Transactions in a Single Database

In a traditional, single-node relational database, a **transaction** is a sequence of operations performed as a single logical unit of work. These transactions are guaranteed to have four key properties, known by the acronym **ACID**.

1.  **Atomicity**: "All or nothing." A transaction either completes in its entirety, or it fails completely. The system is never left in a partially completed state.
2.  **Consistency**: The transaction brings the database from one valid state to another.
3.  **Isolation**: Concurrent transactions do not interfere with each other. The result is the same as if the transactions were executed serially.
4.  **Durability**: Once a transaction is committed, it will remain committed, even in the event of a system crash.

ACID transactions are the gold standard for data integrity and make it much easier to reason about the state of your data.

---

## 3. The Challenge: Distributed Transactions

A **distributed transaction** is a transaction that involves updates to two or more separate, independent data stores.

**The Classic Example: A Bank Transfer in a Microservices Architecture**
- Imagine you have a `Banking` application with two microservices: an `AccountsService` and a `LedgerService`, each with its own private database.
- To transfer money from Account A to Account B, you need to perform two separate database operations:
  1.  **Debit** Account A's balance in the `AccountsService` database.
  2.  **Credit** Account B's balance in the `AccountsService` database.
  3.  (And likely record the transaction in the `LedgerService` database).

What happens if the first operation succeeds, but the second one fails? You have now "lost" money and your system is in an inconsistent state. This violates the **Atomicity** guarantee of ACID.

---

## 4. The Attempted Solution: Two-Phase Commit (2PC)

**Two-Phase Commit** is a classic algorithm that tries to provide atomicity for distributed transactions. It introduces a new component called the **transaction coordinator**.

- **Phase 1: The Prepare Phase**
  1.  The coordinator asks all the participating services (the "cohorts") if they are ready to commit their part of the transaction.
  2.  Each service prepares to commit (e.g., by writing the data to a temporary log) and then votes "yes" or "no". If it votes "yes," it is making a promise that it *can* commit, no matter what.

- **Phase 2: The Commit Phase**
  1.  **If all services vote "yes"**: The coordinator sends a "commit" message to all of them.
  2.  **If any service votes "no" (or times out)**: The coordinator sends an "abort" message to all of them, and they all roll back their changes.

### Why 2PC is Not a Silver Bullet

- **It is a blocking protocol**: While waiting for all the services to vote, the coordinator and all the cohorts have to hold locks on the data, which can be very slow.
- **It is not fault-tolerant**: The coordinator is a single point of failure. If the coordinator crashes in the middle of a transaction, the entire system can be left in an indeterminate state.

Because of these limitations, **2PC and strongly consistent distributed transactions are rarely used in modern, high-availability web applications.** The performance and availability costs are simply too high.

---

## 5. The Modern Approach: Sacrificing Atomicity for Availability

Most modern distributed systems (especially those built on a microservices or NoSQL architecture) make a pragmatic trade-off: they give up the guarantee of distributed ACID transactions in favor of higher availability and performance.

This means that developers have to manage consistency at the **application layer**. Instead of a single, atomic transaction, you have a series of local transactions and a workflow that ensures the system *eventually* becomes consistent.

- **Eventual Consistency**: As discussed in the previous module, this is the model that most distributed systems adopt.
- **Idempotency**: Your operations must be designed to be "idempotent" (meaning they can be safely retried multiple times) to handle transient network failures.
- **The Saga Pattern**: This is an advanced design pattern for managing consistency in a distributed transaction. It is a sequence of local transactions. When one transaction in the sequence fails, the saga executes a series of "compensating transactions" to undo the changes that were made by the previous transactions.

---

## 6. Summary and Mastery Checklist

-   [ ] I can list the four ACID properties (Atomicity, Consistency, Isolation, Durability).
-   [ ] I can define a **distributed transaction** as a transaction that spans multiple, independent databases.
-   [ ] I understand that achieving traditional ACID guarantees in a distributed system is very difficult and has a high performance cost.
-   [ ] I can describe the high-level idea of the **Two-Phase Commit (2PC)** protocol.
-   [ ] I know that most modern, highly available systems **do not use distributed transactions** and instead favor an **eventually consistent** model.
-   [ ] I have heard of the **Saga pattern** as an alternative way to manage consistency at the application level.

---

## 7. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapters 7, 8, and 9 provide an incredibly deep and clear explanation of transactions, their limitations in distributed systems, and the various consistency models.
-   **"Building Microservices" by Sam Newman**: Has a chapter on transactions and communication patterns, including the Saga pattern.
-   **Wikipedia - Two-phase commit protocol**: [Link](https://en.wikipedia.org/wiki/Two-phase_commit_protocol)
-   **Microsoft - "Saga distributed transactions pattern"**: [Link](https://docs.microsoft.com/en-us/azure/architecture/reference-architectures/saga/saga)
