# Consensus Algorithms (Paxos, Raft)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the consensus problem in distributed systems.
- **Explain** why consensus is a fundamental challenge.
- **Describe** the goal of a consensus algorithm.
- **Recognize** the names of the two most famous consensus algorithms: Paxos and Raft.
- **Understand** the role of a "leader" in many consensus protocols.
- **Identify** where consensus algorithms are used in real-world systems (e.g., in databases and coordination services).

---

## 2. Introduction: The Problem of Agreement

In a distributed system, how does a group of computers agree on a single value or a course of action, especially in the face of unreliable networks and server failures? This is the fundamental **consensus problem**.

Achieving consensus is one of the most important and most difficult problems in distributed systems. It is the basis for building any system that needs to be both **consistent** and **fault-tolerant**.

**Examples of where consensus is needed**:
- **Leader Election**: A cluster of nodes needs to agree on which node will be the "leader" or "primary".
- **Distributed Transactions**: A set of nodes needs to agree on whether to commit or abort a transaction (this is what Two-Phase Commit tries to solve).
- **State Machine Replication**: A set of nodes needs to agree on the order in which operations are applied to a database to keep all the replicas in sync.

---

## 3. The Goal of a Consensus Algorithm

A consensus algorithm is a protocol that allows a collection of nodes to agree on a proposed value. A correct consensus algorithm must satisfy three properties:

1.  **Agreement (or Safety)**: All non-faulty nodes must agree on the same value.
2.  **Termination (or Liveness)**: All non-faulty nodes must eventually decide on a value (the algorithm cannot get stuck forever).
3.  **Validity**: If all nodes propose the same value `v`, then all non-faulty nodes must decide `v`.

---

## 4. The Famous Algorithms

Solving the consensus problem in a way that is both theoretically correct and practically implementable is extremely difficult. Two algorithms are famously associated with this problem.

### 1. Paxos

- **History**: Developed by Leslie Lamport in the late 1980s, but not published until 1998. It is the original and most famous provably correct consensus algorithm.
- **How it works**: Paxos is a family of protocols that uses a series of "proposals" and "votes" among a group of "acceptors" to reach a decision. It is famously difficult to understand.
- **Legacy**: Paxos has been hugely influential and is used in many real-world systems, but its complexity has led to the development of more understandable alternatives.

### 2. Raft

- **History**: Developed by Diego Ongaro and John Ousterhout at Stanford in 2013. It was explicitly designed to be **as understandable as Paxos, but also to be provably correct**.
- **How it works**: Raft simplifies the consensus problem by breaking it down into three more manageable subproblems:
  1.  **Leader Election**: One of the nodes is elected as the "leader". This leader is the only node that is responsible for managing the replicated log and communicating with clients.
  2.  **Log Replication**: The leader accepts commands from clients, appends them to its own log, and then replicates this log to the other nodes (the "followers"). A log entry is only considered "committed" when it has been safely replicated to a majority of the nodes.
  3.  **Safety**: The Raft algorithm has a set of rules that guarantee that if any node has applied a particular log entry, no other node can apply a different entry for the same log index.
- **Legacy**: Because of its understandability, Raft has become extremely popular and is now the basis for many modern distributed systems.

**Key idea of Raft**: Decomposing the problem and centralizing the decision-making through a single (but fault-tolerant) leader makes the system much easier to reason about.

---

## 5. Where are Consensus Algorithms Used?

You will almost **never** implement a consensus algorithm yourself. They are notoriously difficult to get right. Instead, you will use systems that have a consensus algorithm built into their core.

- **Distributed Databases**:
  - **etcd**: The key-value store that powers Kubernetes uses **Raft**.
  - **ZooKeeper**: A coordination service for distributed systems, uses a protocol similar to Paxos.
  - **CockroachDB**, **TiDB**: Modern "NewSQL" databases that are designed to be strongly consistent and scalable use consensus protocols (often Raft) at their core.
- **State Machine Replication**:
  - Consensus algorithms are the key to building a **replicated state machine**. This is the most reliable way to build a fault-tolerant system. You have multiple replicas of your service. All incoming requests are put into a replicated log (using Raft or Paxos). Each replica processes the requests from the log in the exact same order, which guarantees that all the replicas will remain in the exact same state.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define the **consensus problem** as the challenge of getting a group of computers to agree on a value in the face of failure.
-   [ ] I know that consensus is the key to building systems that are both **consistent** and **fault-tolerant**.
-   [ ] I can name the two most famous consensus algorithms: **Paxos** and **Raft**.
-   [ ] I know that **Raft** is a more modern algorithm that was designed to be easier to understand than Paxos.
-   [ ] I can describe the high-level idea of Raft: it **elects a leader** who is then responsible for replicating a log to its followers.
-   [ ] I can name a real-world system that uses a consensus algorithm (e.g., `etcd` in Kubernetes).

---

## 7. Research and References

-   **"The Raft Consensus Algorithm"**: The original paper from Ongaro and Ousterhout. It is very readable and is a model for how to write a clear and accessible academic paper. [Link](https://raft.github.io/)
-   **"The Secret Lives of Data - Raft"**: A fantastic, animated, and interactive visualization of how the Raft algorithm works. This is the best way to develop an intuition for it. [Link](http://thesecretlivesofdata.com/raft/)
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 9 provides a brilliant and detailed explanation of the consensus problem, Paxos, and Raft.
-   **"Paxos Made Simple" by Leslie Lamport**: The paper where Lamport tries to explain his famously difficult algorithm.
