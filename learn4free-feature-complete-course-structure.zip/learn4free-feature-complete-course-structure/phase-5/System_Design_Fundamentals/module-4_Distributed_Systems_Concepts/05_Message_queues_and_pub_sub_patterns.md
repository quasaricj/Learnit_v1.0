# Message Queues and Pub/Sub Patterns

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a message queue and a message broker.
- **Explain** the purpose of a message queue: to enable asynchronous communication.
- **Differentiate** between the "Point-to-Point" (Queue) messaging model and the "Publish/Subscribe" (Pub/Sub) model.
- **Describe** how message queues can improve the reliability and scalability of a system.
- **Identify** the key components: a producer, a consumer, and the queue/topic.
- **Recognize** the names of popular message broker systems (e.g., RabbitMQ, Kafka, AWS SQS).
- **Relate** message queues to the Event-Driven Architecture pattern.

---

## 2. Introduction: The Need for Asynchronous Communication

In a distributed system, direct, synchronous communication between services (like a REST API call) creates **tight coupling**. The service making the request (the "producer") is directly dependent on the availability and performance of the service it is calling (the "consumer").

A **message broker** (or **message queue**) is a piece of middleware that allows services to communicate **asynchronously**, thereby decoupling them.

- The **producer** sends a message to the broker and can immediately move on to other tasks. It doesn't wait for a response.
- The **consumer** receives the message from the broker and processes it in its own time.

The broker acts as a reliable intermediary, storing the messages until the consumer is ready to process them. This is the core technology that enables an **Event-Driven Architecture**.

---

## 3. The Two Main Messaging Models

### 1. Point-to-Point (Queue)

- **How it works**:
  - There is a single **producer** and a single **consumer** for a **queue**.
  - The producer sends a message to the queue.
  - The broker ensures that the message is delivered **exactly once** to the consumer.
  - Once the consumer has successfully processed the message, it acknowledges it, and the broker removes the message from the queue.
- **Analogy**: A task list for a single person. You add a task, and that person eventually does it and checks it off.
- **Use Case**: **Task processing**. When you need to guarantee that a specific task will be performed by a specific worker (e.g., "process this payment," "resize this image").
- **Example Systems**: **RabbitMQ**, **Amazon SQS (Simple Queue Service)**.

### 2. Publish/Subscribe (Pub/Sub)

- **How it works**:
  - There can be multiple **producers** (publishers) and multiple **consumers** (subscribers) for a **topic**.
  - A publisher sends a message (often called an "event") to the topic.
  - The broker then broadcasts this message to **all** the subscribers of that topic.
- **Key Idea**: The publisher has no knowledge of who the subscribers are, or even if there are any. It just announces that something has happened. This creates extreme loose coupling.
- **Analogy**: A radio broadcast. The radio station (the publisher) broadcasts a signal. Anyone with a radio tuned to the right frequency (the subscribers) can listen.
- **Use Case**: **Event notification** and **fan-out** scenarios. When a single event needs to trigger many different, independent actions.
  - *Example*: An `OrderPlaced` event could be published to a topic. The `EmailService`, `ShippingService`, and `InventoryService` could all be independent subscribers to this topic.
- **Example Systems**: **Apache Kafka**, **Amazon SNS (Simple Notification Service)**.

---

## 4. Benefits of Using a Message Broker

1.  **Decoupling**: The producer and consumer are completely independent. They don't need to know each other's location or implementation details.
2.  **Reliability and Durability**: The broker acts as a buffer. If a consumer service is down, the messages will be safely stored in the queue until the service comes back online. This prevents data loss.
3.  **Scalability**:
    - **Producer/Consumer Scaling**: You can scale the number of producers and consumers independently to meet the demand.
    - **Load Leveling**: The queue can absorb sudden spikes in traffic. A producer can add a million messages to a queue in a few seconds, and the consumers can then process them at their own, steady pace.
4.  **Asynchronous Processing**: It's the perfect model for long-running tasks that a user doesn't need to wait for.

---

## 5. Popular Message Broker Systems

- **RabbitMQ**:
  - A very popular, traditional message broker that is easy to use and supports both queueing and pub/sub. It is a great choice for task queues.
- **Apache Kafka**:
  - A distributed **event streaming platform**. It is much more than a simple message broker. It is designed to handle extremely high-throughput, real-time streams of data (millions of messages per second). It stores the messages in a durable, ordered log, which allows them to be "replayed".
  - **Use Case**: The backbone of real-time data pipelines, analytics, and event-driven architectures at a massive scale.
- **Amazon SQS (Simple Queue Service)**:
  - A fully managed, highly scalable message queuing service from AWS.
- **Amazon SNS (Simple Notification Service)**:
  - A fully managed pub/sub messaging service from AWS.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that a **message queue** is a tool that enables **asynchronous** communication between services.
-   [ ] I can describe the **Point-to-Point (Queue)** model, where one producer sends a message to one consumer.
-   [ ] I can describe the **Publish/Subscribe (Pub/Sub)** model, where a message is broadcast to all interested subscribers.
-   [ ] I can list a key benefit of using a message broker, such as **decoupling**, **reliability**, or **scalability**.
-   [ ] I know that message brokers are the core technology behind an **Event-Driven Architecture**.
-   [ ] I can name a popular message broker, like **RabbitMQ** or **Apache Kafka**.

---

## 7. Research and References

-   **"Enterprise Integration Patterns" by Gregor Hohpe and Bobby Woolf**: The definitive guide to messaging patterns.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Has an excellent chapter on message brokers.
-   **RabbitMQ Tutorials**: The official website has great tutorials for getting started. [Link](https://www.rabbitmq.com/getstarted.html)
-   **Apache Kafka Introduction**: [Link](https://kafka.apache.org/intro)
