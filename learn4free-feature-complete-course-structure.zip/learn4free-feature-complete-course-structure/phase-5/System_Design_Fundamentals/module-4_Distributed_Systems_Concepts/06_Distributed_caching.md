# Distributed Caching

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a distributed cache and explain its purpose.
- **Differentiate** between a local (in-process) cache and a distributed cache.
- **Explain** the benefits of a distributed cache in a horizontally scaled system.
- **Describe** the trade-offs of using a distributed cache (performance vs. complexity, cost).
- **Recognize** Redis and Memcached as popular distributed caching technologies.
- **Understand** how a distributed cache fits into the overall system architecture.

---

## 2. Introduction: The Limits of Local Caching

As you learned in a previous module, caching is a powerful technique for improving performance. An **in-process** or **local cache** is the simplest form of cache. It is a library that runs within your single application process, storing cached data in the application's own memory.

**The Problem**:
A local cache works perfectly for a single, monolithic application running on one server. But what happens when you **horizontally scale** your application to run on multiple servers behind a load balancer?
- Each instance of your application will have its own, independent local cache.
- **Cache Inconsistency**: If a request to `Server A` updates a piece of data, `Server A`'s local cache will be updated, but the caches on `Server B` and `Server C` will now contain stale data.
- **Inefficiency**: The same piece of data might be wastefully cached on every single server instance.

A **distributed cache** is the solution to this problem.

---

## 3. What is a Distributed Cache?

A **distributed cache** is an external, networked service. It is a cache that is shared by multiple application servers. The cache itself is a separate system, a cluster of one or more servers, that is dedicated to the task of caching.

- **How it works**:
  1.  All the application servers in your cluster are configured to talk to the same, single distributed cache cluster.
  2.  When `Server A` needs a piece of data, it asks the distributed cache.
  3.  If the data is in the cache, it's returned.
  4.  If not, `Server A` fetches the data from the database, puts it *into the distributed cache*, and then uses it.
  5.  Now, when a request for the same data comes to `Server B`, `Server B` will find the data in the distributed cache.

- **Analogy**:
  - A **local cache** is like each employee keeping their own personal notebook of important phone numbers.
  - A **distributed cache** is like a central, shared company directory that everyone in the office can access.

---

## 4. Benefits of a Distributed Cache

1.  **Ensures Cache Coherency**: All application servers share a single, unified view of the cached data. This solves the problem of cache inconsistency.
2.  **Improves Efficiency**: Data is only cached once in the central cache, not duplicated on every application server. This can lead to a much higher "cache hit ratio".
3.  **Decouples the Cache from the Application**: The cache is its own tier in your architecture. You can scale, restart, and maintain your application servers and your cache cluster independently.
4.  **Scalability and Availability**: Distributed cache systems like Redis and Memcached are designed to be run as a cluster of multiple nodes, making them highly scalable and fault-tolerant.

---

## 5. Drawbacks and Trade-offs

1.  **Increased Latency**: Reading from a distributed cache involves a **network call**, which is inherently slower than reading from an in-process memory cache. However, this is still dramatically faster than going to a disk-based database.
2.  **Increased Complexity**: It is another piece of infrastructure that you have to set up, manage, and monitor. (Although cloud providers offer this as a fully managed service, e.g., AWS ElastiCache, Azure Cache for Redis).
3.  **Single Point of Failure?**: If your cache cluster goes down, your application's performance will be severely degraded as all requests will suddenly hit the database. It is critical that your cache cluster is highly available.

---

## 6. Popular Distributed Caching Systems

- **Redis**:
  - The most popular choice for distributed caching.
  - As discussed before, it is an in-memory data structures server. Its speed makes it perfect for caching.
  - It also supports replication and clustering to provide high availability and scalability.

- **Memcached**:
  - Another very popular, high-performance, in-memory key-value store.
  - It is simpler than Redis and is designed purely for caching.

- **Cloud Provider Services**:
  - **AWS ElastiCache**: A fully managed service that makes it easy to deploy and run Redis or Memcached in the cloud.
  - **Azure Cache for Redis**
  - **Google Cloud Memorystore**

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain that a **local cache** is in-process, while a **distributed cache** is an external, shared service.
-   [ ] I understand that a distributed cache is necessary when you have multiple, horizontally scaled application servers, to avoid **cache inconsistency**.
-   [ ] I can list a benefit of a distributed cache, such as ensuring cache coherency or improving efficiency.
-   [ ] I understand that accessing a distributed cache is a **network call**, which is slower than a local cache but faster than a database.
-   [ ] I can name **Redis** and **Memcached** as the two most popular technologies for distributed caching.
-   [ ] I know that cloud providers offer managed distributed caching services like **AWS ElastiCache**.

---

## 8. Research and References

-   **"System Design Interview – An insider's guide" by Alex Xu**: The chapter on designing a distributed cache is excellent.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**
-   **Redis - Caching**: [Link](https://redis.com/solutions/use-cases/caching/)
-   **AWS - "In-Memory Caching"**: A whitepaper that discusses different caching patterns.
