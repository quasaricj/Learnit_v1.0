# The CAP Theorem: Consistency vs. Availability in Distributed Systems

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** the three properties of the CAP Theorem: Consistency, Availability, and Partition Tolerance.
-   **Explain** what a "network partition" is in a distributed system.
-   **Articulate** the core statement of the CAP Theorem: in the presence of a partition, a system must choose between consistency and availability.
-   **Provide** a real-world example of a system that chooses Consistency over Availability (CP).
-   **Provide** a real-world example of a system that chooses Availability over Consistency (AP).
-   **Recognize** that the CAP theorem is a simplification but a powerful mental model for designing distributed systems.

---

## 2. Introduction: The Fundamental Trade-off

The CAP Theorem, also known as Brewer's Theorem after its originator Eric Brewer, is a fundamental principle in distributed systems design. It states that it is **impossible** for a distributed data store to simultaneously provide more than two out of the following three guarantees:

1.  **C**onsistency
2.  **A**vailability
3.  **P**artition Tolerance

Because network partitions are a fact of life in any non-trivial distributed system, the theorem effectively states that a distributed system must **choose between being consistent or being available** when a network failure occurs.

---

## 3. Defining the Three Guarantees

### Consistency (C)

-   **Definition**: Every read receives the most recent write or an error.
-   **In simpler terms**: All clients see the same data at the same time, no matter which node they connect to. The system operates as if it were a single, atomic unit.
-   **Example**: You write `x = 5` to the database. You (and everyone else) should never be able to read the old value of `x` ever again. Any read must return `5`.

### Availability (A)

-   **Definition**: Every request receives a (non-error) response, without the guarantee that it contains the most recent write.
-   **In simpler terms**: The system is always up and running and will always respond to requests. It will do its best to provide the most recent data it has, but it might be stale.
-   **Example**: Even if some nodes are down or unreachable, the system will still serve you data. You might read that `x = 4` even though someone else just updated it to `5`, but you won't get a timeout or an error.

### Partition Tolerance (P)

-   **Definition**: The system continues to operate despite an arbitrary number of messages being dropped (or delayed) by the network between nodes.
-   **In simpler terms**: A "network partition" is a failure in the network that splits the nodes of your distributed system into two or more groups that cannot communicate with each other. Partition Tolerance means your system doesn't grind to a halt when this happens.
-   **This is not optional**: In any real-world distributed system, you *must* assume that network partitions will happen. Therefore, a distributed system must be partition tolerant. This is why the CAP theorem boils down to a choice between C and A.

---

## 4. The Choice: CP vs. AP

Since any distributed system must be Partition Tolerant (P), the real trade-off is between Consistency and Availability when a partition occurs.

Imagine a simple distributed database with two nodes, N1 and N2. A client writes `x = 5` to N1. A network partition occurs, and N1 and N2 can no longer communicate.

![CAP Theorem Partition](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/CAP_theorem.svg/500px-CAP_theorem.svg.png)

Now, another client connects to N2 and tries to read the value of `x`. What should N2 do?

### Choosing Consistency (CP - Consistency/Partition Tolerance)

-   If the system chooses consistency, N2 cannot respond to the read request.
-   **Why?**: N2 cannot be sure it has the most recent version of the data. To guarantee consistency, it would need to check with N1, but it can't because of the partition.
-   **Action**: N2 must return an error or refuse to respond. The system is **not available** from the perspective of a client connected to N2.
-   **Use Cases**: Systems where correctness and having the most up-to-date information is critical.
    -   Bank account balances
    -   Payment processing
    -   Master databases in relational systems (e.g., PostgreSQL, MySQL in their default configurations).

### Choosing Availability (AP - Availability/Partition Tolerance)

-   If the system chooses availability, N2 will respond to the read request with the best data it has.
-   **Why?**: To stay available, the system must respond.
-   **Action**: N2 returns the old value of `x` (whatever it was before the update to `5`). The data is now **inconsistent** or "stale" across the cluster.
-   **Use Cases**: Systems where being always online is more important than every client seeing the exact same data at the exact same time. The inconsistency is usually repaired after the network partition is resolved.
    -   Social media timelines (it's okay if you don't see a "like" for a few seconds)
    -   Shopping cart contents (availability to add items is key)
    -   NoSQL databases like Amazon DynamoDB and Cassandra are famously designed as AP systems.

---

## 5. Deliberate Practice

For each of the following systems, decide whether you would prioritize Consistency (CP) or Availability (AP) during a network partition, and briefly explain why.

1.  **A system that tracks the location of an Uber driver.**
2.  **A DNS server.**
3.  **A stock trading platform's "buy" or "sell" transaction service.**
4.  **A system that counts the number of "likes" on a photo.**

---

## 12. Summary and Mastery Checklist

-   [ ] I can name the three guarantees of the CAP Theorem: **Consistency, Availability, Partition Tolerance**.
-   [ ] I understand that a **network partition** is a communication failure between nodes.
-   [ ] I can articulate the core trade-off: in a distributed system, you must be Partition Tolerant, which forces a choice between **Consistency (CP)** or **Availability (AP)** during a failure.
-   [ ] I can give an example of a CP system (like a bank) and an AP system (like a social media feed).

---

## 13. Research and References

-   **"Please stop calling databases CP or AP" by Martin Kleppmann**: A nuanced look at the limitations of the CAP theorem as a classification tool. [Link](https://martin.kleppmann.com/2015/05/11/please-stop-calling-databases-cp-or-ap.html)
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Provides a deep and clear explanation of the CAP theorem and its practical implications.
-   **"CAP Twelve Years Later: How the "Rules" Have Changed" by Eric Brewer**: The author of the theorem reflects on its modern interpretation. [Link](https://www.infoq.com/articles/cap-twelve-years-later-how-the-rules-have-changed/)
