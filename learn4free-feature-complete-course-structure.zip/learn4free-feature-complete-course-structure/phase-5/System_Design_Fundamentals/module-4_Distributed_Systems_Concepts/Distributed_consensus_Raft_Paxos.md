# Distributed Consensus: Getting Computers to Agree (Raft & Paxos)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** the distributed consensus problem and explain why it's a critical challenge in distributed systems.
-   **Identify** Paxos as the foundational but famously complex consensus algorithm.
-   **Identify** Raft as a modern, understandable alternative to Paxos.
-   **Describe** the high-level operation of Raft, including the concepts of Leader Election and Log Replication.
-   **Explain** that consensus algorithms are the key to building strongly consistent (CP) systems.
-   **List** real-world systems that use consensus algorithms, like `etcd` and Zookeeper.

---

## 2. The Problem: Agreeing in an Unreliable World

Imagine a committee of people trying to vote on a decision. The problem is, they can only communicate by sending messages, the messengers are unreliable (messages can be lost or delayed), and the committee members themselves can leave and rejoin the meeting at any time (they can crash and restart).

How can the committee, despite all these problems, agree on a single, final decision?

This is the **distributed consensus problem**. It's the challenge of getting a group of computer servers (nodes) to agree on a value or a sequence of operations, even in the face of network failures and node crashes. Solving this problem is the key to building fault-tolerant, strongly consistent systems. If you have a cluster of database servers, how do they all agree on who the primary ("leader") server is? How do they all agree on the order of transactions? They need a consensus algorithm.

---

## 3. Paxos: The Foundation

**Paxos** is the original, groundbreaking consensus algorithm described by Leslie Lamport in the late 1980s. It proved that it was possible to achieve consensus in an unreliable environment.

-   **Impact**: Paxos is the foundation of many highly reliable systems built at Google, Microsoft, and others.
-   **Challenge**: The original Paxos paper is notoriously difficult to understand and implement correctly. This difficulty led to the search for more approachable alternatives.

For the purposes of this course, you only need to know that Paxos was the first, and its complexity inspired the creation of Raft.

---

## 4. Raft: Consensus Designed for Understandability

**Raft** is a consensus algorithm developed in 2013 specifically with the goal of being easier to understand than Paxos, without sacrificing correctness or performance. It is the algorithm used by many modern distributed systems, most famously `etcd`, the key-value store that powers Kubernetes.

Raft works by breaking the consensus problem down into three more easily understood subproblems:

1.  **Leader Election**
2.  **Log Replication**
3.  **Safety**

### High-Level Overview of Raft

In a Raft cluster, every node is in one of three states: **Leader**, **Follower**, or **Candidate**.

![Raft States](https://raft.github.io/raft.png)

1.  **Leader Election**:
    -   Under normal operation, there is exactly one **Leader**, and all other nodes are **Followers**. The Leader is responsible for managing the cluster.
    -   Followers are passive. They simply respond to requests from the Leader.
    -   If a Follower stops hearing from the Leader for a certain amount of time (a timeout), it assumes the Leader has crashed.
    -   The Follower changes its state to **Candidate**, starts a new "election term," votes for itself, and sends out requests to all other nodes asking for their votes.
    -   If a Candidate receives votes from a majority of the nodes in the cluster, it becomes the new Leader.

2.  **Log Replication**:
    -   Once a Leader is elected, it is responsible for handling all client requests.
    -   Each client request is a command that needs to be replicated across the cluster.
    -   The Leader first appends the command to its own history, or **log**.
    -   It then sends the command to all its Followers in a message called `AppendEntries`.
    -   Followers receive the message, append the command to their own logs, and send an acknowledgment back to the Leader.
    -   Once the Leader has received acknowledgments from a **majority** of its Followers, the command is considered **committed**. This means it is now a permanent part of the system's history.
    -   At this point, the Leader can "apply" the command to its own state machine (e.g., update a value in its database) and return the result to the client.

**The result**: Through this process of electing a single leader and having it replicate a log of commands to a majority of nodes, the entire cluster comes to an agreement on the exact sequence of operations. This replicated log is the cornerstone of the system's consistency.

---

## 5. Where is Consensus Used?

Consensus algorithms are the engine inside any system that needs to provide strong consistency (the "C" in CAP) in a fault-tolerant way.

-   **`etcd` (used by Kubernetes)**: Uses Raft to agree on the state of the entire Kubernetes cluster (e.g., how many pods should be running, what their configuration is).
-   **Apache Zookeeper**: Uses its own consensus algorithm (ZAB) to provide configuration management and coordination for other distributed systems.
-   **Consul**: Uses Raft for leader election and to maintain a consistent service discovery catalog.
-   **Clustered Databases (e.g., CockroachDB, TiDB)**: Use consensus algorithms to agree on transaction order and which node owns which piece of data.

---

## 12. Summary and Mastery Checklist

-   [ ] I can describe the **distributed consensus problem** as getting multiple servers to agree on something reliably.
-   [ ] I know that **Paxos** is the foundational but complex algorithm, and **Raft** is the modern, understandable alternative.
-   [ ] I can name the two key parts of the Raft algorithm: **Leader Election** and **Log Replication**.
-   [ ] I understand that in Raft, a command is **committed** only after it has been successfully replicated to a **majority** of nodes.
-   [ ] I know that consensus is used to build strongly consistent (CP) systems like `etcd` and Zookeeper.

---

## 13. Research and References

-   **The Secret Lives of Data - Raft**: An absolutely essential, beautiful, and interactive visualization of how the Raft algorithm works. This is the best place to start. [Link](http://thesecretlivesofdata.com/raft/)
-   **Raft Homepage**: The official website for the Raft algorithm, including a link to the original paper. [Link](https://raft.github.io/)
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Has a very clear chapter on the challenges of consensus.
