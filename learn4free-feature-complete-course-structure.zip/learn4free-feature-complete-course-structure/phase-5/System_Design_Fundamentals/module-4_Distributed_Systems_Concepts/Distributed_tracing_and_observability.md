# Distributed Tracing and Observability: Seeing Inside Your Microservices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Observability and differentiate it from classic Monitoring.
-   **List** the "Three Pillars of Observability": Logs, Metrics, and Traces.
-   **Describe** the purpose and limitations of Logs and Metrics in a distributed system.
-   **Define** Distributed Tracing and explain how it solves the problem of debugging across service boundaries.
-   **Explain** the core components of a distributed trace: Spans, Trace IDs, and Parent IDs.
-   **Recognize** popular open standards and tools for observability, like OpenTelemetry, Jaeger, and Prometheus.

---

## 2. From Monitoring to Observability

-   **Monitoring** is what we have traditionally done. We watch for known problems. We gather predefined metrics (CPU, memory), and if one of them crosses a threshold, we get an alert. Monitoring is about asking the system, "Are you okay?" and getting a yes/no answer.
-   **Observability** is a more powerful, modern concept. It's the ability to ask *any* question about your system's state without having to predict that question in advance. It's about having such rich data coming from your system that you can explore the unknown unknowns. Observability is about asking, "Why is this happening?" and being able to find the answer.

In a complex, distributed microservices environment, simple monitoring is not enough. You need observability.

---

## 3. The Three Pillars of Observability

Observability is generally understood to be built upon three main types of telemetry data.

### 1. Logs

-   **What they are**: A timestamped, unstructured (or structured) text record of a discrete event that happened over time. `INFO: User 123 logged in.`
-   **Purpose**: Provide detailed, event-specific context for debugging a specific component.
-   **Limitation in Microservices**: In a distributed system, a single user request might generate logs on a dozen different services. Trying to manually find and correlate all these log entries is a nightmare. This is often called "swivel chair debugging."

### 2. Metrics

-   **What they are**: A numerical representation of data measured over an interval of time. They are aggregated and optimized for storage and analysis. Examples:
    -   System metrics: CPU utilization, memory usage.
    -   Application metrics: API error rate, request latency (p99), number of active users.
-   **Purpose**: Excellent for dashboards, monitoring trends, and alerting on known conditions.
-   **Limitation in Microservices**: Metrics can tell you *that* you have a problem (e.g., "p99 latency for the checkout service is high"), but they can't tell you *why*. The high latency could be caused by a slow database query, a failing downstream service, or something else entirely.

### 3. Traces (The Missing Link)

This is the pillar that is most critical for understanding microservices.

-   **What they are**: A **distributed trace** represents the end-to-end journey of a single request as it flows through all the different services in your system.
-   **Purpose**: To provide a holistic view of a request's lifecycle, allowing you to pinpoint bottlenecks and understand the interactions between services.
-   **How it works**:
    1.  When a request first enters the system (e.g., at the API gateway), it is assigned a globally unique **Trace ID**.
    2.  This Trace ID is passed along in the headers of every subsequent network call that is part of that original request.
    3.  Each individual piece of work done within a service is called a **Span**. Each span has its own ID and also records the ID of its parent span.
    4.  All these spans, tied together by the same Trace ID, can be collected and visualized in a tool like Jaeger or Zipkin. The result is a **flame graph** that shows you exactly how much time the request spent in each service and in each operation.

![Distributed Tracing Diagram](https://opentracing.io/img/trace-spans.png)

With a distributed trace, you can immediately answer the question "Why is the checkout service slow?". You can look at the trace and see, "Oh, it's spending 800ms waiting for a call to the fraud detection service." It moves you from guessing to knowing.

---

## 4. OpenTelemetry: The Emerging Standard

In the past, tracing was often implemented with vendor-specific agents. **OpenTelemetry (OTel)** is a modern, open-source, vendor-neutral standard from the Cloud Native Computing Foundation (CNCF) for collecting all three pillars of observability data.

By instrumenting your application with OpenTelemetry libraries, you can generate logs, metrics, and traces in a standardized format and then choose to send them to any backend you want (e.g., Jaeger for traces, Prometheus for metrics, Splunk for logs).

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that **Observability** is about being able to ask arbitrary questions about a system, which is a step beyond traditional **Monitoring**.
-   [ ] I can name the "Three Pillars of Observability": **Logs, Metrics, and Traces**.
-   [ ] I understand that while logs and metrics are useful, they are insufficient for debugging complex request flows in a microservices architecture.
-   [ ] I can define a **Distributed Trace** as the complete story of a single request as it moves through multiple services, tied together by a **Trace ID**.
-   [ ] I know that a **Span** represents a single unit of work within a trace.
-   [ ] I recognize **OpenTelemetry** as the open standard for instrumenting applications for observability.

---

## 13. Research and References

-   **OpenTelemetry Documentation**: [Link](https://opentelemetry.io/docs/)
-   **Jaeger Tracing - "What is a Trace?"**: [Link](https://www.jaegertracing.io/docs/1.30/architecture/#what-is-a-trace)
-   **"Observability Engineering" by Charity Majors, Liz Fong-Jones, and George Miranda**: A book from the thought leaders who helped popularize the concept.
