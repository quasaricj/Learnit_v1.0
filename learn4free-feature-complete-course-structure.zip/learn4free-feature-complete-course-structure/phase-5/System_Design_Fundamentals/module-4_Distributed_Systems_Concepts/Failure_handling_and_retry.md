# Failure Handling and Resilience Patterns in Distributed Systems

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Accept** that failures (transient or permanent) are inevitable in a distributed system.
-   **Define** a Timeout and explain its importance in preventing cascading failures.
-   **Describe** the Retry pattern and explain why simple, immediate retries are often a bad idea.
-   **Define** Exponential Backoff and Jitter and explain how they create a robust retry strategy.
-   **Define** the Circuit Breaker pattern and explain how it prevents a client from repeatedly calling a failed service.
-   **Understand** the concept of Idempotency and why it's critical for safe retries.

---

## 2. Introduction: "Everything Fails All the Time"

This quote, famously attributed to Amazon's CTO Werner Vogels, is the First Law of distributed systems. In a system where you make network calls between services, you must assume that failures are not an exception; they are a normal part of operation.

-   The network can be unreliable.
-   A downstream service can be temporarily overloaded.
-   A service instance might crash and be restarting.

A **resilient** system is one that is designed to anticipate these failures and handle them gracefully, often without the user even noticing. This is achieved by implementing specific failure handling patterns.

---

## 3. Pattern 1: Timeouts

A timeout is the most fundamental resilience pattern. It is the maximum amount of time a service is willing to wait for a response from a downstream service before giving up.

-   **The Problem**: Imagine Service A calls Service B. But Service B is stuck in an infinite loop or is experiencing extreme garbage collection pauses. Without a timeout, Service A's request thread will be blocked indefinitely, waiting for a response that will never come. If enough threads get blocked like this, Service A will exhaust its thread pool and become completely unresponsive. This is a **cascading failure**.
-   **The Solution**: Every single network call must have an aggressive, sensible timeout. It is better to fail fast and return an error to the user than to become unresponsive.

---

## 4. Pattern 2: Retries with Exponential Backoff and Jitter

Some failures are **transient**. For example, a service might be temporarily overloaded or a network packet might be dropped. In these cases, simply retrying the request a moment later might be successful.

### Why Simple Retries are Dangerous

If a service is overloaded and failing, and all its clients immediately retry their requests, they will just hammer the service even harder, making the problem worse. This is a form of a denial-of-service attack on your own system.

### The Smart Retry Strategy

A robust retry mechanism has two key components:

1.  **Exponential Backoff**: Instead of retrying immediately, the client waits for a period of time before the next attempt. The waiting time increases exponentially with each failed attempt.
    -   *Example*: Wait 100ms, then retry. If that fails, wait 200ms, then retry. If that fails, wait 400ms...
2.  **Jitter**: If all clients use the exact same backoff schedule, they will all retry at the exact same time, causing a "thundering herd" problem. To prevent this, you add a small, random amount of time (**jitter**) to the backoff.
    -   *Example*: Instead of waiting exactly 400ms, wait a random amount of time *between* 400ms and 800ms.

This combined strategy (Exponential Backoff and Jitter) is the industry standard for performing retries.

---

## 5. Pattern 3: The Circuit Breaker

Retrying forever is also a bad idea. If a downstream service is truly down (e.g., all its instances have crashed), repeatedly retrying will just waste resources on both the client and the network.

The **Circuit Breaker** pattern, inspired by electrical circuit breakers, solves this problem. It's a state machine that wraps your network calls and monitors them for failures.

![Circuit Breaker States](https://martinfowler.com/bliki/images/circuitBreaker/state.png)

1.  **Closed State**: This is the normal state. Requests are passed through to the downstream service. The circuit breaker monitors the number of failures. If the failure rate exceeds a configured threshold (e.g., "50% of requests have failed in the last 10 seconds"), the breaker **trips** and moves to the Open state.

2.  **Open State**: In this state, the circuit breaker fails fast. It immediately rejects all outgoing calls without even trying to contact the downstream service. This gives the failing service time to recover. After a configured timeout, the breaker moves to the Half-Open state.

3.  **Half-Open State**: The breaker allows a single "trial" request to pass through.
    -   If this request succeeds, the breaker assumes the service has recovered and moves back to the **Closed** state.
    -   If this request fails, the breaker assumes the service is still down and moves back to the **Open** state, restarting the timeout.

---

## 6. The Importance of Idempotency

A critical consideration for retries is **idempotency**. An operation is idempotent if it can be performed multiple times with the same result as if it were performed only once.

-   **Safe to Retry**: Reading data (`GET /users/123`) is idempotent.
-   **Dangerous to Retry**: Charging a credit card (`POST /payments`) is **not** idempotent. If you send this request, it succeeds, but you get a network error on the response, your retry logic might charge the customer a second time.

To safely retry non-idempotent operations, the API needs to be designed for it, typically by requiring the client to generate a unique **idempotency key** for each transaction. The server can then use this key to recognize and de-duplicate retry attempts.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that every network call must have a **Timeout** to prevent cascading failures.
-   [ ] I understand that the **Retry** pattern is for transient errors and must be combined with **Exponential Backoff** and **Jitter** to be safe.
-   [ ] I can describe the three states of the **Circuit Breaker** pattern (Closed, Open, Half-Open) and its purpose of giving a failing service time to recover.
-   [ ] I can define **Idempotency** and explain why it's a critical prerequisite for safely retrying write operations.

---

## 13. Research and References

-   **Martin Fowler - "Circuit Breaker"**: The canonical blog post describing the pattern. [Link](https://martinfowler.com/bliki/CircuitBreaker.html)
-   **AWS Builders' Library - "Timeouts, retries, and backoff with jitter"**: An excellent and detailed article on the topic. [Link](https://aws.amazon.com/builders-library/timeouts-retries-and-backoff-with-jitter/)
-   **Stripe API Documentation - "Idempotency"**: A great real-world example of how to design APIs for safe retries.
