# Replication and Quorum: Ensuring Data Safety and Consistency

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Data Replication and explain its two primary goals: fault tolerance and scalability.
-   **Describe** the common single-leader (primary-secondary) replication model.
-   **Differentiate** between synchronous and asynchronous replication and their respective trade-offs.
-   **Define** a Quorum in the context of a distributed system.
-   **Explain** the `W + R > N` formula for achieving strong consistency in a leaderless replication system.
-   **Analyze** how tuning the values of W (write quorum) and R (read quorum) allows you to trade off between read/write latency and consistency.

---

## 2. What is Replication?

**Replication** is the process of keeping identical copies of your data on multiple machines (nodes). In a distributed system, you almost never want to have just one copy of your data.

Replication serves two primary purposes:

1.  **Fault Tolerance / High Availability**: If one of the nodes holding your data fails (e.g., its hard drive crashes or it loses network connectivity), the system can continue to operate using one of the other replicas. It prevents a single server failure from causing a complete outage or data loss.
2.  **Scalability (for reads)**: By having multiple copies of the data, you can direct read requests to any of the replicas. This allows you to scale your read throughput far beyond what a single machine could handle. (This is the principle behind "read replicas" in a traditional database).

---

## 3. The Single-Leader Replication Model

The most common way to implement replication is the **single-leader** (also called primary-secondary or master-slave) architecture.

-   **How it works**:
    1.  One of the replicas is designated as the **Leader** (or primary).
    2.  All **write** operations (`INSERT`, `UPDATE`, `DELETE`) *must* be sent to the Leader.
    3.  The Leader applies the write to its local data store.
    4.  The Leader then sends the data change to all of its **Followers** (or secondaries) in a replication log.
    5.  The Followers apply the change to their local copies of the data.

### Synchronous vs. Asynchronous Replication

A critical decision in this model is whether the replication is synchronous or asynchronous.

-   **Synchronous Replication**: The Leader waits until at least one (and sometimes all) Followers have confirmed that they have received the write before it acknowledges the success of the write to the client.
    -   **Pro**: Guarantees that the data is safely stored on multiple machines, preventing data loss if the Leader crashes immediately after the write.
    -   **Con**: Increases write latency, as the write must wait for a network round-trip to the Follower.

-   **Asynchronous Replication**: The Leader acknowledges the write to the client as soon as it has written the data locally. It sends the update to Followers in the background.
    -   **Pro**: Very low write latency.
    -   **Con**: Risk of data loss. If the Leader crashes before the update has been sent to the Followers, that write is lost forever. This is the "eventual consistency" model.

---

## 4. Quorum: Agreeing on the Truth

In a **leaderless** replication system (like Amazon's Dynamo or Apache Cassandra), any replica can accept a write request. This is great for availability, but it introduces a problem: how do you ensure you are reading the latest version of the data when writes could be happening on different nodes at the same time?

The solution is to use a **quorum**. A quorum is the minimum number of nodes that must participate in an operation for it to be considered successful.

We define three variables:
-   `N`: The total number of replicas for a piece of data.
-   `W`: The **write quorum**. The number of replicas that must acknowledge a write before it is considered successful.
-   `R`: The **read quorum**. The number of replicas that a client must contact and get a response from when reading data.

### The Quorum Formula for Strong Consistency: `W + R > N`

This simple formula is the key to managing consistency in these systems. If you configure your `W` and `R` values such that their sum is greater than the total number of replicas, you can guarantee **strong consistency** (i.e., you will always read the most recent write).

**Why it works**: The condition `W + R > N` ensures that the set of nodes you read from (`R`) and the set of nodes you write to (`W`) *must* have at least one node in common. This overlap guarantees that at least one of the nodes you are reading from was part of the last successful write. By comparing version numbers from the `R` nodes, your client can identify and return the most up-to-date value.

### Example:

-   Let `N = 3` (we have 3 replicas for our data).
-   Let's choose `W = 2` and `R = 2`.
-   Check the formula: `W + R = 2 + 2 = 4`, which is greater than `N = 3`. So, we should get strong consistency.

-   **Write operation**: A client sends a write request. The system forwards it to all 3 replicas. The write is considered successful once **2** of them (`W=2`) have confirmed it.
-   **Read operation**: A client sends a read request. The system sends the request to all 3 replicas. It waits until it gets a response from **2** of them (`R=2`).
-   **Guarantee**: Because of the overlap, at least one of the two responding nodes is guaranteed to have the latest write. The client can now be confident it has the correct data.

### Tuning Quorums for Performance

-   **Fast Reads, Slow Writes**: If your system is read-heavy, you might choose `R=1` and `W=N`. A read is very fast (it only needs to contact one node), but a write is slow and less fault-tolerant (it requires all replicas to be up).
-   **Fast Writes, Slow Reads**: If your system is write-heavy, you might choose `W=1` and `R=N`. A write is very fast, but a read is slow and requires contacting all nodes.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that **Replication** provides fault tolerance and read scalability.
-   [ ] I can contrast **synchronous replication** (safe but slow writes) with **asynchronous replication** (fast but risky writes).
-   [ ] I can define a **Quorum** as the minimum number of nodes needed to acknowledge an operation.
-   [ ] I can explain how the `W + R > N` rule guarantees that the set of read nodes and write nodes will always overlap.
-   [ ] I understand that quorums are a powerful mechanism for tuning the trade-off between consistency and performance in a distributed data store.

---

## 13. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapters 5 and 9 provide one of the clearest explanations of replication and consistency available.
-   **Amazon DynamoDB Paper**: The original paper that popularized leaderless replication and quorums for highly available systems.
-   **Microsoft Azure - "Quorum"**: [Link](https://learn.microsoft.com/en-us/azure/architecture/patterns/quorum)
