# Microservices Design Pattern: Database Per Service

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the Database per Service pattern.
- **Explain** the rationale behind this pattern: to ensure loose coupling.
- **Describe** the trade-offs of this pattern compared to a shared database.
- **Identify** the challenges that this pattern introduces (e.g., data consistency, cross-service queries).
- **Understand** that each service can choose the database technology that is best suited for its needs.
- **Relate** this pattern to the concept of a "bounded context" from Domain-Driven Design.

---

## 2. Introduction: The Problem with a Shared Database

One of the most common mistakes when teams first adopt a microservices architecture is to have all their different services share a single, monolithic database.

While this seems simpler at first, it creates a massive point of **tight coupling** between the services.
- **Schema Changes**: If the `UserService` team needs to change a table in the database, that change could break the `OrderService`. The teams are no longer able to develop and deploy independently.
- **Performance Issues**: If the `ReportingService` runs a long, expensive query, it could degrade the performance of the entire database, affecting all the other services.
- **Technology Lock-in**: All services are forced to use the same database technology, even if it's not the best fit for their specific needs.

To achieve the true benefits of microservices (especially team autonomy and independent deployment), you must avoid this tight coupling at the database layer.

---

## 3. The Database per Service Pattern

The **Database per Service** pattern is a core principle of microservices architecture.

- **The Rule**: **Each microservice must own and manage its own private database.**
- **Encapsulation**: The service's data is completely encapsulated. It is a private implementation detail.
- **No Direct Access**: No other service is allowed to directly access another service's database. The only way for one service to get data from another is by calling its **public API**.

**Analogy**: This is the ultimate "good fences make good neighbors" policy for your services. Each service has its own private property (its database), and if a neighbor wants something, they have to come to the front door (the API) and ask for it. They can't just walk into the house and take it.

---

## 4. Benefits of the Database per Service Pattern

1.  **Loose Coupling and Team Autonomy**:
    - This is the primary benefit. Because each service owns its own database, the team that owns the service can make changes to the database schema at any time without having to coordinate with other teams. This enables true independent deployment.

2.  **Polyglot Persistence**:
    - It allows each team to choose the **best database technology for their specific service**.
    - The `ProductCatalogService` might be very read-heavy and have complex data, so it might choose a flexible NoSQL document database like **MongoDB**.
    - The `PaymentService` needs strong transactional guarantees, so it will choose a relational database like **PostgreSQL**.
    - The `SearchService` needs to perform full-text searches, so it will use a dedicated search engine like **Elasticsearch**.

3.  **Improved Scalability**:
    - You can scale each service's database independently, based on its specific needs.

---

## 5. Challenges and How to Solve Them

This pattern is essential for microservices, but it introduces significant challenges.

### 1. How to Implement Cross-Service Queries?

- **Problem**: How do you run a query that needs to `JOIN` data from two different services? For example, how do you get a list of customers and all the orders they have placed? The `users` data is in the `UserService`'s database, and the `orders` data is in the `OrderService`'s database.
- **Solution**:
  - **API Composition**: The client or an API Gateway makes separate calls to the `UserService` and the `OrderService` and then "joins" the data in its own code. This is the simplest approach.
  - **Materialized Views / Data Duplication**: The `OrderService` might store a small, denormalized copy of the relevant user data (like the username) that it needs. This data is kept up-to-date by subscribing to events from the `UserService`.

### 2. How to Handle Transactions Across Services?

- **Problem**: How do you implement a transaction that needs to update data in multiple services? You can no longer use a traditional, ACID database transaction.
- **Solution**: The **Saga Pattern**. This is an advanced pattern that manages consistency using a sequence of local transactions and "compensating transactions" to roll back the changes if a step fails. This is a form of eventual consistency.

---

## 6. Relationship to Domain-Driven Design (DDD)

The Database per Service pattern aligns perfectly with the concept of a **Bounded Context** from Domain-Driven Design. A bounded context is a clear boundary within which a specific domain model (and its language) applies. Each microservice should correspond to a single bounded context, and it should own all the data and logic related to that context.

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain that the **Database per Service** pattern means each microservice has its own private database.
-   [ ] I know that the main reason for this pattern is to ensure **loose coupling** and team autonomy.
-   [ ] I understand that other services can only access a service's data through its **public API**.
-   [ ] I can list a benefit of this pattern, such as the ability to use different database technologies for different services (**polyglot persistence**).
-   [ ] I can identify a major challenge that this pattern creates, such as how to perform a **cross-service query** or a **distributed transaction**.

---

## 8. Research and References

-   **"Building Microservices" by Sam Newman**: Chapter 4, "Integration," is a deep dive into these concepts.
-   **"Pattern: Database per service"** by Chris Richardson. [Link](https://microservices.io/patterns/data/database-per-service.html)
-   **"Domain-Driven Design: Tackling Complexity in the Heart of Software" by Eric Evans**: The seminal book on DDD.
-   **The Saga Pattern**: A critical pattern for managing consistency in a distributed system.
