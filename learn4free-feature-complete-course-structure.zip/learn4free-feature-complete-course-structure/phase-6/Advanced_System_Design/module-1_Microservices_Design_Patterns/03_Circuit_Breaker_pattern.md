# Microservices Design Pattern: Circuit Breaker

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the Circuit Breaker pattern.
- **Explain** the problem that the Circuit Breaker is designed to solve ( cascading failures).
- **Describe** the three states of a Circuit Breaker: Closed, Open, and Half-Open.
- **Understand** how a Circuit Breaker improves the resilience and fault tolerance of a distributed system.
- **Relate** the pattern to a real-world electrical circuit breaker.
- **Recognize** that this pattern is often implemented in service mesh technologies or libraries.

---

## 2. Introduction: The Problem of Cascading Failures

In a distributed system like a microservices architecture, services often make synchronous calls to other services. For example, the `OrderService` might call the `PaymentService` to process a payment.

What happens if the `PaymentService` is slow or unavailable?
- The `OrderService` will be blocked, waiting for a response that will never come (or will eventually time out).
- While it's waiting, the `OrderService` is consuming resources (like threads and memory).
- If enough requests come in to the `OrderService`, all its resources will be consumed by waiting for the failed `PaymentService`, and the `OrderService` itself will become unavailable.
- Now, any service that calls the `OrderService` will also fail.

This chain reaction, where the failure of one downstream service causes a failure in an upstream service, is called a **cascading failure**. The Circuit Breaker pattern is a design pattern used to prevent this.

---

## 3. The Circuit Breaker Pattern

The Circuit Breaker pattern is a mechanism that you wrap around a protected function call (like a network request to another service). It monitors for failures. After a certain number of failures, it "trips" and all further calls to the protected function will fail immediately, without even trying to execute the real function. This is a way for the system to "fail fast" and prevent its resources from being consumed by an operation that is likely to fail.

The pattern is named after a real-world electrical circuit breaker. If you plug in too many appliances, the circuit breaker trips to prevent the house from catching fire.

### The Three States of the Circuit Breaker

A Circuit Breaker acts as a state machine with three states:

1.  **Closed**:
    - This is the normal, default state.
    - Requests are allowed to pass through to the protected service.
    - The breaker maintains a count of recent failures. If the number of failures exceeds a configured threshold within a certain time period, the breaker **trips** and moves to the **Open** state.

2.  **Open**:
    - In this state, the breaker **fails immediately** for all calls to the protected service, without making the actual network request. It returns a cached or default error response.
    - This gives the downstream service (the one that was failing) **time to recover**.
    - After a configured timeout period, the breaker moves to the **Half-Open** state.

3.  **Half-Open**:
    - In this state, the breaker allows a **single, trial request** to pass through to the protected service.
    - **If this trial request succeeds**: The breaker assumes the downstream service has recovered. It resets its failure count and moves back to the **Closed** state.
    - **If this trial request fails**: The breaker assumes the downstream service is still unavailable. It moves back to the **Open** state and starts the timeout period again.

---

## 4. Benefits of the Circuit Breaker Pattern

1.  **Resilience and Fault Tolerance**: It prevents a single service failure from cascading and bringing down the entire system.
2.  **Fail Fast**: By failing immediately when the circuit is open, upstream services can provide a faster and more graceful degradation of service to the end-user (e.g., by showing a cached response or a "try again later" message) instead of just hanging.
3.  **Automatic Recovery**: The Half-Open state provides a mechanism for the system to automatically detect when a failed service has become healthy again, without the need for manual intervention.

---

## 5. Implementation

You will almost never implement a Circuit Breaker from scratch. This pattern is typically provided by a library or as part of a larger framework.

- **Libraries**:
  - **Hystrix**: The original and most famous Circuit Breaker library, created by Netflix (now in maintenance mode).
  - **Resilience4j** (Java), **Polly** (.NET), **pybreaker** (Python) are modern, popular alternatives.
- **Service Mesh**: Modern infrastructure like a **service mesh** (e.g., Istio, Linkerd) can implement the Circuit Breaker pattern at the platform level, "out of process". This means you don't even have to put a library in your code; the service mesh's proxy automatically handles the circuit breaking for all network calls between your services. This is the preferred modern approach.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that the Circuit Breaker pattern is designed to prevent **cascading failures** in a distributed system.
-   [ ] I can use the analogy of an electrical circuit breaker.
-   [ ] I can name and describe the three states: **Closed** (normal), **Open** (failing fast), and **Half-Open** (testing for recovery).
-   [ ] I understand that the primary benefit is to improve the **resilience** of the system.
-   [ ] I know that Circuit Breakers are usually implemented using a **library** or a **service mesh**.

---

## 7. Research and References

-   **"CircuitBreaker" by Martin Fowler**: The original, foundational article on the pattern. [Link](https://martinfowler.com/bliki/CircuitBreaker.html)
-   **"Release It!" by Michael T. Nygard**: The book that popularized this and other stability patterns.
-   **Netflix Hystrix Wiki**: Even though it's in maintenance, the wiki is an excellent resource for understanding the concepts.
-   **Resilience4j Documentation**: [Link](https://resilience4j.readme.io/)
-   **Istio - Circuit Breaking**: The documentation for a popular service mesh, showing how it's done at the infrastructure level.
