# Microservices Design Pattern: Service Discovery

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** service discovery and explain the problem it solves in a microservices architecture.
- **Differentiate** between the client-side discovery and server-side discovery patterns.
- **Explain** the role of a service registry.
- **Understand** how modern platforms like Kubernetes provide service discovery automatically.
- **Relate** service discovery to the ephemeral nature of containers.

---

## 2. Introduction: Where are the Services?

In a monolithic application, components invoke each other through language-level method calls. In a distributed, microservices architecture, services need to make requests to each other over a network. To do this, a client service needs to know the **network location (IP address and port)** of the service it wants to call.

In a modern, cloud-based environment, this is a difficult problem:
- Services are often deployed in containers, and they are **ephemeral**. They can be created and destroyed at any time.
- When a new instance of a service is started, it will get a **new IP address**.
- The number of instances of a service and their locations can change dynamically due to auto-scaling and failures.

You cannot rely on a static configuration file with a list of IP addresses. You need a dynamic way for services to find each other. This is the **service discovery** problem.

---

## 3. The Core Components

Any service discovery mechanism has three main components:

1.  **Service Registry**:
    - A central database that contains the network locations of all the available service instances.
    - It is the "phone book" of your microservices architecture.

2.  **Service Registration**:
    - The process of a new service instance registering itself with the service registry when it starts up. It provides its name and its network location (IP and port).

3.  **Service Discovery**:
    - The process of a client service querying the service registry to find the available locations for another service.

---

## 4. The Two Main Discovery Patterns

### 1. Client-Side Discovery

- **How it works**:
  1.  A service instance registers itself with the Service Registry.
  2.  The client service is responsible for discovering the locations of the target service. It directly queries the Service Registry to get a list of available instances.
  3.  The client then uses a **client-side load balancing** algorithm (like round-robin) to choose one of the instances and makes a request to it.
- **Analogy**: You look up a restaurant's address in the phone book (the registry) and then you drive yourself there.
- **Pros**: Simple to understand.
- **Cons**:
  - The client is more complex. It has to contain the logic for querying the registry and for load balancing.
  - You have to implement this logic in a library for every language and framework that your services use.
- **Example**: Netflix Eureka was a very popular client-side discovery tool.

### 2. Server-Side Discovery

- **How it works**:
  1.  A service instance registers itself with the Service Registry.
  2.  The client service makes a request to a **router** or a **load balancer**. It uses a logical DNS name for the service it wants to call (e.g., `http://payment-service/charge`).
  3.  The router is responsible for querying the Service Registry and routing the request to one of the available backend service instances.
- **Analogy**: You call a central taxi dispatch number (the router). You tell them where you want to go. They look up the available taxis (the registry) and send one to you. You don't have to know where the taxis are.
- **Pros**:
  - The client is much simpler. It doesn't need to know anything about the service registry. All the complexity is in the router.
- **Cons**:
  - The router is a critical piece of infrastructure that must be highly available.
- **This is the dominant pattern today.**

---

## 5. Service Discovery in Modern Platforms

Modern container orchestration platforms have **built-in service discovery**. You don't have to use a separate tool like Eureka.

### Service Discovery in Kubernetes

- Kubernetes uses the **server-side discovery** pattern.
- **Service Registry**: The `etcd` database is the service registry. It stores the locations of all the Pods.
- **Service Registration**: When a new Pod is created, Kubernetes automatically registers its IP address.
- **Discovery and Routing**: The Kubernetes **Service** object acts as the router.
  - A Service gets a stable, internal DNS name (e.g., `payment-service.default.svc.cluster.local`).
  - When a client Pod makes a request to this DNS name, the `kube-dns` and `kube-proxy` components automatically intercept the request, look up the available backend Pods, and load balance the request to one of them.

This built-in, automatic service discovery is one of the most powerful features of Kubernetes. It means that as a developer, you rarely have to think about this problem. You just have your services communicate with each other using their stable Kubernetes Service names.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that **service discovery** is the process of how services find each other's network locations in a dynamic, distributed environment.
-   [ ] I can name the three core components: the **Service Registry**, **Service Registration**, and **Service Discovery**.
-   [ ] I can differentiate between **client-side** and **server-side** discovery.
-   [ ] I know that **server-side discovery** is the more common pattern today.
-   [ ] I understand that a platform like **Kubernetes provides automatic, built-in service discovery** using its **Service** objects and internal DNS.

---

## 7. Research and References

-   **"Pattern: Service Discovery"** by Chris Richardson. [Link](https://microservices.io/patterns/server-side-discovery.html) and [Link](https://microservices.io/patterns/client-side-discovery.html)
-   **"Building Microservices" by Sam Newman**
-   **Kubernetes Docs - Service**: The documentation explains how a Service provides a stable endpoint. [Link](https://kubernetes.io/docs/concepts/services-networking/service/)
-   **Consul**: A popular open-source tool from HashiCorp that provides service discovery, a key-value store, and other features.
-   **CoreDNS**: The DNS server used by Kubernetes for service discovery.
