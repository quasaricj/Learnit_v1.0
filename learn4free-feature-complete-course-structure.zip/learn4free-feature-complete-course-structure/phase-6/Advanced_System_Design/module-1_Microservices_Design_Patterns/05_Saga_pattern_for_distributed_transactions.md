# Microservices Design Pattern: Saga

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the Saga pattern.
- **Explain** the problem that the Saga pattern solves: maintaining data consistency across multiple services without using distributed transactions.
- **Differentiate** between the two main types of sagas: Choreography and Orchestration.
- **Describe** the concept of a "compensating transaction."
- **Understand** that the Saga pattern provides eventual consistency.
- **Recognize** the complexity involved in implementing a saga.

---

## 2. Introduction: The Distributed Transaction Problem

In a microservices architecture, you use the **Database per Service** pattern. Each service has its own private database. This is great for loose coupling, but it creates a major challenge: how do you maintain data consistency for an operation that needs to update data in multiple services?

**Example: The E-commerce Order**
When a customer places an order, you need to:
1.  Create the order in the `OrderService`.
2.  Authorize the payment in the `PaymentService`.
3.  Update the stock in the `InventoryService`.

This is a single, conceptual "transaction". In a monolith with a single database, you would wrap these three operations in a single, atomic **ACID transaction**. If any step failed, the entire transaction would be rolled back automatically.

In a distributed system, you cannot use a traditional ACID transaction that spans multiple databases (as discussed in the "Distributed Transactions" module). The **Saga pattern** is a design pattern for managing consistency in this scenario.

---

## 3. The Saga Pattern

A **saga** is a sequence of **local transactions**. Each local transaction updates the database in a single service and publishes an event or a message that triggers the next local transaction in the saga.

If a local transaction fails for some reason, the saga executes a series of **compensating transactions** to undo the changes that were made by the preceding local transactions.

### Key Concepts

- **Local Transaction**: A standard ACID transaction that is performed on a single service's database.
- **Compensating Transaction**: An operation that reverses the effect of a previous local transaction. For example, the compensating transaction for "Debit Customer's Account" is "Credit Customer's Account".

The Saga pattern guarantees that either all the local transactions in the sequence will complete successfully, or all the changes will be undone via compensating transactions. It ensures **atomicity** at the level of the entire saga.

---

## 4. The Two Types of Sagas

### 1. Choreography-Based Saga

- **How it works**: There is no central coordinator. Each service in the saga participates by publishing and listening for events.
- **The Flow (E-commerce Order)**:
  1.  The `OrderService` creates an order, sets its status to "PENDING", and publishes an `OrderCreated` event.
  2.  The `PaymentService` listens for the `OrderCreated` event. It processes the payment and publishes a `PaymentSucceeded` event.
  3.  The `InventoryService` listens for the `PaymentSucceeded` event. It reserves the stock and publishes an `InventoryUpdated` event.
  4.  The `OrderService` listens for the `InventoryUpdated` event and finally sets the order's status to "APPROVED".
- **Handling Failures**: If the `InventoryService` fails, it would publish an `InventoryUpdateFailed` event. The `PaymentService` would have to listen for this and execute a compensating transaction to refund the payment.
- **Analogy**: A group of dancers performing a choreographed routine. Each dancer knows what to do based on the actions of the dancer before them.
- **Pros**: Simple, loosely coupled.
- **Cons**: Can be difficult to track the state of a transaction. The logic is distributed across all the services.

### 2. Orchestration-Based Saga

- **How it works**: A central **orchestrator** service is responsible for managing the saga. The orchestrator tells the other services what to do.
- **The Flow (E-commerce Order)**:
  1.  A client request comes to the `SagaOrchestrator` to create an order.
  2.  The orchestrator calls the `OrderService`'s API to create the order.
  3.  If that succeeds, the orchestrator calls the `PaymentService`'s API to process the payment.
  4.  If that succeeds, the orchestrator calls the `InventoryService`'s API to update the stock.
- **Handling Failures**: If any step fails, the orchestrator is responsible for calling the compensating transactions in the reverse order.
- **Analogy**: The conductor of an orchestra. The conductor (the orchestrator) tells each musician (the service) when and what to play.
- **Pros**: The transaction logic is centralized and easier to manage and debug.
- **Cons**: Creates a powerful orchestrator service that can become a "god object".

---

## 5. Sagas and Eventual Consistency

The Saga pattern provides **eventual consistency**. There is a period of time during which the overall system is in an inconsistent state. For example, after the payment has been processed but before the inventory has been updated, the system is temporarily inconsistent.

This is a trade-off. The Saga pattern sacrifices the strong, immediate consistency of an ACID transaction for the benefits of loose coupling and higher availability. For most business transactions, this is an acceptable trade-off.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that the **Saga pattern** is a way to manage data consistency across multiple microservices without using distributed transactions.
-   [ ] I can define a saga as a **sequence of local transactions**.
-   [ ] I know that if a step in the saga fails, **compensating transactions** are run to undo the previous steps.
-   [ ] I can describe a **Choreography**-based saga as one that uses events for communication.
-   [ ] I can describe an **Orchestration**-based saga as one that uses a central coordinator.
-   [ ] I understand that sagas provide **eventual consistency**, not strong ACID consistency.

---

## 7. Research and References

-   **"Pattern: Saga"** by Chris Richardson. The definitive guide on his website. [Link](https://microservices.io/patterns/data/saga.html)
-   **"Building Microservices" by Sam Newman**
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**
-   **Microsoft - "Saga distributed transactions pattern"**: A great article in the Azure documentation. [Link](https://docs.microsoft.com/en-us/azure/architecture/reference-architectures/saga/saga)
