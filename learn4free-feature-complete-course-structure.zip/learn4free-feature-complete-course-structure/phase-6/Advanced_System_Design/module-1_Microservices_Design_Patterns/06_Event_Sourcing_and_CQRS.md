# Microservices Design Patterns: Event Sourcing and CQRS

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Event Sourcing and explain how it differs from traditional state-based persistence.
- **Describe** the concept of an event log as the source of truth.
- **Explain** how to derive the current state of an entity from its event history.
- **Define** CQRS (Command Query Responsibility Segregation).
- **Explain** the separation between the "write" side (Commands) and the "read" side (Queries).
- **Understand** how Event Sourcing and CQRS are often used together.
- **Recognize** that these are advanced patterns with significant complexity.

---

## 2. Introduction: A Different Way to Think About Data

In a traditional CRUD (Create, Read, Update, Delete) system, we store the **current state** of our data. For example, a customer's record in the database holds their current address. If they move, we overwrite the old address with the new one. The history of their previous addresses is lost.

**Event Sourcing** is a completely different approach. Instead of storing the current state, we store a **sequence of immutable events** that describe every change that has ever happened to the data.

---

## 3. Event Sourcing

- **The Core Idea**: **The event log is the single source of truth.** We persist the full history of state changes as a chronological sequence of events, rather than just the current state.
- **Example: A Bank Account**
  - **Traditional Model**: A `accounts` table with a `balance` column. `UPDATE accounts SET balance = balance - 10 WHERE id = 123`.
  - **Event Sourcing Model**: We store a series of events:
    - `AccountCreated { accountId: 123, initialBalance: 100 }`
    - `FundsDeposited { accountId: 123, amount: 50 }`
    - `FundsWithdrawn { accountId: 123, amount: 10 }`
- **Deriving Current State**: To get the current balance of the account, you **replay** all the events for that account. `100 + 50 - 10 = 140`. The current state is a "fold" or a "reduce" of the event history.

### Benefits of Event Sourcing

1.  **Complete Audit Trail**: You have a complete, immutable log of everything that has ever happened in the system. This is invaluable for debugging, auditing, and business intelligence.
2.  **Temporal Queries**: You can easily determine the state of an entity at *any point in time* by replaying events up to that point.
3.  **Powerful Decoupling**: You can create new "projections" or "read models" of your data by subscribing to the event stream, without changing the write side of your system at all. This is where CQRS comes in.

### Drawbacks of Event Sourcing

- It is a complex, unfamiliar pattern.
- Replaying a very long history of events to get the current state can be slow (though this is solved with "snapshots").
- Querying the event log can be difficult. You can't just run an SQL query to "find all customers who live in California."

---

## 4. CQRS (Command Query Responsibility Segregation)

**CQRS** is an architectural pattern that separates the model used for **writing** data (the "Command" side) from the model used for **reading** data (the "Query" side).

- **The Command Side**:
  - Handles all the `Create`, `Update`, and `Delete` operations.
  - The model is optimized for validation, business logic, and consistency.
  - It does not return data. It just acknowledges success or failure.
- **The Query Side**:
  - Handles all the `Read` operations.
  - The model is a **denormalized** and highly optimized "read model" designed specifically to answer the queries of your UI.
  - It never has to worry about business logic or validation.

---

## 5. CQRS + Event Sourcing: A Powerful Combination

CQRS and Event Sourcing are two separate patterns, but they are very frequently used together.

- **How they fit**:
  1.  The **Command** side of your application uses an **Event Sourcing** model. It handles a command, validates it, and produces one or more events which are saved to the event log. This is the **write model**.
  2.  You then have one or more separate "projectors" or event handlers that subscribe to the stream of events from the event log.
  3.  These projectors are responsible for updating the **read models**. The read models are stored in a separate database that is highly optimized for querying. This could be a relational database, a document database, or a search index.
  4.  The **Query** side of your application then reads directly from these optimized read models.

This architecture provides the best of both worlds: a consistent, auditable, and decoupled write model, and a highly performant and flexible read model.

---

## 6. When to Use These Patterns

CQRS and Event Sourcing are **advanced patterns**. They add significant complexity to a system. They are **not** suitable for most simple CRUD applications.

**Good Use Cases**:
- **Complex, collaborative domains**: Applications where many users are working on the same data and you need to understand the intent and history of the changes (e.g., a collaborative document editor).
- **Systems with high performance read requirements**: Where you need to have multiple, different, highly optimized read models of your data.
- **Systems that require a complete audit log** for legal or business reasons.

---

## 7. Summary and Mastery Checklist

-   [ ] I can define **Event Sourcing** as a pattern where you store a **sequence of events** instead of the current state.
-   [ ] I know that in Event Sourcing, the **event log is the source of truth**.
-   [ ] I can define **CQRS** as the pattern of separating the **write model (Commands)** from the **read model (Queries)**.
-   [ ] I can explain how Event Sourcing and CQRS are often used together: the Command side produces events, and the Query side consumes these events to build read models.
-   [ ] I understand that these are **advanced, complex patterns** that should not be used for simple applications.

---

## 8. Research and References

-   **"CQRS" by Martin Fowler**: The foundational article on the pattern. [Link](https://martinfowler.com/bliki/CQRS.html)
-   **"Event Sourcing" by Martin Fowler**: [Link](https://martinfowler.com/eaaDev/EventSourcing.html)
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Has an excellent chapter on Event Sourcing.
-   **"Exploring CQRS and Event Sourcing"**: A free e-book from Microsoft.
-   **Greg Young**: The originator of the CQRS pattern. His talks on the subject are highly influential.
