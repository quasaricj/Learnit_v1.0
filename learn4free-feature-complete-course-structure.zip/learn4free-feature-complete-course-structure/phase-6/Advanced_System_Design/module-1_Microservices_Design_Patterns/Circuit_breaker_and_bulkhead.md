# Resilience Patterns: Circuit Breaker and Bulkhead

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** the Circuit Breaker pattern and describe its three states: Closed, Open, and Half-Open.
-   **Explain** how the Circuit Breaker pattern prevents cascading failures by giving a downstream service time to recover.
-   **Define** the Bulkhead pattern using a clear, real-world analogy (the hull of a ship).
-   **Explain** how the Bulkhead pattern isolates failures by partitioning resources.
-   **Analyze** how these two patterns can be used together to build highly resilient and fault-tolerant applications.

---

## 2. Introduction: Building Walls Against Failure

In a distributed system, failures are inevitable. A service can become slow or unresponsive, and network connections can fail. A resilient system is not one that never fails, but one that is designed to **contain failures** and prevent them from spreading and causing a system-wide outage.

The Circuit Breaker and Bulkhead patterns are two of the most important design patterns for containing and managing failures. They act like defensive walls within your application.

---

## 3. The Circuit Breaker Pattern

We've introduced this pattern before, but we'll do a deeper dive here. Its primary goal is to prevent an application from repeatedly trying to perform an operation that is likely to fail.

-   **Analogy**: An electrical circuit breaker in a house. If you plug in a faulty appliance, the breaker trips, cutting off the flow of electricity to that circuit to prevent a fire. It stops the problem from getting worse. After a while, you can try flipping it back on to see if the problem is resolved.

### The States of a Circuit Breaker

A circuit breaker is a state machine that wraps around a protected function call (like a network request).

![Circuit Breaker States](https://martinfowler.com/bliki/images/circuitBreaker/state.png)

1.  **`Closed`**: The normal state. Requests are allowed to pass through to the downstream service. The breaker monitors for failures. If the number of failures in a given time window exceeds a configured threshold, the breaker "trips" and moves to the `Open` state.

2.  **`Open`**: The breaker immediately rejects any calls to the protected function with an error, without even attempting to execute it. This is called "failing fast." This is the crucial part: it gives the struggling downstream service a break, allowing it time to recover. After a configured timeout period, the breaker moves to the `Half-Open` state.

3.  **`Half-Open`**: The breaker allows a single "trial" request to pass through to the downstream service.
    -   If this trial request succeeds, the breaker assumes the service has recovered and moves back to the `Closed` state, resuming the normal flow of traffic.
    -   If the trial request fails, the breaker assumes the service is still unhealthy and immediately transitions back to the `Open` state, starting the recovery timeout again.

### Why It's Critical

Without a circuit breaker, if a downstream service like a payment gateway becomes slow, all the threads in your application server making that call will block. Soon, your server will run out of threads and become completely unresponsive, causing a **cascading failure**. The circuit breaker prevents this by stopping the calls and allowing your service to remain healthy.

---

## 4. The Bulkhead Pattern

The primary goal of the Bulkhead pattern is to **isolate elements of an application into pools so that if one fails, the others will continue to function**.

-   **Analogy**: The hull of a ship. A ship's hull is divided into several watertight compartments called bulkheads. If the hull is breached (e.g., by an iceberg), only the damaged compartment floods. The other compartments remain dry, and the ship can stay afloat.

### How It Works in Software

This pattern is about partitioning resources. In a microservices context, it often means partitioning connection pools and thread pools.

**The Problem**: Imagine a service that talks to two other services, Service A (a fast metadata service) and Service B (a slow, complex data processing service). By default, most HTTP clients use a single, shared connection pool and thread pool for all outgoing requests.
-   If Service B becomes slow and unresponsive, all the threads in the shared pool will eventually become blocked waiting for a response from Service B.
-   Now, when a user makes a request that only needs to talk to the fast and healthy Service A, there are no available threads to handle it.
-   The failure of Service B has caused a failure in the parts of your application that depend on Service A. The failure has spread.

**The Solution**: You configure your HTTP client to maintain **separate connection pools and thread pools** for each downstream service.
-   A pool of 10 threads for calls to Service A.
-   A separate pool of 10 threads for calls to Service B.

Now, if Service B becomes slow, it will only exhaust its own dedicated thread pool. The threads for Service A are completely unaffected and can continue to serve requests. The failure has been **contained**.

---

## 5. Using the Patterns Together

Circuit Breakers and Bulkheads are a powerful combination.
-   You would apply a **Bulkhead** to create separate thread pools for each downstream dependency (`PaymentService`, `InventoryService`, etc.).
-   You would then wrap the calls to each of those services in its own **Circuit Breaker**.

This provides two layers of defense: the bulkhead isolates the resources, and the circuit breaker prevents retries and gives the failing service a chance to recover. This is a cornerstone of building truly resilient, fault-tolerant microservice applications.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that the **Circuit Breaker** pattern prevents an application from making repeated calls to a known-failing service.
-   [ ] I can describe the `Closed` (passing through), `Open` (failing fast), and `Half-Open` (trial request) states of a circuit breaker.
-   [ ] I can explain that the **Bulkhead** pattern isolates failures by partitioning resources like connection and thread pools.
-   [ ] I understand that the goal of a bulkhead is to prevent a failure in one downstream dependency from cascading and affecting other, healthy dependencies.
-   [ ] I can describe how to use both patterns together for a robust, multi-layered defense against cascading failures.

---

## 13. Research and References

-   **"Release It!" by Michael T. Nygard**: The book that popularized these patterns in software engineering. A must-read on resilience.
-   **Martin Fowler - "Circuit Breaker"**: The canonical blog post on the pattern.
-   **Microsoft Azure - "Bulkhead pattern"**: A clear explanation with code examples. [Link](https://learn.microsoft.com/en-us/azure/architecture/patterns/bulkhead)
-   **Resilience4j**: A popular Java library that provides implementations of these and other resilience patterns.
