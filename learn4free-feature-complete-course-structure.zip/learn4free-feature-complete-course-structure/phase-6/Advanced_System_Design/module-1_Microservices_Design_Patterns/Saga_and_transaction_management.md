# The Saga Pattern: Managing Distributed Transactions

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Explain** why traditional ACID transactions are not feasible in a microservices architecture.
-   **Define** the Saga pattern as a mechanism for managing a sequence of local transactions across multiple services.
-   **Describe** a "compensating transaction" and its role in handling failures in a saga.
-   **Differentiate** between the two main saga implementation styles: Choreography (event-based) and Orchestration (command-based).
-   **Analyze** the benefits and significant challenges of the Saga pattern, particularly its eventual consistency model.

---

## 2. The Problem: The End of ACID

In a monolith with a single database, you can use **ACID transactions** (Atomicity, Consistency, Isolation, Durability) to guarantee that a sequence of operations either all succeed or all fail. The classic example is a bank transfer: debiting one account and crediting another must happen as a single, atomic unit.

In a microservices architecture, this is not possible. A single business transaction, like "placing an order," might involve making changes to three different services, each with its own private database:
1.  The `Order Service` creates an `Order` in its database.
2.  The `Payment Service` processes a payment in its database.
3.  The `Inventory Service` reserves the items in its database.

You cannot have a single database transaction that spans these three independent databases. This is where the **Saga pattern** comes in.

---

## 3. The Saga Pattern

A **Saga** is a sequence of **local transactions**. Each local transaction updates the database within a single service. The key principle is that the saga guarantees that the entire sequence of transactions will either complete successfully, or it will be properly compensated for if a failure occurs, maintaining data consistency across the services.

If any step in the saga fails, a series of **compensating transactions** are executed in reverse order to undo the work of the preceding successful steps.

-   **Example: Placing an Order**
    -   **Local Transaction 1**: `Order Service` creates an order and sets its status to `PENDING`.
    -   **Local Transaction 2**: `Payment Service` attempts to charge the customer's credit card.
        -   **If this fails**: The saga must be aborted. The `Order Service` executes a **Compensating Transaction 1**: update the order status to `FAILED`.
    -   **Local Transaction 3**: `Inventory Service` attempts to reserve the items.
        -   **If this fails**: The saga must be aborted. The `Payment Service` executes **Compensating Transaction 2**: refund the payment. Then the `Order Service` executes **Compensating Transaction 1**: update the order status to `FAILED`.
    -   If all steps succeed, the saga completes, and the order status is updated to `CONFIRMED`.

---

## 4. Saga Implementation Styles

There are two main ways to coordinate a saga.

### 1. Choreography (Event-Based)

In a choreographed saga, there is no central coordinator. The services communicate with each other by publishing and subscribing to **events**.

-   **How it works**:
    1.  The `Order Service` creates an order and publishes an `OrderCreated` event.
    2.  The `Payment Service` subscribes to `OrderCreated` events. When it receives one, it processes the payment and publishes a `PaymentSucceeded` event.
    3.  The `Inventory Service` subscribes to `PaymentSucceeded` events. When it receives one, it reserves the inventory.
    -   **Handling Failures**: If the payment fails, the `Payment Service` would publish a `PaymentFailed` event instead. The `Order Service` would subscribe to this event and execute its compensating transaction (canceling the order).

-   **Pros**: Simple, loosely coupled. Services don't need to know about each other.
-   **Cons**: Can be difficult to track and debug. The business logic is spread across all the services. What is the current status of the "Place Order" process? There is no single place to look.

### 2. Orchestration (Command-Based)

In an orchestrated saga, a central **orchestrator** (which is itself a service) is responsible for telling the other services what to do. It manages the entire sequence.

-   **How it works**:
    1.  A client request tells the `OrderOrchestrator` to start the "Place Order" saga.
    2.  The orchestrator sends a `ChargePayment` command to the `Payment Service`.
    3.  When the `Payment Service` is done, it replies to the orchestrator.
    4.  If the reply is "success," the orchestrator then sends a `ReserveInventory` command to the `Inventory Service`.
    -   **Handling Failures**: If any service replies with "failure," the orchestrator is responsible for sending the appropriate `RefundPayment` and `CancelOrder` commands to execute the compensating transactions.

-   **Pros**: Centralized logic. It's much easier to understand and debug the business process because it's all defined in one place.
-   **Cons**: Introduces a central point of control, which can lead to some coupling. The orchestrator can become a "smart" service that knows too much about the other services.

---

## 5. Challenges of Sagas

-   **Complexity**: Implementing sagas, especially the compensating transactions, is complex. You have to consider all possible failure modes.
-   **Eventual Consistency**: Sagas are **eventually consistent**. There is a period of time during which the overall system state is inconsistent (e.g., the order has been created, but the payment hasn't been processed yet). Your system and your users must be able to tolerate this temporary inconsistency.
-   **Isolation**: Sagas lack the "I" (Isolation) of ACID transactions. The changes made by one local transaction are visible to other requests before the entire saga is complete. This can lead to anomalies if not handled carefully.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that traditional **ACID transactions** don't work across multiple microservices.
-   [ ] I can define a **Saga** as a sequence of local transactions used to manage a distributed transaction.
-   [ ] I can explain that a **compensating transaction** is a reverse operation used to undo a step in a failed saga.
-   [ ] I can contrast **Choreography** (decentralized, event-driven) with **Orchestration** (centralized, command-driven) for implementing sagas.
-   [ ] I understand that the biggest challenge and trade-off of the Saga pattern is its **eventual consistency** model.

---

## 13. Research and References

-   **"Microservices Patterns" by Chris Richardson**: This is the definitive guide to the Saga pattern.
-   **Microsoft Azure - "Saga pattern"**: A clear explanation of the pattern with diagrams. [Link](https://learn.microsoft.com/en-us/azure/architecture/reference-architectures/saga/saga)
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Discusses the challenges of distributed transactions in depth.
