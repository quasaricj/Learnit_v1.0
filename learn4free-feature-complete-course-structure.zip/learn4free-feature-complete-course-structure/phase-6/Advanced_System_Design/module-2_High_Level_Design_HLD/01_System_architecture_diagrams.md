# High-Level Design: System Architecture Diagrams

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** the purpose of a system architecture diagram.
- **Identify** the key components to include in a high-level diagram.
- **Use** a simple "box and arrow" notation to create a diagram.
- **Describe** how data flows between the components in your diagram.
- **Understand** that a diagram is a tool for communication and clarification.
- **Recognize** the C4 model as a more formal approach to diagramming.

---

## 2. Introduction: The Power of a Picture

A **system architecture diagram** is a visual representation of a software system. It is the most important and fundamental artifact in High-Level Design. Its purpose is to communicate the overall structure, components, and interactions of the system to a technical audience.

A good diagram is worth a thousand words. It serves as the primary tool for clarifying your own thinking, communicating your design to an interviewer or your team, and providing a focal point for discussion and feedback.

In a system design interview, you will almost always be expected to draw a diagram on a whiteboard.

---

## 3. What to Include in a High-Level Diagram

Your HLD diagram should be a "bird's-eye view" of the system. It should show the major components and how they are connected. Do not get bogged down in low-level details.

**Key Components to Include**:
- **Clients**: The users of your system (e.g., Web Browser, Mobile App).
- **Load Balancers**: The entry point for traffic.
- **Web Servers / API Gateway**: The layer that handles incoming requests.
- **Application Servers / Microservices**: The core logic of your system.
- **Databases**: Where your data is stored (specify the type, e.g., "PostgreSQL DB" or "NoSQL DB").
- **Caches**: In-memory data stores (e.g., "Redis Cache").
- **Message Queues / Event Brokers**: For asynchronous communication.
- **Object Storage**: For storing files, images, or videos (e.g., "AWS S3").
- **Content Delivery Network (CDN)**: For serving static assets.
- **Third-Party Services**: Any external services your system depends on (e.g., a payment provider like Stripe).

---

## 4. How to Draw the Diagram

### 1. Start with the User

- Begin at the edge of your system. Place the user (the client) on the left.

### 2. Follow a Request

- Trace the path of a typical user request as it flows through your system.
- **Example Flow (for a simple web app)**:
  `Client -> CDN -> Load Balancer -> Web Servers -> Database / Cache`

### 3. Use Simple "Box and Arrow" Notation

- **Boxes**: Represent the components (servers, databases, etc.). Keep the labels simple and clear.
- **Arrows**: Represent the flow of data or requests between the components. Label the arrows to indicate the protocol or the type of data being sent.

### 4. Group Components Logically

- You can draw a larger box around a group of components to indicate a logical boundary, like your Virtual Private Cloud (VPC) or a geographic region.

### 5. Iterate and Refine

- Your first diagram will not be perfect. The diagram is a tool for thinking. As you talk through the design and identify new requirements or potential problems, you will add, remove, and rearrange the components. This is a normal and expected part of the process.

**Example Diagram (Simple Photo-Sharing App)**
```
+----------+     +--------+     +---------------+     +----------------+
|          | --> |        | --> |               | --> |                |
|  User    |     |  CDN   |     | Load Balancer |     | API Gateway    |
| (Client) |     |        |     |               |     | (Web Servers)  |
|          | <-- |        | <-- |               | <-- |                |
+----------+     +--------+     +---------------+     +----------------+
                                                         |
                                                         | (REST API Calls)
                                                         v
                                                +----------------+
                                                |                |
                                                |  Photo Service |
                                                |                |
                                                +----------------+
                                                  /         \
                                                 /           \
                                                /             \
                               +----------------+             +-----------------+
                               |                |             |                 |
                               |  PostgreSQL DB |             |  AWS S3         |
                               |  (Metadata)    |             |  (Photo Files)  |
                               +----------------+             +-----------------+
```

---

## 5. A More Formal Approach: The C4 Model

For more formal, real-world documentation, a simple box-and-arrow diagram might not be enough. The **C4 model** is a popular and very effective technique for visualizing software architecture at different levels of detail.

The "C4" stands for the four levels of diagrams it uses:
1.  **C1: System Context**: A high-level overview showing your system as a single box and its relationships with users and other systems.
2.  **C2: Containers**: Zooms into your system, showing the major deployable units (e.g., your API, your database, your frontend app). This is the level that most HLD diagrams in an interview are drawn at.
3.  **C3: Components**: Zooms into a single container, showing the major internal components or modules.
4.  **C4: Code**: (Optional) Zooms into a component, showing the classes and functions.

The C4 model provides a structured way to create a set of maps for your codebase, at different zoom levels.

---

## 6. Summary and Mastery Checklist

-   [ ] I know that a system architecture diagram is a visual map of the system's components and their interactions.
-   [ ] I understand that the diagram is a tool for communication and should be the focal point of a design discussion.
-   [ ] I can list the key components to include in an HLD diagram (e.g., load balancer, servers, database, cache).
-   [ ] I can use a simple "box and arrow" method to draw a diagram, starting from the user and following the path of a request.
-   [ ] I have heard of the **C4 model** as a more formal, multi-level approach to architectural diagramming.

---

## 7. Research and References

-   **"System Design Interview – An insider's guide" by Alex Xu**: This book is filled with excellent examples of HLD diagrams.
-   **The C4 model official website**: A great resource for learning this technique. [Link](https://c4model.com/)
-   **"Visualizing software architecture with the C4 model" by Simon Brown**: A talk from the creator of the C4 model.
-   **Diagramming Tools**:
    -   **Excalidraw**: A free, simple, and very popular tool for creating informal, hand-drawn-style diagrams.
    -   **draw.io (now diagrams.net)**: A free and very powerful diagramming tool.
    -   **Lucidchart**: A popular commercial diagramming tool.
