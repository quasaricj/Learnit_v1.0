# High-Level Design: Component Interaction and Data Flow

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Go beyond** a static component diagram to describe the dynamic behavior of a system.
- **Trace** the flow of a specific user request through your high-level design.
- **Define** the API contracts between your system's components at a high level.
- **Differentiate** between the "read path" and the "write path" in a system.
- **Explain** how synchronous and asynchronous communication patterns affect the data flow.
- **Use** a sequence diagram as a tool to model component interactions over time.

---

## 2. Introduction: Bringing the Architecture to Life

A system architecture diagram shows the static components of your system. The next crucial step in High-Level Design is to describe how these components **interact** to fulfill a user's request. You need to bring the diagram to life by explaining the **data flow**.

In a system design interview, after you have drawn your initial HLD diagram, the interviewer will almost always ask you to walk them through a specific workflow. For example: "Okay, now can you explain what happens, step-by-step, when a user uploads a photo?"

---

## 3. Tracing the Data Flow

To explain the data flow, you should pick a core use case and trace the path of the request and the data from the client all the way through your system and back.

### Example: The "Write Path" for a Photo Upload

Let's use the photo-sharing app example. The user wants to upload a new photo.

1.  **Client -> Load Balancer**: The client (a mobile app) sends a `POST /photos` request, containing the image data and some metadata (like a caption), to your API endpoint. The request first hits the main Load Balancer.

2.  **Load Balancer -> API Gateway**: The Load Balancer forwards the request to one of the available API Gateway instances.

3.  **API Gateway -> Authentication Service**: The API Gateway first calls the `Authentication Service` to validate the user's token and ensure they have permission to upload photos.

4.  **API Gateway -> Photo Service**:
    - The API Gateway then forwards the request to the `Photo Service`.
    - At this point, the `Photo Service` might perform two operations, often in parallel:
      a. **Upload to Object Storage**: It streams the large photo file directly to a cloud object store like **AWS S3**. S3 will return a unique URL for the stored photo.
      b. **Write Metadata to Database**: It writes the photo's metadata (the S3 URL, the user ID, the caption, etc.) to the `photos` table in the database.

5.  **Asynchronous Processing (Optional)**:
    - After the metadata is saved, the `Photo Service` might publish an event like `PhotoUploaded` to a **message queue** (e.g., RabbitMQ or AWS SQS).
    - Other services can then subscribe to this event to perform asynchronous, "post-upload" processing, such as:
      - A `Thumbnail Service` to generate different sizes of the image.
      - A `Notification Service` to create a new story in the feeds of the user's followers.

6.  **Response Path**:
    - Once the metadata has been successfully saved to the database, the `Photo Service` returns a `201 Created` response to the API Gateway.
    - The API Gateway returns this success response to the client. The client can now show a "Upload successful" message.

### Defining API Contracts

As you trace the data flow, you should also be defining the high-level **API contracts** between your services. You don't need to specify every field, but you should describe the intent.
- "The client sends a `POST /photos` request..."
- "The `Photo Service` exposes a `POST /photos` endpoint..."
- "The `Notification Service` consumes a `PhotoUploaded` event from the queue..."

---

## 4. Differentiating Read and Write Paths

It is often very useful to analyze the read and write paths of your system separately, as they often have very different performance and scalability requirements.

- **Write Path**: (As described above for the photo upload). This path is often optimized for durability and consistency.
- **Read Path**: (e.g., a user fetching their photo feed).
  - This path is often much higher traffic than the write path (people look at photos more often than they upload them).
  - It needs to be highly optimized for low latency.
  - This is where you would introduce **caching** layers to avoid hitting the database on every request.
  - The data flow might look like: `Client -> ... -> API Gateway -> Feed Service`. The `Feed Service` would first check a **Redis cache**. If the feed is in the cache (a cache hit), it's returned immediately. If not (a cache miss), the service would then query the database, assemble the feed, store it in the cache for next time, and then return it.

---

## 5. Sequence Diagrams

A **sequence diagram** is a type of UML diagram that is excellent for visualizing the interactions between components over time. It shows the sequence of messages or calls that are exchanged to complete a specific scenario. While you might not need to draw a formal sequence diagram in an interview, thinking in this way is very helpful.

---

## 6. Summary and Mastery Checklist

-   [ ] I understand that after designing the static components, I need to explain the dynamic **data flow**.
-   [ ] I can trace the path of a user request through a system, from the client to the database and back.
-   [ ] I can define the high-level API contracts and communication patterns (synchronous vs. asynchronous) between my components.
-   [ ] I can analyze the **read path** and the **write path** of my system separately.
-   [ ] I understand that the read path is often where I need to introduce **caching** to improve performance.
-   [ ] I have heard of a **sequence diagram** as a tool for modeling these interactions.

---

## 7. Research and References

-   **"System Design Interview – An insider's guide" by Alex Xu**: The book's examples all include a detailed walkthrough of the data flow for key use cases.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**
-   **UML Sequence Diagrams**: There are many online tutorials for this diagramming technique.
-   **"What Happens When You Type google.com into Your Browser?"**: A famous and incredibly detailed explanation of a data flow, from the keyboard to the data center.
