# High-Level Design: Technology Stack Selection

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a technology stack.
- **Identify** the key layers of a typical tech stack (frontend, backend, database, infrastructure).
- **Understand** that technology choices should be driven by requirements, not by personal preference.
- **Analyze** the trade-offs between different technology choices for a given component.
- **Justify** your technology choices in a system design discussion.
- **Recognize** common and popular technology stacks (e.g., MERN, LAMP).

---

## 2. Introduction: Choosing the Right Tools for the Job

Once you have a high-level architecture in mind, you need to decide on the specific technologies you will use to build it. A **technology stack** is the set of tools, programming languages, frameworks, and services that are used to build and run an application.

The choice of technology stack is a critical part of the High-Level Design process. However, you should **never** start your design by choosing the technologies. You should first understand the problem, define the requirements, and sketch out the architecture. The technology choices should then be made to **support the architecture and the requirements**.

---

## 3. The Layers of a Tech Stack

A typical web application stack is composed of several layers:

1.  **Client-Side (Frontend)**:
    - What the user interacts with in their browser.
    - **Technologies**: HTML, CSS, JavaScript.
    - **Frameworks**: React, Vue, Angular.

2.  **Server-Side (Backend)**:
    - The application logic that runs on your servers.
    - **Languages**: Node.js (JavaScript/TypeScript), Python, Java, Go, C#, Ruby.
    - **Frameworks**: Express (Node.js), Django/Flask (Python), Spring Boot (Java), Gin (Go).

3.  **Data Layer (Database)**:
    - Where the application's data is stored.
    - **Relational (SQL)**: PostgreSQL, MySQL.
    - **NoSQL**:
      - **Document**: MongoDB.
      - **Key-Value**: Redis, DynamoDB.
      - **Search Index**: Elasticsearch.

4.  **Infrastructure Layer**:
    - The services that your application runs on.
    - **Cloud Provider**: AWS, Azure, GCP.
    - **Containerization**: Docker.
    - **Orchestration**: Kubernetes.
    - **CI/CD**: GitHub Actions, Jenkins.

---

## 4. Making and Justifying Your Choices

In a system design discussion, you will be expected to make technology choices and, more importantly, to **justify** them based on the requirements of the system and the trade-offs involved.

There is rarely a single "right" answer. The goal is to demonstrate that you can think critically about the options and make a reasoned decision.

### Example: Choosing a Database for a Social Media Feed

- **Requirement**: The feed needs to be able to handle a very high read load (many users fetching their feeds) and scale horizontally. The data (posts) is semi-structured. Strong consistency is not a strict requirement; eventual consistency is acceptable.
- **Analysis**:
  - A traditional **relational database (SQL)** would struggle with the horizontal scaling requirements for a massive read load. `JOIN`ing many tables to assemble a feed would be slow at scale.
  - A **NoSQL document database (MongoDB)** would be a good fit for storing the posts themselves, but it's not specifically designed for time-series data like a feed.
  - A **wide-column NoSQL database (like Cassandra or DynamoDB)** is an excellent choice. These databases are specifically designed for massive-scale, high-read-throughput workloads. They are used by Facebook, Twitter, and Netflix for this exact use case.
- **Justification**: "For the feed service, I would choose a wide-column NoSQL database like Cassandra. This is because the primary requirement is to handle a massive number of reads at low latency. Cassandra is designed for horizontal scalability and high availability, and its data model is well-suited for time-series data like a feed. We are accepting a trade-off here: we lose the strong consistency and rich query capabilities of a SQL database, but we gain the massive scalability and performance that our feed requires."

### Other Factors to Consider

- **Team Expertise**: Does your team already have deep expertise in a particular technology? It's often better to choose a technology that your team knows well than to choose a "perfect" but unfamiliar one.
- **Maturity and Ecosystem**: Is the technology mature and well-supported? Does it have a large community and good libraries?
- **Operational Cost**: How easy is it to operate and maintain this technology? A fully managed service from a cloud provider (like AWS DynamoDB) has a much lower operational cost than running your own open-source database cluster.

---

## 5. Common Stacks

- **LAMP Stack**: One of the original web stacks. **L**inux (OS), **A**pache (Web Server), **M**ySQL (Database), **P**HP (Language).
- **MERN Stack**: A popular modern stack for web applications. **M**ongoDB (Database), **E**xpress (Backend Framework), **R**eact (Frontend Framework), **N**ode.js (Backend Runtime).

---

## 6. Summary and Mastery Checklist

-   [ ] I can define a tech stack as the collection of technologies used to build an application.
-   [ ] I know that I should choose my technology based on the **requirements** of the system.
-   [ ] I can list the main layers of a stack (frontend, backend, database, infrastructure).
-   [ ] For a given problem, I can suggest a technology for a component (e.g., "I would use Redis for the cache").
-   [ ] Most importantly, I can **justify** my choice by explaining the trade-offs involved (e.g., "I chose a NoSQL database to prioritize scalability over strong consistency").

---

## 7. Research and References

-   **StackShare**: A website where companies share the technology stacks they use. It's a great way to see what real-world companies are using. [Link](https://stackshare.io/)
-   **"System Design Interview – An insider's guide" by Alex Xu**
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**
-   **ThoughtWorks Technology Radar**: A regular publication from the consultancy ThoughtWorks that gives an opinionated guide to the latest trends in software development technologies.
