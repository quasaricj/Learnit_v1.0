# High-Level Design: Security Architecture Design

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Integrate** security into your high-level design process.
- **Define** the "CIA Triad" (Confidentiality, Integrity, Availability) as a model for security.
- **Explain** the principle of "Defense in Depth."
- **Identify** key security components and considerations in a system architecture diagram.
- **Describe** common security threats at different layers of the application.
- **Understand** that security is a cross-cutting concern that must be considered at every stage of the design.

---

## 2. Introduction: "Shifting Security Left"

Security is not a feature that you can "add on" at the end of the development process. It must be a fundamental consideration from the very beginning of the system design process. This is known as **"shifting security left"**.

When you are creating a high-level design, you should be constantly asking: "How could this be attacked?" and "How can we mitigate that threat?". **Threat modeling** is the formal process of identifying potential security threats and vulnerabilities in a system.

---

## 3. The Goals of Security: The CIA Triad

The CIA Triad is a foundational model that helps to frame your thinking about security.

1.  **Confidentiality**:
    - **Goal**: Preventing the unauthorized disclosure of information. Data should only be accessible to authorized users.
    - **Mechanisms**: Encryption (both in transit and at rest), access control.

2.  **Integrity**:
    - **Goal**: Ensuring that data is trustworthy and has not been tampered with or modified by an unauthorized party.
    - **Mechanisms**: Hashing, digital signatures, input validation.

3.  **Availability**:
    - **Goal**: Ensuring that the system is available for use by authorized users when they need it.
    - **Mechanisms**: Redundancy, load balancing, protection against Denial of Service (DoS) attacks.

---

## 4. The Principle of Defense in Depth

**Defense in Depth** is the strategy of having multiple, independent layers of security controls. The idea is that if one layer of defense fails, there are other layers behind it that will still protect your system. You should not rely on a single security measure.

**Analogy**: A medieval castle. It has a moat, a drawbridge, high walls, and armed guards. An attacker has to overcome all these layers of defense to reach the king.

---

## 5. Security in a High-Level Design

When you are drawing your architecture diagram, you should be thinking about the security of each component and the communication between them.

**Key Components and Considerations**:

- **Edge Security (The "Moat")**:
  - **CDN / WAF**: Use a Content Delivery Network (CDN) and a Web Application Firewall (WAF) at the edge of your network. These services can filter out a huge amount of malicious traffic, including DDoS attacks and common exploits, before they ever reach your servers.
  - **DDoS Protection**: Your cloud provider or CDN will offer specific DDoS mitigation services.

- **Network Security (The "Walls")**:
  - **VPC and Subnets**: Your application should run inside a Virtual Private Cloud (VPC). You should use **private subnets** for your backend services and databases, meaning they do not have a direct route to or from the public internet.
  - **Security Groups / Firewalls**: Use firewall rules to strictly control what traffic is allowed between your services. By default, you should **deny all** traffic and then explicitly allow only the specific ports and protocols that are needed.

- **Application Security**:
  - **Authentication and Authorization**: Where does user authentication happen? (Usually at the API Gateway). How are permissions managed?
  - **Input Validation**: Every service must validate all its inputs to prevent vulnerabilities like SQL Injection and Cross-Site Scripting (XSS).
  - **Rate Limiting**: The API Gateway should enforce rate limiting.

- **Data Security (The "Treasure Chest")**:
  - **Encryption in Transit**: All communication, both between the client and your servers and between your internal services, must be encrypted using **TLS (HTTPS)**.
  - **Encryption at Rest**: All sensitive data stored in your database or in an object store (like S3) should be encrypted.
  - **Secrets Management**: How are you storing and managing your application's secrets (database passwords, API keys)? You must use a dedicated secrets management tool like **AWS Secrets Manager** or **HashiCorp Vault**. Do not store secrets in configuration files or environment variables in plain text.

---

## 6. The Human Element

Security is not just a technical problem.
- **Principle of Least Privilege**: A user (or a service) should only be granted the minimum level of access and permissions that they need to perform their job.
- **Auditing and Logging**: You must have a detailed audit trail of who accessed what data and when.

---

## 7. Summary and Mastery Checklist

-   [ ] I understand that security must be considered from the very beginning of the design process ("shift left").
-   [ ] I can name the three components of the **CIA Triad** (Confidentiality, Integrity, Availability).
-   [ ] I can explain **Defense in Depth** as the strategy of having multiple layers of security.
-   [ ] I know that my backend services and databases should be in **private subnets**.
-   [ ] I know that all data must be encrypted **in transit (with TLS)** and **at rest**.
-   [ ] I understand that secrets like database passwords must be stored in a dedicated **secrets management** tool.

---

## 8. Research and References

-   **OWASP Top 10**: The definitive list of the most critical web application security risks. You must be familiar with this. [Link](https://owasp.org/www-project-top-ten/)
-   **AWS Well-Architected Framework - Security Pillar**: A comprehensive guide from AWS. [Link](https://aws.amazon.com/architecture/well-architected/)
-   **"The Tangled Web: A Guide to Securing Modern Web Applications" by Michal Zalewski**: A classic and highly respected book on web security.
-   **"Threat Modeling: Designing for Security" by Adam Shostack**: The definitive guide to the process of threat modeling.
