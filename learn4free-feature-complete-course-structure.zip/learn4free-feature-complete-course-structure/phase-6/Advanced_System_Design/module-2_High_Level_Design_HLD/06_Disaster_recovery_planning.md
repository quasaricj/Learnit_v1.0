# High-Level Design: Disaster Recovery Planning

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Disaster Recovery (DR) and differentiate it from High Availability (HA).
- **Explain** the purpose of a DR plan.
- **Define** the key DR metrics: RTO (Recovery Time Objective) and RPO (Recovery Point Objective).
- **Describe** common DR strategies, from simple backups to multi-region active-active.
- **Understand** that the choice of DR strategy is a business decision based on a cost-benefit analysis.
- **Incorporate** DR considerations into a high-level system design.

---

## 2. Introduction: "Plan for Failure"

**High Availability (HA)** is about designing your system to be resilient to small, common failures. It's about surviving the failure of a single server or a single component. It aims to keep the application running within a single data center or geographic region.

**Disaster Recovery (DR)** is about planning for large-scale, catastrophic failures. It's about surviving the failure of an **entire data center or an entire geographic region**. A "disaster" could be a natural event like an earthquake or a hurricane, or a technical event like a massive power outage or a major network failure.

Every large-scale system must have a DR plan. The goal of the plan is to be able to recover your application and your data in a different, unaffected location.

---

## 3. Key Disaster Recovery Metrics

Your DR strategy is defined by two key metrics, which are determined by the business.

### RTO: Recovery Time Objective

- **Question**: **"How long can we afford to be down?"**
- **Definition**: The maximum acceptable amount of time that your application can be offline after a disaster.
- **Example**: An RTO of 1 hour means that the business requires the system to be fully operational again within 1 hour of the disaster.

### RPO: Recovery Point Objective

- **Question**: **"How much data can we afford to lose?"**
- **Definition**: The maximum acceptable amount of time's worth of data loss.
- **Example**: An RPO of 5 minutes means that the business can tolerate losing, at most, the last 5 minutes of data that was written before the disaster.

**RTO and RPO are the primary drivers of your DR strategy.** A lower RTO and RPO (e.g., near-zero) will be exponentially more complex and expensive to achieve than a higher RTO and RPO (e.g., 24 hours).

---

## 4. Common Disaster Recovery Strategies

These strategies are a spectrum, from low cost and high RTO/RPO to high cost and low RTO/RPO.

### 1. Backup and Restore

- **Strategy**: You periodically take backups of your database and your application data (e.g., once a day) and store them in a different geographic region. In the event of a disaster, you would have to manually provision a completely new set of infrastructure in a new region and then restore your data from the latest backup.
- **RTO**: High (hours to days).
- **RPO**: High (e.g., 24 hours).
- **Cost**: Very low.
- **Use Case**: Non-critical applications, development and test environments.

### 2. Pilot Light

- **Strategy**: A minimal version of your infrastructure is kept running in the "DR region". The core services (like the database) are running, but are small and scaled down. The application servers are not running. In the event of a disaster, you would "turn on" and scale up the application servers to a full, production-ready size.
- **RTO**: Medium (tens of minutes to hours).
- **RPO**: Can be low (minutes), if your database is being actively replicated.
- **Cost**: Low to medium.

### 3. Warm Standby

- **Strategy**: A scaled-down but fully functional version of your entire application is kept running in the DR region. It is ready to take over, but it is running on a smaller, cheaper fleet of servers. In the event of a disaster, you would perform a "failover" (by changing the DNS to point to the DR region) and then scale up the DR environment to handle the full production load.
- **RTO**: Low (minutes).
- **RPO**: Very low (seconds to minutes).
- **Cost**: Medium to high.

### 4. Multi-Region Active-Active (or Hot Standby)

- **Strategy**: Your application is deployed in its full, production-ready capacity in **two or more** geographic regions simultaneously. A global load balancer distributes traffic between the regions. If one region fails, the traffic is automatically routed to the other healthy regions.
- **RTO**: Near-zero. Failover is automatic and nearly instantaneous.
- **RPO**: Near-zero. This requires synchronous or near-synchronous data replication between the regions, which is extremely complex and expensive.
- **Cost**: Very high.
- **Use Case**: Only for the most mission-critical, global applications where any amount of downtime is unacceptable.

---

## 5. DR in a System Design Discussion

- **Ask the Interviewer**: When you are clarifying the non-functional requirements, you should always ask: "What are the RTO and RPO requirements for this system?". The answer will dictate your design.
- **Incorporate DR into your HLD**: Your architecture diagram should show that you are thinking about DR. At a minimum, you should show that you are taking backups and storing them in a different region. For a more critical system, you might draw a simplified version of a warm standby or active-active setup.
- **Use Managed Services**: A key benefit of the cloud is that it makes DR much easier. Cloud providers give you the tools to easily replicate your data across regions and to automate the provisioning of your infrastructure.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that **High Availability** is about surviving small, local failures, while **Disaster Recovery** is about surviving a large-scale, regional outage.
-   [ ] I can define **RTO** as "how long can we be down?" and **RPO** as "how much data can we lose?".
-   [ ] I know that a lower RTO/RPO is much more expensive to achieve.
-   [ ] I can describe the **Backup and Restore** strategy as the simplest and cheapest DR option.
-   [ ] I can describe the **Multi-Region Active-Active** strategy as the most complex and expensive, but also the most resilient, DR option.
-   [ ] I understand that the choice of DR strategy is a **business decision** based on a cost-benefit analysis.

---

## 7. Research and References

-   **AWS - "Disaster Recovery of Workloads on AWS"**: A whitepaper that details these strategies in the context of AWS.
-   **Azure - "Disaster recovery"**: The Azure documentation on the topic.
-   **"Release It!" by Michael T. Nygard**: A book on building resilient and stable systems.
-   **"The RTO/RPO Continuum"**: A common topic for blog posts from cloud providers and DR companies.
