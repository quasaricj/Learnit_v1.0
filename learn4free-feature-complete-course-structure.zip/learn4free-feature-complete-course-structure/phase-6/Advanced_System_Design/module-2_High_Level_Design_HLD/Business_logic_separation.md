# High-Level Design: Separating Business Logic

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** "business logic" and "infrastructure code" and provide clear examples of each.
-   **Explain** the importance of separating business logic from other application concerns.
-   **Describe** the classic Layered (N-Tier) Architecture and the role of each layer.
-   **Describe** the core concepts of Hexagonal Architecture (Ports and Adapters).
-   **Analyze** how these patterns lead to more testable, maintainable, and portable applications.
-   **Recognize** that the "business core" of the application should have no dependencies on external frameworks or technologies.

---

## 2. The Core Problem: Tangled Logic

In a poorly structured application, all the different types of code are mixed together. A single function might:
1.  Receive an HTTP request.
2.  Parse the request body.
3.  Perform a business rule calculation (e.g., "is this user eligible for a discount?").
4.  Write the result to a PostgreSQL database.
5.  Format a JSON response.

This function is brittle, hard to test, and hard to maintain. What if you want to change from PostgreSQL to MongoDB? What if you want to expose this logic via a command-line tool instead of an HTTP API? You would have to rewrite the entire function.

The goal of a good high-level design is to **separate the core business logic from the delivery mechanisms and infrastructure details**.

---

## 3. Layered (N-Tier) Architecture

This is the most common and traditional approach to achieving separation. The application is divided into a series of horizontal layers, each with a specific responsibility. A key rule is that a layer can only depend on the layer directly below it.

![Layered Architecture](https://www.oreilly.com/library/view/software-architecture-patterns/9781491971437/assets/sapr_0102.png)

A typical web application might have four layers:

1.  **Presentation Layer (UI)**:
    -   **Responsibility**: The user interface. Renders HTML, handles HTTP requests and responses.
    -   **Code**: Controllers, Views.

2.  **Application Layer (or Service Layer)**:
    -   **Responsibility**: Orchestrates the business logic. It doesn't contain the core rules itself, but it directs the flow of work.
    -   **Code**: Application Services that are called by the Presentation Layer.

3.  **Domain Layer (or Business Logic Layer)**:
    -   **Responsibility**: This is the **heart of the application**. It contains the core business rules, entities, and logic that are unique to the problem you are solving. This layer has no knowledge of databases, networks, or UIs.
    -   **Code**: Domain Models, Entities, Value Objects.

4.  **Infrastructure Layer (or Persistence/Data Access Layer)**:
    -   **Responsibility**: Handles all communication with the outside world: databases, file systems, message brokers, third-party APIs.
    -   **Code**: Repositories, database access objects (DAOs).

This structure enforces a clean separation and makes the application easier to understand and maintain.

---

## 4. Hexagonal Architecture (Ports and Adapters)

This is a more modern and powerful architectural pattern that takes the separation of concerns even further. It is a core principle of Domain-Driven Design (DDD).

-   **Analogy**: Imagine your application is a nuclear reactor. The core (the business logic) is the most important and sensitive part. You want to protect it from the outside world. You build a thick concrete shell around it with a few, well-defined control ports. You can then plug different "adapters" into these ports to control the reactor—a web UI adapter, a testing adapter, a database adapter.

![Hexagonal Architecture](https://miro.medium.com/max/1400/1*c6z8-m7-2-2x-3p-1k-2g.png)

### Core Concepts:

-   **The Hexagon (The Inside)**: This is the core of your application, containing the pure business logic (the Domain Layer). Critically, this core has **zero dependencies** on anything in the outside world. It doesn't know what a database is. It doesn't know what HTTP is.

-   **Ports (The Inside Boundary)**: A Port is an interface defined by the application core. It specifies *what* the application needs from the outside world, without knowing *how* it will be provided.
    -   Example: The core might define a `UserRepository` port (an interface) with methods like `save(user)` and `findById(id)`. This is the core saying, "I need some way to store and retrieve users."

-   **Adapters (The Outside)**: An Adapter is the concrete implementation of a port. It's the "glue" code that connects the pure business core to the messy outside world.
    -   `PostgresUserRepository` would be an **Adapter** that implements the `UserRepository` port using PostgreSQL.
    -   `InMemoryUserRepository` would be another **Adapter** that implements the same port using a simple in-memory list for testing.
    -   `UserController` would be an **Adapter** that takes an incoming HTTP request and calls the application core.

The key rule is the **Dependency Inversion Principle**: The adapters depend on the ports defined by the core, not the other way around. This keeps the core pure and independent of any specific technology.

---

## 5. Benefits of Strong Separation

-   **Testability**: Because your business logic has no external dependencies, you can test it with simple, fast unit tests. You can provide "mock" adapters for your tests.
-   **Maintainability**: The code is easier to understand and reason about. Business logic is in one place, infrastructure in another.
-   **Portability / Technology Independence**: If you want to change your database from PostgreSQL to MongoDB, you only have to write a new adapter. The core business logic remains completely unchanged. If you want to add a GraphQL API alongside your REST API, you just add a new adapter.

---

## 12. Summary and Mastery Checklist

-   [ ] I can distinguish between **business logic** (the core rules of the application) and **infrastructure code** (the plumbing that connects it to the world).
-   [ ] I can describe a **Layered Architecture** where dependencies flow in one direction, from the UI down to the database.
-   [ ] I can describe the **Hexagonal Architecture**, where a pure application core defines **Ports** (interfaces) that are implemented by external **Adapters**.
-   [ ] I understand that the key principle is that the business logic should have **zero dependencies** on external frameworks or technologies.
-   [ ] I can explain that this separation leads to a system that is easier to test, maintain, and evolve.

---

## 13. Research and References

-   **Alistair Cockburn - "Hexagonal Architecture"**: The original article on the pattern. [Link](https://alistair.cockburn.us/hexagonal-architecture/)
-   **"Domain-Driven Design" by Eric Evans**: The book that provides the philosophical foundation for these architectural patterns.
-   **"Clean Architecture" by Robert C. Martin**: A book that describes a very similar architectural philosophy with a different name (The Clean Architecture).
