# Low-Level Design: Class Diagrams and UML Modeling

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Low-Level Design (LLD) and its purpose.
- **Explain** what UML (Unified Modeling Language) is.
- **Read and understand** a simple UML Class Diagram.
- **Identify** the key components of a class diagram: class name, attributes, and methods.
- **Describe** how to represent relationships between classes (association, aggregation, composition, inheritance).
- **Create** a simple class diagram for a given problem.
- **Understand** that LLD is about the detailed, internal design of a single component.

---

## 2. Introduction: Zooming in on a Single Component

**Low-Level Design (LLD)** is the process of designing the detailed, internal structure of an individual component or service that was identified during High-Level Design. While HLD is about the overall architecture, LLD is about the implementation details. It is the final step before you start writing code.

LLD is about answering the question: "How will we actually build this specific module?". A key tool for creating and communicating a low-level design is the **UML Class Diagram**.

**UML (Unified Modeling Language)** is a standardized modeling language that provides a set of graphical notations for visualizing, specifying, constructing, and documenting the artifacts of a software system.

---

## 3. The UML Class Diagram

A **class diagram** is a static, structural diagram that describes the structure of a system by showing the system's classes, their attributes, methods, and the relationships among the classes.

### The Class Box

A single class is represented by a rectangle with three compartments:
1.  **Top**: The **class name**.
2.  **Middle**: The **attributes** (or fields) of the class.
3.  **Bottom**: The **methods** (or operations) of the class.

**Syntax**:
- **Attributes**: `visibility name: type`
- **Methods**: `visibility name(parameters): returnType`
- **Visibility**:
  - `+`: `public`
  - `-`: `private`
  - `#`: `protected`

**Example**:
```
+---------------------------+
|        BankAccount        |
+---------------------------+
| - owner: String           |
| - balance: double         |
+---------------------------+
| + deposit(amount: double) |
| + withdraw(amount: double)|
| + getBalance(): double    |
+---------------------------+
```

---

## 4. Relationships Between Classes

Class diagrams are powerful because they show the relationships between classes.

### 1. Association

- **What it is**: A general "uses-a" relationship. It indicates that two classes are aware of each other and can interact.
- **Notation**: A solid line between the classes.
- **Example**: A `Customer` class and a `Product` class. A customer can buy a product.

### 2. Aggregation

- **What it is**: A specialized form of association that represents a "has-a" relationship. It describes a whole-part relationship where the "part" can exist independently of the "whole".
- **Notation**: A solid line with an unfilled diamond on the "whole" side.
- **Example**: A `Department` "has-a" set of `Professor`s. If the department is closed, the professors still exist and can move to another department.

### 3. Composition

- **What it is**: A stronger form of aggregation. It represents a "has-a" relationship where the "part" **cannot** exist independently of the "whole". If the "whole" is destroyed, the "part" is also destroyed.
- **Notation**: A solid line with a filled diamond on the "whole" side.
- **Example**: A `House` is composed of `Room`s. If you demolish the house, the rooms are also destroyed.

### 4. Inheritance (or Generalization)

- **What it is**: An "is-a" relationship. One class (the subclass) inherits from another class (the superclass).
- **Notation**: A solid line with an unfilled, triangular arrowhead pointing to the **superclass**.
- **Example**: A `Car` and a `Truck` are both types of `Vehicle`.

---

## 5. LLD in Practice

LLD is not about creating a perfect, detailed diagram for every class in your system. That would be a waste of time. LLD is a tool for **thinking and communication**.

**When to use it**:
- When you are designing a particularly complex or critical part of a service.
- To help clarify the responsibilities and collaborations of a set of related classes before you start coding.
- In a "Low-Level Design" or "Object-Oriented Design" interview, where you are asked to design a specific component (e.g., "Design a parking lot system").

**The Process**:
1.  **Identify the Core Classes**: What are the main nouns or entities in your system?
2.  **Define Attributes and Methods**: What data does each class need to hold, and what actions can it perform?
3.  **Establish Relationships**: How do the classes relate to each other? (is-a, has-a).
4.  **Iterate and Refine**: The diagram is a tool. Draw it on a whiteboard and discuss it with your team.

---

## 6. Summary and Mastery Checklist

-   [ ] I know that **Low-Level Design (LLD)** is about the detailed, internal design of a single component.
-   [ ] I can explain that **UML** is a standardized graphical language for modeling software.
-   [ ] I can read a simple **UML Class Diagram** and identify the class name, attributes, and methods.
-   [ ] I can recognize the notation for the four main relationships: **association**, **aggregation**, **composition**, and **inheritance**.
-   [ ] I understand that an **inheritance** ("is-a") relationship is different from a **composition** ("has-a") relationship.
-   [ ] I know that LLD and class diagrams are tools for thinking and communication, not rigid blueprints.

---

## 7. Research and References

-   **"UML Distilled" by Martin Fowler**: The classic, concise guide to UML.
-   **"Design Patterns: Elements of Reusable Object-Oriented Software" by the "Gang of Four"**: This book uses UML class diagrams extensively to describe its patterns.
-   **"Head First Design Patterns"**: A more accessible book that also uses a simplified version of UML.
-   **PlantUML**: A tool that allows you to write UML diagrams in code. [Link](https://plantuml.com/)
-   **Lucidchart / draw.io**: Online tools with excellent support for creating UML diagrams.
