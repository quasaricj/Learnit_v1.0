# Low-Level Design: Module and Interface Design

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a module in the context of software design.
- **Explain** the principles of high cohesion and low coupling.
- **Define** an interface and its role in software design.
- **Differentiate** between an interface and an implementation.
- **Explain** the concept of "programming to an interface."
- **Understand** how interfaces enable modularity, testability, and polymorphism.

---

## 2. Introduction: Organizing Your Code

Low-Level Design is about creating a detailed blueprint for a specific component. A critical part of this is deciding how to organize the code within that component into logical **modules** and how those modules will communicate with each other through **interfaces**.

Good module and interface design is the key to creating code that is **maintainable, testable, and flexible**.

---

## 3. High Cohesion and Low Coupling

These are two of the most important and enduring principles in all of software design. They are your primary guides for how to structure your code.

### High Cohesion

- **Definition**: **Cohesion** is a measure of how related the responsibilities of a single module or class are. **High Cohesion** means that all the elements of a module (its functions, its data) belong together and are focused on a single, well-defined purpose.
- **Analogy**: A well-organized kitchen drawer. One drawer contains all the forks, knives, and spoons. It has high cohesion. A junk drawer, which contains a random collection of unrelated items, has low cohesion.
- **Goal**: You want your classes and modules to have **high cohesion**. A class should have one main job (this is the Single Responsibility Principle).

### Low Coupling

- **Definition**: **Coupling** is a measure of how dependent two modules are on each other. **Low Coupling** means that a change in one module should have a minimal impact on the other modules.
- **Analogy**: A lamp and a wall socket. The lamp is connected to the house's electrical system through a standard, well-defined interface (the plug and socket). You can unplug the lamp and plug in a completely different one without having to change the wiring in the walls. This is low coupling. If you had to solder the lamp's wires directly to the house's wiring, that would be high coupling.
- **Goal**: You want your modules to have **low coupling**. They should communicate with each other through stable, well-defined interfaces, without depending on each other's internal implementation details.

---

## 4. Interfaces: The Key to Low Coupling

An **interface** is a **contract**. It defines a set of methods that a class *must* implement, but it says nothing about *how* they are implemented.

- **Interface**: The "what". It defines the public API of a component.
- **Implementation**: The "how". This is the concrete class that contains the actual code that implements the methods defined in the interface.

**Example**:
```java
// The Interface (the contract)
public interface UserRepository {
    User findById(String id);
    void save(User user);
}

// A concrete implementation for a PostgreSQL database
public class PostgresUserRepository implements UserRepository {
    // ... implementation details for talking to Postgres ...
}

// Another concrete implementation for an in-memory test database
public class InMemoryUserRepository implements UserRepository {
    // ... implementation details for an in-memory hash map ...
}
```

---

## 5. "Program to an Interface, Not an Implementation"

This is a fundamental principle of good object-oriented design. It means that your business logic should depend on the **interface**, not on the concrete implementation.

**Example**: Your `UserService` should not know or care that it is talking to a `PostgresUserRepository`. It should only know that it is talking to a `UserRepository`.

```java
// Bad: High Coupling
public class UserService {
    private PostgresUserRepository repository = new PostgresUserRepository(); // Dependency on the concrete class

    public void createUser(...) {
        // ...
        repository.save(user);
    }
}

// Good: Low Coupling (using Dependency Injection)
public class UserService {
    private final UserRepository repository; // Dependency on the INTERFACE

    public UserService(UserRepository repository) { // The concrete implementation is "injected"
        this.repository = repository;
    }

    public void createUser(...) {
        // ...
        repository.save(user);
    }
}
```

### Benefits of Programming to an Interface

1.  **Flexibility and Maintainability**: Because the `UserService` depends only on the interface, you can easily swap out the implementation. You can switch from a `PostgresUserRepository` to a `MongoUserRepository` without changing a single line of code in the `UserService`.
2.  **Testability**: This is a huge benefit. When you are unit testing your `UserService`, you can easily "inject" a fake, in-memory implementation of the `UserRepository` (a mock or a stub). This allows you to test your business logic in complete isolation, without needing a real database.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that **High Cohesion** means a module should have a single, well-defined purpose.
-   [ ] I can explain that **Low Coupling** means that modules should be independent of each other.
-   [ ] I know that high cohesion and low coupling are the primary goals of good module design.
-   [ ] I can define an **interface** as a contract that specifies the "what," while an **implementation** provides the "how."
-   [ ] I can explain the principle of "programming to an interface."
-   [ ] I understand that using interfaces is the key to achieving low coupling, which makes my code more **flexible** and **testable**.

---

## 7. Research and References

-   **"Design Patterns: Elements of Reusable Object-Oriented Software" by the "Gang of Four"**: This book is the source of the "program to an interface" principle.
-   **"Clean Architecture" by Robert C. Martin**: A book that is entirely about how to create a system with clear boundaries and interfaces between its modules.
-   **"The Pragmatic Programmer" by David Thomas and Andrew Hunt**: A classic book with a strong focus on creating flexible and decoupled code.
-   **SOLID Principles**: The Interface Segregation Principle and the Dependency Inversion Principle are directly related to good interface design.
