# Low-Level Design: Design Patterns Implementation

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a design pattern in the context of LLD.
- **Explain** how design patterns provide a reusable solution to a common problem.
- **Differentiate** between creational, structural, and behavioral patterns.
- **Identify** a common problem and select an appropriate design pattern to solve it.
- **Understand** the implementation of a basic design pattern (e.g., Factory or Strategy).
- **Recognize** that design patterns are a shared vocabulary for developers.

---

## 2. Introduction: Reusable Solutions

In Low-Level Design, you are concerned with the detailed implementation of a single component. As you do this, you will encounter common, recurring problems:
- "How do I create an object when the exact type of the object might vary?"
- "How do I change the behavior of an object at runtime?"
- "How do I allow objects to communicate without being tightly coupled?"

**Design patterns** are well-documented, battle-tested, reusable solutions to these and other commonly occurring problems in software design. They are not specific algorithms or pieces of code, but rather general concepts and templates that you can adapt to your own specific situation.

Using design patterns helps you write code that is more flexible, maintainable, and resilient, and it allows you to leverage the collective experience of the software development community.

---

## 3. The Three Categories of Design Patterns

The original and most famous set of design patterns comes from the book "Design Patterns: Elements of Reusable Object-Oriented Software" by the "Gang of Four" (GoF). They categorized their 23 patterns into three groups.

### 1. Creational Patterns

- **Purpose**: To provide object creation mechanisms that increase flexibility and reuse of existing code.
- **Core Idea**: They decouple the client from the details of how a complex object is created.
- **Examples**:
  - **Factory Method**: Defer instantiation to subclasses.
  - **Abstract Factory**: Create families of related objects.
  - **Builder**: Construct complex objects step by step.
  - **Singleton**: Ensure a class has only one instance.
  - **Prototype**: Create new objects by copying an existing object.

### 2. Structural Patterns

- **Purpose**: To explain how to assemble objects and classes into larger structures, while keeping the structures flexible and efficient.
- **Core Idea**: They focus on the relationships between objects.
- **Examples**:
  - **Adapter**: Make incompatible interfaces work together.
  - **Decorator**: Add new behaviors to an object dynamically by wrapping it.
  - **Facade**: Provide a simple, unified interface to a complex subsystem.
  - **Proxy**: Provide a surrogate or placeholder for another object to control access to it.
  - **Composite**: Compose objects into tree structures to represent part-whole hierarchies.

### 3. Behavioral Patterns

- **Purpose**: To handle effective communication and the assignment of responsibilities between objects.
- **Core Idea**: They describe how objects collaborate to perform a task.
- **Examples**:
  - **Strategy**: Define a family of algorithms, put each of them into a separate class, and make their objects interchangeable. This lets you change an object's behavior at runtime.
  - **Observer**: Define a one-to-many dependency between objects so that when one object changes state, all its dependents are notified and updated automatically.
  - **Command**: Turn a request into a stand-alone object that contains all information about the request.
  - **Iterator**: Provide a way to access the elements of a collection sequentially without exposing its underlying representation.
  - **State**: Allow an object to alter its behavior when its internal state changes.

---

## 4. A Closer Look: The Strategy Pattern

- **Problem**: You are designing a shipping cost calculator. The calculation logic needs to change depending on the shipping method chosen by the user (e.g., FedEx, UPS, USPS). You could use a giant `if/else if` or `switch` statement, but this violates the Open/Closed Principle.
- **Solution**: The **Strategy Pattern**.
  1.  **Define a Strategy Interface**: Create an interface `ShippingStrategy` with a single method, `calculate(order)`.
  2.  **Create Concrete Strategies**: Create a separate class for each shipping method that *implements* the `ShippingStrategy` interface: `FedExStrategy`, `UPSStrategy`, etc. Each class contains the specific calculation logic for that method.
  3.  **Create a Context**: Your `ShippingCalculator` (the "Context") has a field to hold a reference to a `ShippingStrategy` object.
  4.  **Delegate**: When the `ShippingCalculator` needs to calculate the cost, it doesn't do the calculation itself. It **delegates** the call to the `calculate` method of the strategy object it is currently holding.
  5.  **Change at Runtime**: You can now change the shipping method at runtime by simply setting a different strategy object on the calculator.

This pattern makes your system easy to extend. To add a new shipping method, you just have to create a new strategy class; you don't have to modify the existing `ShippingCalculator` at all.

---

## 5. Design Patterns as a Shared Vocabulary

One of the greatest benefits of learning design patterns is that they provide a **shared vocabulary** for developers.

When you say, "I'm using a Strategy here to handle the different pricing rules," another developer who knows the pattern immediately understands the structure, the intent, and the trade-offs of your design without having to read every line of code. This makes technical communication much more efficient and precise.

**Caution**: Do not force a design pattern where it doesn't fit. "Pattern-itis" (the overuse of design patterns) can lead to overly complex and abstract code for a simple problem. A pattern is a tool, not a goal.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that a design pattern is a reusable solution to a common LLD problem.
-   [ ] I can name the three categories of GoF patterns: **Creational**, **Structural**, and **Behavioral**.
-   [ ] I can describe the purpose of a **Creational** pattern (object creation), a **Structural** pattern (object composition), and a **Behavioral** pattern (object communication).
-   [ ] I can explain the high-level idea of a common pattern, like the **Strategy** or **Observer** pattern.
-   [ ] I understand that design patterns provide a **shared vocabulary** that improves communication between developers.
-   [ ] I know that I should use a pattern to solve a real problem, not just for the sake of using a pattern.

---

## 7. Research and References

-   **"Design Patterns: Elements of Reusable Object-Oriented Software" by the "Gang of Four"**: The original, classic, and definitive book. It is dense but foundational.
-   **"Head First Design Patterns" by Eric Freeman & Elisabeth Robson**: Widely considered the most accessible and fun introduction to the GoF design patterns.
-   **Refactoring Guru**: An excellent website with clear explanations, analogies, and code examples for a wide range of design patterns. [Link](https://refactoring.guru/design-patterns)
-   **"Game Programming Patterns" by Robert Nystrom**: A fantastic book that applies the concept of design patterns specifically to the domain of game development. It is available for free online.
