# Low-Level Design: Database Schema Design

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** database schema design as part of the LLD process.
- **Translate** class diagrams into a physical database schema.
- **Choose** appropriate data types for your table columns.
- **Define** primary keys, foreign keys, and indexes.
- **Model** different types of relationships (one-to-one, one-to-many, many-to-many) in a relational database.
- **Understand** the basics of denormalization as a performance optimization.

---

## 2. Introduction: The Blueprint for Your Data

**Database schema design** is the low-level design process of creating the detailed blueprint for your database. It involves defining the tables, the columns in each table, the data types for each column, and the relationships between the tables.

This is a critical part of the LLD. A well-designed schema will be efficient, scalable, and will enforce data integrity. A poorly designed schema will lead to performance problems, data corruption, and maintenance nightmares.

The schema design is the physical implementation of the data model you identified in your higher-level design.

---

## 3. The Design Process

### 1. Identify Entities and Attributes

- Your entities (from your class diagram or domain model) become your **tables** (e.g., `Users`, `Products`, `Orders`).
- The attributes of your entities become the **columns** in those tables (e.g., the `Users` table will have `username`, `email`, `password_hash` columns).

### 2. Choose Data Types

- For each column, you must choose the most appropriate data type. Being specific is important for performance and data integrity.
- **Common Data Types**:
  - `INT`, `BIGINT`: For whole numbers.
  - `VARCHAR(n)`: For variable-length strings with a maximum length.
  - `TEXT`: For long-form text.
  - `BOOLEAN`: For true/false values.
  - `DECIMAL(p, s)`: For fixed-point numbers where precision is important (like money).
  - `TIMESTAMP` or `DATETIME`: For storing dates and times.
  - `UUID`: For universally unique identifiers.

### 3. Define Keys and Indexes

- **Primary Key (PK)**: Choose a primary key for each table. The most common and recommended practice is to have a surrogate key, typically an auto-incrementing integer or a UUID called `id`.
- **Foreign Keys (FK)**: Use foreign keys to establish the relationships between your tables.
- **Indexes**: Create indexes on columns that will be frequently used in `WHERE` clauses or `JOIN`s to improve query performance. Foreign keys are almost always indexed.

---

## 4. Modeling Relationships

### 1. One-to-One Relationship

- **Example**: A `User` has one `Profile`.
- **Implementation**: The primary key of one table is also a foreign key that references the other table. For example, the `Profiles` table could have a `user_id` column that is both its primary key and a foreign key to the `Users` table.

### 2. One-to-Many Relationship

- **Example**: A `User` can have many `Posts`. A `Post` belongs to only one `User`.
- **Implementation**: This is the classic foreign key relationship. The "many" side of the relationship has a foreign key column that points to the "one" side.
  - The `Posts` table will have a `user_id` column that is a foreign key referencing the `id` of the `Users` table.

### 3. Many-to-Many Relationship

- **Example**: A `Student` can be enrolled in many `Courses`, and a `Course` can have many `Students`.
- **Implementation**: You cannot implement this with a single foreign key. You must create a third table, called a **join table** (or junction table).
  - You would create an `Enrollments` table.
  - This table would have two columns: `student_id` (a foreign key to the `Students` table) and `course_id` (a foreign key to the `Courses` table).
  - Each row in the `Enrollments` table represents a single link between a student and a course.

---

## 5. Denormalization for Performance

As you learned in the database design module, **normalization** is the process of reducing data redundancy. This is the correct default approach for a relational database schema.

However, a highly normalized schema can sometimes lead to performance problems, as it may require a large number of `JOIN`s to retrieve data.

**Denormalization** is the process of intentionally adding redundant data to your schema to improve read performance. It is a trade-off: you are sacrificing some write efficiency and data consistency for faster reads.

- **Example**:
  - In a normalized schema, a `posts` table would have an `author_id`. To get the author's name, you would have to `JOIN` with the `users` table.
  - In a denormalized schema, you might decide to also store the `author_name` directly in the `posts` table.
- **Trade-off**:
  - **Faster Reads**: You can now get the author's name without a `JOIN`.
  - **Slower Writes and Inconsistency**: If a user changes their name, you now have to update it in the `users` table *and* in every single post they have ever written. This is a significant overhead.

**Rule of Thumb**: Start with a normalized (3NF) schema. Only denormalize when you have a proven and measured performance problem that cannot be solved by other means (like proper indexing or caching).

---

## 6. Summary and Mastery Checklist

-   [ ] I know that database schema design is the LLD for the database.
-   [ ] I can translate a simple class diagram into a set of tables and columns.
-   [ ] I can choose appropriate data types for my columns.
-   [ ] I know that a **one-to-many** relationship is implemented with a foreign key.
-   [ ] I know that a **many-to-many** relationship requires a **join table**.
-   [ ] I can define **denormalization** as the process of adding redundant data to improve read performance, and I understand the trade-offs.

---

## 7. Research and References

-   **"SQL Antipatterns: Avoiding the Pitfalls of Database Programming" by Bill Karwin**: A great book that teaches good design by showing you examples of bad design.
-   **"Database Design for Mere Mortals" by Michael J. Hernandez**
-   **dbdiagram.io**: A free and simple tool for drawing database schema diagrams.
-   **"Normalization vs. Denormalization"**: A common topic for database design articles.
