# Low-Level Design: API Contract Specifications

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** an API contract and explain its purpose.
- **Identify** the key components of an API contract.
- **Differentiate** between the high-level API design (in HLD) and the detailed contract specification (in LLD).
- **Understand** the "contract-first" vs. "code-first" approaches to API development.
- **Recognize** the OpenAPI Specification as the standard for defining REST API contracts.
- **Read and understand** a simple API specification written in OpenAPI/Swagger format.

---

## 2. Introduction: The Rules of Engagement

An **API contract** is a detailed, formal specification that defines how two systems will communicate. It is the "rules of engagement" for your API. It provides a single, unambiguous source of truth that both the provider of the API (the backend team) and the consumers of the API (the frontend team, the mobile team, third-party developers) can agree on.

While High-Level Design defines the general interactions ("the `PhotoService` talks to the `UserService`"), the Low-Level Design for an API specifies the exact details of that communication. This is the API contract.

---

## 3. Key Components of an API Contract

A good API contract is precise and leaves no room for ambiguity. It should include:

1.  **Endpoints**: The specific URL paths for each resource (e.g., `/users`, `/users/{id}`).
2.  **HTTP Methods**: The allowed HTTP verb for each endpoint (e.g., `GET`, `POST`, `PUT`, `DELETE`).
3.  **Parameters**:
    - **Path Parameters**: e.g., the `{id}` in `/users/{id}`.
    - **Query Parameters**: For filtering and sorting, e.g., `/users?role=admin`.
    - **Header Parameters**: e.g., the `Authorization` header.
4.  **Request Bodies**:
    - The exact structure and data types for the JSON payload in a `POST` or `PUT` request.
    - Which fields are required and which are optional.
5.  **Response Bodies**:
    - The exact structure and data types for the JSON payload of all possible responses.
    - You must define the structure for **successful** responses (e.g., `200 OK`, `201 Created`) and for **error** responses (e.g., `400 Bad Request`, `404 Not Found`).
6.  **Authentication**: The required authentication scheme (e.g., "Requires a JWT Bearer token").

---

## 4. "Contract-First" vs. "Code-First"

There are two main approaches to creating your API contract.

- **Code-First**:
  - You write your application code first (e.g., your controllers and models).
  - You then use a tool or a library to **auto-generate** the API specification from your code.
  - **Pros**: Fast to get started. The documentation is always in sync with the code.
  - **Cons**: The design of the API is driven by the implementation details, which can lead to a less clean and user-friendly API.

- **Contract-First**:
  - You **write the API specification first**, before you write any implementation code.
  - This specification is treated as the formal contract. It is reviewed and agreed upon by all the teams (frontend, backend, mobile).
  - **Pros**:
    - **Promotes good design**: You are forced to think carefully about the API design from the consumer's perspective.
    - **Enables Parallel Development**: Once the contract is agreed upon, the frontend and backend teams can work in **parallel**. The frontend team can build their UI against a **mock server** that is generated from the specification, without having to wait for the backend to be built.
  - **Cons**: Requires more discipline and upfront planning.

For team-based development, especially in a microservices environment, the **Contract-First approach is highly recommended.**

---

## 5. The OpenAPI Specification (Swagger)

The **OpenAPI Specification** is the industry standard for defining REST API contracts. It is a language-agnostic specification that allows you to describe your entire API in a single **YAML** or **JSON** file.

### A Simple OpenAPI Example

```yaml
openapi: 3.0.0
info:
  title: Simple User API
  version: 1.0.0

paths:
  /users/{id}:
    get:
      summary: Get a user by their ID
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: integer
      responses:
        '200':
          description: A single user.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/User'
        '404':
          description: User not found.

components:
  schemas:
    User:
      type: object
      properties:
        id:
          type: integer
        name:
          type: string
        email:
          type: string
```

This specification file is the **single source of truth**. From this file, you can:
- Generate interactive documentation (with tools like Swagger UI).
- Generate mock servers.
- Generate client SDKs.
- Run automated contract tests.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define an **API contract** as a formal specification of how an API works.
-   [ ] I know that the contract is the "single source of truth" for both the frontend and backend teams.
-   [ ] I can list the key components of a contract (endpoints, methods, parameters, request/response bodies).
-   [ ] I can explain the **"Contract-First"** approach and its main benefit: enabling **parallel development**.
-   [ ] I can name the **OpenAPI Specification** as the industry standard for defining REST API contracts.
-   [ ] I can read a simple OpenAPI/Swagger YAML file and understand what it's describing.

---

## 7. Research and References

-   **OpenAPI Specification**: The official website. [Link](https://www.openapis.org/)
-   **Swagger**: The most popular set of tools for working with the OpenAPI specification. The editor and UI are great for learning. [Link](https://swagger.io/)
-   **"Contract-First vs. Code-First"**: A common topic for API design articles.
-   **API-First Development**: A philosophy that emphasizes designing your API contract as the first step in the development process.
