# Low-Level Design: Class Diagrams and Relationships

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Low-Level Design (LLD) and its role in translating HLD into an implementation plan.
-   **Identify** the core components of a UML Class Diagram: classes, attributes, and methods.
-   **Describe** and **differentiate** between the key relationships in a class diagram: Association, Aggregation, Composition, and Inheritance.
-   **Interpret** a basic class diagram and understand the structural design it represents.
-   **Use** class diagrams as a tool for detailed design and communication within an engineering team.

---

## 2. Introduction: From Blueprint to Floor Plan

If a High-Level Design (HLD) is the architect's blueprint for a house, the Low-Level Design (LLD) is the detailed floor plan created by the engineers. It zooms in on a specific component or service from the HLD and describes its internal structure in detail.

The LLD is the bridge between the high-level architectural vision and the actual code. One of the most common and effective tools for creating an LLD is the **UML Class Diagram**. It provides a static, structural view of a system by showing its classes, their attributes, and the relationships between them.

---

## 3. The Building Blocks of a Class Diagram

A class is represented as a rectangle with three compartments:

1.  **Class Name**: The name of the class (e.g., `User`, `Order`).
2.  **Attributes (or Properties)**: The data or state that an object of the class holds (e.g., `- username: string`, `+ email: string`).
3.  **Methods (or Operations)**: The actions or behaviors that an object of the class can perform (e.g., `+ calculateTotal(): double`, `- validatePassword()`).

-   **Visibility**: The `+`, `-`, and `#` symbols denote the visibility of attributes and methods:
    -   `+`: `public` (accessible from anywhere)
    -   `-`: `private` (accessible only within the class)
    -   `#`: `protected` (accessible within the class and its subclasses)

![UML Class Diagram Components](https://www.uml-diagrams.org/class-diagrams/class-diagram-example-bank-account.png)

---

## 4. Key Relationships Between Classes

A class diagram is more than just a collection of boxes; it's the **lines** between them that show how the system is structured.

### 1. Association

-   **What it is**: The most general relationship. It indicates that two classes are "aware" of each other and can interact. It's a "has-a" or "uses-a" relationship.
-   **Analogy**: A `Driver` "uses a" `Car`. They are related, but their lifecycles are not tied. The `Car` can exist without the `Driver`.
-   **Notation**: A solid line between the classes. Multiplicity (e.g., `1`, `*` for "many") can be specified at each end.

### 2. Aggregation (A special type of Association)

-   **What it is**: A stronger, "whole-part" relationship. It's a "has-a" relationship, but one class represents a collection or container of the other.
-   **Analogy**: A `Department` "has" `Professors`. The `Department` is the whole, and the `Professors` are the parts. However, if the `Department` is dissolved, the `Professors` can still exist and move to another department. The parts can exist independently of the whole.
-   **Notation**: A solid line with an empty diamond on the "whole" side.

### 3. Composition (A special type of Aggregation)

-   **What it is**: The strongest "whole-part" relationship. It's a "contains-a" or "is-composed-of" relationship.
-   **Analogy**: A `House` "is composed of" `Rooms`. The `Rooms` are an integral part of the `House`. If you destroy the `House`, the `Rooms` are destroyed with it. The parts **cannot** exist independently of the whole.
-   **Notation**: A solid line with a filled diamond on the "whole" side.

### 4. Inheritance (or Generalization)

-   **What it is**: An "is-a" relationship. One class (the subclass or child) inherits the attributes and methods of another class (the superclass or parent).
-   **Analogy**: A `Car` "is a" `Vehicle`. A `Truck` "is a" `Vehicle`. Both `Car` and `Truck` share the common properties of a `Vehicle`.
-   **Notation**: A solid line with a hollow arrow pointing from the child to the parent.

![UML Relationships](https://miro.medium.com/max/1200/1*d-e_P-D32-u_1-a-1qAFgA.png)
*(Note: This is a simplified representation of common UML notations)*

---

## 5. Deliberate Practice

**Scenario**: You are creating the LLD for an `Order` system in an e-commerce application.

-   **Classes**: You have the following classes: `Order`, `OrderItem`, `Customer`, and `Address`.
-   **Business Rules**:
    -   An `Order` is placed by exactly one `Customer`. A `Customer` can have many `Orders`.
    -   An `Order` must have at least one `OrderItem`.
    -   Each `OrderItem` is part of exactly one `Order`. If the `Order` is deleted, its `OrderItem`s are also deleted.
    -   Each `Order` has a shipping `Address`. The `Address` is a value object; it is part of the `Order` and does not have its own lifecycle.

**Task**: Draw a simple class diagram that represents these classes and their relationships. Use the correct notation for multiplicity and the type of relationship (Association, Aggregation, Composition).

---

## 12. Summary and Mastery Checklist

-   [ ] I know that a **Class Diagram** is a key tool in LLD for modeling the static structure of a system.
-   [ ] I can identify the three parts of a class in a diagram: **Name, Attributes, and Methods**.
-   [ ] I can define an **Association** as a general "uses-a" relationship.
-   [ ] I can distinguish between **Aggregation** (a "has-a" relationship where parts can exist independently) and **Composition** (a "contains-a" relationship where parts are destroyed with the whole).
-   [ ] I can define **Inheritance** as an "is-a" relationship.
-   [ ] I understand that these diagrams are a precise way to communicate the detailed design to other developers before writing code.

---

## 13. Research and References

-   **UML Class Diagram Tutorial**: A comprehensive guide to the formal notation. [Link](https://www.visual-paradigm.com/guide/uml-unified-modeling-language/what-is-class-diagram/)
-   **"Head First Design Patterns" by Eric Freeman & Elisabeth Robson**: Uses a simplified version of class diagrams to explain object-oriented design patterns.
-   **Martin Fowler - "UML as Sketch"**: An article advocating for using UML informally as a sketching and communication tool, rather than a rigid formal process.
