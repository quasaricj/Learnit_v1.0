# Low-Level Design: Designing for Testability

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Testability as a critical quality attribute of a software design.
-   **Explain** why tightly-coupled code is difficult to test.
-   **Describe** the Dependency Inversion Principle and the use of interfaces to break dependencies.
-   **Define** Dependency Injection (DI) and explain how it enables unit testing with mock objects.
-   **Explain** the concept of a "pure function" and why it is inherently easy to test.
-   **Recognize** that a design that is easy to test is also, by extension, loosely coupled and more maintainable.

---

## 2. Introduction: Why Design for Testability?

**Testability** is a measure of how easily a piece of software can be tested. It is not an afterthought; it is a fundamental characteristic that must be designed into your code from the very beginning.

Code that is easy to test has several desirable properties:
-   It is **loosely coupled**, meaning its components are independent and not tangled together.
-   It is **maintainable**, as changes in one part of the system are less likely to break another.
-   It is **understandable**, as the dependencies and responsibilities are made explicit.

Conversely, code that is hard to test is often a sign of a poor design (often called "spaghetti code"). If you find yourself needing to spin up a real database or make a real network call just to test a simple piece of business logic, your design has a problem.

---

## 3. The Core Problem: Tight Coupling and Hidden Dependencies

The primary enemy of testability is **tight coupling**. Consider this example:

```java
// Tightly-Coupled Code - HARD TO TEST
public class OrderService {
    private final PostgresRepository database = new PostgresRepository(); // Direct instantiation

    public void createOrder(Order order) {
        // ... business logic ...
        database.save(order);
    }
}
```

How would you write a unit test for the `createOrder` method? You can't. To test it, you would have to:
1.  Have a real PostgreSQL database running.
2.  Manage the database connection.
3.  Clean up the database after the test is finished.

This is slow, complex, and brittle. It's an **integration test**, not a **unit test**. The problem is that `OrderService` is tightly coupled to the concrete `PostgresRepository`.

---

## 4. The Solution: Inversion of Control and Dependency Injection

The solution is to "invert the control" of dependency creation. Instead of the `OrderService` creating its own dependencies, we will provide them to it from the outside.

### Step 1: Depend on Abstractions (Interfaces)

First, we apply the **Dependency Inversion Principle**. Our high-level business logic (`OrderService`) should not depend on low-level implementation details (`PostgresRepository`). Instead, both should depend on an abstraction (an interface).

```java
// The Abstraction (Port)
public interface OrderRepository {
    void save(Order order);
}

// Loosely-Coupled Code - EASY TO TEST
public class OrderService {
    private final OrderRepository database; // Depends on the interface, not the concrete class

    public OrderService(OrderRepository database) { // The dependency is passed in
        this.database = database;
    }

    public void createOrder(Order order) {
        // ... business logic ...
        database.save(order);
    }
}
```

### Step 2: Inject the Dependency

The technique of providing a class with its dependencies from the outside is called **Dependency Injection (DI)**. The most common form is "constructor injection," as shown above. The `OrderService` *declares* that it needs something that implements `OrderRepository`, and its creator is responsible for providing it.

### Why This is Testable

Now, writing a unit test for `OrderService` is trivial. We don't need a real database. We can create a "mock" or "fake" implementation of the `OrderRepository` interface and inject that into our service for the test.

```java
// A Mock Repository for Testing
public class MockOrderRepository implements OrderRepository {
    public int timesSaveWasCalled = 0;
    public Order lastOrderSaved = null;

    @Override
    public void save(Order order) {
        timesSaveWasCalled++;
        lastOrderSaved = order;
        // No database connection needed!
    }
}

// The Unit Test
@Test
public void testCreateOrder() {
    MockOrderRepository mockRepo = new MockOrderRepository();
    OrderService service = new OrderService(mockRepo); // Inject the mock
    Order myOrder = new Order(...);

    service.createOrder(myOrder);

    // Assert that the business logic worked correctly
    assertEquals(1, mockRepo.timesSaveWasCalled);
    assertEquals(myOrder, mockRepo.lastOrderSaved);
}
```
This test is fast, simple, and runs in complete isolation. We have successfully separated the business logic of `OrderService` from the infrastructure concern of database persistence.

---

## 5. The Power of Pure Functions

A **pure function** is a function whose output value is determined *only* by its input values, with no observable side effects. It doesn't read from a database, write to a file, or depend on any global state.

```java
// A Pure Function - Inherently Testable
public double calculateDiscount(double orderTotal, UserStatus status) {
    if (status == UserStatus.PREMIUM && orderTotal > 100.0) {
        return orderTotal * 0.9; // 10% discount
    }
    return orderTotal;
}
```

Pure functions are the most testable code you can write. To test them, you simply provide a set of inputs and assert that the output is what you expect. A good LLD will strive to isolate as much core business logic as possible into pure functions.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that **Testability** is a key indicator of a good, loosely-coupled design.
-   [ ] I understand that **Dependency Inversion** (depending on interfaces, not concrete classes) is the key to breaking tight coupling.
-   [ ] I can define **Dependency Injection** as the pattern of providing a class with its dependencies from an external source.
-   [ ] I can explain how DI allows me to replace real dependencies (like a database) with **mock objects** in my unit tests.
-   [ ] I know that **pure functions** are the easiest possible code to test, as their output depends only on their input.

---

## 13. Research and References

-   **"Working Effectively with Legacy Code" by Michael Feathers**: The classic book on how to break dependencies and make difficult code testable.
-   **"Clean Architecture" by Robert C. Martin**: Emphasizes a design philosophy centered on testability and the separation of concerns.
-   **Martin Fowler - "Inversion of Control Containers and the Dependency Injection pattern"**: The seminal article explaining DI.
