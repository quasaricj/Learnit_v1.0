# Low-Level Design (LLD) Review Practices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Understand** the purpose and importance of a Low-Level Design review as a collaborative quality gate.
-   **Identify** the key areas to focus on during an LLD review, such as SOLID principles, testability, and clarity.
-   **Formulate** constructive questions and feedback based on a proposed design.
-   **Participate** effectively in a design review, both as a presenter and a reviewer.
-   **Recognize** that the goal of a review is to improve the design, not to criticize the designer.

---

## 2. Introduction: The "Look Before You Leap" of Coding

A Low-Level Design (LLD) review is a formal or informal process where engineers collaboratively review the detailed design of a component or feature *before* a significant amount of code is written. It is the "look before you leap" moment that bridges the gap between the high-level plan and the final implementation.

**Why is it crucial?**
-   **It's cheap**: Finding a design flaw on a whiteboard or in a document is exponentially cheaper to fix than finding it after thousands of lines of code have been written.
-   **Knowledge Sharing**: It's an excellent way to share knowledge, patterns, and context across the team. Junior engineers learn from seniors, and seniors gain a deeper understanding of the feature.
-   **Improves Quality**: It helps catch potential issues with complexity, testability, and maintainability early in the process.
-   **Builds Consensus**: It ensures the team agrees on the implementation path, reducing future arguments and refactoring.

---

## 3. The LLD Review Checklist: Key Questions to Ask

Whether you are presenting your design or reviewing a teammate's, these questions provide a framework for a thorough review.

### ☐ 1. Does the Design Meet the Requirements?
-   Does the LLD correctly and completely implement the functional requirements from the HLD?
-   Does the design account for the relevant non-functional requirements (e.g., performance, security)?

### ☐ 2. Is the Design Clear and Understandable?
-   Is the design easy to explain? A good design should not require a convoluted explanation.
-   Are the class and method names clear, intention-revealing, and consistent?
-   Is the separation of responsibilities logical? (Single Responsibility Principle).

### ☐ 3. Does the Design Adhere to SOLID Principles?
-   **Single Responsibility Principle (SRP)**: Does each class have one, and only one, reason to change?
-   **Open/Closed Principle (OCP)**: Is the design open for extension but closed for modification? (e.g., using interfaces and plugins).
-   **Liskov Substitution Principle (LSP)**: If using inheritance, can a subclass truly be substituted for its parent class without breaking anything?
-   **Interface Segregation Principle (ISP)**: Are interfaces small and focused, or are they "fat" interfaces that force clients to depend on methods they don't use?
-   **Dependency Inversion Principle (DIP)**: Does the design depend on abstractions (interfaces) rather than concrete implementations?

### ☐ 4. Is the Design Testable?
-   How would you write a unit test for the core business logic?
-   Are dependencies being properly injected (Dependency Injection)?
-   Are there hidden dependencies or global state that will make testing difficult?

### ☐ 5. Is the Design Over-Engineered?
-   Is the design more complex than it needs to be for the current requirements? (YAGNI - "You Ain't Gonna Need It").
-   Is it using a complex design pattern where a simpler solution would suffice?
-   Is it adding abstractions that aren't currently necessary and might never be?

### ☐ 6. How Does the Design Handle Errors and Edge Cases?
-   How are invalid inputs handled?
-   What happens when a network call fails?
-   How are exceptions propagated and handled?

---

## 4. Best Practices for Reviewers

-   **Be Constructive, Not Critical**: Frame feedback as questions and suggestions, not as demands. "Have you considered what might happen if this service call fails?" is better than "Your design doesn't handle failures."
-   **Focus on the "Why"**: Seek to understand the reasons behind the designer's decisions before challenging them.
-   **Distinguish Between Principles and Preferences**: Is your feedback based on a fundamental design principle (e.g., "This is tightly coupled") or a personal style preference (e.g., "I would have named this variable differently")? Prioritize the former.
-   **Offer Alternatives**: If you identify a problem, try to suggest a potential alternative solution.

## 5. Best Practices for Presenters

-   **Provide Context**: Start by briefly explaining the business problem and the high-level goals.
-   **Use Visuals**: Use class diagrams, sequence diagrams, and other visuals to explain the design.
-   **Be Open to Feedback**: Your goal is to arrive at the best possible design, not to prove that your first draft was perfect. Be grateful for the feedback you receive.
-   **Document the Outcome**: After the review, update the design document to reflect the decisions and feedback.

---

## 12. Summary and Mastery Checklist

-   [ ] I understand that an LLD review is a collaborative process to improve code quality **before** implementation.
-   [ ] I can use a checklist of key areas—including **SOLID principles** and **testability**—to guide my review.
-   [ ] I know to ask "why" and provide constructive, principle-based feedback rather than purely stylistic criticism.
-   [ ] I recognize the danger of **over-engineering** and the importance of YAGNI.
-   [ ] I see the LLD review process as a valuable tool for team alignment and knowledge sharing.

---

## 13. Research and References

-   **"Code Complete" by Steve McConnell**: A classic and comprehensive book on software construction that covers many aspects of LLD.
-   **Google's Engineering Practices Documentation**: Contains excellent guides on how Google conducts code and design reviews.
-   **"Clean Architecture" by Robert C. Martin**: Provides the foundation for many of the principles (like SOLID) that are central to a good LLD.
