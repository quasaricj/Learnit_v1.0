# LLD: Use Case and Sequence Diagrams

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Differentiate** between static (structural) and dynamic (behavioral) design diagrams.
-   **Define** a Use Case Diagram and its purpose in capturing functional requirements.
-   **Identify** the key components of a Use Case Diagram: Actors, Use Cases, and the System Boundary.
-   **Define** a Sequence Diagram and its purpose in modeling interactions over time.
-   **Identify** the key components of a Sequence Diagram: Lifelines, Activation Bars, and Messages.
-   **Use** these diagrams together to model a system's behavior from a high-level user goal down to a detailed object interaction.

---

## 2. Introduction: Modeling Behavior vs. Structure

In the previous lesson, we looked at **Class Diagrams**, which provide a *static* or *structural* view of the system. They show the building blocks (classes) and their relationships, but they don't show how those blocks interact over time to get something done.

To model the *dynamic* or *behavioral* aspects of a system, we use different diagrams. Two of the most important are **Use Case Diagrams** (for the high-level user goals) and **Sequence Diagrams** (for the detailed, step-by-step interactions).

---

## 3. Use Case Diagrams: What the System Does

A Use Case Diagram provides a high-level, "black box" view of a system. It answers the question: **"What can the users do with this system?"** It's an excellent tool for capturing and communicating the functional requirements of a system.

### Key Components:

1.  **Actor**: An Actor is anyone or anything that interacts with the system. This is typically a user role (e.g., `Customer`, `Administrator`), but it can also be another external system. Represented by a stick figure.

2.  **Use Case**: A Use Case represents a specific goal or task that an Actor wants to achieve with the system. It's a single, observable piece of functionality. Represented by an oval.

3.  **System Boundary**: A rectangle that is drawn around all the use cases to indicate the scope of the system being modeled.

![Use Case Diagram Example](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Use_case_restaurant_model.svg/800px-Use_case_restaurant_model.svg.png)

This diagram for a restaurant system clearly communicates:
-   A `Customer` can `Order Food`, `Drink`, and `Pay for Food`.
-   A `Chef` is an Actor who `Prepares Food`.
-   The `Waiter` is involved in multiple use cases.

It provides a simple, at-a-glance view of the system's intended functionality from the user's perspective.

---

## 4. Sequence Diagrams: How the System Does It

A Sequence Diagram zooms in on a single use case and shows the step-by-step interactions between different objects or components required to fulfill that use case. It answers the question: **"In what sequence do the messages flow to accomplish this goal?"**

It's a powerful tool for low-level design because it forces you to think through the detailed logic and communication flow before you write code.

### Key Components:

1.  **Lifeline**: A vertical dashed line that represents a single object or component instance over time. A box at the top shows the object's name.

2.  **Activation Bar**: A thin rectangle on a lifeline that indicates the period during which an object is actively performing an operation (i.e., a method is being executed).

3.  **Message**: An arrow from one lifeline to another representing a communication (e.g., a method call).
    -   **Synchronous Message**: A solid arrowhead. The sender waits for the receiver to finish before continuing.
    -   **Asynchronous Message**: An open arrowhead. The sender does not wait.
    -   **Return Message**: A dashed arrow showing the return value.

![Sequence Diagram Example](https://www.websequencediagrams.com/images/use_case_login.png)

This diagram for a "User Login" sequence clearly shows:
1.  The `User` calls the `login()` method on the `Login Screen`.
2.  The `Login Screen` then calls `validatePassword()` on the `Authentication Service`.
3.  The `Authentication Service` calls `getPassword()` on the `User DAO` (Data Access Object).
4.  The `User DAO` returns the password hash.
5.  The `Authentication Service` confirms the password is valid and returns `true`.
6.  Finally, the `Login Screen` shows a success message to the `User`.

This diagram makes the flow of control and the dependencies between objects explicit and easy to understand.

---

## 5. Deliberate Practice

**Scenario**: Consider the "Order Food" use case from the restaurant diagram above.

**Task**: Draw a simple sequence diagram for this use case.
-   **Lifelines**: You will need lifelines for the `Customer`, the `Waiter`, the `Kitchen`, and the `Order` object.
-   **Messages**: Think about the sequence of messages.
    1.  The `Customer` gives their order to the `Waiter`.
    2.  The `Waiter` creates an `Order`.
    3.  The `Waiter` submits the `Order` to the `Kitchen`.
    4.  (Bonus) The `Kitchen` sends an asynchronous "Order Ready" message back to the `Waiter`.

---

## 12. Summary and Mastery Checklist

-   [ ] I can distinguish between **static diagrams (like Class Diagrams)** which show structure, and **dynamic diagrams (like Sequence Diagrams)** which show behavior.
-   [ ] I can explain that a **Use Case Diagram** models the high-level functional requirements of a system from an **Actor's** perspective.
-   [ ] I can explain that a **Sequence Diagram** models the detailed, step-by-step message flow between objects over time for a specific use case.
-   [ ] I can identify the key elements of a sequence diagram: **Lifelines, Activation Bars, and Messages**.
-   [ ] I understand how to use these diagrams to translate a user requirement into a detailed implementation plan.

---

## 13. Research and References

-   **UML Sequence Diagrams Tutorial**: A comprehensive guide to the formal notation and its features. [Link](https://www.visual-paradigm.com/guide/uml-unified-modeling-language/what-is-sequence-diagram/)
-   **"UML Distilled" by Martin Fowler**: A classic, concise guide to the most useful parts of UML, including these diagrams.
-   **WebSequenceDiagrams**: A fantastic online tool for quickly generating sequence diagrams from a simple text-based language. [Link](https://www.websequencediagrams.com/)
