# Observability and Monitoring: Logging Strategies and Log Aggregation

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Differentiate** between logging, monitoring, and observability.
- **Explain** the purpose of application logging.
- **Describe** the characteristics of a good log event.
- **Implement** structured logging (e.g., in JSON format).
- **Explain** the purpose of a log aggregation system.
- **Recognize** the components of the ELK stack as a popular log aggregation solution.
- **Understand** the importance of correlation IDs for tracing requests in a distributed system.

---

## 2. Introduction: What Happened?

In a complex or distributed system, things will inevitably go wrong. When they do, you need to be able to investigate and understand *what* happened, *why* it happened, and *where* it happened. **Logging** is the practice of recording discrete, timestamped events about the execution of your application. These logs are the primary tool for debugging and troubleshooting problems in a production environment.

While monitoring is about observing aggregated metrics (the "what"), logging is about understanding the specific, individual events (the "why").

---

## 3. Effective Logging Strategies

### 1. Use Log Levels

Not all log events are created equal. Using different log levels allows you to control the verbosity of your logs and to quickly filter for the most important events.

- **`FATAL` / `CRITICAL`**: A severe error that will cause the application to terminate.
- **`ERROR`**: An error that has occurred, but the application can continue running. This always requires investigation.
- **`WARN`**: An unexpected event that might indicate a potential problem, but is not yet an error.
- **`INFO`**: A standard, high-level message that records a significant event in the application's lifecycle (e.g., "Application started," "User logged in").
- **`DEBUG`**: A fine-grained message used by developers to trace the execution of the code.

**Best Practice**: Your production environment should be configured to log at the `INFO` level or higher. You can then dynamically change the log level to `DEBUG` if you need to investigate an active issue.

### 2. Log in a Structured Format (JSON)

Traditional, plain-text logs are easy for humans to read, but they are very difficult for machines to parse and query. **Structured logging** is the practice of writing your logs in a machine-readable format, like JSON.

- **Plain Text (Bad)**: `[2023-10-27T10:00:00Z] INFO: User 123 logged in from IP 192.168.1.1`
- **Structured JSON (Good)**:
  ```json
  {
    "timestamp": "2023-10-27T10:00:00Z",
    "level": "INFO",
    "message": "User logged in successfully",
    "event": {
      "type": "user_login",
      "userId": 123,
      "sourceIp": "192.168.1.1"
    }
  }
  ```
- **Benefit**: Structured logs can be easily ingested, indexed, and queried by a log aggregation system. You can run queries like `level:ERROR AND event.userId:123`.

### 3. What to Log

- **Log the "Why"**: Don't just log "Method called." Log the important context and the outcome.
- **Log Important Events**: Log at the boundaries of your application (e.g., incoming API requests) and at key business events (e.g., `OrderPlaced`).
- **Log Errors and Warnings**: Log every error, with the full stack trace and as much context as possible.
- **Don't Log Sensitive Data**: **Never** log passwords, API keys, credit card numbers, or other personally identifiable information (PII). This is a major security and privacy risk.

---

## 4. Log Aggregation

In a distributed, containerized environment, you might have hundreds of instances of your services running, and they are ephemeral. It is not feasible to SSH into each container to read its log files.

A **log aggregation system** is a centralized system that collects, stores, and analyzes logs from all your different services and servers in one place.

### The Log Aggregation Pipeline

1.  **Collection**: An "agent" running on each of your servers (or as a sidecar container) collects the logs.
2.  **Shipping/Ingestion**: The agent ships the logs to the central log management system.
3.  **Storage and Indexing**: The system stores the logs and indexes them to make them searchable.
4.  **Analysis and Visualization**: The system provides a UI that allows you to search, query, and visualize your logs, and to create dashboards and alerts.

### Popular Log Aggregation Stacks

- **The ELK Stack (or Elastic Stack)**: The most popular open-source solution.
  - **E**lasticsearch: A powerful search and analytics engine used to store and index the logs.
  - **L**ogstash: A data processing pipeline that ingests and transforms the logs.
  - **K**ibana: The web interface for searching and visualizing the logs.
  - (Often used with **Beats**, which is a family of lightweight data shippers for collecting the logs).
- **Other Solutions**: Splunk, Graylog, Datadog Logs, AWS CloudWatch Logs.

---

## 5. Correlation IDs

How do you trace a single user request as it flows through multiple microservices? Each service will produce its own log entries, but how do you tie them all together?

A **correlation ID** (also called a trace ID or request ID) is a unique identifier that is generated for a request when it first enters your system (e.g., at the API Gateway). This ID is then **passed along in the headers of every subsequent downstream call** between your microservices.

**Best Practice**: Every single log message that is generated as part of that request should include the correlation ID. This allows you to go into your log aggregation system and, with a single query, see the complete, ordered trail of logs for a single request across all your different services. This is an essential technique for debugging in a microservices architecture.

---

## 6. Summary and Mastery Checklist

-   [ ] I know that logging is for debugging and understanding specific events, while monitoring is for tracking aggregated metrics.
-   [ ] I can explain that **structured logging (JSON)** is a best practice because it makes logs machine-readable and queryable.
-   [ ] I know that I must **never log sensitive user data**.
-   [ ] I can explain that a **log aggregation** system (like the ELK Stack) is used to collect all logs from all services into a single, centralized place.
-   [ ] I can define a **correlation ID** and explain its importance for tracing a request across a distributed system.

---

## 7. Research and References

-   **"The Twelve-Factor App - XI. Logs"**: The classic guide to application logging. [Link](https://12factor.net/logs)
-   **OWASP - "Logging Cheat Sheet"**: A great security-focused guide to logging.
-   **Elasticsearch - "What is the ELK Stack?"**: [Link](https://www.elastic.co/what-is/elk-stack)
-   **"Logging in a Distributed System"**: A common topic for engineering blogs from companies like Uber and Netflix.
-   **OpenTelemetry**: The open-source standard that is standardizing the generation of logs, metrics, and traces.
