# Observability and Monitoring: Metrics Collection and Visualization

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a metric in the context of observability.
- **Differentiate** between a log and a metric.
- **Identify** the four main types of metrics (Counter, Gauge, Histogram, Summary).
- **Describe** the "pull" vs. "push" models for metric collection.
- **Recognize** Prometheus as a leading open-source monitoring system.
- **Understand** the role of a time-series database (TSDB).
- **Explain** the purpose of dashboards and alerting in a monitoring system.

---

## 2. Introduction: What is a Metric?

While logs record discrete, individual events, **metrics** are a numerical representation of data measured over a period of time. Metrics are **aggregates**. They are designed to be collected, stored, and queried very efficiently, and they are the foundation of modern monitoring and alerting.

- **Log**: "User 123 failed to log in at 10:00:01 AM." (A specific event).
- **Metric**: "The total number of failed logins in the last 1 minute was 5,210." (An aggregated number).

Metrics are what power your dashboards and tell you, at a glance, about the health of your system.

---

## 3. The Four Main Types of Metrics

When you instrument your application to expose metrics, you will typically use one of these four types. (These are the standard types used by the Prometheus monitoring system).

1.  **Counter**:
    - **What it is**: A cumulative metric that represents a single, monotonically increasing value. It can only go up or be reset to zero.
    - **Use Case**: Counting things.
      - Total number of HTTP requests.
      - Number of jobs completed.
      - Number of errors.
    - **Example**: `http_requests_total`

2.  **Gauge**:
    - **What it is**: A metric that represents a single numerical value that can arbitrarily go up and down.
    - **Use Case**: Measuring the current value of something.
      - Current memory usage.
      - Number of items in a queue.
      - Number of concurrent users.
    - **Example**: `memory_usage_bytes`

3.  **Histogram**:
    - **What it is**: A more complex metric that samples observations (usually request durations or response sizes) and counts them in configurable buckets.
    - **Use Case**: Measuring latency. It allows you to calculate **percentiles** (e.g., the 95th or 99th percentile response time), which is crucial for understanding your system's performance.
    - **Example**: `http_request_duration_seconds`

4.  **Summary**:
    - Similar to a histogram, it also samples observations. It calculates configurable quantiles (percentiles) on the client-side and exposes them directly.

For measuring latency, **histograms are the generally recommended and most powerful choice.**

---

## 4. Metrics Collection: Pull vs. Push

How do your metrics get from your application to your monitoring system?

- **Push Model**:
  - **How it works**: The application is responsible for "pushing" its metrics to the monitoring system at a regular interval.
  - **Example**: AWS CloudWatch works this way. Your application calls the CloudWatch API to send its metrics.

- **Pull Model**:
  - **How it works**: The application exposes its current metrics on a specific HTTP endpoint (e.g., `/metrics`). The monitoring system is then configured to "scrape" or "pull" the metrics from this endpoint at a regular interval (e.g., every 15 seconds).
  - **Example**: **Prometheus** uses a pull model. This is the dominant model in the modern, cloud-native ecosystem.

---

## 5. The Prometheus Ecosystem

**Prometheus** is the leading open-source monitoring and alerting system, and it is the second project to graduate from the Cloud Native Computing Foundation (CNCF), after Kubernetes.

**The components**:
1.  **Prometheus Server**: The core of the system. It is responsible for:
    - **Scraping**: Pulling metrics from your applications.
    - **Storage**: Storing the metrics in a highly efficient **time-series database (TSDB)**.
    - **Querying**: It provides a powerful query language called **PromQL** that allows you to slice, dice, and aggregate your metrics.
2.  **Client Libraries**: Libraries that you add to your application code to instrument it and expose the metrics in the Prometheus format.
3.  **Alertmanager**: A separate component that handles alerts. You define alerting rules in Prometheus. If an alert fires, Prometheus tells the Alertmanager, which is then responsible for deduplicating, grouping, and routing the alert to the correct notification channel (e.g., email, Slack, PagerDuty).

### Visualization with Grafana

Prometheus itself has a basic UI for querying. However, the standard and most powerful way to visualize Prometheus data is with **Grafana**.
- **Grafana** is an open-source visualization and analytics tool.
- You can connect it to a Prometheus server as a data source and then build rich, interactive **dashboards** to visualize the health and performance of your system.

---

## 6. The "Four Golden Signals"

When you are deciding what to monitor for a service, a great place to start is the "Four Golden Signals" from Google's Site Reliability Engineering book.

1.  **Latency**: The time it takes to serve a request. (Use a Histogram).
2.  **Traffic**: A measure of how much demand is being placed on your system (e.g., requests per second). (Use a Counter).
3.  **Errors**: The rate of requests that fail. (Use a Counter for the total number of errors).
4.  **Saturation**: How "full" your service is. (Use a Gauge).

If you are monitoring these four signals for every service in your system, you will have a very good high-level view of your system's health.

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain that a **metric** is a numerical, aggregated measurement of a system's behavior over time.
-   [ ] I can name the four types of metrics, and I know that a **Counter** is for counting things and a **Histogram** is for measuring latency.
-   [ ] I can describe the **pull model** of metrics collection used by **Prometheus**.
-   [ ] I know that Prometheus stores data in a **time-series database (TSDB)**.
-   [ ] I can name **Grafana** as the most popular tool for creating **dashboards** to visualize Prometheus metrics.
-   [ ] I can list the **Four Golden Signals** (Latency, Traffic, Errors, Saturation).

---

## 8. Research and References

-   **Prometheus Official Documentation**: [Link](https://prometheus.io/docs/introduction/overview/)
-   **Grafana Official Website**: [Link](https://grafana.com/)
-   **"Site Reliability Engineering: How Google Runs Production Systems"**: Chapter 6, "Monitoring Distributed Systems," is the source of the Four Golden Signals.
-   **"Prometheus: Up & Running" by Brian Brazil**: The definitive book on the Prometheus ecosystem.
-   **"The Four Golden Signals"**: A great article from Google's SRE book, available online.
