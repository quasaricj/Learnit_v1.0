# Observability and Monitoring: Distributed Tracing

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** distributed tracing and the problem it solves.
- **Explain** the key components of a trace: a Trace, a Span, and a Span Context.
- **Describe** how a trace context is propagated between services.
- **Understand** the role of "instrumentation" in generating trace data.
- **Recognize** OpenTelemetry as the open-source standard for observability.
- **Differentiate** between the three pillars of observability: logs, metrics, and traces.

---

## 2. Introduction: The Problem of "Why is it Slow?"

In a monolithic application, when a request is slow, you can use a profiler to figure out which function is taking all the time. In a **microservices architecture**, this is much harder. A single user request might travel through a dozen different, independent services before a final response is returned.

If that request is slow, how do you know where the bottleneck is? Is it the `APIGateway`? The `UserService`? The database call in the `OrderService`?

**Distributed tracing** is a technique that allows you to answer this question. It gives you the ability to profile and monitor a single request as it flows through all the different services in your distributed system.

---

## 3. The Components of a Trace

Distributed tracing is the third "pillar of observability," alongside logs and metrics.

- **Logs**: Tell you about a specific, discrete event.
- **Metrics**: Tell you about the aggregated health of a system.
- **Traces**: Tell you the **story** of a single request.

A trace is a visualization of the entire lifecycle of a request. It is made up of **Spans**.

### Span

- **What it is**: A **Span** represents a single unit of work or an operation within a request. It has a name, a start time, and a duration. Spans can be nested to form a parent-child relationship.
- **Examples of Spans**:
  - An incoming HTTP request to a service.
  - A database query.
  - A call to another microservice.

### Trace

- **What it is**: A **Trace** is a collection of all the Spans that are associated with a single request. It is represented as a tree of Spans.
- By looking at a trace in a visualization tool, you can see:
  - The total time the request took.
  - The path the request took through all your services.
  - How much time was spent in each individual service and in each operation (like a database call).
  - This makes it easy to pinpoint the source of latency.

### Span Context

- **What it is**: The "glue" that holds a trace together. The **Span Context** is a set of globally unique identifiers that includes the `trace_id` and the parent `span_id`.
- **Context Propagation**: When a service makes a call to another service, it is responsible for **propagating** the context by passing these IDs along, usually in the HTTP headers (like the `traceparent` header).
- When the downstream service receives the request, it extracts the context from the headers. Any new spans it creates will be a child of the incoming span and will be part of the same overall trace.

---

## 4. Instrumentation

How does your code generate this trace data? This process is called **instrumentation**.

- **Manual Instrumentation**: You can use a tracing library in your code to manually start and stop spans, and to add the context to your outbound requests. This is powerful but can be a lot of work.
- **Automatic Instrumentation**: This is the more common and preferred approach. You use an agent or a library that automatically "instruments" your code for you. It can automatically create spans for all incoming HTTP requests, outgoing HTTP calls, and database queries, without you having to change your code.

---

## 5. The OpenTelemetry Standard

For a long time, the world of tracing was fragmented, with many different competing vendors and open-source formats.

**OpenTelemetry (OTel)** is a CNCF (Cloud Native Computing Foundation) project that is the new, open-source **standard for observability**. It provides a single, unified set of APIs, libraries, agents, and collector services for capturing distributed traces, metrics, and logs from your applications.

- **How it works**:
  1.  You use the OpenTelemetry libraries for your language to **instrument** your application (often automatically).
  2.  Your application sends this observability data to an **OpenTelemetry Collector**.
  3.  The Collector can then be configured to export your data to a variety of backend systems, whether they are open source (like **Jaeger** or **Prometheus**) or commercial (like **Datadog** or **New Relic**).

By instrumenting your application with OpenTelemetry, you avoid vendor lock-in. You can change your backend observability platform without having to change your application's code.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that **distributed tracing** is a technique for monitoring a single request as it flows through a microservices system.
-   [ ] I know that the goal of tracing is to identify **bottlenecks** and sources of latency.
-   [ ] I can define a **Trace** as the story of a request, and a **Span** as a single operation within that request.
-   [ ] I can explain that the **Span Context** (containing the `trace_id`) is propagated between services in HTTP headers.
-   [ ] I have heard of **OpenTelemetry** as the open-source standard for instrumentation.
-   [ ] I can name the three pillars of observability: **logs**, **metrics**, and **traces**.

---

## 7. Research and References

-   **OpenTelemetry Official Website**: [Link](https://opentelemetry.io/)
-   **Jaeger**: A popular open-source, end-to-end distributed tracing system. [Link](https://www.jaegertracing.io/)
-   **"Distributed Tracing – we've been doing it wrong"**: An article that explains the importance of context propagation.
-   **"Mastering Distributed Tracing" by Yuri Shkuro** (the creator of Jaeger).
-   **Observability 101**: A good high-level overview of the three pillars.
