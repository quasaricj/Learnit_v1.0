# Observability and Monitoring: Alerting and Incident Response

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** an alert and its purpose in a monitoring system.
- **Explain** the principle of "alerting on symptoms, not causes."
- **Differentiate** between an alert and a notification.
- **Describe** the role of a tool like PagerDuty in managing alerts.
- **Understand** the basic concepts of an incident response process.
- **Define** an SLO (Service Level Objective) and its relationship to alerting.
- **Explain** the concept of an "error budget."

---

## 2. Introduction: From Monitoring to Action

Monitoring and dashboards are great for seeing the health of your system. But you can't stare at a dashboard 24/7. An **alert** is a notification that is automatically triggered when a monitoring system detects a potential problem.

The goal of alerting is to notify the right people at the right time about a problem, so that they can take action to resolve it before it has a significant impact on users. A good alerting strategy is a critical part of a reliable production system.

---

## 3. The Principles of Good Alerting

### 1. Alert on Symptoms, Not Causes

- This is a key principle from Google's Site Reliability Engineering (SRE) practice.
- You should alert on things that are **directly impacting your users** (the symptoms), not on the potential underlying causes.
- **Bad Alert (Cause)**: "CPU utilization on host XYZ is at 95%."
  - *Why it's bad*: High CPU might be perfectly fine. It might not be affecting users at all. This kind of alert is often "noisy" and leads to "alert fatigue."
- **Good Alert (Symptom)**: "The p99 latency for the `/api/login` endpoint has been above 500ms for the last 5 minutes."
  - *Why it's good*: This is a direct measure of a poor user experience. It is actionable and clearly indicates a real problem.
- **Good Alert (Symptom)**: "The error rate for the checkout service is above 1%."

### 2. Make Alerts Actionable

- Every alert that fires should be urgent, important, and should require a human to take an action.
- The alert notification should include a clear description of the problem and a link to a "playbook" or a dashboard to help the on-call engineer diagnose the issue.
- If an alert is not actionable, you should tune it or get rid of it.

---

## 4. Alerting Tools

- **Prometheus and Alertmanager**:
  - In the Prometheus ecosystem, you define your **alerting rules** in the Prometheus server.
  - When a rule's condition is met, Prometheus fires the alert and sends it to the **Alertmanager**.
  - The **Alertmanager** is responsible for deduplicating, grouping, and silencing alerts, and for routing the notifications to the correct channel.

- **Notification Channels**:
  - **Email / Slack / ChatOps**: For low-urgency, "warning" level alerts.
  - **PagerDuty / Opsgenie**: For high-urgency, critical alerts that require an immediate human response. These are on-call management tools that can manage schedules, escalate alerts, and wake people up in the middle of the night via a phone call.

---

## 5. Service Level Objectives (SLOs) and Error Budgets

A mature approach to alerting is based on **Service Level Objectives (SLOs)**.

- **SLO (Recap)**: A target for the performance or reliability of your service (e.g., "99.9% of requests in a month should be successful").
- **Error Budget**: The SLO gives you an **error budget**. If your availability SLO is 99.9%, it means you are "allowed" to have 0.1% of your requests fail over the course of the month.
  - `Error Budget = 100% - SLO`
- **Alerting on Burn Rate**: Instead of alerting on a simple error rate, you can create an alert based on how quickly you are "burning through" your monthly error budget.
  - **Example Alert**: "If the error rate over the last hour is so high that, if it continues, we will burn our entire 28-day error budget in just 2 days, then page the on-call engineer."
- **Benefit**: This approach is much better at catching a sustained, serious problem, while ignoring small, transient blips that are not a real threat to your overall reliability.

---

## 6. Incident Response

An **incident** is an event that is not part of the standard operation of a service and that causes, or may cause, an interruption to or a reduction in the quality of that service.

When a critical alert fires, it triggers an **incident response** process. This is a structured process for how the team should react to and manage the incident.

**A Basic Incident Response Flow**:
1.  **Alert**: A high-urgency alert fires and pages the on-call engineer.
2.  **Acknowledge**: The engineer acknowledges the page.
3.  **Triage**: The engineer does an initial investigation to determine the severity and impact of the issue.
4.  **Communicate**: The engineer opens a communication channel (like a Slack channel) and notifies the team and stakeholders.
5.  **Diagnose**: The team works together to find the root cause of the problem.
6.  **Mitigate**: The team takes action to fix the immediate problem (e.g., by rolling back a bad deployment, restarting a server).
7.  **Resolve**: Once the user impact is gone, the incident is considered resolved.
8.  **Postmortem**: After the incident is over, the team conducts a **blameless postmortem** to understand the root cause and to identify follow-up actions to prevent the same problem from happening again.

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain that an **alert** is an automated notification about a problem.
-   [ ] I know that it's better to **alert on symptoms** (like high error rate or latency) rather than causes (like high CPU).
-   [ ] I know that every alert should be **actionable**.
-   [ ] I can name a tool like **PagerDuty** that is used to manage on-call schedules and high-urgency alerts.
-   [ ] I can define an **SLO** as a target for my service's reliability.
-   [ ] I can define an **error budget** as the amount of allowable unreliability.
-   [ ] I understand the importance of a **blameless postmortem** as part of the incident response process.

---

## 8. Research and References

-   **"Site Reliability Engineering: How Google Runs Production Systems"**: Chapters 6 ("Monitoring Distributed Systems") and 10 ("Practical Alerting") are the definitive guides.
-   **"The Site Reliability Workbook"**: A more practical, hands-on companion to the SRE book.
-   **PagerDuty - "Incident Response"**: A guide from a leading company in the space. [Link](https://www.pagerduty.com/guides/incident-response/)
-   **"Alerting on SLOs"**: A great article from Google's SRE book.
