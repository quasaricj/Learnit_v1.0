# Observability: Alerting, SLAs, and Incident Response

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** and **differentiate** between Service Level Indicators (SLIs), Objectives (SLOs), and Agreements (SLAs).
-   **Explain** the concept of an "Error Budget" and how it empowers teams.
-   **Describe** the principles of creating actionable, symptom-based alerts to reduce alert fatigue.
-   **Outline** the key phases and roles of a structured incident response process.
-   **Understand** the purpose and principles of a blameless post-mortem (post-incident review).

---

## 2. Introduction: From Data to Action

Having logs, metrics, and traces is a great start, but data is useless without a plan for how to act on it. This is the "Monitoring" part of Observability. The goal is not just to see what's happening, but to be notified when things are going wrong and to have a clear, rehearsed plan for how to fix them.

This process revolves around three key activities:
1.  **Defining "good"**: What does it mean for our service to be healthy? (SLOs)
2.  **Notifying us when it's "bad"**: How do we get alerted when we're not meeting our goals? (Alerting)
3.  **Fixing it when it breaks**: What do we do when an alert fires? (Incident Response)

---

## 3. Defining "Good": SLIs, SLOs, and SLAs

These three terms, popularized by Google's Site Reliability Engineering (SRE) discipline, provide a formal framework for defining the reliability of your service.

-   **SLI (Service Level Indicator)**: A quantitative measure of some aspect of your service. It is the *thing you measure*.
    -   *Examples*: The latency of API requests, the error rate of a service, the throughput of a data pipeline.

-   **SLO (Service Level Objective)**: A target value for an SLI over a period of time. This is your **internal goal**. It is the promise you make to yourself and your internal users about the reliability of your service.
    -   *Examples*:
        -   "99.9% of `/login` requests will be successful over a 28-day window."
        -   "99% of `GET /users/{id}` requests will complete in under 250ms."

-   **SLA (Service Level Agreement)**: A formal, external contract with your customers that defines your SLOs and the consequences (e.g., financial penalties, service credits) if you fail to meet them. An SLA is typically a looser, less-strict subset of your internal SLOs.

### The Power of Error Budgets

An SLO is never 100%. The gap between your SLO and 100% is your **error budget**.
-   If your availability SLO is 99.9%, your error budget is 0.1%. This means you are "allowed" to be down for about 43 minutes per month.
-   The error budget is a data-driven tool for balancing reliability with feature development.
    -   If you have a lot of error budget left, you can take more risks: push new features, perform risky migrations.
    -   If you have burned through your error budget for the month, all new development stops, and the team's entire focus must be on improving reliability.

---

## 4. Actionable Alerting

The goal of an alert is to tell a human that they need to take action *right now*. A common failure mode for monitoring systems is **alert fatigue**: so many low-priority, unactionable alerts fire that engineers start ignoring them, and eventually miss the one that really matters.

### Principles of Good Alerting:

1.  **Alert on Symptoms, Not Causes**: Alert on things that are directly impacting the user (the symptom), not on the underlying cause.
    -   *Bad Alert*: "CPU utilization on host `db-prod-05` is 90%." (So what? Is the user affected?)
    -   *Good Alert*: "p99 query latency for the primary database has exceeded 500ms for 5 minutes." (This is a user-impacting symptom).
2.  **Alert on SLO Violations**: The best alerts are tied directly to your SLOs. You should be alerted when you are burning through your error budget at an unsustainable rate.
3.  **Have a Clear "Playbook"**: Every alert should have a corresponding document (a playbook) that tells the on-call engineer what the alert means, what its likely causes are, and what the first steps for mitigation should be.

---

## 5. Incident Response: What to Do When the Pager Goes Off

An **incident** is an event that causes a service to violate its SLOs (an outage or a degradation).

The **#1 goal of incident response is to restore service as quickly as possible**, not to find the root cause. The deep analysis can wait until after the incident is over.

### Key Roles:

-   **Incident Commander (IC)**: The person in charge. Their job is to manage the incident, not to fix it. They coordinate the team, manage communication to stakeholders, and make the final decisions.
-   **On-Call Engineer / Subject Matter Expert (SME)**: The hands-on person (or people) with the technical knowledge to investigate the system, form a hypothesis, and apply a fix.

### Common Mitigation Strategies (Your "Get Out of Jail Free" Cards):

-   **Rollback**: The first and best option is often to roll back the most recent deployment.
-   **Scale Up**: Add more instances to handle the load.
-   **Restart**: Sometimes, simply restarting a misbehaving service is the fastest path to recovery.
-   **Disable a Feature**: Use a feature flag to disable the broken part of the application.

---

## 6. Learning From Failure: The Blameless Post-mortem

After the service is restored, the work is not over. A **post-mortem** (or Post-Incident Review) is a written document that details the incident's timeline, its impact, the actions taken, and, most importantly, the **root cause** and the **follow-up action items** to prevent it from happening again.

The most important rule is **blamelessness**. The goal is to learn from failure, not to punish people. The analysis should focus on systemic weaknesses and process failures, not on the mistake of a single individual. "Human error" is never an acceptable root cause. The real root cause is "why was the system designed in a way that allowed a single human error to cause a catastrophic failure?"

---

## 12. Summary and Mastery Checklist

-   [ ] I can define an **SLI** (a metric), an **SLO** (an internal goal), and an **SLA** (an external contract).
-   [ ] I understand that an **Error Budget** is the allowable level of unreliability and is used to balance features vs. stability.
-   [ ] I know to create **actionable alerts** based on user-impacting symptoms and SLO violations.
-   [ ] I can describe the primary goal of **incident response** (restore service) and the key roles (Incident Commander).
-   [ ] I understand that a **blameless post-mortem** is a critical tool for learning from incidents and preventing their recurrence.

---

## 13. Research and References

-   **The Google SRE Book**: The definitive source for all of these concepts. [Link](https://sre.google/sre-book/landing/)
-   **The PagerDuty Incident Response Guide**: A great, practical guide from a company that is an expert in the field. [Link](https://response.pagerduty.com/)
-   **"The Phoenix Project" by Gene Kim, Kevin Behr, and George Spafford**: A novel that teaches DevOps principles, including incident management.
