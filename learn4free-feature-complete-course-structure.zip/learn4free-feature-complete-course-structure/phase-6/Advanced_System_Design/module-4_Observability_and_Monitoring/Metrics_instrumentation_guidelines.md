# Observability: Metrics Instrumentation Guidelines

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** "Instrumentation" as the process of adding code to an application to generate telemetry data.
-   **Describe** the three main metric types: Counters, Gauges, and Histograms/Summaries.
-   **List** and **describe** the "Four Golden Signals" of monitoring: Latency, Traffic, Errors, and Saturation.
-   **Apply** best practices for naming and labeling metrics to make them easily discoverable and queryable.
-   **Recognize** the importance of exposing a `/metrics` endpoint for collection by systems like Prometheus.

---

## 2. Introduction: The Art of Measuring

Metrics are the foundation of monitoring and alerting. But where do they come from? **Instrumentation** is the process of adding code to your application to record and expose these measurements.

Just like the instrument panel in an airplane, your application's metrics should give you a clear, at-a-glance view of its health. But a poorly designed instrument panel can be confusing and misleading. Effective instrumentation is about measuring the *right* things and exposing them in a standardized, understandable way.

---

## 3. The Four Golden Signals

This is a framework, popularized by Google's SRE book, that defines the four most important things you should be measuring for any user-facing system. If you can only measure four things, measure these.

1.  **Latency**:
    -   **Definition**: The time it takes to service a request.
    -   **Why it matters**: Slowness is a form of outage. It is crucial to track the latency of your responses.
    -   **How to measure**: It's important to track the *distribution* of latencies, not just the average. p50 (median), p95, and p99 latencies are standard.

2.  **Traffic**:
    -   **Definition**: A measure of how much demand is being placed on your system.
    -   **Why it matters**: It's your top-level indicator of system load. A sudden drop in traffic can be a sign of a major outage.
    -   **How to measure**: For a web service, this is typically measured in requests per second (RPS).

3.  **Errors**:
    -   **Definition**: The rate of requests that fail.
    -   **Why it matters**: This is a direct measure of your system's correctness and reliability.
    -   **How to measure**: The number of failed requests (e.g., HTTP `5xx` responses) as a percentage of total traffic.

4.  **Saturation**:
    -   **Definition**: How "full" your service is. A measure of the utilization of your most constrained resource.
    -   **Why it matters**: This is your early warning sign. It tells you when you are approaching a capacity limit, *before* it starts impacting latency or errors.
    -   **How to measure**: This is highly system-dependent. It could be CPU utilization, memory usage, or the depth of a message queue.

---

## 4. The Three Main Metric Types

Modern monitoring systems, like Prometheus, define several types of metrics. The three most common are:

1.  **Counter**:
    -   **What it is**: A single numerical value that only ever **increases**.
    -   **Use Case**: Counting the total number of things.
        -   `http_requests_total`
        -   `user_login_failures_total`
    -   The monitoring system can calculate the *rate* of change from this cumulative total.

2.  **Gauge**:
    -   **What it is**: A single numerical value that can go **up or down**.
    -   **Use Case**: Measuring a value at a specific point in time.
        -   `cpu_temperature_celsius`
        -   `queue_depth_current`
        -   `connected_users`

3.  **Histogram / Summary**:
    -   **What it is**: A more complex metric type used to measure the **distribution** of a set of observations.
    -   **Use Case**: Measuring things like request latency. A simple average can be misleading. A histogram allows you to calculate percentiles (p50, p95, p99), giving you a much better understanding of your users' experience.
        -   `http_request_duration_seconds`

---

## 5. Best Practices for Instrumentation

### Naming and Labeling

A good metric is like a good variable name: it should be clear and self-describing. The modern standard, popularized by Prometheus, is:

`application_subsystem_thing_being_measured_units`

-   Example: `api_http_requests_total`

To add dimensionality, we use **labels** (also called tags). A label is a key-value pair that allows you to slice and dice your data.

```
# A single metric with multiple label dimensions
api_http_requests_total{method="GET", path="/users/{id}", status="200"}  104
api_http_requests_total{method="GET", path="/users/{id}", status="500"}  3
api_http_requests_total{method="POST", path="/users", status="201"}      22
```

-   **Best Practice**: Use labels to separate the "what" from the "where." The metric name describes *what* you're measuring, and the labels describe the different contexts or dimensions (`path`, `status_code`, `region`, etc.).
-   **Caution**: Avoid high-cardinality labels. Do not put values like `user_id` or `request_id` in a label, as this will create millions of unique time series and overload your monitoring system.

### Exposing Metrics

Your application needs to expose these metrics on an HTTP endpoint, typically `/metrics`, in a format that your monitoring system can scrape. Fortunately, all major languages and frameworks have client libraries (especially for Prometheus) that handle this for you. Your job is simply to add the instrumentation code.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define **Instrumentation** as the code that generates metrics.
-   [ ] I can name the **Four Golden Signals**: Latency, Traffic, Errors, and Saturation.
-   [ ] I can describe the three main metric types: **Counters** (always go up), **Gauges** (go up and down), and **Histograms** (measure distributions).
-   [ ] I know to use **labels** to add dimensions to my metrics, and to avoid high-cardinality values in labels.
-   [ ] I understand that the standard practice is to expose metrics on a `/metrics` endpoint for scraping.

---

## 13. Research and References

-   **The Google SRE Book - Chapter 6, "Monitoring Distributed Systems"**: The source of the "Four Golden Signals."
-   **Prometheus Documentation - "Metric Types"**: The definitive guide for the most popular modern monitoring system. [Link](https://prometheus.io/docs/concepts/metric_types/)
-   **"Observability Engineering" by Charity Majors et al.**: Provides deep insights into the philosophy and practice of instrumentation.
