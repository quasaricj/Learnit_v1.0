# Observability: Monitoring with Prometheus and Grafana

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Describe** the roles of Prometheus and Grafana in a modern monitoring stack.
-   **Explain** Prometheus's "pull-based" or "scrape" model for collecting metrics.
-   **Define** a "time series" as the fundamental data model in Prometheus.
-   **Describe** the purpose of PromQL (Prometheus Query Language) for querying and aggregating metrics.
-   **Explain** Grafana's role as a visualization and dashboarding tool that uses Prometheus as a data source.
-   **Recognize** this combination as the de facto open-source standard for metrics-based monitoring.

---

## 2. Introduction: The de Facto Open-Source Stack

While there are many excellent commercial monitoring products (like Datadog and New Relic), the combination of **Prometheus** and **Grafana** has become the dominant open-source stack for metrics-based monitoring, particularly in the cloud-native and Kubernetes ecosystems.

They have distinct but highly complementary roles:
-   **Prometheus**: The backend. It is responsible for collecting, storing, and querying the metrics data. It is the database and the query engine.
-   **Grafana**: The frontend. It is responsible for visualizing the data stored in Prometheus (and many other data sources) by creating powerful, interactive dashboards.

---

## 3. Prometheus: The Monitoring Backend

Prometheus, a graduated project of the CNCF, is a powerful time-series database and monitoring system.

### The Pull Model

The core architectural feature of Prometheus is its **pull-based** (or **scrape**) model.
-   Your application instances are responsible for exposing their metrics on an HTTP endpoint (usually `/metrics`).
-   The central Prometheus server is configured with a list of "targets" to monitor.
-   Periodically (e.g., every 15 or 30 seconds), the Prometheus server makes an HTTP `GET` request to the `/metrics` endpoint of each target. It "scrapes" the current value of all the metrics, ingests them, and stores them in its time-series database.

This is different from older, "push-based" systems where the application is responsible for actively sending its metrics to the monitoring server.

### The Data Model: Time Series

The fundamental unit of data in Prometheus is a **time series**. A time series is a stream of timestamped values belonging to the same metric and the same set of labels.

-   `api_http_requests_total{method="POST", path="/users"}` is **one time series**.
-   `api_http_requests_total{method="GET", path="/users"}` is a **separate time series**.

### The Query Language: PromQL

Prometheus provides a powerful and expressive query language called **PromQL**. It allows you to select, filter, and aggregate your time-series data in real-time.

**Example Queries**:
-   Get the total number of HTTP requests:
    `api_http_requests_total`

-   Calculate the per-second rate of all HTTP requests over the last 5 minutes:
    `rate(api_http_requests_total[5m])`

-   Get the 95th percentile latency for API requests:
    `histogram_quantile(0.95, sum(rate(api_request_duration_seconds_bucket[5m])) by (le))`

PromQL is the engine that allows you to turn raw metric data into meaningful insights.

---

## 4. Grafana: The Visualization Frontend

While Prometheus is excellent at storing and querying data, its built-in visualization tools are basic. **Grafana** is an open-source analytics and interactive visualization web application. It allows you to create beautiful, complex, and highly customized dashboards.

### How it Works with Prometheus:

1.  **Add a Data Source**: You configure Grafana to connect to your Prometheus server by giving it the server's URL.
2.  **Create a Dashboard**: You create a new dashboard and add panels to it.
3.  **Write Queries**: For each panel (e.g., a graph, a single stat, a gauge), you write a **PromQL query**. Grafana sends this query to Prometheus, gets back the time-series data, and then renders it in the panel.

![Grafana Dashboard Example](https://grafana.com/static/assets/img/blog/kubernetes_monitoring.png)

Grafana allows you to combine data from multiple sources, use variables to create dynamic dashboards (e.g., select a service from a dropdown to see its metrics), and share your dashboards with your team. It is the primary way that engineers interact with and understand the metrics collected by Prometheus.

---

## 5. A Complete Monitoring Workflow

1.  **Instrumentation**: You add a Prometheus client library to your application and use it to expose metrics (counters, gauges, histograms) on a `/metrics` endpoint.
2.  **Collection**: You configure your Prometheus server to discover and scrape the `/metrics` endpoint of all your running application instances.
3.  **Alerting**: You configure alerting rules directly in Prometheus. If a PromQL query for a dangerous condition (e.g., high error rate) returns a value, Prometheus's Alertmanager component will fire an alert and send a notification to a system like PagerDuty or Slack.
4.  **Visualization**: You connect Grafana to your Prometheus server as a data source and build dashboards to visualize your key SLIs (like the Four Golden Signals) and other important metrics.

---

## 12. Summary and Mastery Checklist

-   [ ] I can describe the roles of **Prometheus** (the backend: collection, storage, querying) and **Grafana** (the frontend: visualization, dashboarding).
-   [ ] I understand Prometheus's **pull-based model** where it "scrapes" metrics from a `/metrics` endpoint.
-   [ ] I know that **PromQL** is the powerful query language used to interact with Prometheus data.
-   [ ] I can explain that Grafana uses a Prometheus data source to execute PromQL queries and render the results in dashboard panels.
-   [ ] I recognize the Prometheus + Grafana stack as a powerful, open-source standard for modern monitoring.

---

## 13. Research and References

-   **Prometheus Documentation**: The official and comprehensive source for all things Prometheus. [Link](https://prometheus.io/docs/introduction/overview/)
-   **Grafana Documentation**: The official documentation for Grafana.
-   **"Prometheus: Up & Running" by Brian Brazil**: A great book for a deep dive into Prometheus.
