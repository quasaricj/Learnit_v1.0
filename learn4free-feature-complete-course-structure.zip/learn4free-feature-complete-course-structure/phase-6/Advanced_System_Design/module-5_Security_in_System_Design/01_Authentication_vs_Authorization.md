# Security in System Design: Authentication vs. Authorization

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define and clearly differentiate** between Authentication (AuthN) and Authorization (AuthZ).
- **Provide** a real-world analogy to explain the difference.
- **Explain** the role of an Identity Provider (IdP).
- **Describe** common authentication factors (something you know, have, are).
- **Describe** common authorization models (e.g., Role-Based Access Control - RBAC).
- **Understand** that both AuthN and AuthZ are critical components of a secure system.

---

## 2. Introduction: The Two Pillars of Access Control

In system security, **access control** is the process of restricting access to resources. It is governed by two fundamental and distinct concepts: Authentication and Authorization. While they are often used together and are closely related, they are not the same thing. Understanding the difference is the first step in designing a secure system.

---

## 3. Authentication (AuthN)

- **The Question**: **"Who are you?"**
- **Definition**: **Authentication** is the process of **verifying a user's identity**. It's about proving that you are who you say you are.
- **The Process**: A user presents a set of **credentials** to the system. The system validates these credentials against a trusted source. If they match, the user is authenticated.
- **Analogy**: **Showing your ID to the security guard at the entrance of a building.** The guard is checking your identity to make sure you are on the list of people allowed to enter the building.

### Authentication Factors

Authentication is based on one or more "factors":
1.  **Something you know**: A password, a PIN, a secret question.
2.  **Something you have**: A physical object, like a mobile phone (for an SMS code), a hardware security key (like a YubiKey), or a key card.
3.  **Something you are**: A biometric factor, like a fingerprint, a face scan, or a retina scan.

**Multi-Factor Authentication (MFA)** is the practice of requiring two or more of these factors to authenticate, which provides a much higher level of security than just a password.

### Identity Provider (IdP)

- An **Identity Provider** is a trusted system that is responsible for managing a user's identity and for handling the authentication process.
- In a modern system, you often delegate the authentication to a dedicated IdP.
- **Examples**: Auth0, Okta, or social logins like "Login with Google" or "Login with Facebook".

---

## 4. Authorization (AuthZ)

- **The Question**: **"What are you allowed to do?"**
- **Definition**: **Authorization** is the process of **determining if an authenticated user has the permission** to perform a specific action or to access a specific resource.
- **The Process**: Authorization happens *after* a user has been successfully authenticated. The system checks the user's identity against a set of rules or policies to decide if the requested action is permitted.
- **Analogy**: **Your key card for the building.** After the security guard has verified your identity (authentication), you use your key card to try to open a door. The key card system checks if you are *authorized* to open that specific door. You might be allowed to enter the main lobby but not the secure server room.

### Authorization Models

- **Access Control Lists (ACLs)**: A list of permissions attached to an object.
- **Role-Based Access Control (RBAC)**: This is the most common model.
  - Permissions are associated with **roles** (e.g., `admin`, `editor`, `viewer`).
  - Users are then assigned one or more **roles**.
  - This is much easier to manage than assigning permissions directly to individual users.
- **Attribute-Based Access Control (ABAC)**: A more fine-grained and powerful model where access rights are granted to users through the use of policies which combine attributes together.

---

## 5. The Relationship

Authentication and Authorization always work in sequence.

`Request -> Authentication -> Authorization -> Access Granted/Denied`

1.  A user makes a request.
2.  The system first authenticates the user to verify their identity.
3.  If authentication is successful, the system then checks if that verified identity is authorized to perform the requested action.
4.  If authorization is successful, the system grants access.

You cannot have authorization without authentication. It makes no sense to ask "What is this person allowed to do?" if you don't first know who the person is.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that **Authentication (AuthN)** is about proving **identity** ("Who are you?").
-   [ ] I can explain that **Authorization (AuthZ)** is about granting **permissions** ("What can you do?").
-   [ ] I can use the "ID card and key card" analogy to clearly explain the difference.
-   [ ] I know that authorization always comes *after* successful authentication.
-   [ ] I can list the three types of authentication factors (know, have, are).
-   [ ] I can describe **Role-Based Access Control (RBAC)** as a common model for managing permissions.

---

## 7. Research and References

-   **OWASP - "Authentication Cheat Sheet"**: [Link](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html)
-   **OWASP - "Authorization Cheat Sheet"**: [Link](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)
-   **"What's the Difference Between Authentication and Authorization?"**: A very common topic for security blogs and articles.
-   **Auth0 Blog**: A fantastic resource for articles on identity and security.
-   **NIST Digital Identity Guidelines**: The official US government standards for authentication.
