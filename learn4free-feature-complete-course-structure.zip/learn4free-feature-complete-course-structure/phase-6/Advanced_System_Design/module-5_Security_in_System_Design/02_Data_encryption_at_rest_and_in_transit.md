# Security in System Design: Data Encryption

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** data encryption and its purpose.
- **Differentiate** between Encryption in Transit and Encryption at Rest.
- **Explain** the role of TLS (Transport Layer Security) for encrypting data in transit.
- **Describe** how data is encrypted at rest in cloud storage and databases.
- **Understand** the importance of key management.
- **Recognize** that encryption is a fundamental requirement for protecting sensitive data.

---

## 2. Introduction: Protecting Data Everywhere

**Encryption** is the process of converting data from a readable format (plaintext) into an unreadable, encoded format (ciphertext). Only a party that has the correct **key** can decrypt the ciphertext and read the original data.

Encryption is a fundamental tool for ensuring **confidentiality**. It is the primary defense against an attacker who has managed to bypass your other security layers. Even if an attacker manages to steal your data, if it is properly encrypted, it will be useless to them.

In a modern system, you must protect your data in its two main states: when it is moving across a network, and when it is being stored on a disk.

---

## 3. Encryption in Transit

- **What it is**: Encrypting data before it is sent over a network and decrypting it at the other end.
- **The Threat**: An attacker who can "sniff" the network traffic (a "man-in-the-middle" attack). If the data is sent in plaintext, the attacker can read it.
- **The Solution**: **TLS (Transport Layer Security)**.
  - TLS is the cryptographic protocol that powers **HTTPS**. It is the standard for all web security.
  - When your browser connects to a website with `https://`, it is using TLS to create a secure, encrypted channel between your browser and the web server.
  - TLS uses a system of **public-key cryptography** and **SSL certificates** to establish this secure channel.
- **The Rule**: **All communication over an untrusted network (like the public internet) MUST be encrypted with TLS.** There is no excuse not to use HTTPS for your websites and APIs.
- **Internal Traffic**: It is also a best practice to use TLS to encrypt the traffic *between* your own microservices inside your private cloud network. This is known as "mutual TLS" (mTLS).

---

## 4. Encryption at Rest

- **What it is**: Encrypting data before it is written to a non-volatile storage medium, like a hard drive (SSD) or an object store.
- **The Threat**: An attacker who gains physical access to your hardware. If they can steal a hard drive from your data center, and the data is not encrypted, they can read everything on it.
- **The Solution**: All modern cloud services and database systems provide options for transparent data encryption at rest.
  - **Cloud Storage (AWS S3, Azure Blob Storage)**: These services offer server-side encryption. When you upload a file, the service automatically encrypts it before saving it to disk and automatically decrypts it for you when you download it.
  - **Cloud Databases (AWS RDS, Azure SQL)**: These managed database services can automatically encrypt the underlying storage that your database runs on.
- **The Rule**: **All sensitive data stored at rest should be encrypted.**

---

## 5. Key Management

Encryption is only as strong as the security of the keys. If an attacker can steal your encryption key, they can decrypt all your data. **Key management** is the process of securely managing your cryptographic keys.

- **The Challenge**: Where do you store the key? You can't store it on the same server as the data, because if the server is compromised, the attacker will get both.
- **The Solution**: A **Key Management Service (KMS)**.
  - A KMS is a dedicated, highly secure hardware and software system for generating, storing, and managing encryption keys.
  - All major cloud providers offer a KMS as a managed service:
    - **AWS KMS**
    - **Azure Key Vault**
    - **Google Cloud KMS**
- **How it works (Envelope Encryption)**:
  1.  You ask the KMS to generate a unique "data key" for each piece of data you want to encrypt.
  2.  You use this data key to encrypt your data.
  3.  You then ask the KMS to encrypt the *data key itself* using a central, highly protected "master key".
  4.  You store the encrypted data and the **encrypted data key** together.
  5.  To decrypt, you first ask the KMS to decrypt the data key, and then you use the decrypted data key to decrypt the data.
- **Benefit**: Your master keys never leave the secure, hardware-backed environment of the KMS. This is the standard and best practice for managing encryption at scale.

---

## 6. Summary and Mastery Checklist

-   [ ] I can define **Encryption** as the process of making data unreadable without the correct key.
-   [ ] I can explain that **Encryption in Transit** protects data as it moves across a network and is provided by **TLS (HTTPS)**.
-   [ ] I can explain that **Encryption at Rest** protects data as it is stored on a disk.
-   [ ] I know that I must use **HTTPS** for all my APIs.
-   [ ] I understand that **Key Management** is critical for security, and that I should use a dedicated service like **AWS KMS** or **Azure Key Vault** to manage my encryption keys.

---

## 7. Research and References

-   **OWASP - "Transport Layer Protection Cheat Sheet"**: [Link](https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html)
-   **OWASP - "Cryptographic Storage Cheat Sheet"**: [Link](https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html)
-   **AWS KMS Documentation**: Provides a good overview of the concepts. [Link](https://aws.amazon.com/kms/)
-   **Let's Encrypt**: The non-profit certificate authority that provides free SSL/TLS certificates. [Link](https://letsencrypt.org/)
-   **"Cryptography Engineering: Design Principles and Practical Applications" by Niels Ferguson, Bruce Schneier, and Tadayoshi Kohno**: A great book on the practical application of cryptography.
