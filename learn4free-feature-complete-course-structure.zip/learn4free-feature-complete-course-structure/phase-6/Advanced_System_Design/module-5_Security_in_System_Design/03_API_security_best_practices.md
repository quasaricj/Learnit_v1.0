# Security in System Design: API Security Best Practices

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **List** and **describe** common API security threats.
- **Explain** the importance of input validation for preventing vulnerabilities like Injection and XSS.
- **Understand** the need for robust authentication and authorization.
- **Describe** the purpose of rate limiting and throttling.
- **Explain** why you should never expose database IDs in your URLs.
- **Apply** the principle of least privilege to your API design.

---

## 2. Introduction: Securing the "Front Door"

Your API is the "front door" to your application's data and logic. As such, it is a primary target for attackers. Securing your API is not a single action, but a multi-layered approach that combines many of the security concepts you have already learned.

This module recaps and reinforces some of the most important, practical best practices for designing secure APIs. A great reference for this is the **OWASP API Security Top 10**, a list of the most critical security risks for APIs.

---

## 3. The OWASP API Security Top 10 (Selected Best Practices)

### 1. Broken Object Level Authorization (BOLA)

- **The Threat**: This is the most common and severe API vulnerability. It occurs when an endpoint exposes an object ID in the URL, and the server does not correctly verify that the authenticated user has permission to access *that specific object*.
- **Example**: An API has an endpoint `GET /api/orders/{orderId}`. A user, Alice (ID `123`), makes a request to `GET /api/orders/xyz`. The server correctly authenticates Alice. However, `orderId` `xyz` belongs to another user, Bob. If the server does not check that `orderId xyz` actually belongs to `userId 123`, it will incorrectly return Bob's order details to Alice.
- **The Defense**: **Never trust the ID from the client.** For any request that tries to access a specific resource, your business logic must **always** verify that the authenticated user has the necessary permissions for *that resource*.

### 2. Broken Authentication

- **The Threat**: Authentication mechanisms are often implemented incorrectly, allowing attackers to compromise authentication tokens or to exploit implementation flaws to assume other users' identities.
- **The Defense**:
  - **Do not reinvent the wheel.** Use standard, well-vetted authentication patterns (like OAuth2) and libraries.
  - Use a dedicated Identity Provider (like Auth0 or Okta) if possible.
  - Protect against brute force attacks on your login endpoints with rate limiting and account lockout policies.
  - Use strong, secure JWTs with short-lived access tokens.

### 3. Injection

- **The Threat**: Injection flaws, such as **SQL Injection**, NoSQL Injection, and Command Injection, occur when untrusted data is sent to an interpreter as part of a command or query.
- **The Defense**: **Validate and sanitize all client-provided input.**
  - **Never** build a database query by concatenating strings with user input.
  - **Always** use an ORM (Object-Relational Mapper) or parameterized queries (prepared statements). These tools are specifically designed to treat user input as data, never as executable code.

### 4. Security Misconfiguration

- **The Threat**: This is a broad category that includes insecure default configurations, overly verbose error messages that leak information, and missing security headers.
- **The Defense**:
  - Have a repeatable, automated hardening process for your deployments.
  - **Never send detailed error messages or stack traces to the client in production.**
  - Add security-related headers to your API responses (e.g., `Strict-Transport-Security`, `Content-Security-Policy`).
  - Configure your Cross-Origin Resource Sharing (CORS) policy to be as restrictive as possible.

### 5. Lack of Resources & Rate Limiting

- **The Threat**: APIs that do not have rate limiting are vulnerable to Denial of Service (DoS) attacks and simple brute-force attacks.
- **The Defense**: Implement **rate limiting** and **throttling** at your API Gateway or load balancer. The limits should be based on the user, their API key, or their IP address.

---

## 4. Other Important Best Practices

### Use UUIDs instead of Auto-incrementing IDs in URLs

- **The Problem**: If you use sequential, integer IDs in your URLs (e.g., `/users/1`, `/users/2`), you are making it very easy for an attacker to guess the IDs of other resources and to try to exploit a Broken Object Level Authorization vulnerability (this is called an "IDOR" attack). It also leaks information about the size of your user base.
- **The Solution**: Use non-guessable, random IDs, such as **UUIDs (Universally Unique Identifiers)** in any public-facing URL or API response.
  - e.g., `GET /users/1a7b9f8e-8b1a-4b0f-8c1a-9c7b6a5b4d3e`

### The Principle of Least Privilege

- When designing your authorization model (e.g., RBAC), a user or a service should only be granted the **absolute minimum set of permissions** that they need to perform their job.
- An API token for a read-only analytics service should not have permission to delete data.

### Logging and Monitoring

- You must have detailed logs and monitoring for your API. This will allow you to detect suspicious activity, investigate security incidents, and identify potential attacks in progress.

---

## 5. Summary and Mastery Checklist

-   [ ] I am aware of the **OWASP API Security Top 10** as the primary guide for API security.
-   [ ] I can explain **Broken Object Level Authorization (BOLA)** and know that I must always verify that a user has permission to access the specific object they are requesting.
-   [ ] I know that **input validation** and **parameterized queries** are the primary defense against **Injection** attacks.
-   [ ] I understand that **rate limiting** is a critical defense against DoS and brute-force attacks.
-   [ ] I know that I should use non-guessable **UUIDs** in my public URLs instead of sequential integer IDs.

---

## 6. Research and References

-   **OWASP API Security Top 10 Project**: The definitive resource. [Link](https://owasp.org/www-project-api-security/)
-   **"API Security in Action" by Neil Madden**: A comprehensive book on the topic.
-   **"Hacking APIs" by Corey Ball**: A book that takes an attacker's perspective to show you how to find and fix vulnerabilities.
-   **The blogs of major authentication providers** (like Auth0 and Okta) are excellent resources for API security best practices.
