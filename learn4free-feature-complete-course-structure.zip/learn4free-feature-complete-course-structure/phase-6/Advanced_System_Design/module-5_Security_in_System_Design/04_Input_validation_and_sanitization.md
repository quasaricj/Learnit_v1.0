# Security in System Design: Input Validation and Sanitization

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** input validation and its importance as a security mechanism.
- **Explain** the principle of "never trust user input."
- **Differentiate** between validation and sanitization.
- **Describe** common types of validation (type, format, range, length).
- **Identify** common vulnerabilities that input validation helps to prevent (e.g., Injection, XSS).
- **Understand** that validation must always be performed on the server side.
- **Recognize** the importance of using a standard library for validation.

---

## 2. Introduction: The First Line of Defense

**Input validation** is the process of checking any data that is received from an external source to ensure that it is **well-formed, trustworthy, and safe** before it is processed by your application.

This is arguably the **single most important security principle** in web development. The vast majority of major security vulnerabilities, including SQL Injection, Cross-Site Scripting (XSS), and Command Injection, are the result of a failure to properly validate user-provided input.

The core principle is simple: **Never trust user input.** You must treat all data coming from a client as potentially malicious.

---

## 3. Validation vs. Sanitization

- **Validation**:
  - **What it is**: The process of **checking** if the input meets a set of criteria.
  - **The Action**: If the input is invalid, you **reject** it and return an error to the user.
  - **Example**: Checking if a `zip_code` field contains exactly 5 digits. If it contains letters, you reject the input.
  - **This should be your default and preferred approach.**

- **Sanitization**:
  - **What it is**: The process of **modifying** the input to make it safe.
  - **The Action**: You try to "clean up" the input by removing or modifying potentially malicious parts.
  - **Example**: A user submits a comment that contains `<script>alert('XSS')</script>`. A sanitization process would remove the `<script>` tags before storing the comment.
  - **The Danger**: Sanitization is very difficult to get right. It's easy to miss a clever variation of an attack (e.g., `<scr<script>ipt>`). You should only use sanitization when you have a specific business requirement to accept a certain type of complex input (like HTML in a blog post comment), and you should always use a well-vetted, standard library for it.

**Rule of Thumb**: **Validate, don't sanitize.** Rejecting invalid input is always safer than trying to clean it up.

---

## 4. Where to Validate

Validation must be performed at every trust boundary.

- **Client-Side Validation**:
  - **Where**: In the browser, using JavaScript or HTML5 attributes.
  - **Purpose**: To provide a better **user experience**. It gives the user immediate feedback that they have made a mistake (e.g., "Password must be at least 8 characters long").
  - **Security**: Client-side validation provides **zero security**. An attacker can easily bypass it by turning off JavaScript or by sending a raw HTTP request directly to your API.

- **Server-Side Validation**:
  - **Where**: In your backend application code.
  - **Purpose**: This is your **security boundary**. This is the validation that actually protects your application.
  - **The Rule**: **Server-side validation is mandatory and non-negotiable.** You must re-validate all data on the server, even if it has already been validated on the client.

---

## 5. What to Validate

You should validate against a strict "allow-list" of what is acceptable.

- **Data Type**: Is it a number, a string, a boolean?
- **Length**: Is the string within the expected minimum and maximum length?
- **Range**: Is the number within an acceptable range?
- **Format / Syntax**: Does the input match a specific format?
  - Is it a valid email address? (Use a regular expression).
  - Is it a valid UUID?
- **Allowed Values**: If the input can only be one of a few specific values (e.g., from a dropdown list), check that the submitted value is in that list.

**Use a Library**: Do not write your own validation logic from scratch. This is an error-prone and solved problem. Use a well-known, battle-tested validation library for your language or framework.
- **JavaScript/Node.js**: `express-validator`, `Joi`, `zod`
- **Python**: The validation features built into Django or Pydantic.
- **Java**: Jakarta Bean Validation (`javax.validation`).

---

## 6. Common Vulnerabilities Prevented by Validation

- **SQL Injection**: Prevented by using parameterized queries, but also by validating that an input that is supposed to be a number is actually a number.
- **Cross-Site Scripting (XSS)**: Prevented by correctly validating input and, crucially, by **output encoding** all data before it is rendered in an HTML page. (This is a separate but related concept).
- **Command Injection**: Prevented by validating that input does not contain any unexpected characters.
- **Broken Object Level Authorization**: While not a direct solution, validating that an ID is in the correct format (e.g., a UUID) can be a first layer of defense.

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain the principle of **"never trust user input."**
-   [ ] I know that **validation** is about **rejecting** bad input, while **sanitization** is about **modifying** it.
-   [ ] I understand that **validation is almost always the safer choice.**
-   [ ] I know that client-side validation is for UX, but **server-side validation is mandatory for security.**
-   [ ] I can list several types of validation to perform (type, length, range, format).
-   [ ] I know that I should use a **standard library** for validation instead of writing my own.

---

## 8. Research and References

-   **OWASP - "Input Validation Cheat Sheet"**: The definitive guide on this topic. [Link](https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html)
-   **OWASP - "Cross-Site Scripting (XSS) Prevention Cheat Sheet"**: Explains the importance of both input validation and output encoding.
-   **"Bobby Tables: A guide to preventing SQL injection"**: A classic web comic that every developer should know. [Link](https://xkcd.com/327/)
-   **Joi / express-validator / Pydantic documentation**: The documentation for these popular libraries provides great examples of how to implement validation rules.
