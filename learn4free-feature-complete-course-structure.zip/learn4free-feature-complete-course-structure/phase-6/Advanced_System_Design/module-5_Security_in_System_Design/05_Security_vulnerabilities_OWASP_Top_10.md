# Security in System Design: Security Vulnerabilities (OWASP Top 10)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** the OWASP Top 10 and its purpose.
- **Recognize** the OWASP Top 10 as the industry-standard awareness document for web application security.
- **Describe** at a high level some of the most critical risks from the list.
- **Relate** the vulnerabilities on the list to the security principles and best practices you have already learned.
- **Understand** that security is a broad and evolving field.

---

## 2. Introduction: The Most Common Threats

How do you know what to focus on when you are designing a secure system? The **OWASP (Open Web Application Security Project)** is a worldwide non-profit organization focused on improving the security of software.

Their most famous project is the **OWASP Top 10**. This is a standard awareness document for developers and web application security professionals. It represents a broad consensus about the most critical security risks to web applications. The list is updated every few years to reflect the changing landscape of web security.

Knowing the OWASP Top 10 is not about being a security expert. It is about being an **aware software developer**. It helps you to understand the most common ways that applications are attacked, so that you can design and build your code defensively.

---

## 3. A Tour of the OWASP Top 10 (2021 Edition)

This is a high-level summary. Many of these topics have been covered in more detail in previous security modules.

1.  **A01: Broken Access Control**:
    - **What it is**: Flaws that allow users to act outside of their intended permissions. This includes **Broken Object Level Authorization (BOLA)**, where a user can access another user's data.
    - **Defense**: This is the #1 risk. You must enforce authorization checks on every single request that accesses a private resource.

2.  **A02: Cryptographic Failures**:
    - **What it is**: Failures related to cryptography, which often lead to the exposure of sensitive data. This includes not using **Encryption in Transit (HTTPS)**, or storing data with weak or no **Encryption at Rest**.
    - **Defense**: Encrypt everything. Use modern, well-vetted cryptographic algorithms and a secure key management system.

3.  **A03: Injection**:
    - **What it is**: Flaws, such as **SQL Injection**, NoSQL Injection, and Cross-Site Scripting (XSS), where untrusted data is processed by an interpreter as a command.
    - **Defense**: **Input Validation** and, crucially, the use of **parameterized queries** or ORMs.

4.  **A04: Insecure Design**:
    - **What it is**: A new category that focuses on the risks associated with flaws in design and architecture. This is about failing to "shift security left" and not using **threat modeling** in the design phase.
    - **Defense**: Integrate security into every step of the SDLC.

5.  **A05: Security Misconfiguration**:
    - **What it is**: This includes insecure default configurations, open cloud storage, and overly verbose error messages.
    - **Defense**: A repeatable, automated hardening process for your deployments.

6.  **A06: Vulnerable and Outdated Components**:
    - **What it is**: Using libraries, frameworks, and other software modules with known security vulnerabilities.
    - **Defense**: Have a process for managing your dependencies. Use a tool (like **GitHub's Dependabot** or **Snyk**) to automatically scan your code for known vulnerabilities and to help you keep your dependencies up to date.

7.  **A07: Identification and Authentication Failures**:
    - **What it is**: Flaws in how you confirm a user's identity, such as allowing brute-force attacks or having a weak password policy.
    - **Defense**: Implement **Multi-Factor Authentication (MFA)**, rate limiting, and strong password policies.

8.  **A08: Software and Data Integrity Failures**:
    - **What it is**: Failures related to code and infrastructure that does not protect against integrity violations. A key example is downloading a dependency from an untrusted source without verifying its signature.
    - **Defense**: Ensure your CI/CD pipeline uses a secure, trusted source for all its dependencies.

9.  **A09: Security Logging and Monitoring Failures**:
    - **What it is**: Insufficient logging, monitoring, or alerting, which makes it impossible to detect and respond to an attack in a timely manner.
    - **Defense**: Implement robust logging, monitoring, and alerting for all security-sensitive events.

10. **A10: Server-Side Request Forgery (SSRF)**:
    - **What it is**: A vulnerability where a web application is tricked into making an arbitrary HTTP request to a domain of the attacker's choosing. This can be used to scan an internal network or to access internal services from a public-facing web server.
    - **Defense**: Your server-side code should never make a request to a URL provided by a user without first validating it against an "allow-list" of permitted domains.

---

## 4. How to Use the OWASP Top 10

- **As a Checklist**: When you are designing a new system, you can use the Top 10 as a mental checklist. Have I thought about access control? Am I protecting against injection?
- **As an Educational Tool**: Use it to learn about the most common types of attacks and to understand the "why" behind security best practices.
- **As a Justification for Security Work**: You can use the Top 10 list to explain the importance of security work to non-technical stakeholders.

---

## 5. Summary and Mastery Checklist

-   [ ] I can define the **OWASP Top 10** as an industry-standard list of the most critical web application security risks.
-   [ ] I know that the list is an **awareness document** to help developers build more secure software.
-   [ ] I can recognize and describe at a high level at least one of the top three risks: **Broken Access Control**, **Cryptographic Failures**, or **Injection**.
-   [ ] I can see how the security best practices I have learned (e.g., input validation, HTTPS, RBAC) are a direct defense against the risks on this list.
-   [ ] I know that I should use a tool like **Dependabot** or **Snyk** to scan my project for vulnerable and outdated components.

---

## 6. Research and References

-   **OWASP Top 10 Official Website**: The full list, with detailed explanations, examples, and prevention advice for each risk. This is the primary source. [Link](https://owasp.org/www-project-top-ten/)
-   **"OWASP Top 10 for Dummies"**: A common format for introductory blog posts and videos.
-   **Snyk - "OWASP Top 10"**: A guide from a leading security company.
-   **"The Web Application Hacker's Handbook: Finding and Exploiting Security Flaws" by Dafydd Stuttard and Marcus Pinto**: A classic book that teaches you how to think like an attacker.
