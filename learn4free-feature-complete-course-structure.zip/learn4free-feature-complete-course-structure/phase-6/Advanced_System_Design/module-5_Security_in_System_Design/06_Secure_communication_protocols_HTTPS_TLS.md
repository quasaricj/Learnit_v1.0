# Security in System Design: Secure Communication Protocols (HTTPS, TLS)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** HTTPS and explain its importance.
- **Explain** the role of TLS (Transport Layer Security) as the protocol that powers HTTPS.
- **Describe** the three main security guarantees that TLS provides (Encryption, Integrity, Authentication).
- **Explain** at a high level how the TLS handshake works.
- **Define** the role of a Certificate Authority (CA).
- **Understand** that using HTTPS for all web traffic is a non-negotiable baseline for security.
- **Describe** how to use mutual TLS (mTLS) to secure communication *between* backend services.

---

## 2. Introduction: The Need for Secure Communication

The internet is an **untrusted network**. When your browser sends an HTTP request to a server, that request travels through many different routers and systems that are outside of your control. Any one of these intermediate systems could potentially:
- **Eavesdrop** on your communication (Confidentiality).
- **Tamper with** or modify your communication (Integrity).
- **Impersonate** the server you are trying to talk to (Authentication).

**HTTPS (Hypertext Transfer Protocol Secure)** is the secure version of HTTP. It is a protocol that uses **TLS (Transport Layer Security)** to create a secure channel for communication over an untrusted network.

---

## 3. The Three Guarantees of TLS

TLS provides three fundamental security guarantees:

1.  **Encryption (Confidentiality)**:
    - **What it is**: All data sent between the client and the server is encrypted.
    - **The Benefit**: It prevents an attacker from being able to read the content of your communication, such as your password on a login form or your credit card number.

2.  **Integrity**:
    - **What it is**: TLS uses a Message Authentication Code (MAC) to ensure that the data has not been altered or corrupted in transit.
    - **The Benefit**: It prevents an attacker from being able to modify the data. For example, they can't change the destination account number in a bank transfer request.

3.  **Authentication**:
    - **What it is**: The client can be sure that it is talking to the **real, legitimate server** that it thinks it is talking to.
    - **The Benefit**: This prevents "man-in-the-middle" (MITM) attacks, where an attacker impersonates the real server to try to steal your credentials.

---

## 4. How TLS Works (A High-Level Overview)

The process of establishing a secure TLS connection is called the **TLS handshake**.

1.  **Client Hello**: The client (your browser) sends a "hello" message to the server, which includes the versions of TLS it supports and a list of available cryptographic suites.
2.  **Server Hello and Certificate**: The server responds with its own "hello," chooses a cryptographic suite, and, most importantly, it presents its **SSL/TLS Certificate**.
3.  **Certificate Verification**: The client's browser verifies the certificate.
    - The certificate contains the server's public key and its domain name.
    - The certificate is digitally signed by a trusted third party called a **Certificate Authority (CA)** (e.g., Let's Encrypt, DigiCert).
    - The browser has a built-in list of trusted CAs. It checks that the signature on the certificate is valid and that the domain name on the certificate matches the domain name of the server it is trying to connect to. This is the **authentication** step.
4.  **Key Exchange**: The client and the server use the server's public key to securely exchange a **symmetric session key**.
5.  **Encrypted Communication**: All further communication between the client and the server is now encrypted using this shared, symmetric session key.

---

## 5. Mutual TLS (mTLS) for Service-to-Service Communication

TLS provides authentication for the *server*. The client knows it's talking to the right server, but the server doesn't know for sure who the client is (it relies on a password or a token at the application layer).

In a high-security microservices environment, you also want to secure the communication *between* your services. **Mutual TLS (mTLS)** is a technique where **both** the client and the server present certificates to each other and they both have to validate each other's identity.

- **Use Case**: This ensures that only authorized services within your network can communicate with each other. A `BillingService` can be configured to only accept connections from a `PaymentService` that presents a valid client certificate.
- **Implementation**: This is often implemented at the infrastructure level by a **service mesh** (like Istio or Linkerd).

---

## 6. The Bottom Line: Always Use HTTPS

For any public-facing website or API, using HTTPS is **not optional**. It is a fundamental baseline for security.
- Modern browsers will show a "Not Secure" warning for any site that is still using plain HTTP.
- Thanks to free and automated Certificate Authorities like **Let's Encrypt**, there is no longer any cost or excuse for not using HTTPS.
- Your web server or load balancer should be configured to automatically redirect all `http://` traffic to `https://`.

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain that **HTTPS** is the secure version of HTTP and is powered by **TLS**.
-   [ ] I can name the three security guarantees that TLS provides: **Encryption**, **Integrity**, and **Authentication**.
-   [ ] I know that the server's identity is authenticated by the client's browser by verifying its **TLS certificate**.
-   [ ] I know that a certificate is issued by a trusted **Certificate Authority (CA)**.
-   [ ] I understand that **all** public web traffic should be encrypted with HTTPS.
-   [ ] I have heard of **mutual TLS (mTLS)** as a way to secure communication between backend microservices.

---

## 8. Research and References

-   **"High Performance Browser Networking" by Ilya Grigorik**: Chapter 4 is a brilliant and detailed explanation of TLS. It is available for free online.
-   **OWASP - "Transport Layer Protection Cheat Sheet"**: The definitive guide for developers. [Link](https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html)
-   **Let's Encrypt**: Learn about how the process of getting a certificate has been automated. [Link](https://letsencrypt.org/)
-   **How does HTTPS actually work?**: A common topic for blog posts and videos with great visualizations of the handshake.
-   **Istio - "Mutual TLS"**: The documentation for a popular service mesh, explaining how mTLS is implemented.
