# Security: Authentication, OAuth, SAML, and SSO

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Differentiate** between Authentication ("who you are") and Authorization ("what you can do").
-   **Define** OAuth 2.0 and its primary use case: delegated authorization.
-   **Describe** the key actors in an OAuth 2.0 flow: Resource Owner, Client, and Authorization Server.
-   **Define** SAML (Security Assertion Markup Language) and its primary use case: enterprise federation and Single Sign-On (SSO).
-   **Define** Single Sign-On (SSO) and explain how it improves both user experience and security.
-   **Recognize** that these technologies are fundamental building blocks for modern, secure identity management.

---

## 2. Authentication vs. Authorization

These two terms are the foundation of access control, and they are often confused.

-   **Authentication (AuthN)**: This is the process of **verifying identity**. It answers the question, "Who are you?" This is what happens when you log in with a username and password, use a fingerprint, or present a passport at a border. The output of a successful authentication is a verifiable identity.

-   **Authorization (AuthZ)**: This is the process of **verifying permissions**. It answers the question, "What are you allowed to do?" This is what happens *after* you've been authenticated. Just because the system knows who you are doesn't mean you are allowed to access every resource. Authorization is about enforcing access control policies (e.g., "Only administrators can access the user management page").

In short: **Authentication proves you are who you say you are. Authorization determines what you can do.**

---

## 3. OAuth 2.0: Delegated Authorization

**OAuth 2.0 is an open standard for access delegation.** It is an authorization framework, not an authentication protocol (though it is often used as part of one).

-   **Core Problem it Solves**: How do you allow a third-party application (a **Client**) to access resources you own on another service (the **Resource Server**), without giving that application your password?
-   **Analogy**: The Hotel Key Card. When you check into a hotel, you (the **Resource Owner**) don't give the hotel your house keys. You go to the front desk (the **Authorization Server**), prove your identity, and they give you a key card (an **Access Token**). This key card has limited permissions: it can only open your room and the gym, and only for the duration of your stay. You can then use this key card (token) at the door (the **Resource Server**) to gain access.

### The OAuth 2.0 Actors:

-   **Resource Owner**: The user who owns the data.
-   **Client**: The third-party application that wants to access the user's data.
-   **Authorization Server**: The server that authenticates the user and issues the access token.
-   **Resource Server**: The server that hosts the user's data and accepts the access token.

-   **Common Use Case**: The "Log in with Google" or "Log in with Facebook" button. When you use this, you are telling an application (the Client) that you are authorizing it to access some of your information (like your name and email) from Google (the Resource Server). You authenticate with Google's Authorization Server, which then provides an access token to the application.

---

## 4. SAML: Enterprise Federation and Single Sign-On

**SAML (Security Assertion Markup Language)** is an older, XML-based open standard for exchanging authentication and authorization data between parties, in particular, between an **Identity Provider (IdP)** and a **Service Provider (SP)**.

-   **Core Problem it Solves**: How does a company (the **Identity Provider**, like Okta or Azure AD) securely tell a third-party SaaS application (the **Service Provider**, like Salesforce or Slack) that one of its employees is authenticated and what their role is?
-   **How it works**:
    1.  An employee tries to log in to the Service Provider (Salesforce).
    2.  Salesforce, which is configured to trust the employee's company, redirects the user's browser to the company's Identity Provider (Okta).
    3.  The employee logs in with their corporate credentials on the Okta login page.
    4.  Okta generates a **SAML Assertion** (a digitally signed XML document) that says, "I, Okta, certify that this user is `jane.doe@company.com` and she is a member of the `sales` group."
    5.  Okta sends this assertion back to the user's browser, which then forwards it to Salesforce.
    6.  Salesforce verifies the digital signature on the assertion, trusts the information from Okta, and logs the user in.

---

## 5. Single Sign-On (SSO)

**Single Sign-On (SSO)** is a property of an access control system, not a specific technology. It is the ability for a user to log in **once** with a single set of credentials and gain access to multiple, independent software systems without having to log in again.

Both SAML and OAuth (when used with a protocol layer like OpenID Connect) can be used to implement SSO.

-   **User Experience**: SSO is a massive improvement to the user experience. Users don't have to remember dozens of different passwords for all their different tools.
-   **Security**: SSO improves security.
    -   It reduces the number of places a password is stored, minimizing the attack surface.
    -   It allows the company to enforce strong security policies (like multi-factor authentication) in one central place (the Identity Provider).
    -   When an employee leaves the company, their access can be revoked in one place, and they immediately lose access to all connected applications.

---

## 12. Summary and Mastery Checklist

-   [ ] I can distinguish between **Authentication (verifying identity)** and **Authorization (verifying permissions)**.
-   [ ] I can describe **OAuth 2.0** as a framework for **delegated authorization**, enabling a third-party app to access my data without my password.
-   [ ] I can describe **SAML** as an XML-based standard for exchanging identity information, primarily used in **enterprise SSO**.
-   [ ] I can define **Single Sign-On (SSO)** as the "log in once" experience that allows a user to access multiple applications with a single set of credentials.
-   [ ] I recognize that an **Identity Provider (IdP)** is the central authority that manages a user's identity in an SSO system.

---

## 13. Research and References

-   **OAuth 2.0 Simplified**: A clear, easy-to-understand guide to the OAuth 2.0 framework. [Link](https://oauth.net/2/)
-   **Okta - "What is SAML?"**: A great overview from a major Identity Provider. [Link](https://www.okta.com/identity-101/what-is-saml/)
-   **"The OAuth 2.0 Authorization Framework" (RFC 6749)**: The official specification.
-   **OpenID Connect**: A simple identity layer built on top of OAuth 2.0, which is what actually turns OAuth into a full authentication protocol.
