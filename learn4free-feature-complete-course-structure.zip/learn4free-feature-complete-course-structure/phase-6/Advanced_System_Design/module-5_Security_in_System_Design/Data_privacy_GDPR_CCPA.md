# Security: Data Privacy and Regulations (GDPR, CCPA)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** "Personally Identifiable Information" (PII) as the data protected by privacy regulations.
-   **Identify** GDPR and CCPA as two of the most significant data privacy regulations.
-   **Describe** the core principles of modern data privacy laws, including Data Minimization, User Consent, and Data Portability.
-   **Explain** the technical challenges of implementing the "Right to be Forgotten."
-   **Understand** that data privacy is not just a legal requirement but a fundamental principle of trustworthy system design.
-   **Translate** these legal principles into concrete system design considerations.

---

## 2. Introduction: Privacy as a Design Concern

In the past, data was often collected and stored with little thought given to the privacy of the individuals it described. A series of high-profile data breaches and a growing awareness of the power of personal data have led to a new era of strict data privacy regulations.

As a system designer, you are no longer just responsible for building a functional system; you are a steward of your users' data. Privacy is now a first-class design concern, just like scalability and reliability. Failure to comply with these regulations can result in massive fines, reputational damage, and loss of user trust.

This lesson provides a high-level overview of the principles behind two key regulations:
-   **GDPR (General Data Protection Regulation)**: Enacted by the European Union, it is one of the most comprehensive and influential privacy laws in the world.
-   **CCPA (California Consumer Privacy Act)**: A landmark privacy law in the United States, granting consumers more control over their personal data.

---

## 3. Core Principles and Their Technical Implications

While the legal details are complex, the core principles of these regulations are similar and can be translated into concrete engineering requirements.

### 1. Data Minimization and Purpose Limitation

-   **Principle**: You should only collect the data you absolutely need to provide your service, and you should only use it for the specific purpose for which you collected it.
-   **Technical Implication**:
    -   **Be intentional**: Every field in your database should have a clear justification. Avoid collecting "nice-to-have" data that you *might* use in the future.
    -   **Audit your data**: Regularly review the data you store and delete anything that is no longer necessary.

### 2. User Consent and Transparency

-   **Principle**: You must obtain clear, explicit consent from users before collecting and processing their data. You must be transparent about what data you are collecting and how you are using it.
-   **Technical Implication**:
    -   **Granular Consent**: Your UI and backend must be able to manage granular consent flags (e.g., user agrees to marketing emails but not to third-party data sharing).
    -   **Privacy Policies**: Your system must be able to version and display clear privacy policies.

### 3. The Right to Access and Data Portability

-   **Principle**: Users have the right to request a copy of all the personal data you hold on them, in a common, machine-readable format.
-   **Technical Implication**:
    -   **Data Export Feature**: You must build a system (often a "self-serve" feature in the user's account settings) that can gather all of a user's PII from your various microservices and package it for export (e.g., as a JSON or CSV file). This can be a complex data-gathering exercise.

### 4. The Right to be Forgotten (Right to Erasure)

-   **Principle**: Users have the right to request that you permanently delete all of their personal data.
-   **Technical Implication**: This is often the **most difficult technical challenge**.
    -   **"Hard" vs. "Soft" Deletes**: Simply flagging a user as `is_deleted = true` in your main database (a "soft delete") is not enough. The data must be truly erased.
    -   **The Problem of Backups**: Your user's data will still exist in database backups, potentially for years. Your data retention policy must account for this, and you must have a process for ensuring the data is not restored from a backup.
    -   **The Problem of Logs**: Your user's IP address, name, or other PII might be scattered across years of application logs. Anonymizing or deleting this data is a massive challenge.
    -   **The Problem of Distributed Systems**: A single user's data might be replicated across a dozen different services and data stores. You need a robust, often Saga-based, process to coordinate the deletion across all of them.

---

## 5. Privacy by Design

The best approach is to practice **"Privacy by Design"**. This means building privacy considerations into your system from the very beginning, rather than trying to "bolt it on" at the end.

### Practical Design Patterns:

-   **Data Classification**: Identify and label all PII in your systems. Know what is sensitive and what is not.
-   **Anonymization and Pseudonymization**: Wherever possible, replace direct PII (like a name or email) with a non-identifiable token or pseudonym in your analytical systems.
-   **Centralized User Service**: Having a single service that owns the "master" record of a user can make it easier to manage privacy requests, as it provides a single point of entry.
-   **Data Retention Policies**: Automate the deletion of old data that is no longer needed. Don't store data forever "just in case."

---

## 12. Summary and Mastery Checklist

-   [ ] I know that modern regulations like **GDPR** and **CCPA** treat data privacy as a fundamental user right.
-   [ ] I can name several core principles of these laws, such as **Data Minimization**, **User Consent**, and the **Right to be Forgotten**.
-   [ ] I understand that the "Right to be Forgotten" is a particularly difficult technical challenge due to backups, logs, and the distributed nature of modern systems.
-   [ ] I can translate these legal requirements into practical design considerations, such as building data export features and implementing automated data retention policies.
-   [ ] I recognize that **Privacy by Design** means building privacy into the core architecture of a system from the start.

---

## 13. Research and References

-   **GDPR Full Text**: [Link](https://gdpr-info.eu/)
-   **CCPA Fact Sheet**: [Link](https://oag.ca.gov/privacy/ccpa)
-   **OWASP Top 10 Privacy Risks**: A great resource for understanding common privacy-related vulnerabilities in web applications.
-   **"The Architecture of Privacy" by Courtney Bowman et al.**: A book on building privacy-aware systems.
