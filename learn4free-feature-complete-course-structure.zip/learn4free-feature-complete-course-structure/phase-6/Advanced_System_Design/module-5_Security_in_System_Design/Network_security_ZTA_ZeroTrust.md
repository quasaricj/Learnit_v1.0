# Security: Network Security and Zero Trust Architecture (ZTA)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Describe** the traditional "castle-and-moat" (perimeter) security model and its weaknesses.
-   **Define** a Zero Trust Architecture (ZTA) and its core principle: "never trust, always verify."
-   **Explain** that in a Zero Trust model, network location is no longer a reliable indicator of trust.
-   **Define** Mutual TLS (mTLS) and its role in establishing strong, authenticated, and encrypted communication channels between services.
-   **Recognize** that a Service Mesh is a powerful tool for implementing a Zero Trust network for microservices.

---

## 2. The Old Model: The Castle and the Moat

For decades, network security was based on the **perimeter model**, also known as the "castle-and-moat" approach.

-   **The Idea**: The network was divided into a trusted "internal" zone (the castle) and an untrusted "external" zone (the world outside the moat).
-   **The Defense**: A strong firewall was placed at the perimeter to inspect all traffic coming in and out. The assumption was that anything *inside* the firewall was trusted and could communicate freely, while anything *outside* was untrusted.

### Why This Model is Broken

This model is no longer sufficient in the modern world of cloud computing, microservices, and remote work.
-   **Insider Threats**: It offers no protection against malicious actors who are already inside the network.
-   **The Blurring Perimeter**: Where is the "perimeter" when your applications are running in the cloud and your employees are working from home? The concept of a secure internal network is dissolving.
-   **Lateral Movement**: Once an attacker breaches the perimeter, they can often move laterally across the internal network with little resistance, as internal services are configured to trust each other by default.

---

## 3. The New Model: Zero Trust Architecture (ZTA)

**Zero Trust** is a modern security model that fundamentally inverts the "trust but verify" mindset. Its core principle is **"never trust, always verify."**

In a Zero Trust Architecture, there is no such thing as a "trusted" internal network. Every single request, regardless of where it originates from, must be treated as if it came from an untrusted, external network.

### The Core Principles of Zero Trust:

1.  **Identity is the New Perimeter**: Access is granted based on the authenticated identity of the user or service, not on its network location.
2.  **Authenticate and Authorize Everywhere**: Every request to access a resource must be authenticated (who are you?) and authorized (are you allowed to do this?). This applies to users *and* services.
3.  **Assume Breach**: You operate under the assumption that the network is already compromised.
4.  **Enforce Least Privilege**: Users and services should only be granted the absolute minimum level of access required to perform their specific function.

---

## 4. Implementing Zero Trust for Microservices: Mutual TLS (mTLS)

How do you implement Zero Trust for service-to-service communication? How does the `Order Service` *prove* to the `Payment Service` that it is who it says it is?

The answer is **Mutual TLS (mTLS)**.

-   **Standard TLS (the 'S' in HTTPS)**: When you connect to your bank's website, your browser (the client) verifies the bank's certificate (the server identity), and then an encrypted channel is established. This is **one-way authentication**. Your browser knows it's talking to the real bank, but the bank doesn't have a cryptographic way of knowing it's talking to your specific browser.

-   **Mutual TLS (mTLS)**: mTLS extends this process. Not only does the client verify the server's certificate, but the **server also demands and verifies a certificate from the client**. It's **two-way authentication**.

In an mTLS-enabled microservices architecture:
1.  Every single service (`Order Service`, `Payment Service`, etc.) is issued its own unique, short-lived x.509 certificate, which acts as its cryptographic identity.
2.  When the `Order Service` wants to call the `Payment Service`, they perform an mTLS handshake.
3.  The `Payment Service` presents its certificate. The `Order Service` verifies it.
4.  The `Order Service` presents *its* certificate. The `Payment Service` verifies it.
5.  Only after this mutual authentication is complete is an encrypted communication channel established.

This provides a strong, verifiable identity for every single request, which is the foundation of a Zero Trust network.

---

## 5. The Role of a Service Mesh

Implementing and managing mTLS for hundreds of services—including issuing and rotating thousands of certificates—is incredibly complex. This is a problem that is perfectly solved by a **Service Mesh** (like Istio or Linkerd).

A service mesh can automate the entire mTLS lifecycle:
-   It acts as a **Certificate Authority (CA)** to automatically issue a certificate to each service when it starts up.
-   The **sidecar proxy** (Envoy) next to each service transparently intercepts all traffic and performs the mTLS handshake on behalf of the application.
-   It automatically rotates the certificates frequently (e.g., every 24 hours) to reduce the window of opportunity for a compromised certificate.
-   The control plane can be used to define fine-grained authorization policies (e.g., "Allow `POST` requests from the `Order Service` to `/payments`, but deny all others").

By using a service mesh, you can enforce a strict Zero Trust policy on your network, without your application code needing to know anything about certificates, TLS, or security policies.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that the old "castle-and-moat" security model is outdated because the network perimeter is no longer well-defined.
-   [ ] I can define **Zero Trust Architecture** by its core principle: "never trust, always verify."
-   [ ] I know that in ZTA, access decisions are based on **authenticated identity**, not network location.
-   [ ] I can describe **Mutual TLS (mTLS)** as a mechanism for strong, two-way authentication between services.
-   [ ] I understand that a **Service Mesh** is a powerful tool that automates the implementation of mTLS and other Zero Trust principles.

---

## 13. Research and References

-   **NIST Special Publication 800-207 - "Zero Trust Architecture"**: The definitive technical guide from the US National Institute of Standards and Technology.
-   **Google's BeyondCorp**: Google's pioneering implementation of the Zero Trust model. [Link](https://cloud.google.com/beyondcorp)
-   **Istio Documentation - "Security"**: Explains in detail how a service mesh can be used to secure microservice communication. [Link](https://istio.io/latest/docs/concepts/security/)
