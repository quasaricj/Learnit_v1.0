# Security: Security Reviews and Threat Modeling

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Threat Modeling as a proactive and structured process for identifying and mitigating security risks.
-   **Explain** that threat modeling shifts security from a reactive to a proactive ("shift left") mindset.
-   **Describe** the four key questions of the threat modeling process.
-   **List** and **describe** the six threat categories of the STRIDE framework.
-   **Understand** how to use a system's data flow diagram as a basis for a threat modeling exercise.

---

## 2. Introduction: Thinking Like an Attacker

Security is not a feature you can add to a system at the last minute. A secure system must be designed with security in mind from the very beginning. But how do you find potential security flaws before you've even written the code?

**Threat Modeling** is a structured, systematic process for identifying potential security threats, vulnerabilities, and mitigations in a system during its design phase. It's an exercise in "thinking like an attacker." Instead of waiting for a vulnerability to be discovered, you proactively hunt for them on the whiteboard.

It's a collaborative process that brings together developers, architects, and security experts to analyze a system design and ask, "What could go wrong here?"

---

## 3. The Four Key Questions of Threat Modeling

A threat modeling session revolves around answering four fundamental questions:

1.  **What are we working on?**
    -   You start with a representation of your system, typically a Data Flow Diagram (DFD). This shows the components, data stores, external dependencies, and how data flows between them.

2.  **What can go wrong?**
    -   This is the core brainstorming phase. The team systematically examines every part of the diagram and identifies potential security threats. Frameworks like STRIDE are used to guide this process.

3.  **What are we going to do about it?**
    -   For each identified threat, the team proposes a mitigation. This could be a design change, a specific security control, or a code-level fix.

4.  **Did we do a good enough job?**
    -   The team reviews the mitigations to ensure they are sufficient and documents the findings, including any accepted risks.

---

## 4. The STRIDE Framework for Finding Threats

**STRIDE** is a mnemonic, developed by Microsoft, that helps structure the "What can go wrong?" phase. It provides six categories of threats to consider for each component and data flow in your diagram.

-   **S**poofing:
    -   *The Threat*: An attacker illegally assumes the identity of another user, component, or system.
    -   *Example*: A service calls another service with a fake user ID in a header.
    -   *Mitigation*: Strong authentication. Require signed JWTs for users; use mTLS for service-to-service communication.

-   **T**ampering:
    -   *The Threat*: An attacker modifies data in transit or at rest.
    -   *Example*: An attacker on the network intercepts a request to the payment service and changes the `amount` from $10 to $1.
    -   *Mitigation*: Data integrity controls. Use TLS for all communication to prevent tampering in transit. Use digital signatures or checksums for data at rest.

-   **R**epudiation:
    -   *The Threat*: A user or system denies having performed an action.
    -   *Example*: A user claims they never approved a financial transaction.
    -   *Mitigation*: Secure, non-repudiable audit logs. Log every critical action with a timestamp, the authenticated user, and the source IP address.

-   **I**nformation Disclosure:
    -   *The Threat*: An attacker gains access to sensitive information they are not authorized to see.
    -   *Example*: An API endpoint accidentally returns the password hashes for all users. A server misconfiguration exposes environment variables with database credentials.
    -   *Mitigation*: Defense in depth. Encrypt sensitive data both at rest and in transit. Enforce strict authorization. Sanitize API outputs.

-   **D**enial of Service (DoS):
    -   *The Threat*: An attacker makes a resource or service unavailable to legitimate users.
    -   *Example*: An unauthenticated endpoint performs a very expensive database query, allowing an attacker to easily overload the database.
    -   *Mitigation*: Rate limiting, throttling. Using CDNs to absorb traffic. Load balancing and auto-scaling.

-   **E**levation of Privilege:
    -   *The Threat*: A user with limited privileges is able to gain higher-level, administrative privileges.
    -   *Example*: A regular user finds a flaw that allows them to call an admin-only API endpoint to delete another user's account.
    -   *Mitigation*: Strict, centralized authorization and access control. Enforce the principle of least privilege.

---

## 5. The Threat Modeling Process in Practice

1.  **Schedule a meeting** with the key engineers and a security expert.
2.  **Before the meeting**, the lead engineer prepares a **Data Flow Diagram (DFD)** of the feature or system being designed.
3.  **During the meeting**, the team walks through the diagram, component by component, and data flow by data flow.
4.  For each element, the team brainstorms potential threats using **STRIDE** as a guide. "How could someone *spoof* this component? How could they *tamper* with this data flow?"
5.  All identified threats are documented.
6.  The team then discusses and documents a **mitigation** for each threat. Threats are often rated by risk (e.g., High, Medium, Low) to prioritize the most important fixes.
7.  The output is a **threat model document** that becomes part of the system's design documentation and creates a clear set of action items for the development team.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define **Threat Modeling** as a proactive security review process done during the design phase.
-   [ ] I understand that the goal is to "think like an attacker" and find vulnerabilities before code is written.
-   [ ] I can list the six categories of the **STRIDE** mnemonic: Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, and Elevation of Privilege.
-   [ ] I know that a **Data Flow Diagram** is the typical starting point for a threat modeling session.
-   [ ] I understand that the output of a threat model is a documented list of threats and their corresponding mitigations.

---

## 13. Research and References

-   **"Threat Modeling: Designing for Security" by Adam Shostack**: The definitive book on the topic by one of the creators of STRIDE.
-   **OWASP Threat Modeling Cheat Sheet**: A great, concise guide from the Open Web Application Security Project. [Link](https://cheatsheetseries.owasp.org/cheatsheets/Threat_Modeling_Cheat_Sheet.html)
-   **Microsoft's Threat Modeling Process**: Microsoft has extensive public documentation on their mature threat modeling practices.
