# Security: Common Web Vulnerabilities (OWASP Top 10)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Identify** the OWASP Top 10 as a standard awareness document for web application security.
-   **Define** SQL Injection (SQLi) and identify parameterized queries (prepared statements) as the primary defense.
-   **Define** Cross-Site Scripting (XSS) and identify output encoding and Content Security Policy (CSP) as the primary defenses.
-   **Define** Cross-Site Request Forgery (CSRF) and identify the use of anti-CSRF tokens as the primary defense.
-   **Recognize** that secure coding is a continuous practice, not a one-time fix.

---

## 2. Introduction: The OWASP Top 10

The Open Web Application Security Project (OWASP) is a non-profit foundation dedicated to improving software security. Their most famous project is the **OWASP Top 10**, a regularly updated report that outlines the 10 most critical security risks to web applications.

While the list changes over time, it consistently includes a core set of vulnerabilities that every system designer and developer must understand. Designing a system without considering these common attack vectors is negligent. This lesson will cover three of the most classic and dangerous vulnerabilities.

---

## 3. A01: Injection (Specifically, SQL Injection)

-   **What it is**: An injection attack occurs when untrusted user input is sent to an interpreter as part of a command or query. The most famous example is **SQL Injection (SQLi)**. This happens when an application constructs a raw SQL query by concatenating strings with user-provided data.
-   **The Attack**: Imagine your code builds a query like this:
    ```sql
    query = "SELECT * FROM users WHERE username = '" + userName + "';"
    ```
    An attacker can provide a `userName` like this: `' OR '1'='1`.
    The final query your database runs becomes:
    ```sql
    SELECT * FROM users WHERE username = '' OR '1'='1';
    ```
    This query will return **all** users in your database, bypassing authentication. A more malicious attacker could use `'; DROP TABLE users; --` to delete your entire database.

-   **The Defense: Parameterized Queries (Prepared Statements)**:
    -   You must **never** build queries by concatenating strings.
    -   Instead, use a library that supports **parameterized queries**. This separates the SQL command from the user data.
    ```java
    // Java JDBC Example
    PreparedStatement stmt = connection.prepareStatement("SELECT * FROM users WHERE username = ?");
    stmt.setString(1, userName); // The user data is sent separately
    ResultSet rs = stmt.executeQuery();
    ```
    -   The database engine is then able to distinguish between the command and the data, and it will treat the user input as literal data, not as executable code. This is the single most important defense against SQL injection.

---

## 4. A03: Cross-Site Scripting (XSS)

-   **What it is**: XSS is a vulnerability where an attacker is able to inject malicious client-side scripts (usually JavaScript) into a web page viewed by other users.
-   **The Attack**:
    -   **Stored XSS**: Imagine a comment field on a blog. An attacker posts a comment that includes a `<script>` tag: `Nice article! <script>malicious_code()</script>`. If the application doesn't properly sanitize this input, it will store the malicious script in the database. Now, every other user who views that blog post will have the malicious script executed in their browser, allowing the attacker to steal their session cookies, redirect them to a phishing site, or perform actions on their behalf.
    -   **Reflected XSS**: The malicious script comes from the current HTTP request (e.g., in a URL query parameter) and is reflected back in the server's response.

-   **The Defense: Output Encoding and Content Security Policy**:
    1.  **Context-Aware Output Encoding**: The primary defense is to **encode all untrusted data** before it is rendered in the HTML. Your templating engine should do this for you. For example, the character `<` would be transformed into its HTML entity `&lt;`. This ensures the browser treats the malicious input as literal text to be displayed, not as code to be executed.
    2.  **Content Security Policy (CSP)**: An HTTP response header that tells the browser which sources of content (scripts, images, etc.) are allowed to be loaded and executed. A strong CSP can provide a powerful second layer of defense, preventing the browser from executing malicious scripts even if an XSS flaw exists.

---

## 5. A05: Cross-Site Request Forgery (CSRF or XSRF)

-   **What it is**: A CSRF attack tricks an authenticated user into submitting a malicious request to a web application that they are currently logged into.
-   **The Attack**:
    1.  A user is logged into their banking website, `bank.com`.
    2.  They receive an email with a link that says "Cute Puppies!"
    3.  This link actually points to an attacker's website, `evil.com`. When the user clicks it, the attacker's page loads.
    4.  The HTML on `evil.com` contains a hidden form that automatically submits a `POST` request to `bank.com/transfer`. The request is to transfer money from the user's account to the attacker's account.
    5.  Because the user is already authenticated with `bank.com`, their browser will automatically include their session cookie with the `POST` request.
    6.  The bank's server sees a valid request from an authenticated user and processes the transfer. The user never knew it happened.

-   **The Defense: Anti-CSRF Tokens**:
    1.  When the user first loads a legitimate form on `bank.com` (like the transfer page), the server generates a unique, secret, unpredictable token (the "anti-CSRF token").
    2.  This token is embedded in the form as a hidden field.
    3.  When the user submits the form, the token is sent back to the server.
    4.  The server validates that the token in the submitted form matches the token it generated for that user's session.
    5.  The attacker on `evil.com` has no way of knowing what the correct token is for the user's session, so their forged request will be missing the valid token and will be rejected by the server.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define **SQL Injection** as an attack where malicious SQL is passed via user input, and I know that **parameterized queries** are the defense.
-   [ ] I can define **Cross-Site Scripting (XSS)** as an attack where malicious scripts are injected into a web page, and I know that **output encoding** is the defense.
-   [ ] I can define **Cross-Site Request Forgery (CSRF)** as an attack that forces an authenticated user to perform an unwanted action, and I know that **anti-CSRF tokens** are the defense.
-   [ ] I recognize that using modern, secure frameworks and libraries is a critical first step, as they often have these defenses built-in.

---

## 13. Research and References

-   **OWASP Top 10**: The official website with the full, up-to-date list and detailed explanations. [Link](https://owasp.org/www-project-top-ten/)
-   **OWASP Cheat Sheet Series**: An incredible collection of detailed, practical guides on how to defend against these and many other vulnerabilities. [Link](https://cheatsheetseries.owasp.org/)
-   **MDN Web Docs - "Content Security Policy (CSP)"**: [Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP)
