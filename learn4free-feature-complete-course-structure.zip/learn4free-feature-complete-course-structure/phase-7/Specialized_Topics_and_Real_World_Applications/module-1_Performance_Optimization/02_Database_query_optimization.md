# Performance Optimization: Database Query Optimization

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Explain** why the database is a common performance bottleneck in applications.
- **Use** the `EXPLAIN` (or `EXPLAIN ANALYZE`) command to view a query's execution plan.
- **Identify** a "full table scan" in an execution plan and understand why it's often bad.
- **Apply** indexing as the primary tool for query optimization.
- **Describe** common query optimization techniques (e.g., `SELECT` specific fields, avoid functions in `WHERE`).
- **Understand** the purpose of a database connection pool.
- **Recognize** that denormalization is a form of database optimization.

---

## 2. Introduction: The Database Bottleneck

For most data-driven applications, the **database is the single biggest performance bottleneck**. Your application code can run in microseconds, but a slow database query can take seconds or even minutes. A single, unoptimized query can bring your entire application to a halt.

**Database query optimization** is the process of tuning your database and your SQL queries to improve their performance. This is one of the most critical and high-impact skills for a backend or full-stack developer.

---

## 3. The Most Important Tool: `EXPLAIN`

How do you know if a query is slow, and why it's slow? You ask the database itself.

The **`EXPLAIN`** command is a special SQL command that asks the database's **query planner** to show you the **execution plan** it will use to run your query. It shows you what steps the database will take, in what order, and how it estimates the cost of each step.

- **Usage**: `EXPLAIN SELECT * FROM users WHERE email = '...';`
- **`EXPLAIN ANALYZE`**: A more powerful version (supported by PostgreSQL and MySQL) that actually *executes* the query and shows you the real time taken for each step, in addition to the plan.

### Reading the Plan: Index Scan vs. Full Table Scan

The most important thing to look for in an execution plan is how the database is finding the data.
- **Sequential Scan (or Full Table Scan)**: This means the database is reading **every single row** in the table to find the ones that match your `WHERE` clause. For a large table, this is extremely slow and inefficient.
- **Index Scan**: This means the database is using an **index** to quickly look up the location of the matching rows, without having to scan the whole table. This is what you want to see.

---

## 4. The Primary Solution: Indexing

As covered in the previous database module, **adding the right indexes is the most effective way to optimize a slow query.**

**Rule of Thumb**:
- You should have an index on your **primary keys** (this is done automatically).
- You should have indexes on all your **foreign keys**.
- You should have indexes on any other columns that are frequently used in `WHERE`, `JOIN`, or `ORDER BY` clauses.

A **composite index** (an index on multiple columns) can be used to optimize queries that filter on multiple columns at the same time.

---

## 5. Other Query Optimization Techniques

### 1. `SELECT` Only the Fields You Need

- **Anti-Pattern**: `SELECT *`.
- **Problem**: This forces the database to fetch all the data for all the columns in a row, even if your application only needs two of them. This wastes I/O and network bandwidth.
- **Solution**: Always specify the exact columns you need in your `SELECT` statement.

### 2. Avoid Functions in the `WHERE` Clause

- **Anti-Pattern**: `WHERE LOWER(username) = 'alice'`.
- **Problem**: Applying a function to a column in the `WHERE` clause often prevents the database from being able to use an index on that column.
- **Solution**: If you need to do case-insensitive searches, you can create a **function-based index** (e.g., an index on `LOWER(username)`).

### 3. Understand Your `JOIN`s

- Be aware of the cost of `JOIN`ing multiple, large tables.
- Ensure that the columns you are joining on are **indexed** (this is critical).

### 4. Denormalization

- As a last resort for extreme read-heavy workloads, you can use **denormalization**. By intentionally adding redundant data, you can avoid expensive `JOIN`s. This is a trade-off that should be made carefully.

---

## 6. Application-Level Optimizations

### 1. Connection Pooling

- **Problem**: Establishing a new connection to a database is a slow and expensive operation. If your application opens a new connection for every single query, your performance will be terrible.
- **Solution**: A **database connection pool** is a cache of database connections that are maintained so they can be reused. When your application needs to talk to the database, it "borrows" a connection from the pool. When it's done, it "returns" the connection to the pool, where it can be used by another request.
- **Best Practice**: All modern web frameworks and ORMs manage a connection pool for you. You just need to make sure it is configured correctly.

### 2. Caching

- The fastest query is the one you don't have to make at all.
- Caching the results of frequent and expensive database queries in an in-memory cache like **Redis** is a critical strategy for reducing the load on your database.

---

## 7. Summary and Mastery Checklist

-   [ ] I know that the database is a common performance bottleneck.
-   [ ] I can use the **`EXPLAIN ANALYZE`** command to see a query's execution plan and identify a **full table scan**.
-   [ ] I understand that **indexing** is the most important technique for query optimization.
-   [ ] I know that I should `SELECT` specific fields instead of using `SELECT *`.
-   [ ] I can explain that a **connection pool** is used to reuse database connections and avoid the high cost of creating new ones.
-   [ ] I understand that caching is a powerful way to reduce the read load on my database.

---

## 8. Research and References

-   **"Use The Index, Luke"**: A website dedicated to database performance and indexing. [Link](https://use-the-index-luke.com/)
-   **"High Performance MySQL" by Baron Schwartz, Peter Zaitsev, and Vadim Tkachenko**: The classic, deep-dive book on the topic.
-   **The PostgreSQL Documentation - "EXPLAIN"**: [Link](https://www.postgresql.org/docs/current/using-explain.html)
-   **"PgBouncer" / "HikariCP"**: Examples of popular, high-performance connection poolers.
-   **"How to read an `EXPLAIN ANALYZE` plan"**: A common topic for database-focused blog posts.
