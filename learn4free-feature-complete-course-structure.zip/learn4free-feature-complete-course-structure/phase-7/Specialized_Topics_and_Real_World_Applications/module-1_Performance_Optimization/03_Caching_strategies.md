# Performance Optimization: Advanced Caching Strategies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Recap** the purpose of caching and the cache-aside strategy.
- **Define** and **differentiate** between the cache-aside, read-through, and write-through caching patterns.
- **Describe** the write-back (or write-behind) caching pattern and its trade-offs.
- **Explain** the "thundering herd" problem and how a cache can help mitigate it.
- **Understand** cache eviction policies beyond simple TTL (e.g., LRU).
- **Recognize** that the choice of caching strategy depends on the application's specific read/write patterns and consistency requirements.

---

## 2. Introduction: Beyond Cache-Aside

Caching is a critical performance optimization technique. In a previous module, you learned about the most common caching pattern, **Cache-Aside (or Lazy Loading)**.

**Cache-Aside Recap**:
1.  Application checks the cache.
2.  If it's a **miss**, the application reads from the database and then writes the result to the cache.
3.  If it's a **hit**, the application reads from the cache.

In this model, the **application code is responsible for managing the cache**. This is simple and gives the application a lot of control. However, there are other caching patterns that can be more powerful in certain scenarios.

---

## 3. The Caching Patterns

### 1. Read-Through Cache

- **How it works**: The application treats the cache as its main data store and always talks directly to the cache. The cache itself is responsible for fetching data from the database on a cache miss.
  1.  The application asks the cache for an item.
  2.  **Cache Hit**: The cache returns the item.
  3.  **Cache Miss**: The cache is responsible for fetching the item from the underlying database, storing it in itself, and then returning it to the application.
- **Key Difference from Cache-Aside**: The **cache library/provider** (not the application code) is responsible for the logic of fetching from the database.
- **Benefit**: The application code is simpler.

### 2. Write-Through Cache

- **How it works**: When the application needs to write new data, it writes it **directly to the cache**. The cache is then responsible for immediately and **synchronously** writing that data to the underlying database.
- **The Flow**: `Application -> Cache -> Database`
- **Benefit**:
  - **Data Consistency**: The cache is never stale with respect to the database (for writes that go through this path).
  - When combined with a Read-Through cache, you get a system where the cache is always in sync, and the application only ever talks to the cache.
- **Drawback**:
  - **Higher Write Latency**: The write operation is not complete until the data has been written to both the cache and the database.

### 3. Write-Back Cache (or Write-Behind)

- **How it works**: This is a more advanced and performant write strategy. When the application needs to write new data, it writes it **only to the cache**.
- The cache immediately acknowledges the write to the application and then writes the data to the database **asynchronously** at a later time (e.g., after a few seconds, or by batching multiple writes together).
- **The Flow**: `Application -> Cache ... (later) ... -> Database`
- **Benefit**:
  - **Extremely Low Write Latency**: Write operations are incredibly fast because you are just writing to an in-memory cache.
- **Drawback**:
  - **Risk of Data Loss**: If the cache server crashes before it has had a chance to write the data to the database, that data is **lost forever**. This pattern is only suitable for data where a small amount of loss is acceptable.

---

## 4. Other Caching Concepts

### The "Thundering Herd" Problem (or Cache Stampede)

- **The Scenario**:
  1.  You have a very popular piece of data in your cache with a short TTL.
  2.  The TTL expires.
  3.  At that exact moment, thousands of concurrent user requests come in for that same piece of data.
- **The Problem**: All of those requests will result in a **cache miss**. All of them will then proceed to hit your database at the exact same time, potentially overwhelming it and causing it to crash.
- **A Simple Solution**: When a process gets a cache miss, instead of immediately fetching from the database, it can check a "lock" in the cache. Only the first process gets the lock and is allowed to fetch from the database and repopulate the cache. The other processes will wait a short time and then re-check the cache.

### Cache Eviction Policies

- **TTL (Time To Live)**: Simple, but not always the most efficient.
- **LRU (Least Recently Used)**: When the cache is full, the item that has been accessed the least recently is the first to be evicted. This is a very common and effective policy.
- **LFU (Least Frequently Used)**: Evicts the item that has been accessed the least frequently.
- **Random**: Simple and surprisingly effective in some cases.

---

## 5. Choosing a Strategy

| Strategy      | Write Latency | Data Consistency | Risk of Data Loss |
|---------------|---------------|------------------|-------------------|
| **Cache-Aside** | Normal (DB speed) | Eventual (TTL)   | Low               |
| **Write-Through** | High          | Strong           | Very Low          |
| **Write-Back**  | Very Low      | Eventual         | High              |

The choice of strategy depends entirely on your application's requirements:
- For most read-heavy applications, **Cache-Aside** is the simplest and best choice.
- **Write-Through** is good when you need strong consistency and can tolerate a slightly slower write.
- **Write-Back** is for write-heavy applications that need the absolute lowest latency and can tolerate a small amount of data loss.

---

## 6. Summary and Mastery Checklist

-   [ ] I can describe the **Read-Through** pattern, where the cache itself is responsible for fetching from the database.
-   [ ] I can describe the **Write-Through** pattern, where writes go to the cache and the database synchronously.
-   [ ] I can describe the **Write-Back** pattern, where writes go to the cache first and are written to the database asynchronously, and I understand the risk of data loss.
-   [ ] I can define the **"Thundering Herd"** problem.
-   [ ] I can name an eviction policy other than TTL, such as **LRU (Least Recently Used)**.

---

## 7. Research and References

-   **AWS - Caching Patterns**: A great whitepaper from AWS that describes these patterns in detail.
-   **"System Design Interview – An insider's guide" by Alex Xu**
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**
-   **Redis Documentation**: The Redis docs have great articles on caching patterns and best practices.
-   **Memcached Wiki**: Also contains good information on caching strategies.
