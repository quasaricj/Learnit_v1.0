# Performance Optimization: Load Testing and Stress Testing

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** performance testing and its purpose.
- **Differentiate** between load testing, stress testing, and soak testing.
- **Explain** the goals of a load test (to understand performance under expected load).
- **Explain** the goals of a stress test (to find the breaking point of the system).
- **Identify** key performance metrics to monitor during a performance test (e.g., latency, throughput, error rate).
- **Recognize** the names of popular open-source load testing tools (e.g., k6, JMeter).
- **Understand** that performance testing should be an automated part of your CI/CD pipeline.

---

## 2. Introduction: "How Much Can It Handle?"

You've deployed your application. Your monitoring shows that it's working correctly for a single user. But how will it behave under a real production load? How many concurrent users can it support before performance starts to degrade? At what point will it break?

**Performance testing** is a type of non-functional testing that is designed to answer these questions. It is the practice of simulating a load on your application to measure its performance and behavior under that load. It is a critical step in ensuring that your application is **scalable** and **reliable**.

---

## 3. Types of Performance Tests

### 1. Load Testing

- **The Question**: "How does the system perform under a **normal and expected** load?"
- **The Goal**:
  - To verify that the system can meet its performance SLOs (Service Level Objectives) under a realistic, peak production load.
  - To identify performance bottlenecks.
- **The Process**:
  1.  You define an expected load (e.g., "500 concurrent users" or "2000 requests per second").
  2.  You use a load testing tool to simulate this load for a fixed period of time.
  3.  During the test, you monitor your key performance metrics (latency, throughput, error rate) and the resource utilization of your system (CPU, memory).
- **The Outcome**: You get a baseline of your system's performance under a normal load.

### 2. Stress Testing

- **The Question**: "At what point does the system **break**?"
- **The Goal**:
  - To find the maximum capacity of the system.
  - To observe how the system behaves when it is pushed beyond its limits. Does it degrade gracefully, or does it crash and burn?
- **The Process**: You gradually increase the load on the system far beyond its expected peak, until it starts to produce a high number of errors or its latency becomes unacceptably high.
- **The Outcome**: You understand the upper limits of your system's capacity and its failure modes. This is critical for capacity planning.

### 3. Soak Testing (or Endurance Testing)

- **The Question**: "How does the system perform under a sustained load over a **long period of time**?"
- **The Goal**: To uncover issues that only appear after the system has been running for a long time.
- **The Process**: You run a normal load test, but for a much longer duration (e.g., 8, 12, or 24 hours).
- **The Outcome**: This type of test is excellent for finding **memory leaks**, database connection leaks, or other resource management issues.

---

## 4. The Performance Testing Process

1.  **Define Goals and SLOs**: What are you trying to achieve? What is the acceptable p99 latency for your API?
2.  **Create a Test Environment**: Performance testing should be done in a dedicated, production-like environment. **Never run a stress test against your actual production system.**
3.  **Script the Scenarios**: Use a load testing tool to create scripts that simulate your key user workflows.
4.  **Run the Test**: Execute the test and collect the results.
5.  **Analyze and Correlate**: Analyze the results from your load testing tool and correlate them with the monitoring data from your application and infrastructure. If you see a spike in latency, you should be able to correlate it with a spike in CPU or a database bottleneck.
6.  **Tune and Re-test**: Make a change to address the bottleneck you've found, and then run the test again to verify that the change had a positive effect.

---

## 5. Load Testing Tools

- **k6**: A modern, open-source, developer-friendly load testing tool. Your test scripts are written in JavaScript. It is known for its performance and ease of use.
- **Apache JMeter**: A very mature and powerful open-source tool from the Apache Foundation. It has a GUI for creating test plans and can be used for a wide variety of protocols.
- **Gatling**: Another popular open-source tool, focused on high performance. Your test scripts are written in Scala.
- **Commercial Tools**: BlazeMeter, LoadRunner.

---

## 6. Performance Testing in CI/CD

Performance testing should not be a one-off, manual process. It should be integrated into your CI/CD pipeline.
- You can have a stage in your pipeline that automatically runs a small-scale load test against your staging environment on every pull request.
- This creates a **performance regression test**. It ensures that a new code change has not introduced a significant performance degradation.

---

## 7. Summary and Mastery Checklist

-   [ ] I can explain that **performance testing** is about understanding how my system behaves under load.
-   [ ] I can define **Load Testing** as testing under a normal, expected load.
-   [ ] I can define **Stress Testing** as testing to find the breaking point of the system.
-   [ ] I can define **Soak Testing** as testing under a sustained load for a long period to find issues like memory leaks.
-   [ ] I know that performance testing should be done in a **dedicated, production-like environment.**
-   [ ] I can name a popular load testing tool, like **k6** or **JMeter**.
-   [ ] I understand that performance tests can and should be automated in a CI/CD pipeline.

---

## 8. Research and References

-   **The Art of Application Performance Testing" by Ian Molyneaux**: A good book on the practice of performance testing.
-   **k6 Official Documentation**: Has excellent tutorials and examples. [Link](https://k6.io/docs/)
-   **"Site Reliability Engineering: How Google Runs Production Systems"**: Has chapters on testing for reliability.
-   **"Performance Testing Guidance for Web Applications"** from Microsoft.
