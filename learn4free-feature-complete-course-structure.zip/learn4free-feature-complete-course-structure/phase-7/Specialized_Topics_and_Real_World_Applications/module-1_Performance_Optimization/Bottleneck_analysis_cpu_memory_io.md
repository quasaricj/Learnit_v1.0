# Performance Optimization: Bottleneck Analysis (CPU, Memory, I/O)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a "bottleneck" in the context of system performance.
-   **Identify** and **differentiate** between the three main types of resource bottlenecks: CPU-bound, Memory-bound, and I/O-bound.
-   **Describe** the common symptoms and causes for each type of bottleneck.
-   **List** common tools and metrics used to identify which resource is the limiting factor.
-   **Understand** that performance tuning is the science of identifying and widening the narrowest bottleneck in a system.

---

## 2. Introduction: What is a Bottleneck?

In any system, there is always one component that is the limiting factor for its overall performance. This is the **bottleneck**.

-   **Analogy**: Imagine a multi-lane superhighway that narrows down to a single lane for a toll booth. The toll booth is the bottleneck. It doesn't matter how fast cars can travel on the rest of the highway; the overall throughput of the system is limited by the rate at which cars can pass through that single lane.

Performance optimization is the process of:
1.  **Finding** the current bottleneck.
2.  **Widening** it (making it more efficient).
3.  **Repeating** the process, as a new bottleneck will now be exposed elsewhere.

A program's performance is almost always constrained by one of three physical resources: the **CPU**, **Memory**, or **I/O** (Input/Output).

---

## 3. CPU-Bound Bottlenecks

-   **Definition**: A system is CPU-bound when its performance is limited by the speed of the processor. The CPU is running at or near 100% utilization, while other resources like disk and network are often waiting.
-   **Analogy**: A brilliant mathematician who can solve complex problems very quickly, but only one at a time. The speed of calculation is the limit.

### Common Causes:

-   **Heavy Computation**: Algorithms with high time complexity (e.g., O(n^2) nested loops), complex mathematical calculations (e.g., in scientific computing or machine learning), or cryptographic operations.
-   **Inefficient Code**: Poorly optimized algorithms or code that does more work than necessary.
-   **Compression/Decompression**: These tasks are often computationally expensive.
-   **Rendering**: Graphics or video rendering is a classic CPU-intensive task.

### How to Identify:

-   **Metrics**: Consistently high CPU utilization (e.g., >80-90%) in monitoring tools (`top`, `htop`, Prometheus, cloud provider dashboards).
-   **Profiling**: Using a code profiler will show that the majority of the application's "wall clock time" is being spent executing specific functions on the CPU, not waiting for external resources.

---

## 4. Memory-Bound Bottlenecks

-   **Definition**: A system is Memory-bound when its performance is limited by the amount of available RAM or the speed of memory access.
-   **Analogy**: A chef with a very small countertop. They can only work with a few ingredients at a time and spend most of their time swapping ingredients between the countertop and the pantry (the slow disk).

### Common Causes:

-   **Large Datasets**: Loading huge files or database result sets into memory at once.
-   **Memory Leaks**: The application allocates memory but fails to release it when it's no longer needed. Over time, this consumes all available RAM and leads to a crash.
-   **Garbage Collection (GC) Pauses**: In managed languages (Java, C#, Go), the garbage collector may need to pause the application ("stop the world") to clean up memory, causing noticeable latency spikes.
-   **High Concurrency**: Each new thread or connection can consume a significant amount of RAM.

### How to Identify:

-   **Metrics**: High memory utilization, a steady increase in memory usage over time (indicates a leak), frequent and long GC pauses (from GC logs or application profilers).
-   **System Behavior**: The system becomes slow, and you observe high "swap usage" (`vmstat`, `top`), which means the OS is being forced to use the slow disk as an extension of RAM. The application may crash with an `OutOfMemory` error.

---

## 5. I/O-Bound Bottlenecks

-   **Definition**: A system is I/O-bound when it spends most of its time waiting for Input/Output operations to complete. During this time, the CPU is often idle.
-   **Analogy**: A manager who is waiting for information from other departments. They are ready to work, but they are blocked until they receive the documents they need.
-   **I/O comes in two main flavors**:
    1.  **Disk I/O**: Reading from or writing to a hard drive, SSD, or database.
    2.  **Network I/O**: Making a request to another service, an external API, or a database over the network.

### Common Causes:

-   **Slow Database Queries**: A query that has to scan millions of rows on disk without a proper index.
-   **N+1 Query Problem**: Making many small database queries in a loop instead of one larger, more efficient query.
-   **Slow Downstream Services**: Waiting for a response from a slow, third-party API.
-   **Reading/Writing Many Small Files**: The overhead of opening and closing files can be a significant bottleneck.

### How to Identify:

-   **Metrics**: **Low CPU utilization** is the key indicator. If your application is slow but your CPU is idle, you are almost certainly I/O-bound. High "iowait" time in tools like `top` or `iostat`.
-   **Profiling**: A profiler will show that the application is spending most of its time blocked on `read()`, `write()`, `socket.recv()`, or similar system calls.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define a **bottleneck** as the single component limiting a system's performance.
-   [ ] I can identify a **CPU-bound** system by its high CPU utilization and its association with heavy computation.
-   [ ] I can identify a **Memory-bound** system by its high memory usage, memory leaks, or frequent GC pauses.
-   [ ] I can identify an **I/O-bound** system by its **low CPU utilization** combined with slow performance, as it waits on disk or network operations.
-   [ ] I understand that the first step in optimization is always to **measure** and correctly identify the current bottleneck.

---

## 13. Research and References

-   **"Systems Performance" by Brendan Gregg**: The definitive, expert guide to performance analysis on Linux.
-   **Linux `perf` command**: A powerful and advanced profiling tool.
-   **VisualVM**: A visual tool for profiling Java applications, great for identifying CPU and memory bottlenecks.
-   **Using `top`, `iostat`, `vmstat`**: Essential Linux command-line tools for real-time performance analysis.
