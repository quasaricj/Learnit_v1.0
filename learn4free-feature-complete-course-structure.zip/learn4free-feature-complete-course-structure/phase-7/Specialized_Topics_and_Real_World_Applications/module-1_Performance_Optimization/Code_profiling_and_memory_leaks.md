# Performance Optimization: Code Profiling and Memory Leaks

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Code Profiling as the dynamic analysis of a program's performance.
-   **Differentiate** between CPU profiling and Memory profiling.
-   **Interpret** a flame graph to identify a CPU hotspot (a function where the application spends a lot of time).
-   **Define** a memory leak and its impact on an application.
-   **Describe** how a memory profiler (or heap analyzer) can be used to find the source of a memory leak.
-   **Recognize** that profiling is an essential, data-driven step that must come before any attempt at code optimization.

---

## 2. Introduction: Stop Guessing, Start Measuring

Bottleneck analysis can tell you *that* your application is CPU-bound or Memory-bound, but it can't tell you *why*. Which specific lines of code are causing the high CPU usage? Which objects are consuming all the memory?

You should **never** try to guess the answers to these questions. Performance optimization based on guesswork is almost always a waste of time. **Code Profiling** is the process of using a tool (a **profiler**) to gather detailed, function-level performance data from a running application. It replaces guesswork with data.

There are two primary types of profiling: CPU profiling and memory profiling.

---

## 3. CPU Profiling: Where is the Time Going?

A CPU profiler helps you understand which parts of your code are consuming the most CPU time.

### How it Works: Sampling Profilers

The most common type of profiler is a **sampling profiler**.
1.  It "wakes up" at a very high frequency (e.g., 100 times per second).
2.  Each time it wakes up, it takes a "snapshot" of the application's current **call stack**. The call stack is the list of functions that are currently being executed.
3.  It collects thousands of these samples.
4.  The functions that appear most frequently in the samples are, by definition, the ones where your program is spending the most time.

### Visualizing the Data: Flame Graphs

The standard way to visualize the output of a sampling profiler is a **flame graph**.

![Flame Graph Example](https://www.brendangregg.com/FlameGraphs/cpu-mysql-flamegraph.svg)
*(Image from brendangregg.com)*

-   **How to Read It**:
    -   The **y-axis** represents the stack depth (what function called what).
    -   The **x-axis** represents the number of samples. **A wider bar means that function appeared in more samples and is therefore a performance hotspot.**
-   **How to Use It**: You look for the widest plateaus in the graph. The function at the top of a wide plateau is the "leaf" function where your CPU is spending a lot of time. This is where you should focus your optimization efforts.

---

## 4. Memory Profiling: Where is the Memory Going?

A memory profiler helps you understand how your application is using memory. It can answer questions like:
-   What types of objects are consuming the most memory?
-   Where in the code are these objects being allocated?
-   Who is still holding a reference to this object, preventing it from being garbage collected?

### The Hunt for Memory Leaks

A **memory leak** is a condition where a program allocates memory for an object but never releases it, even after the object is no longer needed. In a long-running server application, even a small leak can eventually consume all available RAM and cause the application to crash with an `OutOfMemory` error.

### How it Works: Heap Analysis

1.  A memory profiler can take a **heap dump**, which is a complete snapshot of every object currently living in the application's memory (the "heap").
2.  The profiler can then analyze this dump and show you:
    -   A list of all objects, sorted by the total memory they consume.
    -   For any given object, it can show you the **reference chain** (or "path to GC root"). This is the chain of references that is keeping the object alive and preventing the garbage collector from cleaning it up.

By analyzing the reference chain for a large object that *should* have been released, you can pinpoint the exact place in your code that is holding onto the unnecessary reference, which is the source of your leak.

-   **Common Cause**: A classic example of a memory leak is adding objects to a global, static `List` or `Map` and never removing them. Since the global list lives forever, all the objects it references will also live forever.

---

## 5. Common Profiling Tools

Every major programming language has excellent profiling tools.

-   **Java**: VisualVM, JProfiler (commercial), YourKit (commercial). Built into most IDEs.
-   **Go**: `pprof`. Built directly into the Go runtime and toolchain.
-   **Python**: `cProfile` (built-in), `py-spy`.
-   **Node.js**: The V8 profiler, accessible via the Chrome DevTools.
-   **Linux (language-agnostic)**: `perf`, a powerful kernel-level profiler.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that **Code Profiling** is the data-driven way to find performance issues, and that I should always measure before I optimize.
-   [ ] I can distinguish between **CPU profiling** (finding slow code) and **Memory profiling** (finding memory-hungry code).
-   [ ] I can read a **flame graph** to identify CPU hotspots by looking for the widest function bars.
-   [ ] I can define a **memory leak** and explain how a **heap dump** can be used to find the reference chain that is keeping a leaked object alive.
-   [ ] I can name at least one profiling tool for my preferred programming language.

---

## 13. Research and References

-   **Brendan Gregg's Website**: The world's leading expert on systems performance and the inventor of the flame graph. An incredible resource. [Link](https://www.brendangregg.com/flamegraphs.html)
-   **VisualVM Homepage**: A great, free profiler for Java applications. [Link](https://visualvm.github.io/)
-   **Go Blog - "Profiling Go Programs"**: A practical guide to using `pprof`.
