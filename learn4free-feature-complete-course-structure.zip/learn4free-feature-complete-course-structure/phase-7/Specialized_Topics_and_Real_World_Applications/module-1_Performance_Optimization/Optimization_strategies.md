# Performance Optimization: Common Strategies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Apply** a systematic approach to optimization: identify the bottleneck type, then apply the appropriate strategy.
-   **List** at least three common strategies for optimizing I/O-bound systems (e.g., Caching, Indexing, Asynchronous Processing).
-   **List** at least two common strategies for optimizing CPU-bound systems (e.g., Algorithmic improvements, Horizontal Scaling).
-   **List** at least two common strategies for optimizing Memory-bound systems (e.g., Fixing leaks, Data Streaming).
-   **Internalize** the principle that optimization should be data-driven and focused on measured hotspots.

---

## 2. Introduction: Measure Twice, Cut Once

Once you have identified a bottleneck and profiled your code to find the hotspot, the final step is to apply an optimization strategy. The strategy you choose depends entirely on the nature of the bottleneck. Applying a CPU optimization to an I/O-bound problem will have no effect.

Remember the golden rule: **"Premature optimization is the root of all evil."** Never optimize code until you have measured and proven that it is a performance bottleneck. Clear, simple code is always preferable to complex, optimized code until performance requirements dictate otherwise.

---

## 3. Strategies for I/O-Bound Bottlenecks

I/O-bound systems spend most of their time waiting for a disk or network. Therefore, the goal is to **reduce the number of I/O operations or make them faster.**

### 1. Caching (The #1 Strategy)

-   **Strategy**: Store the results of expensive I/O operations in a fast, in-memory cache (like Redis or Memcached).
-   **Effect**: The next time the same data is requested, it can be served directly from the cache, completely avoiding the slow database or network call. This is the single most effective way to reduce read latency and database load.

### 2. Database Indexing

-   **Strategy**: Add a database index to the columns that are frequently used in `WHERE` clauses or `JOIN`s.
-   **Effect**: An index is a special data structure that allows the database to find the rows it needs very quickly, without having to scan the entire table. For a large table, a missing index is the most common cause of slow queries.

### 3. Asynchronous Processing

-   **Strategy**: For slow operations that don't need to be completed in real-time (like sending an email, processing an image, or generating a report), move the work out of the user's request-response cycle. Use a **message queue** to defer the task to a background worker.
-   **Effect**: The user's request completes almost instantly, and the slow I/O-bound work is handled in the background, dramatically improving perceived performance.

### 4. Query and Payload Optimization

-   **Strategy**: Optimize what you are asking for.
    -   **Fix N+1 Queries**: Instead of fetching a list of items and then making a separate query for each item's details in a loop, use a single, more efficient query (e.g., a `JOIN` or a `WHERE IN (...)` clause).
    -   **Avoid `SELECT *`**: Only select the specific columns you need from the database.
    -   **Smaller Payloads**: Reduce the size of data sent over the network. Use pagination for large result sets.

---

## 4. Strategies for CPU-Bound Bottlenecks

CPU-bound systems are limited by the speed of computation. The goal is to **reduce the amount of work the CPU has to do.**

### 1. Algorithmic Optimization

-   **Strategy**: This is the most powerful CPU optimization. Analyze the code identified by your profiler and see if a more efficient algorithm can be used.
-   **Effect**: Changing an algorithm from O(n^2) to O(n log n) can result in a 100x or 1000x performance improvement for large inputs, a far greater impact than any micro-optimization.

### 2. Horizontal Scaling

-   **Strategy**: If the work can be divided and run in parallel, simply add more servers.
-   **Effect**: By distributing the computational load across more machines, you can increase the overall throughput of the system. This is the classic "scale-out" approach.

### 3. Code-Level Optimizations

-   **Strategy**: After profiling, look for small inefficiencies in the identified hotspots.
    -   Avoid unnecessary work inside loops.
    -   Use more efficient data structures for the task.
    -   Cache the results of expensive computations (memoization).
-   **Effect**: These are micro-optimizations and should only be considered after a profiler has identified a specific line of code as a true hotspot.

---

## 5. Strategies for Memory-Bound Bottlenecks

Memory-bound systems are limited by the amount or speed of RAM. The goal is to **reduce the amount of memory the application needs.**

### 1. Fixing Memory Leaks

-   **Strategy**: Use a memory profiler to identify objects that are being held in memory unnecessarily and fix the code to release the references to them.
-   **Effect**: This is not just an optimization; it's a critical bug fix that prevents the application from crashing over time.

### 2. Data Streaming

-   **Strategy**: Instead of loading an entire large file (e.g., a 1GB CSV) or a massive database result set into memory at once, process it as a **stream**. Read and process one chunk or one row at a time.
-   **Effect**: The application can process datasets that are much larger than the available RAM, with a very small and constant memory footprint.

### 3. Vertical Scaling

-   **Strategy**: Sometimes, the simplest and most cost-effective solution is to just buy more RAM.
-   **Effect**: If the application's memory usage is legitimate and not a leak, scaling up the server instance can be a perfectly valid optimization strategy.

---

## 12. Summary and Mastery Checklist

-   [ ] I know that the most effective optimizations for I/O-bound systems are **caching, indexing, and asynchronous processing**.
-   [ ] I understand that the most powerful optimization for a CPU-bound system is to improve the underlying **algorithm**.
-   [ ] I know that the key strategies for memory-bound systems are **fixing leaks** and using **streaming** to process large datasets.
-   [ ] I will always remember to **profile my code** before attempting to optimize it, focusing my efforts on the measured hotspots.

---

## 13. Research and References

-   **"High Performance Browser Networking" by Ilya Grigorik**: While focused on the browser, it contains excellent explanations of universal performance concepts.
-   **"Code Complete" by Steve McConnell**: Contains a great chapter on performance tuning and the importance of measurement.
-   **Use The Index, Luke**: A guide to database performance and indexing. [Link](https://use-the-index-luke.com/)
