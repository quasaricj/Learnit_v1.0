# Performance Optimization: Performance Testing with JMeter and Lighthouse

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Performance Testing and its goal of verifying that a system meets its non-functional requirements.
-   **Differentiate** between key types of performance tests, such as Load, Stress, and Soak testing.
-   **Describe** the role of Apache JMeter for load testing backend services.
-   **Describe** the role of Google's Lighthouse for auditing and measuring frontend performance.
-   **Identify** key performance metrics for both backend (Throughput, Latency, Error Rate) and frontend (Core Web Vitals like LCP, CLS).
-   **Understand** that performance testing is a critical practice for validating scalability and preventing performance regressions.

---

## 2. Introduction: Trust, but Verify

You've designed a scalable and resilient system, but how do you *know* it will work? How do you prove that your application can handle the 10,000 requests per second that you designed it for?

**Performance Testing** is the discipline of testing a system to determine its responsiveness, throughput, and stability under a given workload. It's the "verify" part of "trust, but verify." It's not about finding functional bugs; it's about understanding and validating the system's performance characteristics.

### Types of Performance Tests:

-   **Load Test**: The most common type. It verifies that the system can handle its *expected* peak workload while still meeting its performance SLOs (e.g., "Can the system handle 10,000 RPS with a p99 latency below 200ms?").
-   **Stress Test**: This test pushes the system *beyond* its expected limits to find its breaking point and to see how it recovers.
-   **Soak Test (or Endurance Test)**: This is a long-running load test (e.g., 8-24 hours) designed to find subtle issues like memory leaks that only appear over time.

---

## 3. Backend Load Testing: Apache JMeter

**Apache JMeter** is a powerful, open-source Java application designed for load testing backend services. It is a workhorse of the performance testing world.

-   **Core Concept**: JMeter simulates a large number of "virtual users" making concurrent requests to your backend APIs. This allows you to generate a controlled, repeatable load to see how your system behaves.

### A Typical JMeter Workflow:

1.  **Create a Test Plan**: This is the top-level container for your test.
2.  **Add a Thread Group**: This defines the parameters of your virtual users.
    -   `Number of Threads (users)`: How many virtual users to simulate.
    -   `Ramp-up period (seconds)`: How long it takes to start all the threads.
    -   `Loop Count`: How many times each thread will execute the test.
3.  **Add Samplers**: A sampler represents a specific request to be executed. The most common is the **HTTP Request Sampler**, where you define the server, path, method, and parameters for an API call.
4.  **Add Listeners**: A listener is a component that collects and visualizes the results of the test.
    -   `Summary Report`: Shows aggregated metrics in a table.
    -   `View Results in Tree`: Shows the detailed request and response for every single sample (useful for debugging).
    -   `Graph Results`: Plots metrics over time.

### Key Backend Metrics to Measure:

-   **Throughput**: The number of requests your system can handle per unit of time (e.g., requests per second). This is the primary measure of capacity.
-   **Latency (Response Time)**: How long each request takes. You should always look at the distribution (average, median, 95th percentile, 99th percentile), not just the average.
-   **Error Rate**: The percentage of requests that fail (e.g., return a `5xx` status code). A high error rate under load indicates a bottleneck or a failure in the system.

---

## 4. Frontend Performance Auditing: Google Lighthouse

A fast backend is only half the story. If your frontend is bloated with huge images and unoptimized JavaScript, the user's experience will still be slow.

**Google Lighthouse** is an open-source, automated tool for auditing the quality of web pages. It is built directly into the Chrome DevTools (`F12 -> Lighthouse tab`).

-   **Core Concept**: Lighthouse loads your web page simulating a mid-tier mobile device on a moderately fast 3G/slow 4G network. It then runs a series of audits and generates a report with scores from 0-100 for several categories. The most important is **Performance**.

### Key Frontend Metrics (Core Web Vitals):

Lighthouse's report focuses on user-centric metrics, including Google's Core Web Vitals.

-   **Largest Contentful Paint (LCP)**: Measures *loading* performance. It's the time it takes for the largest image or text block in the user's viewport to become visible. (Good: < 2.5 seconds).
-   **Interaction to Next Paint (INP)** (formerly First Input Delay - FID): Measures *interactivity*. It's the time from when a user first interacts with your page (e.g., clicks a button) to the time when the browser is able to paint the response. (Good: < 200 milliseconds).
-   **Cumulative Layout Shift (CLS)**: Measures *visual stability*. It quantifies how much the content on the screen unexpectedly shifts during the loading process. (Good: < 0.1).

The Lighthouse report also provides a list of specific, actionable **Opportunities** and **Diagnostics** to help you improve your score, such as "Properly size images," "Eliminate render-blocking resources," and "Minify JavaScript."

---

## 12. Summary and Mastery Checklist

-   [ ] I can define **Performance Testing** as the practice of validating a system's behavior under a specific workload.
-   [ ] I know that **JMeter** is a tool for **backend load testing**, used to measure metrics like **throughput** and **latency**.
-   [ ] I know that **Lighthouse** is a tool for **frontend performance auditing**, used to measure user-centric metrics like the **Core Web Vitals**.
-   [ ] I can name the three Core Web Vitals: **LCP** (loading), **INP** (interactivity), and **CLS** (visual stability).
-   [ ] I understand that performance testing should be integrated into the development lifecycle to catch regressions early.

---

## 13. Research and References

-   **Apache JMeter Official Website**: [Link](https://jmeter.apache.org/)
-   **Google web.dev - "Lighthouse"**: The official documentation and guides for Lighthouse. [Link](https://web.dev/lighthouse/)
-   **"The Art of Application Performance Testing" by Ian Molyneaux**: A classic book on the discipline of performance testing.
-   **k6.io**: A popular, modern, developer-friendly alternative to JMeter for load testing.
