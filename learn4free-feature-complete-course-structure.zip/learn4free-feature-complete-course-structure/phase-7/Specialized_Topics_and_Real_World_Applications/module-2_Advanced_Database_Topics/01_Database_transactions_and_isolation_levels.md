# Advanced Database Topics: Transactions and Isolation Levels

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Recap** the ACID properties of a transaction.
- **Define** a database transaction and its purpose.
- **Explain** the concurrency control problem in databases.
- **Describe** common race conditions that can occur with concurrent transactions (dirty reads, non-repeatable reads, phantom reads).
- **Define** an isolation level.
- **List and differentiate** between the four standard SQL isolation levels.
- **Understand** the trade-off between isolation (safety) and performance.

---

## 2. Introduction: The Challenge of Concurrency

Databases are, by their nature, **concurrent** systems. They are designed to handle many different requests from many different clients at the same time. This concurrency is essential for performance, but it also creates a host of difficult problems.

What happens if two users try to modify the same piece of data at the exact same time? How does the database prevent them from corrupting the data or overwriting each other's changes? This is the **concurrency control** problem.

**Transactions** and **isolation levels** are the mechanisms that relational databases use to solve this problem and to provide strong guarantees about data consistency.

---

## 3. Recap: ACID Transactions

A **transaction** is a way to group a sequence of database operations into a single, "all or nothing" unit of work. The **ACID** properties are the guarantees that a database provides for its transactions.

- **A**tomicity: All or nothing.
- **C**onsistency: The database is always in a valid state.
- **I**solation: This is the key to concurrency control. It means that concurrent transactions should not interfere with each other.
- **D**urability: Once a transaction is committed, it is saved permanently.

This module focuses on the "I" in ACID: **Isolation**.

---

## 4. Concurrency Problems (Race Conditions)

Perfect isolation (as if each transaction were run serially, one after another) is very expensive. To allow for better performance, most databases do not provide perfect isolation by default. This can lead to several types of race conditions.

1.  **Dirty Read**:
    - **What it is**: Transaction A reads data that has been written by Transaction B, but Transaction B has **not yet committed**.
    - **The Problem**: If Transaction B then decides to **roll back** (abort) its changes, Transaction A will have read "dirty," non-existent data.

2.  **Non-Repeatable Read**:
    - **What it is**: Transaction A reads a piece of data. Transaction B then **updates** that same piece of data and commits. Transaction A then reads the *same* piece of data again and gets a *different value*.
    - **The Problem**: The data that Transaction A was working with has changed from underneath it, which can lead to inconsistencies.

3.  **Phantom Read**:
    - **What it is**: Transaction A runs a query that retrieves a *range* of rows. Transaction B then **inserts** a new row that falls within that range and commits. Transaction A then runs the *same* query again and gets a *different set of rows* (the new "phantom" row appears).

---

## 5. Isolation Levels

An **isolation level** is a setting that determines how isolated a transaction is from other concurrent transactions. The SQL standard defines four isolation levels. Each level provides more protection against race conditions, but at the cost of reduced performance and concurrency.

| Isolation Level          | Dirty Read         | Non-Repeatable Read | Phantom Read       |
|--------------------------|--------------------|---------------------|--------------------|
| 1. **Read Uncommitted**  | Possible           | Possible            | Possible           |
| 2. **Read Committed**    | Not Possible       | Possible            | Possible           |
| 3. **Repeatable Read**   | Not Possible       | Not Possible        | Possible           |
| 4. **Serializable**      | Not Possible       | Not Possible        | Not Possible       |

### 1. Read Uncommitted

- The lowest level of isolation. Provides almost no protection. It is rarely used.

### 2. Read Committed

- **The Guarantee**: Prevents dirty reads. Any data you read is guaranteed to have been committed.
- **How it works**: A transaction can only see data that was committed before the transaction began.
- **This is the default isolation level** for most relational databases (including PostgreSQL and SQL Server).

### 3. Repeatable Read

- **The Guarantee**: Prevents dirty reads and non-repeatable reads. If you read the same row multiple times within a single transaction, you are guaranteed to get the same result every time.
- **How it works**: The transaction operates on a consistent "snapshot" of the database, taken at the beginning of the transaction.
- **This is the default isolation level** for MySQL.

### 4. Serializable

- **The Guarantee**: The highest level of isolation. It prevents all race conditions, including phantom reads. This level guarantees that the result of running a set of concurrent transactions is the same as if they had been run serially, one after another.
- **How it works**: The database uses pessimistic locking mechanisms to prevent concurrent transactions from interfering with each other at all.
- **The Trade-off**: This level provides the strongest safety guarantees, but it can significantly reduce concurrency and performance. It should only be used when absolutely necessary.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that **isolation** is the "I" in ACID and is about preventing concurrent transactions from interfering with each other.
-   [ ] I can name a common concurrency problem, like a **Dirty Read** or a **Non-Repeatable Read**.
-   [ ] I can define an **isolation level** as a setting that controls the trade-off between performance and consistency.
-   [ ] I can name the four standard SQL isolation levels.
-   [ ] I know that **Read Committed** is a common default level.
-   [ ] I know that **Serializable** is the highest (and most expensive) level of isolation.

---

## 7. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 7, "Transactions," is a masterclass on this topic.
-   **PostgreSQL Documentation - "Transaction Isolation"**: The documentation for your specific database is the best source of truth for how it implements these levels. [Link](https://www.postgresql.org/docs/current/transaction-iso.html)
-   **MySQL Documentation - "Isolation Levels"**: [Link](https://dev.mysql.com/doc/refman/8.0/en/innodb-transaction-isolation-levels.html)
-   **"A Critique of ANSI SQL Isolation Levels"**: A famous paper that shows that the SQL standard's definitions have ambiguities.
