# Advanced Database Topics: Multi-Version Concurrency Control (MVCC)

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** Multi-Version Concurrency Control (MVCC) at a high level.
- **Explain** how MVCC works by keeping multiple versions of a row.
- **Describe** the primary benefit of MVCC: "readers don't block writers, and writers don't block readers."
- **Relate** MVCC to the implementation of different isolation levels (especially Snapshot Isolation).
- **Recognize** that MVCC is the underlying concurrency control mechanism for many popular relational databases, including PostgreSQL and Oracle.

---

## 2. Introduction: The Problem with Locking

In the previous module, you learned about isolation levels, which are designed to prevent concurrent transactions from interfering with each other. A simple way to implement isolation is to use **locks**.

- **Pessimistic Locking**: When a transaction wants to read or write a piece of data, it acquires a **lock** on it. Other transactions that want to access the same piece of data are **blocked** and have to wait until the first transaction releases its lock.
- **The Problem**: This "readers block writers and writers block readers" approach can severely limit the concurrency and performance of a database, especially in a system with many read operations.

**Multi-Version Concurrency Control (MVCC)** is a much more sophisticated and performant concurrency control mechanism that is used by many modern databases to avoid this problem.

---

## 3. How MVCC Works: "A Picture of the Past"

The central idea of MVCC is that **the database never overwrites data in place**. Instead, when a piece of data is updated, the database creates a **new version** of that data and leaves the old version in place for a while.

Each transaction is given a consistent "snapshot" of the database at the time it started.

**The Process**:
1.  **Transaction Start**: When a new transaction begins, the database gives it a unique transaction ID and records the current "timestamp". This timestamp defines the consistent snapshot of the database that this transaction is allowed to see.
2.  **Reads**: When the transaction tries to read a row, the database will find the version of that row that was valid at the transaction's start time. It will ignore any versions of the row that were created by later, uncommitted transactions.
3.  **Writes (`UPDATE`)**: When a transaction updates a row, it does not overwrite the existing row. Instead, it:
    a. Makes a copy of the row.
    b. Applies the changes to the copy.
    c. Marks this new copy with its own transaction ID, creating a new "version" of the row.
    d. Marks the old version as "expired" by this transaction.
4.  **Commit**: When the transaction commits, the database marks all the new versions it created as "committed" and globally visible to new transactions.
5.  **Garbage Collection**: A background "vacuum" process is responsible for periodically cleaning up the old, expired row versions that are no longer visible to any active transaction.

---

## 4. The Main Benefit: Readers Don't Block Writers

This versioning approach has one huge benefit: **a transaction that is only reading data never has to block a transaction that is writing data, and vice versa.**

- A **reader** can continue to read the old, consistent version of the data from its snapshot, even while a **writer** is simultaneously creating a new version of that same data.
- They can operate in parallel without interfering with each other. This dramatically improves the performance and concurrency of read-heavy workloads.

---

## 5. MVCC and Isolation Levels

MVCC is the mechanism that allows databases like PostgreSQL to efficiently implement the **Read Committed** and **Repeatable Read** isolation levels. The "consistent snapshot" that a transaction gets is the basis for these levels. This specific implementation is often called **Snapshot Isolation**.

- **Snapshot Isolation**: Each transaction reads from a snapshot of the database as of the time the transaction started. This prevents non-repeatable reads.
- **Note**: The Snapshot Isolation provided by MVCC is very similar to the standard `Repeatable Read` level, but it can have some subtle differences in how it handles "write skew" anomalies.

---

## 6. Databases that use MVCC

- **PostgreSQL**: One of the earliest and most well-known implementations.
- **Oracle**
- **Microsoft SQL Server** (in certain modes)
- **MySQL** (with the InnoDB storage engine)

---

## 7. Summary and Mastery Checklist

-   [ ] I can define **MVCC** as a concurrency control mechanism that keeps multiple versions of data.
-   [ ] I know that the primary benefit of MVCC is that **"readers don't block writers, and writers don't block readers."**
-   [ ] I can explain the high-level idea: when a row is updated, the database creates a **new version** instead of overwriting the old one.
-   [ ] I understand that each transaction gets a consistent **snapshot** of the database to read from.
-   [ ] I can name a popular database that uses MVCC, such as **PostgreSQL**.

---

## 8. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 7 is a brilliant and highly recommended deep dive into transactions and MVCC.
-   **The PostgreSQL Documentation - "Concurrency Control"**: The official documentation provides a detailed explanation of its MVCC implementation. [Link](https://www.postgresql.org/docs/current/mvcc.html)
-   **Wikipedia - "Multiversion concurrency control"**: [Link](https://en.wikipedia.org/wiki/Multiversion_concurrency_control)
-   **"Readings in Database Systems" (the "Red Book")**: A collection of seminal papers in database research, for those who want to go to the source.
