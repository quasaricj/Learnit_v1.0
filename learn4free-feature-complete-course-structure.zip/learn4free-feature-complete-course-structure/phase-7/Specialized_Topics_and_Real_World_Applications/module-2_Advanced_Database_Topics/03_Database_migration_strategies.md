# Advanced Database Topics: Database Migration Strategies

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a database schema migration.
- **Explain** why a structured, automated migration process is necessary.
- **Describe** the role of a schema migration tool (like Flyway or Alembic).
- **Differentiate** between a forward migration ("up") and a backward migration ("down").
- **Understand** the challenges of "zero-downtime" migrations.
- **Describe** a basic strategy for performing a non-breaking, backward-compatible migration.

---

## 2. Introduction: "Change is the Only Constant"

Your application is not static; it evolves over time. As you add new features, you will inevitably need to change your database schema:
- Adding a new table.
- Adding a new column to an existing table.
- Renaming a column.
- Removing a column.

A **database schema migration** is the process of managing and versioning these changes to your database schema in a structured and controlled way.

You cannot just log in to your production database and manually run a `CREATE TABLE` or `ALTER TABLE` statement. This is a recipe for disaster. It is not repeatable, not version controlled, and extremely error-prone. You need an automated, code-based approach.

---

## 3. Database Migration Tools

A **schema migration tool** is a piece of software that automates the process of applying and tracking schema changes.

- **How they work**:
  1.  You write each schema change as a separate **SQL script**. Each script is given a version number in its filename (e.g., `V1__Create_users_table.sql`, `V2__Add_email_to_users.sql`).
  2.  These scripts are stored in your application's source code repository.
  3.  The migration tool maintains a special table in your database (e.g., `schema_version`) that tracks which migration scripts have already been applied.
  4.  When you run the tool, it will compare the list of scripts in your codebase with the list of applied scripts in the database and will automatically apply any new, pending scripts in the correct order.

- **Popular Tools**:
  - **Flyway**: A popular, open-source tool for the JVM (Java, etc.).
  - **Alembic**: The standard tool for Python/SQLAlchemy.
  - **Active Record Migrations**: Built into the Ruby on Rails framework.
  - Many ORMs (Object-Relational Mappers) come with their own built-in migration tools.

### Up and Down Migrations

- **Up (Forward) Migration**: The script that applies a change (e.g., `CREATE TABLE ...`).
- **Down (Backward) Migration**: The script that **reverts** or **undoes** a change (e.g., `DROP TABLE ...`).
- Having a "down" script for every "up" script is a good practice, as it allows you to easily roll back a bad change if necessary.

---

## 4. The Challenge: Zero-Downtime Migrations

In a modern, continuously deployed application, you want to be able to deploy changes to your database **without taking your application offline**. This is a **zero-downtime deployment**.

This creates a major challenge: during a rolling deployment, you will have a period of time when **both the old version and the new version of your application code are running in production at the same time.** Your database schema must be able to support both versions of the code simultaneously.

This means that you cannot make **"breaking" schema changes** in a single step.

- **Breaking Change Example**: Renaming a column from `username` to `user_name`.
  - If you apply this change to the database, the old version of your application code, which is still trying to read the `username` column, will break.

---

## 5. Backward-Compatible Migration Strategy

To perform a breaking change like renaming a column with zero downtime, you must break the process down into multiple, separate, backward-compatible steps. This is often called the **"expand and contract"** pattern.

**Scenario: Renaming `username` to `user_name`**

1.  **Deployment 1 (Expand)**:
    - **Migration**: Add the **new column** `user_name` to the `users` table, but allow it to be `NULL`.
    - **Code Change**:
      - Change the application code to **write** to **both** the old `username` column and the new `user_name` column.
      - Change the application code to **read** from the new `user_name` column, but fall back to reading from the old `username` column if the new one is empty.
    - **Deploy**: Roll out this new version of the code. Now, all your code is compatible with a schema that has both columns.

2.  **Data Migration**:
    - Run a separate background script to copy the data from the old `username` column to the new `user_name` column for all the existing rows in the database.

3.  **Deployment 2 (Contract)**:
    - **Code Change**:
      - Change the application code to **only read and write** from the **new** `user_name` column. You can now remove the fallback logic and the logic for writing to the old column.
    - **Deploy**: Roll out this new version. Now, no part of your application is using the old column.

4.  **Deployment 3 (Cleanup)**:
    - **Migration**: You can now safely apply a schema migration to **drop the old `username` column**.
    - **Deploy**: This deployment might not even require a code change.

This multi-step process is complex, but it is the standard and safest way to perform breaking schema changes in a continuously deployed, highly available system.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that a **database migration** is a version-controlled, automated way to manage schema changes.
-   [ ] I know that I should use a **migration tool** (like Flyway) and store my migration scripts in my source code repository.
-   [ ] I can differentiate between an "up" migration (applies a change) and a "down" migration (reverts a change).
-   [ ] I understand that a **zero-downtime deployment** means that the database schema must be compatible with both the old and new versions of the code at the same time.
-   [ ] I can describe the high-level, multi-step "expand and contract" process for making a breaking change like renaming a column.

---

## 7. Research and References

-   **"The Twelve-Factor App - V. Build, release, run"**: Touches on the separation of the build and run stages.
-   **"Database Refactoring" by Scott W. Ambler**: A book of patterns for safely evolving a database schema.
-   **"Evolving Database Design" by Martin Fowler**: A blog post on the topic.
-   **Flyway Official Documentation**: [Link](https://flywaydb.org/documentation/)
-   **Alembic Official Documentation**: [Link](https://alembic.sqlalchemy.org/en/latest/)
-   **"Zero-Downtime Database Migrations"**: A common topic for engineering blogs from companies like GitHub, Stripe, and Shopify.
