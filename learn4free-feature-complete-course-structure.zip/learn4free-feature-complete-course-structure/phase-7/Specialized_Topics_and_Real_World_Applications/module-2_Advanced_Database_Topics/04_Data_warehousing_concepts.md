# Advanced Database Topics: Data Warehousing Concepts

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a data warehouse and its purpose.
- **Differentiate** between OLTP (Online Transaction Processing) and OLAP (Online Analytical Processing).
- **Describe** the characteristics of an OLTP system.
- **Describe** the characteristics of an OLAP system.
- **Explain** the ETL (Extract, Transform, Load) process.
- **Recognize** the names of popular cloud data warehouse solutions (e.g., Snowflake, BigQuery, Redshift).
- **Understand** why you need a separate system for analytics.

---

## 2. Introduction: Two Different Worlds

So far, the databases we have discussed have been **operational databases**. Their job is to run your day-to-day application. They are designed to handle a high volume of small, simple transactions quickly and reliably. This type of workload is called **OLTP (Online Transaction Processing)**.

However, businesses also have another, very different need: they need to run large, complex, analytical queries on their data to gain business insights, generate reports, and power business intelligence (BI) dashboards. This type of workload is called **OLAP (Online Analytical Processing)**.

Running a large, analytical OLAP query on your live, operational OLTP database is a very bad idea. It can consume all the database's resources and bring your user-facing application to a halt.

The solution is to have two separate systems: an OLTP database for your application, and a **data warehouse** for your analytics.

---

## 3. OLTP vs. OLAP

### OLTP (Online Transaction Processing)

- **Purpose**: Running the day-to-day operations of the application.
- **Workload**: A large number of small, simple read and write transactions.
- **Queries**: `SELECT` or `UPDATE` a few records at a time, based on an index.
- **Data Structure**: Highly normalized (3NF) to ensure data consistency and to avoid update anomalies.
- **Key Metrics**: High throughput, low latency.
- **Example Systems**: The PostgreSQL or MySQL database that backs your web application.

### OLAP (Online Analytical Processing)

- **Purpose**: Business intelligence, reporting, and data analysis.
- **Workload**: A small number of very large, complex queries that scan millions or billions of rows.
- **Queries**: Aggregate queries with `GROUP BY`, `SUM`, `AVG`.
- **Data Structure**: Highly **denormalized**. Often uses a special "star" or "snowflake" schema that is optimized for these large aggregate queries.
- **Key Metrics**: The speed of large, complex queries.
- **Example Systems**: A **data warehouse** like Snowflake or Google BigQuery.

---

## 4. The Data Warehouse

A **data warehouse** is a central repository of information that can be analyzed to make more informed decisions. It is a database that is specifically designed and optimized for OLAP workloads.

### Key Characteristics

- **Columnar Storage**: While OLTP databases are "row stores" (they store all the data for a row together on disk), data warehouses are often **"column stores"**. They store all the values for a single *column* together. This makes aggregate queries (like `SUM(price)`) incredibly fast, as the database only needs to read the data for the one column it cares about.
- **Massive Parallel Processing (MPP)**: Data warehouses are distributed systems that can run a single query in parallel across a large cluster of nodes.

### The ETL Process

How does data get from your OLTP database into your data warehouse? This is handled by a process called **ETL (Extract, Transform, Load)**.

1.  **Extract**: Periodically (e.g., once a day), you extract the new data from your various operational databases.
2.  **Transform**: You clean, enrich, and transform this raw, normalized data into the denormalized, analytical schema that is required by the data warehouse.
3.  **Load**: You load the transformed data into the data warehouse.

This process is often run by a dedicated **data pipeline** or **data integration** tool. A modern variation of this is **ELT**, where you load the raw data into the warehouse first and then use the power of the warehouse itself to perform the transformations.

---

## 5. Popular Cloud Data Warehouses

The modern data warehouse is a fully managed, cloud-native service that can scale to petabytes of data.

- **Snowflake**: A very popular, modern cloud data warehouse that is known for its unique architecture that separates storage and compute.
- **Google BigQuery**: Google's fully managed, serverless data warehouse.
- **Amazon Redshift**: The data warehouse service from AWS.
- **Databricks**: A platform that is built on top of open-source technologies like Apache Spark and is focused on the "data lakehouse" paradigm, which combines the features of a data lake and a data warehouse.

---

## 6. Summary and Mastery Checklist

-   [ ] I can explain that **OLTP** databases are for running the live application, while **OLAP** systems are for running analytics.
-   [ ] I know that you should not run large, analytical queries on your live OLTP database.
-   [ ] I can define a **data warehouse** as a special type of database that is optimized for OLAP workloads.
-   [ ] I know that data warehouses often use **columnar storage** to make aggregate queries very fast.
-   [ ] I can describe the **ETL (Extract, Transform, Load)** process for getting data from the OLTP database to the data warehouse.
-   [ ] I can name a popular cloud data warehouse, like **Snowflake** or **BigQuery**.

---

## 7. Research and References

-   **"The Data Warehouse Toolkit" by Ralph Kimball**: The definitive, classic book on data warehouse design.
-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 3 is a fantastic overview of the difference between OLTP and OLAP, and row vs. column storage.
-   **"What is a Data Warehouse?"**: A common topic for articles from all the major cloud and database vendors.
-   **"ETL vs. ELT"**: A common comparison that explains the modern approach to data integration.
