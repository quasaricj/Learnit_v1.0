# Advanced Database Topics: Graph Databases

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

- **Define** a graph database and its data model.
- **Identify** the core components of a graph model: nodes and edges.
- **Explain** the types of problems that graph databases are designed to solve.
- **Differentiate** a graph database from a relational database.
- **Understand** the performance benefits of a graph database for "graph traversal" queries.
- **Recognize** the names of popular graph databases (e.g., Neo4j).
- **Identify** a use case where a graph database would be a good choice.

---

## 2. Introduction: "It's All About the Relationships"

In a relational database, the focus is on the **entities** (the data in the tables). The **relationships** are a secondary concept, represented by foreign keys and `JOIN`s.

A **graph database** flips this on its head. It is a type of NoSQL database that is specifically designed to store and navigate **relationships**. The relationships between the data are treated as first-class citizens, just as important as the data itself.

Graph databases are built to answer questions about how data is connected.

---

## 3. The Graph Data Model

A graph database is based on a "property graph" model, which has two fundamental components:

1.  **Nodes (or Vertices)**:
    - **What they are**: These represent the **entities** in your data.
    - **Examples**: A `Person`, a `Product`, a `Company`, a `Movie`.
    - **Properties**: Nodes can have properties (key-value pairs) that store information about the entity, just like the columns in a relational table.

2.  **Edges (or Relationships)**:
    - **What they are**: These are the connections between the nodes. They are the most important concept in a graph database.
    - **Key Features**:
      - **They have a direction**: An edge always has a start node and an end node.
      - **They have a type**: An edge has a label that describes the nature of the relationship (e.g., `FRIENDS_WITH`, `ACTED_IN`, `PURCHASED`).
      - **They can have properties**: An edge can also have its own properties. For example, a `PURCHASED` edge could have a `date` property.

**Analogy**: A graph database is like a mini, real-time social network for your data.

---

## 4. The Problem with `JOIN`s

Imagine you want to answer the question: "Find the friends of my friends."
- **In a relational (SQL) database**:
  - You would have a `users` table and a `friendships` join table.
  - To find your friends, you would do a `JOIN`.
  - To find the friends of your friends, you would have to do **another `JOIN`**.
  - To find the friends of your friends of your friends, you would have to do **yet another `JOIN`**.
- The complexity and the cost of the query grows exponentially with the depth of the relationship you are trying to traverse. `JOIN`s are very expensive for deep, recursive queries.

### The Graph Database Advantage

- **Index-Free Adjacency**: In a graph database (like Neo4j), each node maintains a direct, physical pointer to its adjacent nodes.
- **How it works**: To find the friends of your friends, the graph database starts at your node, follows the pointers to your direct friends, and then follows the pointers from each of them to find their friends.
- **Performance**: This is a very fast and efficient "graph traversal" operation. The performance of the query depends only on the number of nodes and relationships you are traversing, **not** on the total size of the database. This is the key performance benefit of a graph database.

---

## 5. Popular Graph Databases and Query Languages

- **Neo4j**:
  - The most popular and mature graph database.
  - It uses a powerful, declarative query language called **Cypher**, which is designed to be an "ASCII-art" representation of a graph pattern.
  - **Example Cypher Query** (Find the friends of a user named "Alice"):
    `MATCH (user:Person {name: 'Alice'})-[:FRIENDS_WITH]-(friend:Person) RETURN friend.name`

- **Amazon Neptune**:
  - A fully managed graph database service from AWS.

---

## 6. Common Use Cases

Graph databases excel at any problem that involves highly connected data and requires you to analyze the relationships between things.

- **Social Networks**: The classic use case. Modeling the relationships between people.
- **Recommendation Engines**: "Customers who bought this product also bought...". This is a query about the relationships between customers and products.
- **Fraud Detection**: Identifying complex patterns of fraudulent activity by looking at the relationships between accounts, transactions, and devices.
- **Knowledge Graphs**: Modeling complex, interconnected information, like Google's Knowledge Graph.
- **Identity and Access Management**: Modeling the complex relationships between users, groups, roles, and permissions.

A graph database is **not** a general-purpose replacement for a relational database. It is a specialized tool for a specific set of problems.

---

## 7. Summary and Mastery Checklist

-   [ ] I can define a **graph database** as a database that is optimized for storing and querying **relationships**.
-   [ ] I can name the two core components of a graph model: **Nodes** (entities) and **Edges** (relationships).
-   [ ] I can explain the key advantage of a graph database: it is extremely fast at **graph traversal** queries (like "friends of friends").
-   [ ] I know that a graph database avoids the need for expensive, deep `JOIN`s that are required in a relational database for the same task.
-   [ ] I can identify a good use case for a graph database, such as a **social network** or a **recommendation engine**.
-   [ ] I can name **Neo4j** as the most popular graph database.

---

## 8. Research and References

-   **"Graph Databases" by Ian Robinson, Jim Webber, and Emil Eifrem**: The definitive book from the creators of Neo4j. It is available for free online.
-   **Neo4j Official Website**: Has excellent tutorials, sandboxes, and documentation. [Link](https://neo4j.com/)
-   **"A Six-Minute Video That Will Change How You Think About Data"**: A great introductory video from Neo4j.
-   **Cypher Query Language**: The documentation for the Cypher language.
