# Advanced Databases: Data Warehousing and ETL Pipelines

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a Data Warehouse and its primary purpose: business intelligence and analytics.
-   **Contrast** a data warehouse with a traditional transactional (OLTP) database.
-   **Describe** the ETL (Extract, Transform, Load) process as the primary mechanism for populating a data warehouse.
-   **Explain** the function of each stage: Extract, Transform, and Load.
-   **Differentiate** between traditional batch ETL and modern streaming ELT approaches.
-   **Recognize** common technologies used in data warehousing and ETL pipelines (e.g., Snowflake, BigQuery, Airflow, Spark).

---

## 2. Introduction: A Library for Your Business Data

Your production databases are optimized for one thing: running your application. They are designed to handle thousands of small, fast transactions per second (e.g., creating an order, updating a user profile). This is called **Online Transaction Processing (OLTP)**. However, they are often poorly suited for complex analytical queries that scan millions of rows to answer business questions like, "What was our total sales revenue for each product category in the last quarter, broken down by region?"

A **Data Warehouse** is a separate, specialized database system designed specifically for **Online Analytical Processing (OLAP)**.

-   **Analogy**: Your production database is a busy post office, processing thousands of individual letters and packages. A data warehouse is a research library. You don't send individual letters to the library; you send entire archives of historical documents. The library then carefully organizes (transforms) these documents so that researchers (analysts) can efficiently find insights and trends.

To get data from the post office to the library, you need a process. This is the **ETL pipeline**.

---

## 3. ETL: Extract, Transform, Load

ETL is the multi-stage process of copying data from one or more source systems into a destination system, typically a data warehouse.

![ETL Process Diagram](https://www.alooma.com/wp-content/uploads/2018/02/ETL-Diagram.png)

### 1. Extract

-   **Goal**: To pull raw data from various source systems.
-   **Sources**:
    -   Production databases (e.g., a read replica of your PostgreSQL `users` and `orders` tables).
    -   Application event logs.
    -   Third-party APIs (e.g., Salesforce, Google Analytics).
    -   Files (CSVs, JSON logs).
-   **Process**: This is typically a batch process that runs on a schedule (e.g., nightly) to pull all the data generated since the last run.

### 2. Transform

-   **Goal**: To cleanse, enrich, and restructure the raw data into a consistent, query-able format suitable for analysis. This is often the most complex and computationally intensive stage.
-   **Common Transformations**:
    -   **Cleaning**: Filtering out corrupt data, handling missing values.
    -   **Joining**: Combining data from multiple sources (e.g., joining user data from the `users` table with payment data from the Stripe API).
    -   **Aggregation**: Pre-calculating summary data (e.g., calculating the total amount for an order).
    -   **Schema Remodeling**: Restructuring the data into a star or snowflake schema, which is optimized for analytical queries. This often involves creating "fact" and "dimension" tables.

### 3. Load

-   **Goal**: To load the transformed, structured data into the target data warehouse.
-   **Process**: The clean data is loaded in bulk into the final analytical tables. Once loaded, it is ready to be queried by business intelligence (BI) tools, dashboards, and data analysts.

---

## 4. The Rise of ELT and Streaming

The traditional ETL model is a **batch process**. It runs periodically, meaning the data in the warehouse is always hours or even a day old. Modern business requirements often demand more real-time data.

### ELT (Extract, Load, Transform)

-   With the rise of powerful, scalable cloud data warehouses (like Snowflake, BigQuery, and Redshift), a new pattern has emerged: **ELT**.
-   **Process**:
    1.  **Extract** the raw data from the sources.
    2.  **Load** the raw data *immediately* into a staging area in the data warehouse.
    3.  **Transform** the data *inside* the data warehouse using its powerful SQL engine.
-   **Benefit**: This approach is often faster and more flexible, as it leverages the immense computational power of the modern data warehouse to do the transformations.

### Streaming ETL/ELT

-   **Process**: Instead of running in large batches, a streaming pipeline processes events one by one in near real-time.
-   **Technologies**: Tools like Apache Kafka, Spark Streaming, or Flink are used to create pipelines that can ingest, transform, and load data into the warehouse with only a few seconds or minutes of delay.
-   **Benefit**: Provides much fresher data for more timely business insights.

---

## 5. Key Technologies

-   **Data Warehouses**: Amazon Redshift, Google BigQuery, Snowflake, Apache Hive.
-   **ETL Orchestration**: Tools used to schedule, manage, and monitor the ETL workflows. **Apache Airflow** is the most popular open-source tool.
-   **Transformation Engine**: The tool that performs the heavy lifting of the transform step. **Apache Spark** is the de facto standard for large-scale data transformation.
-   **Managed ETL/ELT Services**: Tools like Fivetran and Stitch provide pre-built connectors to hundreds of data sources, automating the "E" and "L" parts of the process.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that a **Data Warehouse** is a database optimized for analytical queries (OLAP), not transactions (OLTP).
-   [ ] I can name and describe the three stages of the **ETL** process: **Extract** (get data from sources), **Transform** (clean and remodel), and **Load** (put into the warehouse).
-   [ ] I understand that the **Transform** step is often the most complex, preparing the data for efficient analysis.
-   [ ] I can describe the **ELT** pattern and explain why it has become popular with modern cloud data warehouses.
-   [ ] I can name a technology for orchestration (Airflow), transformation (Spark), and data warehousing (Snowflake/BigQuery).

---

## 13. Research and References

-   **"The Data Warehouse Toolkit" by Ralph Kimball**: The classic, definitive book on data warehouse design and dimensional modeling.
-   **The Apache Airflow Documentation**: A great resource for learning about modern data orchestration.
-   **The Apache Spark Documentation**: To understand the leading engine for large-scale data transformation.
