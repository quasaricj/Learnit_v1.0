# Advanced Databases: Replication and Failover

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Recap** the goals of replication: high availability and read scalability.
-   **Describe** the mechanics of single-leader replication, including the role of the replication log (like the WAL).
-   **Analyze** the deep trade-offs between Synchronous and Asynchronous replication regarding performance vs. durability.
-   **Define** "replication lag" and explain its impact on read-your-writes consistency.
-   **Outline** the key steps in an automated database failover process.
-   **Identify** potential problems in a failover, such as "split brain" and data loss.

---

## 2. Introduction: The Heartbeat of a Resilient Database

Nearly every production database system, from a traditional SQL database to a distributed NoSQL cluster, relies on **replication**. As we've discussed, replication is the process of keeping identical copies of data on multiple servers (replicas).

While we've touched on this before, this lesson will go deeper into the mechanics and challenges of ensuring your database can survive the failure of its primary node. This involves two key components:
1.  **Replication**: The ongoing process of copying data from the leader to the followers.
2.  **Failover**: The emergency process of promoting a follower to become the new leader when the old leader fails.

---

## 3. A Deeper Look at Single-Leader Replication

This is the most common replication topology for relational databases.

-   The **Leader** (Primary/Master) is the single source of truth. It is the only node that can accept write operations.
-   The **Followers** (Standbys/Slaves) maintain a near-identical copy of the leader's data.

### The Replication Log

The mechanism for this copying is the **replication log**. In a relational database, this is often called the **Write-Ahead Log (WAL)** or the binary log (binlog).
1.  When a write (`INSERT`, `UPDATE`, etc.) comes to the leader, it is first written to this append-only log file on disk.
2.  The leader then sends this log stream over the network to its followers.
3.  The followers receive the log, write it to their own disk, and then apply the changes to their local data tables.
4.  Followers can be used to serve read traffic, thus scaling out the system's read capacity.

---

## 4. The Durability vs. Performance Trade-off: Sync vs. Async

The most critical decision in a replication setup is how the leader handles the acknowledgment of a write.

### Asynchronous Replication (Default, High Performance)

-   **How it works**: The leader acknowledges the write to the client as soon as it has written the change to its *own* local log. The replication to followers happens in the background.
-   **Pros**: Very low write latency. The client doesn't have to wait for any network communication.
-   **Cons**: **Potential for data loss.** If the leader crashes *after* acknowledging the write but *before* the change has been sent to any followers, that write is lost forever.
-   **Replication Lag**: There is always a delay (the "replication lag") between when data is written to the leader and when it becomes visible on the followers. This can cause consistency problems, such as a user writing a post and then not seeing it when their next read request is sent to a follower.

### Synchronous Replication (High Durability)

-   **How it works**: The leader does *not* acknowledge the write to the client until it has received confirmation from at least one follower that the change has been received and written to the follower's log.
-   **Pros**: **Guaranteed durability.** The write is guaranteed to exist on at least two machines. If the leader crashes, the data is safe on the synchronous follower.
-   **Cons**: **Higher write latency.** Every write must now pay the price of a network round-trip to a follower. This can significantly impact performance.

**Common Configuration**: A "best of both worlds" approach is to have one **synchronous** follower (for HA) and multiple **asynchronous** followers (for read scaling).

---

## 5. The Failover Process: When the Leader Fails

Automated failover is the process of detecting a leader failure and promoting a follower to take its place. This must be handled with extreme care.

### The Steps:

1.  **Failure Detection**: The system needs a reliable way to determine that the leader is truly down and not just slow. This is usually done by a monitoring system or by the followers themselves, which expect a constant "heartbeat" from the leader. If the heartbeat is missed for a configured timeout (e.g., 30 seconds), a failover is initiated.

2.  **Leader Election / Promotion**: A new leader must be chosen.
    -   In a simple setup with one synchronous follower, that follower is the obvious and only choice, as it is guaranteed to have the most up-to-date data.
    -   In a more complex, multi-follower setup, a consensus algorithm might be needed to elect a new leader from among the most up-to-date followers.

3.  **Reconfiguration**: The system must be reconfigured to route traffic to the new leader.
    -   The application's database connection strings must be updated to point to the new leader. This is often handled by a virtual IP address or a DNS entry that is automatically updated.
    -   The other old followers must be reconfigured to start following the *new* leader.

### The "Split Brain" Problem

A major danger in automated failover is **split brain**. This happens when the old leader is not actually down, but is merely disconnected from the rest of the system due to a network partition.
-   The followers, unable to see the old leader, will promote a new leader.
-   Now you have **two active leaders**, both accepting writes.
-   When the network partition is resolved, you have two conflicting versions of the truth, which can be extremely difficult and time-consuming to reconcile, often leading to data loss.
-   Robust failover systems need a **fencing mechanism** to ensure that the old leader is definitively powered down or blocked from accepting writes before a new one is promoted.

---

## 12. Summary and Mastery Checklist

-   [ ] I can explain that single-leader replication uses a **replication log** to send writes from a leader to its followers.
-   [ ] I can analyze the trade-off between **asynchronous replication** (fast writes, risk of data loss) and **synchronous replication** (durable writes, higher latency).
-   [ ] I understand that **replication lag** can cause consistency issues in read-heavy applications.
-   [ ] I can list the three steps of a failover: **detection, promotion, and reconfiguration**.
-   [ ] I can define **split brain** as a dangerous condition where two leaders are active simultaneously and know that a "fencing" mechanism is the solution.

---

## 13. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 5 on Replication is the definitive guide to this topic.
-   **PostgreSQL Documentation - "High Availability, Load Balancing, and Replication"**: A great real-world example of the features and complexities involved.
-   **Jepsen.io**: A blog and set of tools by Kyle Kingsbury that tests the consistency and fault tolerance claims of distributed databases.
