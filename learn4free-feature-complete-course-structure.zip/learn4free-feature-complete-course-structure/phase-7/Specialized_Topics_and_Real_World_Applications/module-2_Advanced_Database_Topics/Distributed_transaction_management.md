# Advanced Databases: Distributed Transaction Management

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** a distributed transaction and the atomicity problem it aims to solve.
-   **Describe** the classic Two-Phase Commit (2PC) protocol and its coordinator/participant model.
-   **Analyze** the significant drawbacks of 2PC, particularly its blocking nature and single point of failure.
-   **Recap** the Saga pattern as a more resilient, non-blocking alternative for managing distributed transactions in a microservices world.
-   **Understand** that true distributed atomicity is rarely achievable without significant performance and availability trade-offs.

---

## 2. The Problem: All or Nothing, Across a Network

A transaction is an "all or nothing" operation. In a single database, ACID properties guarantee that a series of operations are treated as a single atomic unit. But what happens when that unit of work spans multiple, independent systems?

This is a **distributed transaction**. For example:
-   Transferring money from a `CheckingAccount` service to a `SavingsAccount` service.
-   An e-commerce order that must update the `Order` database, the `Payment` database, and the `Inventory` database.

The goal is **atomicity**: all of these separate database writes must either succeed together, or they must all fail together. You can never leave the system in an inconsistent state (e.g., money debited from one account but never credited to the other).

---

## 3. The Classic Solution: Two-Phase Commit (2PC)

Two-Phase Commit is a classic algorithm for achieving atomic commitment across multiple distributed systems. It uses a central **coordinator** to manage the transaction across several **participants** (the databases or services).

### The Two Phases:

**Phase 1: The Prepare Phase**
1.  The coordinator sends a `prepare` message to all participants, asking them if they are ready to commit the transaction.
2.  Each participant does all the work it needs to (e.g., validates the data, reserves resources) and then writes its changes to a durable log on disk *without* actually committing them.
3.  Each participant then responds to the coordinator with a `vote`: `YES` if it is ready, `NO` if it cannot commit. By voting `YES`, a participant makes a binding promise that it *will* be able to commit if asked.

**Phase 2: The Commit Phase**
1.  The coordinator collects all the votes.
2.  **If all participants voted `YES`**: The coordinator makes the final decision to `COMMIT`. It sends a `commit` message to all participants. The participants then make their changes permanent and release their locks.
3.  **If even one participant voted `NO` (or timed out)**: The coordinator makes the final decision to `ABORT`. It sends a `rollback` message to all participants. The participants then discard the changes from their logs.

### The Problem with 2PC

While it provides atomicity, 2PC is rarely used in modern, highly available web services for several critical reasons:

-   **It is a Blocking Protocol**: During the entire process (from the prepare phase until the final commit/abort message is received), each participant must hold locks on the resources it needs to modify. This can block other operations for a significant amount of time, severely degrading performance and throughput.
-   **The Coordinator is a Single Point of Failure**: If the coordinator crashes after the prepare phase but before it has sent the final commit/abort decision, the participants are left in a "limbo" state. They are holding locks and don't know whether to commit or abort. They are stuck until the coordinator can be recovered.
-   **It Doesn't Work Well with Modern Infrastructure**: It assumes a small, stable set of participants and is not well-suited for elastically scaling systems where participants can come and go.

---

## 4. The Modern Alternative: The Saga Pattern

As we discussed in the Microservices Design Patterns module, the **Saga pattern** is the modern solution to this problem. It embraces the fact that true distributed atomicity is often at odds with high availability and performance.

### A Quick Recap:

-   A saga is a sequence of **local transactions**.
-   Each local transaction is atomic within its own service.
-. If a step fails, **compensating transactions** are executed to undo the preceding steps.

### Saga vs. 2PC

| Aspect        | Two-Phase Commit (2PC)                                   | Saga Pattern                                             |
|---------------|----------------------------------------------------------|----------------------------------------------------------|
| **Atomicity**   | Provides full, atomic commitment. All or nothing.        | Does not. It's an "all or nothing eventually" model.     |
| **Consistency** | Strong Consistency.                                      | **Eventual Consistency**.                                |
| **Isolation**   | Provides isolation through long-lived locks.             | **No Isolation**. Partial changes are visible to others.   |
| **Coupling**    | Tightly coupled to the coordinator.                      | Loosely coupled (especially the choreography model).     |
| **Performance** | Poor. The blocking nature and chattiness limit throughput.| High. The asynchronous, non-blocking nature is performant.|
| **Availability**| Low. The coordinator is a SPOF.                          | High. No central coordinator is required to fail.        |

**Conclusion**: For systems that prioritize high availability and scalability (which is most modern web services), the trade-offs made by the Saga pattern (giving up strong consistency and isolation in favor of eventual consistency) are almost always the better choice. 2PC is generally only used in environments where strong, immediate consistency is an absolute, non-negotiable requirement.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define a **distributed transaction** as a single logical operation that involves writes to multiple, independent data stores.
-   [ ] I can describe the two phases of **2PC**: the `prepare` phase (voting) and the `commit` phase (decision).
-   [ ] I can explain the major drawbacks of 2PC, including its **blocking nature** and the **coordinator as a single point of failure**.
-   [ ] I recognize the **Saga pattern** as the preferred, non-blocking, and more resilient alternative for managing distributed transactions in microservices.
-   [ ] I understand the fundamental trade-off: 2PC provides strong consistency at the cost of availability, while Sagas provide high availability at the cost of eventual consistency.

---

## 13. Research and References

-   **"Designing Data-Intensive Applications" by Martin Kleppmann**: Chapter 9 provides an excellent, in-depth critique of distributed transactions and 2PC.
-   **"Microservices Patterns" by Chris Richardson**: The definitive guide to the Saga pattern.
-   **Wikipedia - "Two-phase commit protocol"**: A detailed look at the algorithm and its failure modes.
