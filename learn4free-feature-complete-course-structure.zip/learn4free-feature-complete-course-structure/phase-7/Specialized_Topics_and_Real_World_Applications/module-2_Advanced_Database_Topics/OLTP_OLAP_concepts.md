# Advanced Databases: OLTP vs. OLAP

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Define** Online Transaction Processing (OLTP) and its primary purpose.
-   **Define** Online Analytical Processing (OLAP) and its primary purpose.
-   **Clearly contrast** the typical workload patterns of OLTP and OLAP systems (e.g., read/write patterns, data volume, query complexity).
-   **Explain** why databases designed for OLTP are generally not well-suited for OLAP workloads, and vice-versa.
-   **Connect** OLTP systems to production applications and OLAP systems to data warehousing and business intelligence.

---

## 2. Introduction: Two Worlds of Data

Not all database workloads are created equal. The way an e-commerce website interacts with its database is fundamentally different from the way a data analyst queries that same data to find business insights. Understanding this difference is key to choosing the right database technology and architecture.

The two primary categories of database workloads are **OLTP** and **OLAP**.

---

## 3. OLTP: Online Transaction Processing

-   **What it is**: The database workload of your day-to-day, user-facing applications. It's about processing a large number of concurrent, short, simple transactions.
-   **Analogy**: A bank teller. They handle a high volume of quick, individual transactions: one deposit, one withdrawal, one balance check. They don't do complex financial forecasting.

### Workload Characteristics:

-   **Operations**: A mix of many small, fast reads and writes. (e.g., `INSERT`, `UPDATE`, `SELECT` with a `WHERE` clause on an indexed column).
-   **Concurrency**: Very high. Thousands of users or services might be accessing the database at the same time.
-   **Data Scope**: Each transaction typically touches only a small number of records (e.g., a single user's profile, one order).
-   **Primary Goal**: **High throughput and low latency** for concurrent operations. The system must be fast and always available to run the business.
-   **Data Structure**: Typically highly normalized (3rd Normal Form) to avoid data duplication and ensure consistency.

-   **System Examples**: The primary database for an e-commerce site, a banking application, a social media app. This is the "live," operational data.
-   **Database Examples**: PostgreSQL, MySQL, Oracle, SQL Server.

---

## 4. OLAP: Online Analytical Processing

-   **What it is**: The database workload of business intelligence, analytics, and reporting. It's about processing a low volume of very complex, long-running queries that aggregate huge amounts of historical data.
-   **Analogy**: A financial analyst preparing a quarterly report. They don't process individual transactions; they scan and aggregate millions of historical transactions to answer big-picture questions like, "What was our average profit margin by product category over the last three years?"

### Workload Characteristics:

-   **Operations**: Almost exclusively read-only, complex `SELECT` queries with many `JOIN`s, `GROUP BY` clauses, and aggregate functions (`SUM`, `AVG`).
-   **Concurrency**: Low. Only a small number of analysts or BI tools are using the system at any given time.
-   **Data Scope**: Each query typically scans millions or even billions of rows across multiple tables.
-   **Primary Goal**: **Fast query performance** for complex, large-scale aggregations.
-   **Data Structure**: Typically highly denormalized, often using a **star schema** or **snowflake schema**. These schemas are designed to make "slicing and dicing" the data fast, at the expense of data redundancy.

-   **System Examples**: A **Data Warehouse**.
-   **Database Examples**: Amazon Redshift, Google BigQuery, Snowflake, Apache Druid. These are often **columnar databases**, which are architecturally different from the row-store databases used for OLTP and are optimized for scanning and aggregating large columns of data.

---

## 5. Why You Need Both: The Summary Table

| Characteristic        | OLTP (Online Transaction Processing)         | OLAP (Online Analytical Processing)             |
|-----------------------|----------------------------------------------|-------------------------------------------------|
| **Primary Goal**      | Run the business                             | Analyze the business                            |
| **Workload**          | Many small, concurrent reads and writes      | Few complex, long-running read queries          |
| **Users**             | Application end-users, services              | Data analysts, data scientists, BI tools        |
| **Data Scope**        | Single records or a few records              | Large aggregates over many records              |
| **Data Structure**    | Normalized (3NF)                             | Denormalized (Star/Snowflake Schema)            |
| **Database Type**     | Row-oriented (e.g., PostgreSQL, MySQL)       | Column-oriented (e.g., Redshift, BigQuery)      |
| **Example System**    | E-commerce website database                  | Data Warehouse                                  |

### Why Not Use One for Both?

-   **Running OLAP on an OLTP database**: An analyst running a huge, long-running `SUM` query can consume all the database's resources (CPU, I/O), locking tables and causing the user-facing application to slow down or become unavailable.
-   **Running OLTP on an OLAP database**: OLAP databases are designed for bulk loads and massive scans. They are often very inefficient at handling the thousands of small, concurrent `INSERT`s and `UPDATE`s required by a live application.

This fundamental mismatch in workload patterns is why companies invest in building separate OLAP systems (data warehouses) and the ETL pipelines needed to move data into them.

---

## 12. Summary and Mastery Checklist

-   [ ] I can define **OLTP** as the workload for running a live application, characterized by many small, fast transactions.
-   [ ] I can define **OLAP** as the workload for business analytics, characterized by a few complex queries over large amounts of historical data.
-   [ ] I can list the key differences between the two, including their read/write patterns, data structures, and primary goals.
-   [ ] I know that production application databases are **OLTP** systems.
-   [ ] I know that data warehouses are **OLAP** systems.
-   [ ] I can explain why running a complex analytical query on a live production (OLTP) database is a dangerous idea.

---

## 13. Research and References

-   **"The Data Warehouse Toolkit" by Ralph Kimball**: The definitive book on OLAP database design (dimensional modeling).
-   **Wikipedia - "OLTP" vs. "OLAP"**: Provides a good, concise summary.
-   **AWS Documentation - "What is OLAP?"**: [Link](https://aws.amazon.com/what-is/olap/)
