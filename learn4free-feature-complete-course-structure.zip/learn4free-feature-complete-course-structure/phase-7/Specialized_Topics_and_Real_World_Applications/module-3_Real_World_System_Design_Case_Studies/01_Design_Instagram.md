# Real-World System Design: Design Instagram

## 1. The Problem: Design a Photo-Sharing Service

This is a classic system design interview question. The goal is to design a service similar to Instagram.

The problem is intentionally vague. The first and most important step is to **clarify the requirements and scope**.

---

## 2. Step 1: Clarify Requirements and Scope

### Functional Requirements

- **Must-haves (Core Features)**:
  - Users can upload photos.
  - Users can view a news feed of photos from the people they follow.
  - Users can follow other users.
- **Should-haves (If time permits)**:
  - Users can "like" a photo.
  - Users can add a caption to a photo.
- **Out of Scope (Features we will not design today)**:
  - Video uploads.
  - Stories and Reels.
  - Direct messaging.
  - Search and Explore page.

### Non-Functional Requirements

- **Scalability**: The system should be highly scalable to support millions of users.
- **Availability**: The system must be highly available. Users should always be able to view their feeds.
- **Latency**: The news feed must load very quickly (e.g., under 200ms).
- **Durability**: Uploaded photos must never be lost.

---

## 3. Step 2: Back-of-the-Envelope Estimation

- **Users**: Assume 500 million total users, with 100 million Daily Active Users (DAU).
- **Uploads (Writes)**:
  - 100M DAU, and 1 in 10 users uploads a photo per day = 10M photos/day.
  - Average photo size = 500 KB.
  - **Storage needed for photos**: 10M photos/day * 500 KB/photo = 5 TB/day.
- **Feed Reads**:
  - 100M DAU, and each user checks their feed 10 times a day = 1 billion feed loads/day.
  - **Read QPS (Queries Per Second)**: 1B / (24*3600s) ≈ 12,000 QPS.
- **Conclusion**: The system is **very read-heavy**. The feed generation service must be highly optimized for reads.

---

## 4. Step 3: High-Level Design (Architecture Diagram)

```
+--------+     +-----+      +-------------+      +-------------------+
|        | --> | CDN | -->  |             | -->  |                   |
| Client |     +-----+      | Load Balancer|      | API Gateway       |
|        |                  |             |      | (Web Servers)     |
+--------+     <-- Photos -- |             | <--  |                   |
               (for reads)   +-------------+      +-------------------+
                                                      /        \
                                                     /          \ (API Calls)
                                                    v            v
+------------------+                       +-----------------+   +--------------------+
|                  | <-- (Async Event) --- |                 |   |                    |
| Feed Fanout      |                       |  Photo Service  |   |    User Service    |
| Service (Push)   |                       |                 |   | (Follows, etc.)    |
|                  | ------------------- > |                 |   |                    |
+------------------+   (Write to Cache)    +-----------------+   +--------------------+
       |                                      /         \             |
       v                                     /           \            v
+------------------+            +--------------+   +--------------+   +-------------------+
|                  |            |              |   |              |   |                   |
| Redis Cache      |            |  PostgreSQL  |   |    AWS S3    |   | PostgreSQL        |
| (User Feeds)     |            |  (Metadata)  |   | (Photo Files)|   | (Users, Follows)  |
|                  |            |              |   |              |   |                   |
+------------------+            +--------------+   +--------------+   +-------------------+
```

---

## 5. Step 4: Data Flow and Component Deep Dive

### The Write Path (Photo Upload)

1.  **Client -> API Gateway**: User uploads a photo via a `POST /photos` request.
2.  **API Gateway -> Photo Service**: The Gateway routes the request to the `Photo Service`.
3.  **Photo Service**:
    a. Stores the image file in an **Object Store (AWS S3)**. S3 is perfect for storing large binary files and is highly durable.
    b. Stores the photo's metadata (S3 URL, user ID, caption, etc.) in a **PostgreSQL database**. This database is optimized for writes and data consistency.
4.  **Async Fanout**:
    a. The `Photo Service` publishes a `PhotoUploaded` event to a **message queue**.
    b. A `Feed Fanout Service` consumes this event. It looks up all the followers of the user who posted the photo. For each follower, it injects the new photo's ID into their **feed cache** in Redis.

### The Read Path (News Feed Generation)

This is the critical, high-traffic path. We need to avoid hitting the database as much as possible.

1.  **Client -> API Gateway**: User requests their feed via a `GET /feed` request.
2.  **API Gateway -> Feed Service** (or the User Service, which could own this logic).
3.  **Feed Service -> Redis Cache**:
    a. The service gets the user's ID. It looks up their feed in a **Redis Cache**. The key could be `feed:{user_id}`.
    b. The value in Redis is a list of photo IDs for that user's feed.
4.  **Cache Hit (The common case)**:
    a. The service gets the list of photo IDs from Redis.
    b. It might need to "hydrate" this data by making a call to the `Photo Service` to get the full metadata for those photo IDs (or this metadata could also be cached).
    c. It returns the fully formed feed to the user.
5.  **Cache Miss (e.g., a new user)**:
    a. If the user's feed is not in the cache, the service has to generate it "on-the-fly".
    b. It queries the database to find the people the user follows.
    c. It then queries the database for the most recent photos from those people, aggregates them, and ranks them.
    d. It stores this generated feed in the Redis cache for next time.
    e. It returns the feed to the user.

### Why "Push on Write" (Fanout)?

- **The Trade-off**: The "fanout on write" approach means that the write operation (uploading a photo) is slower, because we have to do the work of updating the feeds for all the followers. However, it makes the **read operation (loading the feed) extremely fast**, because the feed is pre-computed and waiting in a cache.
- **For a read-heavy system like Instagram's feed, this is the right trade-off.**
- **The Celebrity Problem**: What if a user has 30 million followers? You can't update all their feeds at once. For these "celebrity" users, you can use a hybrid approach: don't fan out their posts. Instead, when a normal user loads their feed, you fetch their followed "celebrities" and merge their recent posts into the feed at read time.

---

## 6. Step 5: Data Model and Further Considerations

### Database Schema

- **`users` table**: `user_id (PK)`, `username`, `email`, `...`
- **`photos` table**: `photo_id (PK)`, `user_id (FK)`, `s3_url`, `caption`, `created_at`
- **`followers` table** (Join table for many-to-many): `follower_id (FK)`, `followed_id (FK)`

### Bottlenecks and Scaling

- **Database Scaling**: The databases will be under heavy load. We will need to use **Read Replicas** to scale the read load and potentially **Sharding** (e.g., sharding the `photos` and `followers` tables by `user_id`) to scale the write load.
- **Caching**: The Redis feed cache is a critical component. It must be highly available and scalable, likely run as a cluster.
- **CDN**: All photos should be served to users via a **CDN** to reduce latency and the load on our S3 bucket.

---

## 7. Summary

This design outlines a scalable, highly available photo-sharing service. It uses a microservices architecture, separates the read and write paths, and makes a critical trade-off to optimize for a fast feed-loading experience by using a "fanout on write" or "push" model.

---

## 8. Research and References

-   **"Instagram's architecture"**: This is a very common topic for engineering blogs and conference talks.
-   **"System Design Interview – An insider's guide" by Alex Xu**
-   **Grokking the System Design Interview**
-   **"Fanout on write vs. pull on read"**: A classic system design trade-off.
