# Real-World System Design: Design Twitter

## 1. The Problem: Design a Twitter-like Service

This is another classic system design question. The core of the problem is to design a service where users can post short messages ("tweets") and follow other users to see their tweets in a timeline.

---

## 2. Step 1: Clarify Requirements and Scope

### Functional Requirements

- **Must-haves (Core Features)**:
  - Users can post a tweet (up to 280 characters).
  - Users can view a "Home Timeline" of tweets from the people they follow.
  - Users can view a "User Timeline" of tweets from a specific user.
  - Users can follow other users.
- **Should-haves (If time permits)**:
  - The feed should be ranked by relevance, not just chronologically.
- **Out of Scope**:
  - Images and videos in tweets.
  - Retweets, likes, replies.
  - Direct messaging.
  - Search.
  - Hashtags.

### Non-Functional Requirements

- **Scalability**: The system must be highly scalable to support hundreds of millions of users.
- **Availability**: The system must be highly available. The timeline must be available for reading.
- **Latency**: The Home Timeline must load very quickly (e.g., under 200ms). Posting a tweet can be slower.
- **Consistency**: Eventual consistency is acceptable. If a user posts a tweet, it's okay if it takes a few seconds to appear in their followers' timelines.

---

## 3. Step 2: Back-of-the-Envelope Estimation

- **Users**: 1 billion total users, 200 million Daily Active Users (DAU).
- **Writes (Posting a Tweet)**:
  - Assume 100 million tweets per day.
  - **Write QPS**: 100M / (24*3600s) ≈ 1,200 QPS.
- **Reads (Loading the Timeline)**:
  - Assume each DAU loads their timeline 10 times a day = 2 billion timeline loads/day.
  - **Read QPS**: 2B / (24*3600s) ≈ 24,000 QPS.
- **Conclusion**: The system is **extremely read-heavy**. The Read QPS is about 20 times the Write QPS. This is the single most important characteristic of the system and must drive our design.

---

## 4. Step 3: High-Level Design (The Hybrid Model)

The core of the Twitter design is the timeline generation. There are two main approaches:
1.  **Pull-based (Fan-out on read)**: When a user requests their timeline, you find all the people they follow, get the recent tweets from each of them, and merge them together. This is simple but very slow for the read path.
2.  **Push-based (Fan-out on write)**: When a user posts a tweet, you "fan out" that tweet to all of their followers. You pre-compute the home timeline for every user. This makes the read path extremely fast, but the write path is very expensive, especially for "celebrity" users with millions of followers.

**Twitter uses a hybrid approach.**

```
                               +-----------------+
                               |                 |
+--------+      +------------+ |  Tweet Service  |
| Client |----> | Load       | | (Writes)        |
|        |      | Balancer   | +-----------------+
+--------+      +------------+         |
                      |                v
                      |      +-----------------+
                      |      |                 |
                      |      |  Fanout Service |
                      |      |                 |
                      |      +-----------------+
                      |          /         \
                      | (Async) /           \ (Sync)
                      v        v             v
+-----------------+  +-------------+   +----------------+
|                 |  |             |   |                |
| Timeline Service|  | Redis Cache |   |  Tweet DB      |
| (Reads)         |  | (Timelines) |   | (Cassandra)    |
|                 |  |             |   |                |
+-----------------+  +-------------+   +----------------+
       ^
       |
+-----------------+
|                 |
| User Service    |
| (Follow Graph)  |
| (MySQL/Sharded) |
+-----------------+

```

---

## 5. Step 4: Data Flow and Component Deep Dive

### The Write Path (Posting a Tweet)

1.  A user's `POST /tweet` request is sent to the `Tweet Service`.
2.  The `Tweet Service` saves the tweet to a **Tweet Database**. A NoSQL database like **Cassandra** is a good choice here, as it's optimized for high write throughput and is scalable. The tweets can be partitioned by `user_id`.
3.  The `Tweet Service` then sends the tweet to the **Fanout Service**.
4.  The `Fanout Service` looks up the user's followers from the `User Service`.
5.  **For each follower**, the Fanout service injects the `tweet_id` into their **Home Timeline cache**, which is stored in a distributed cache like **Redis**. The timeline is stored as a list of `tweet_id`s.
    - Redis's `LPUSH` and `LTRIM` commands are perfect for this, as they can be used to add a new tweet to the front of a list and to keep the list from growing too long.

### The Read Path (Loading the Home Timeline)

1.  A user's `GET /timeline` request is sent to the **Timeline Service**.
2.  The `Timeline Service` gets the user's ID. It then fetches a list of `tweet_id`s from the **Redis cluster** using the user's ID as the key (e.g., `GET timeline:{user_id}`).
3.  This gives the service a list of `tweet_id`s. It then needs to "hydrate" these IDs to get the full tweet data (the text, the author's name, etc.). This can be done by calling the `Tweet Service` or by looking in another cache (a "tweet cache").
4.  The fully formed timeline is returned to the user.
- **Benefit**: This is extremely fast. It's just a single, fast lookup in a Redis cache.

### The Hybrid Model: Handling "Celebrities"

- The pure fan-out on write approach fails for a user with 30 million followers. You can't update 30 million Redis lists on every tweet.
- **The Solution**:
  1.  Most users (those with < 1000 followers) are handled with the **push-based** model described above.
  2.  A small number of "celebrity" users are handled with a **pull-based** model. Their tweets are *not* fanned out on write.
  3.  When a normal user requests their timeline, the `Timeline Service` will:
      a. Fetch the pre-computed timeline from Redis (which contains the tweets from all the non-celebrities they follow).
      b. Separately, fetch the recent tweets from all the *celebrities* they follow.
      c. Merge these two lists together in memory and return the final timeline.
- This hybrid model optimizes for the common case (the vast majority of users are not celebrities) while still handling the extreme load of the edge cases.

---

## 6. Data Model

- **`tweets` table (Cassandra/NoSQL)**: `tweet_id (PK)`, `user_id`, `text`, `created_at`. Partitioned by `user_id`.
- **`users` table (SQL, Sharded)**: `user_id (PK)`, `username`, `...`
- **`followers` table (SQL, Sharded)**: `user_id`, `follower_id`. This is a classic social graph and a relational database is a good fit. This table would be sharded by `user_id`.
- **`timelines` cache (Redis)**: `user_id` -> `[tweet_id, tweet_id, ...]`

---

## 7. Summary

The design of Twitter is a masterclass in the trade-offs required for a read-heavy system. The key insight is to use a **hybrid push-pull model** for timeline generation, optimizing for the common case (the "long tail" of normal users) while handling the exceptional case (celebrities) with a different strategy.

---

## 8. Research and References

-   **"Scaling Twitter: Making Twitter 10000 percent faster"**: A famous presentation on Twitter's architecture.
-   **"System Design Interview – An insider's guide" by Alex Xu**: Has an excellent chapter on designing Twitter.
-   **Grokking the System Design Interview**
-   **"The Architecture of Twitter"**: Many high-level overviews are available on engineering blogs.
