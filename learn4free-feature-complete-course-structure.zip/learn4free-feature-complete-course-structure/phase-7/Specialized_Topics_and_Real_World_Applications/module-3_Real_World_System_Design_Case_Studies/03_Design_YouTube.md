# Real-World System Design: Design YouTube

## 1. The Problem: Design a Video Streaming Service

This is a very common system design question. The goal is to design a simplified version of a massive-scale video streaming service like YouTube or Netflix.

---

## 2. Step 1: Clarify Requirements and Scope

### Functional Requirements

- **Must-haves**:
  - Users can upload videos.
  - Users can watch videos.
  - Users can search for videos.
- **Should-haves**:
  - Users can "like" videos and add comments.
  - The system should recommend other videos to watch.
- **Out of Scope**:
  - Live streaming.
  - YouTube Premium / monetization.
  - User analytics.

### Non-Functional Requirements

- **Scalability**: The system must be able to handle a massive amount of data and a huge number of concurrent users. This is a **read-heavy** system (many more people watch videos than upload them).
- **Availability and Reliability**: The system must be highly available. Videos should play without buffering.
- **Durability**: Uploaded videos must never be lost.
- **Latency**: Video playback must start very quickly.

---

## 3. Step 2: Back-of-the-Envelope Estimation

- **Users**: 1 billion daily active users (DAU).
- **Consumption**: Assume each user watches 5 videos per day = 5 billion video views/day.
- **Uploads**: Assume 1 in 100 users uploads a video per day = 10 million uploads/day.
- **Storage**:
  - Average video size = 100 MB.
  - **Storage needed**: 10M videos/day * 100 MB/video = 1 Petabyte (PB) / day. This is an enormous amount of data.
- **Bandwidth**:
  - The amount of data streamed out to users will be massive. This will be the single biggest operational cost.

**Conclusions**:
- The storage system must be infinitely scalable and extremely durable.
- The system must be heavily optimized for delivering large files to a global audience. **A CDN is not optional; it is the core of the system.**
- The write path (upload) is complex and happens in the background. The read path (streaming) must be simple and incredibly fast.

---

## 4. Step 3: High-Level Design

This system is best designed by separating the **Video Upload** (write) path from the **Video Streaming** (read) path.

```
                  +----------------------+
                  | Video Upload         |
                  | (Write Path)         |
                  +----------------------+
                          |
+--------+      +------------+      +-------------------+
| Uploader|----> |            |----> |                   |
|         |     | Load       |      | API Gateway       |
+--------+      | Balancer   |      |                   |
                  | (for API)  |      +-------------------+
                  +------------+               |
                                               v
+------------------+      +--------------------+      +----------------------+
|                  |      |                    |      |                      |
| Video Processing | <--- |   Message Queue    | <--- |   Upload Service     |
| Service          |      |   (Kafka/SQS)      |      |                      |
| (Transcoding)    |      |                    |      +----------------------+
+------------------+      +--------------------+         |             |
       |                                                 v             v
       |                                     +--------------+  +--------------------+
       | (Processed Videos)                  |              |  |                    |
       +-----------------------------------> |  Raw Storage |  |  Video Metadata DB |
                                             |  (S3 Bucket) |  |  (PostgreSQL)      |
                                             |              |  |                    |
                                             +--------------+  +--------------------+

                  +----------------------+
                  | Video Streaming      |
                  | (Read Path)          |
                  +----------------------+
                          |
+--------+      +----------------------+      +--------------------+
| Viewer  |----> |                      |----> |                    |
|         |     |     CDN              |      | Streaming Service  |
+--------+      | (Cloudfront, etc.)   |      | (Serves Manifest)  |
                  |                      |      +--------------------+
                  +----------------------+               |
                           ^                             |
                           | (Videos)                    v
                  +----------------------+      +--------------------+
                  |                      |      |                    |
                  | Transcoded Storage   |      |  Video Metadata DB |
                  | (S3 Bucket)          |      |  (Read Replica)    |
                  |                      |      |                    |
                  +----------------------+      +--------------------+
```

---

## 5. Step 4: Component Deep Dive

### The Write Path: Video Upload and Processing

1.  **Upload**: A user uploads a video file. The request hits a load balancer and is routed to an `Upload Service`.
2.  **Storage**:
    a. The `Upload Service` stores the raw, original video file in an **Object Storage** bucket (e.g., S3). This provides the durable master copy.
    b. It also writes the video's initial metadata (title, description, etc.) to a **Video Metadata Database** (e.g., a sharded PostgreSQL database).
3.  **Asynchronous Processing**:
    a. The `Upload Service` then publishes a `VideoUploaded` event to a **message queue**.
    b. This decouples the upload process from the complex and time-consuming processing step. The user can get an immediate "Upload successful, your video is being processed" response.
4.  **Transcoding**:
    a. A fleet of **Video Processing Workers** consumes events from the queue.
    b. Each worker takes a raw video file and **transcodes** it. This involves:
       i.  **Converting it to different formats** (e.g., MP4, HLS, DASH).
       ii. **Converting it to different resolutions** (e.g., 1080p, 720p, 480p) to support adaptive bitrate streaming.
    c. The processed video segments are stored in a separate "Transcoded" S3 bucket.
5.  **Completion**: Once transcoding is complete, the worker updates the status in the Video Metadata DB to "Ready" and might publish another event.

### The Read Path: Video Streaming

1.  **Request**: A user clicks "play" on a video. The client (the browser or mobile app) makes a request for the video.
2.  **Metadata Fetch**: The client first hits our backend API to get the video metadata, including the URLs for the video streams.
3.  **Streaming from the CDN**: The video player in the client then requests the video files **directly from the CDN**. This is the critical optimization. The vast majority of traffic never hits our servers.
4.  **Adaptive Bitrate Streaming**: The video player continuously monitors the user's network conditions. If the connection is slow, it will automatically switch to requesting the lower-resolution (e.g., 480p) video segments. If the connection improves, it will switch back to a higher resolution. This ensures a smooth playback experience with minimal buffering.

---

## 6. Other Components

- **Search**: Video metadata would be indexed in a dedicated search engine like **Elasticsearch**.
- **Recommendations**: This would be a complex Machine Learning service that analyzes a user's watch history and generates a list of recommended video IDs.

---

## 7. Summary

The design of a video streaming service is all about **scale**. It requires a clear separation of the write and read paths. The write path is a complex, asynchronous pipeline designed to process a huge amount of incoming data. The read path is a simple, massively distributed system that is almost entirely offloaded to a **CDN** to handle the enormous bandwidth requirements.

---

## 8. Research and References

-   **"How YouTube Works"**: Many articles and videos break down the architecture.
-   **Netflix Engineering Blog**: A fantastic resource for articles on video encoding, streaming, and running a massive-scale distributed system.
-   **"System Design Interview – An insider's guide" by Alex Xu**: Has a great chapter on designing YouTube.
-   **Adaptive Bitrate Streaming**: The core technology behind modern video streaming (HLS and DASH are the main protocols).
