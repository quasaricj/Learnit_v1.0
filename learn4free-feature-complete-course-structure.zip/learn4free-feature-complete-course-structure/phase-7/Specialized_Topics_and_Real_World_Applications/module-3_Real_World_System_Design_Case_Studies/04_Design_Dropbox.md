# Real-World System Design: Design Dropbox

## 1. The Problem: Design a File Syncing Service

This question asks you to design a cloud file synchronization service like Dropbox, Google Drive, or OneDrive.

---

## 2. Step 1: Clarify Requirements and Scope

### Functional Requirements

- **Must-haves**:
  - A user can upload/download files to/from the cloud.
  - A user can have multiple clients (desktop, mobile).
  - Files should be automatically synchronized between all of a user's clients.
  - The service should support offline editing. Changes made offline should be synced when the client comes back online.
- **Should-haves**:
  - The service should track file versions/revisions.
  - The service should support sharing files with other users.
- **Out of Scope**:
  - Collaborative editing (like Google Docs).
  - Enterprise features (admin dashboards, etc.).

### Non-Functional Requirements

- **Reliability and Durability**: Files must **never** be lost. This is the most important requirement.
- **Availability**: The service must be highly available.
- **Performance**: The sync process should be fast and efficient. It should only transfer the *differences* in a file, not the whole file, if possible.
- **Scalability**: Must scale to support millions of users and petabytes of data.

---

## 3. Step 2: High-Level Design

The core of the system is a **synchronization client** running on the user's device and a set of backend services. The client is a "thick client" that does a lot of the heavy lifting.

```
+----------------+                            +--------------------+
|                |                            |                    |
| Desktop Client |                            |  Mobile Client     |
|                |                            |                    |
+----------------+                            +--------------------+
       |   \                                    /        |
       |    `----------------.  .-------------'          |
       |                      \/                          | (Sync Protocol)
       | (File System Watcher) |                          |
       |                       |                          |
       v                       v                          v
+----------------+      +----------------+      +------------------+
|                |      |                |      |                  |
| Block Store    |<---->| Sync Service   |<---->| Metadata DB      |
| (S3)           |      | (Backend)      |      | (MySQL/Sharded)  |
|                |      |                |      |                  |
+----------------+      +----------------+      +------------------+
                             |
                             v
                       +----------------+
                       |                |
                       | Notification   |
                       | Service        |
                       | (WebSockets)   |
                       +----------------+
```

---

## 4. Step 3: Component Deep Dive

### The Client Architecture

The client is a critical and complex part of this design.
1.  **File System Watcher**: A component that watches the local "Dropbox" folder for any changes (file added, modified, deleted).
2.  **Indexer**: When a change is detected, the Indexer scans the file and splits it into smaller, fixed-size **blocks** (e.g., 4MB).
3.  **Chunking and Hashing**: It then computes a **hash** (e.g., SHA-256) for each block. This hash acts as the unique ID for that block.
4.  **Communicator**: The client communicates with the backend **Sync Service**.
    - It sends the list of block hashes for the modified file.
    - The backend checks which of these blocks it has already stored (from other files or other users).
    - The client then only needs to upload the blocks that the server does not already have. This is a key optimization for both storage and bandwidth.

### The Backend Architecture

1.  **Sync Service**:
    - This is the main backend service that handles the synchronization logic.
    - It receives the metadata from the clients (the list of file blocks, file versions, etc.).
    - It authenticates the client and checks for permissions.
    - It coordinates with the Metadata DB and the Block Store.

2.  **Metadata Database**:
    - This database stores all the information **about** the files: filenames, directory structure, versions, users, sharing permissions, and the list of block hashes that make up each file.
    - A **relational database** (like MySQL, sharded by `user_id`) is a good choice here, as we need strong consistency for the file system metadata.

3.  **Block Store**:
    - This is where the actual file **blocks** are stored.
    - An **Object Store** like **AWS S3** is the perfect choice. It is highly durable and infinitely scalable.
    - The name of each object in S3 would be the **hash** of the block. This provides automatic **deduplication**: if two users upload the exact same 4MB block of data, it will only be stored once in S3.

4.  **Notification Service**:
    - **The Problem**: How does a client know when a change has been made on another client? It could poll the server every few seconds ("are there any changes yet?"), but this is very inefficient.
    - **The Solution**: The client maintains a persistent, long-lived connection to a **Notification Service**, likely using **WebSockets** or **Long Polling**.
    - When `Client A` uploads a change, the Sync Service processes it and then tells the Notification Service to send a message to `Client B` and `Client C` for the same user.
    - Upon receiving the notification, `Client B` and `Client C` will then proactively contact the Sync Service to download the changes.

---

## 5. The Sync Protocol in Detail

1.  **Client A** modifies a file.
2.  The **Watcher** detects the change. The **Indexer** splits the file into blocks, hashes them, and informs the **Communicator**.
3.  The **Communicator** sends the file metadata (new version, list of block hashes) to the **Sync Service**.
4.  The **Sync Service** checks the **Metadata DB**. It then tells the client which blocks it needs to upload.
5.  **Client A** uploads the new, unique blocks to the **Block Store (S3)**.
6.  The **Sync Service** updates the **Metadata DB** to point the new file version to the new list of blocks.
7.  The **Sync Service** tells the **Notification Service** that this user's files have changed.
8.  The **Notification Service** sends a push notification to **Client B** and **Client C**.
9.  **Client B** and **Client C** contact the **Sync Service** to ask for the latest changes.
10. The **Sync Service** tells them the new file version and the list of block hashes they need.
11. **Client B** and **Client C** download the required blocks from the **Block Store (S3)** and reconstruct the file locally.

---

## 6. Summary

The design of a file syncing service is a great example of a **thick client** architecture. A significant amount of logic (chunking, hashing, reconstructing files) happens on the client. The backend is responsible for orchestrating the synchronization and providing a highly durable and scalable storage layer. The use of a **Notification Service** with a persistent connection is a key component for providing a fast, real-time sync experience.

---

## 7. Research and References

-   **"System Design Interview – An insider's guide" by Alex Xu**: Has an excellent, detailed chapter on designing Dropbox.
-   **"The Dropbox Tech Blog"**: Has many articles on their architecture and how it has evolved.
-   **"How Dropbox synchronizes files"**: A common topic for engineering blog posts.
-   **Differential Synchronization**: The algorithm that is often used to sync only the *diffs* of a file, not the whole block.
-   **WebSockets vs. Long Polling**: The two common techniques for a server to push notifications to a client.
