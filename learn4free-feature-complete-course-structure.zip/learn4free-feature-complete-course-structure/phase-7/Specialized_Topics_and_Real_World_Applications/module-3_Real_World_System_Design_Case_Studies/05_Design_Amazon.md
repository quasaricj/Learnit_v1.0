# Real-World System Design: Design Amazon.com

## 1. The Problem: Design an E-commerce Website

This is a huge, complex problem. Designing the entire Amazon.com platform is not feasible in a single session. The first step is to **aggressively narrow the scope**.

---

## 2. Step 1: Clarify Requirements and Scope

### Functional Requirements

- **Must-haves (Core User Flow)**:
  - Users can search for products.
  - Users can view a product details page.
  - Users can add products to a shopping cart.
  - Users can place an order (checkout).
- **Should-haves**:
  - Users can view their order history.
  - Users can leave reviews for products.
- **Out of Scope**:
  - Recommendations (`"Customers who bought this also bought..."`).
  - Seller accounts and the seller side of the platform.
  - Fulfillment, shipping, and logistics.
  - Amazon Prime, Alexa, and all other Amazon services.

We are designing the core customer-facing **shopping experience**.

### Non-Functional Requirements

- **High Availability**: The site must be highly available. Downtime means lost revenue.
- **High Scalability**: The system must handle a massive number of users and products, with huge spikes in traffic (e.g., on Black Friday).
- **Durability**: Orders and user data must never be lost.
- **Consistency**: Strong consistency is required for some parts of the system (e.g., inventory and payment processing), but eventual consistency is acceptable for others (e.g., reviews).

---

## 3. Step 2: High-Level Design (Microservices)

An e-commerce platform is a classic use case for a **microservices architecture**. The different business domains (Products, Cart, Orders, etc.) are very well defined and can be developed and scaled independently.

```
+--------+      +-----------+      +-------------+      +-------------------+
|        |----->|           |----->|             |----->|                   |
| Client |      |    CDN    |      | Load Balancer|      | API Gateway       |
|        |      |           |      |             |      | (Web Servers)     |
+--------+      +-----------+      +-------------+      +-------------------+
                                                              |
            (Synchronous REST API calls) ---------------------+---------------------
                                        |           |           |           |
                                        v           v           v           v
+-----------------+     +-----------------+  +----------------+  +----------------+
|                 |     |                 |  |                |  |                |
| Product Catalog |     |  Search Service |  | Shopping Cart  |  |  User Account  |
| Service         |     | (Elasticsearch) |  | Service (Redis)|  | Service        |
+-----------------+     +-----------------+  +----------------+  +----------------+
       |
       |
       v
+-----------------+
|                 |
|  Order Service  | -- (Async Event) -> | Payment Service | -> | Notification Service |
|                 |                     +-----------------+    +----------------------+
+-----------------+

```
Each of these services will have its own private database, following the **Database per Service** pattern.

---

## 4. Step 3: Component Deep Dive

### Product Catalog Service

- **Responsibilities**: Manages all the information about products (name, description, price, images).
- **Database**: Can be a relational database (like PostgreSQL) or a NoSQL document database (like MongoDB), depending on the complexity of the product data. The read load will be high, so it will need **read replicas** and a heavy **caching** layer.
- **Data Flow**: Product data is served to the client from a cache or the read replicas. Images are served from a **CDN**.

### Search Service

- **Responsibilities**: Provides full-text search capabilities for products.
- **Technology**: This is a specialized problem. You would **not** use a traditional database. You would use a dedicated search engine like **Elasticsearch** or **Algolia**.
- **Data Flow**: The `Product Catalog Service` would asynchronously feed its data into the `Search Service` to be indexed.

### Shopping Cart Service

- **Responsibilities**: Manages the shopping carts for all users.
- **Characteristics**: Carts are temporary and do not need to be stored with the same durability as orders. The service needs to handle a very high volume of reads and writes.
- **Technology**: A distributed **in-memory key-value store** like **Redis** or **DynamoDB** is a perfect fit. It is extremely fast and scalable. The key could be the `user_id`.

### User Account Service

- **Responsibilities**: Manages user profiles, authentication, and authorization.
- **Database**: A relational database like PostgreSQL or MySQL is a good choice. It would be sharded by `user_id`.

### Order Service (The Checkout Flow - A Saga)

This is the most critical and complex workflow. It is a distributed transaction and a perfect use case for the **Saga pattern**.

1.  **Create Order**: The client initiates the checkout. The `Order Service` receives the request, creates an order in its own database, and marks its status as `PENDING`. It then starts the saga.
2.  **Process Payment**: The `Order Service` (or an orchestrator) calls the `Payment Service`. The `Payment Service` will integrate with a third-party payment provider like **Stripe**.
3.  **Update Inventory**: If the payment is successful, the `Inventory Service` is called to reserve the stock.
4.  **Confirm Order**: If the inventory is successfully updated, the `Order Service` marks the order's status as `CONFIRMED`.
5.  **Notify User**: The `Order Service` publishes an `OrderConfirmed` event, which is consumed by the `Notification Service` to send a confirmation email to the user.

- **Failure Handling**: If any step in this chain fails (e.g., the payment is declined), the saga must execute **compensating transactions** to roll back the previous steps (e.g., release the inventory, cancel the order).
- **Communication**: This workflow can be implemented using either **orchestration** (a central `OrderOrchestrator` service) or **choreography** (services communicating via events on a message queue).

---

## 5. Data Consistency

- **Strong Consistency**: Required for the core checkout flow (Payment, Inventory). The Saga pattern helps to manage this.
- **Eventual Consistency**: Acceptable for many other parts of the system.
  - When a seller updates a product's stock, it might take a few seconds for that to be reflected in the search results.
  - When a user leaves a review, it doesn't need to appear instantly.

---

## 6. Summary

Designing an e-commerce platform is a classic exercise in designing a **microservices architecture**. The key is to correctly identify the different business domains (bounded contexts) and to design them as independent, loosely coupled services. The most critical part of the system, the checkout process, requires careful management of a **distributed transaction** using a pattern like the Saga.

---

## 7. Research and References

-   **"Building Microservices" by Sam Newman**
-   **The Saga Pattern**: A critical pattern for this design.
-   **"Amazon's Architecture"**: Many presentations and articles from Amazon engineers are available online, describing how they have scaled their massive system.
-   **"A Decade of Architectural Evolution at Amazon"**: A well-known presentation from 2010.
