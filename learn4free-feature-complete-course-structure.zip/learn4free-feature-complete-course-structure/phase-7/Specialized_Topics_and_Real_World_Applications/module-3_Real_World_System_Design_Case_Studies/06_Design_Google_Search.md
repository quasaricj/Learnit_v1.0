# Real-World System Design: Design Google Search (A Search Engine)

## 1. The Problem: Design a Web Search Engine

This is one of the most complex system design questions, as it touches on massive-scale data processing and information retrieval. The key is to simplify the problem and focus on the high-level components of a search engine.

---

## 2. Step 1: Clarify Requirements and Scope

### Functional Requirements

- The user can enter a search query (a few words).
- The system will return a ranked list of relevant web page URLs.
- The system should show a title, a URL, and a short snippet for each result.

### Non-Functional Requirements

- **Scalability**: Must be able to index the entire public web (billions of documents) and handle a massive number of queries per second.
- **Performance (Latency)**: Search results must be returned extremely quickly (e.g., < 200ms).
- **Relevance**: The results must be highly relevant to the user's query.

---

## 3. Step 2: High-Level Design

A search engine can be broken down into two main parts:
1.  **The Offline Indexing Pipeline**: The system that crawls the web, processes the content, and builds the search index. This is a massive-scale data processing pipeline.
2.  **The Online Serving System**: The system that receives a user's query, searches the index, ranks the results, and returns them to the user. This must be a very low-latency system.

```
+----------------+
|                |
| Web Crawler    |
| (Distributed)  |
|                |
+----------------+
       | (Fetches Pages)
       v
+----------------+
|                |
| Page Processor |
| (Parsing, etc.)|
|                |
+----------------+
       | (Words and Documents)
       v
+----------------+
|                |
| Indexer        |
|                |
+----------------+
       | (Creates Inverted Index)
       v
+----------------+
|                |
| Search Index   |
| (Massive,      |
|  Distributed)  |
+----------------+
       ^
       | (Searched by...)
+----------------+
|                |
| Query Processor|
| / Ranker       |
|                |
+----------------+
       ^
       |
+----------------+
|                |
|  Frontend      |
|  (Web Servers) |
|                |
+----------------+
       ^
       |
+------+--+
|         |
|  User   |
|         |
+---------+
```

---

## 4. Step 3: Component Deep Dive

### The Offline Pipeline: Building the Index

This is a massive **data pipeline** that runs continuously.

1.  **Web Crawler**:
    - A fleet of distributed robots that systematically browse the web.
    - It starts with a list of seed URLs. It fetches the HTML of those pages, parses them to find all the links to other pages, and adds those new links to a queue of pages to be crawled.
    - The crawled pages are stored in a massive-scale storage system.

2.  **Page Processor**:
    - Takes the raw HTML content and processes it.
    - **Parsing**: Extracts the important content: the title, the body text, the links, etc.
    - **Tokenization**: Breaks the body text down into individual words (tokens).
    - **Linguistics**: Might perform stemming (reducing words to their root form, e.g., "running" -> "run") and remove "stop words" (common words like "a", "the", "is").

3.  **Indexer**:
    - The core of the offline system. The Indexer's job is to create an **Inverted Index**.
    - **What is an Inverted Index?**: This is the fundamental data structure of a search engine. Instead of mapping a Document ID to the words it contains, it maps a **Word** to a list of all the **Document IDs** that contain that word.
    - **Example**:
      - Doc 1: "the cat sat"
      - Doc 2: "the dog sat"
    - **Inverted Index**:
      - `the`: [1, 2]
      - `cat`: [1]
      - `sat`: [1, 2]
      - `dog`: [2]
    - The index also stores information about the position and frequency of the word in each document, which is used for ranking.
    - This index is massive and must be sharded (likely by the word or a hash of the word) and stored across thousands of machines.

### The Online System: Serving a Query

This is the real-time, user-facing part of the system.

1.  **Frontend / Web Servers**: A user's query (`"brown dog"`) hits the web servers.
2.  **Query Processor**:
    - The query is sent to a Query Processor.
    - It performs the same tokenization and linguistic processing on the query that was done on the documents.
    - It then sends the processed query to the Search Index.
3.  **Searching the Index**:
    - The system looks up each word from the query in the Inverted Index.
      - `brown`: [Doc 5, Doc 20, Doc 99, ...]
      - `dog`: [Doc 2, Doc 20, Doc 87, ...]
    - It then finds the **intersection** of these lists to get the set of documents that contain all the query words (in this case, Doc 20).
4.  **Ranking**:
    - Just finding the matching documents is not enough. The key is to **rank** them by relevance.
    - The ranking algorithm is the secret sauce of a search engine. It is incredibly complex and is based on hundreds of signals, but some of the most important are:
      - **Term Frequency / Inverse Document Frequency (TF-IDF)**: How often does the word appear in this document, relative to how common it is across all documents?
      - **PageRank**: An algorithm that measures the "importance" of a web page by looking at the quantity and quality of the links that point to it. It is a measure of a page's authority.
    - The Ranker fetches the metadata for the matching documents, applies the ranking algorithm, and produces a sorted list of Document IDs.
5.  **Snippet Generation**: The system then fetches the titles and a short snippet of the text from the top-ranked documents and returns them to the user.

---

## 5. Scalability and Performance

- **Massive Parallelism**: Every step of this process is massively parallelized. A single user query is sent to thousands of index shards in parallel.
- **Caching**: There is aggressive caching at every layer. The results for common queries are cached.
- **Geographic Distribution**: The search index is replicated in data centers all over the world, so that a user's query can be served from a nearby location.

---

## 6. Summary

Designing a search engine is a fascinating problem in large-scale distributed systems. The key architectural idea is the **separation of the offline indexing pipeline from the online serving system**. The core data structure is the **Inverted Index**, and the "magic" is in the highly sophisticated **ranking algorithm**.

---

## 7. Research and References

-   **"The Anatomy of a Large-Scale Hypertextual Web Search Engine" by Sergey Brin and Lawrence Page**: The original paper on Google's architecture. A foundational paper of computer science.
-   **"Introduction to Information Retrieval" by Christopher D. Manning, Prabhakar Raghavan and Hinrich Schütze**: The classic textbook on the subject.
-   **Apache Lucene**: The open-source search engine library that powers Elasticsearch and Solr. Understanding Lucene is understanding how search works.
-   **"How Google Search Works"**: Many high-level overviews are available from Google and on YouTube.
