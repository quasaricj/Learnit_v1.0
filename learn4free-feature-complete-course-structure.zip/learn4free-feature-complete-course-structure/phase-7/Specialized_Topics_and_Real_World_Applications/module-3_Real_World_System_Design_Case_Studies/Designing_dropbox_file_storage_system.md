# Case Study: Designing a Dropbox-like File Storage System

## 1. Clear Learning Objectives

By the end of this case study, you will be able to:

-   **Apply** system design principles to a large-scale, data-intensive application.
-   **Analyze** the unique challenges of handling large binary files and client-side synchronization.
-   **Design** a system that efficiently handles file uploads and downloads by breaking files into chunks.
-   **Develop** a synchronization mechanism that uses both a long polling and a persistent connection model.
-   **Propose** a data model for tracking file metadata, versions, and user data.
-   **Integrate** object storage, message queues, and a metadata database into a cohesive architecture.

---

## 2. Step 1: Establish Requirements

### Functional Requirements:

1.  **File Upload/Download**: A user can upload and download files from any of their clients.
2.  **File Synchronization**: Changes to a file on one client (add, update, delete) should be automatically synchronized to the user's other clients and the cloud.
3.  **Offline Editing**: A user can modify files while offline. The changes should be synced when they come back online.
4.  **File Versioning**: The system should maintain a history of file versions.

### Non-Functional Requirements:

1.  **High Reliability & Durability**: A user's files must never be lost. Data durability is the top priority.
2.  **High Availability**: The service should be highly available.
3.  **Scalability**: The system must handle petabytes of file storage and millions of users.
4.  **Performance**: The sync process should be fast and efficient, minimizing both latency and the amount of data transferred.

---

## 3. Step 2: High-Level Architecture

The core of the system is separating the **file data (the "what")** from the **file metadata (the "who, where, when")**.

-   **File Data**: The large binary file content itself. This will be stored in a highly durable, scalable **Object Storage** system like Amazon S3.
-   **File Metadata**: Information *about* the files (filenames, versions, permissions, modification dates, which chunks belong to which file). This will be stored in a scalable database.

![Dropbox High-Level Architecture](https://miro.medium.com/max/1400/1*Qy-S-3Q-g-2r-1z-2y-7A.png)

-   **Client**: The desktop or mobile application. It has a local copy of the user's files and a small local database to track file state.
-   **Block Store (Object Storage)**: The source of truth for the file data itself (e.g., S3).
-   **Metadata Database**: A scalable database (e.g., a sharded SQL DB or Cassandra) that stores all information about the files.
-   **Stateless Application Servers**: The main backend logic.
-   **Synchronization Service**: A stateful service that manages real-time notifications to clients.
-   **Message Queue**: To handle the asynchronous processing of file chunks.

---

## 4. Step 3: Deep Dive - The Upload and Sync Process

A key optimization for handling large files is to break them into smaller, fixed-size **chunks** (or **blocks**). For example, a 100MB file might be broken into 25 4MB chunks.

### The Upload Flow:

1.  The **Client** breaks the file into chunks.
2.  The Client calculates a hash (e.g., SHA-256) for each chunk. This allows for **deduplication**: if a chunk with the same hash already exists in the system (from another user or another file), it doesn't need to be uploaded again.
3.  The Client uploads the chunks in parallel to the **Application Servers**.
4.  The Application Servers save the chunks directly to the **Block Store**.
5.  After all chunks are uploaded, the Client makes a final API call to the Application Server: `commit_file`. This call includes the list of chunk hashes and their order.
6.  The **Application Server** receives the `commit_file` call, writes the new file's metadata (name, version, list of chunks) to the **Metadata Database**, and publishes a `FileUpdated` message to the **Message Queue**.

### The Synchronization Flow:

This is the most complex part of the system. How do a user's *other* clients know that a file has changed?

1.  The **Synchronization Service** is a set of servers that maintains a persistent connection with every online client. When a client comes online, it establishes a connection with one of these servers.
2.  A **Fan-out Service** subscribes to the `FileUpdated` messages from the **Message Queue**.
3.  When it receives a message for a given user, it finds which Synchronization Server is currently connected to that user's other clients.
4.  It forwards the notification to the relevant Sync Server, which then pushes the update down the persistent connection to the other clients (e.g., Client B).
5.  **Client B** receives the notification ("File 'report.docx' has been updated"). It then contacts the Application Server to get the new metadata (the new list of chunks).
6.  Client B checks which of the required chunks it already has locally. It only downloads the chunks it is missing, then reconstructs the new version of the file. This chunk-based downloading is extremely efficient.

### The "Offline" Problem:

What if a client is offline? The persistent connection model doesn't work. The solution is **long polling**.
-   When a client comes online, it first makes a call to the Application Server: `get_changes_since=<last_timestamp>`. This gets it caught up on all the changes that happened while it was offline.
-   After it's caught up, it can then switch to the persistent connection model for real-time updates.

---

## 5. Step 4: Data Model

### Metadata Database (Sharded SQL):

-   `Users`: `user_id`, `name`, `...`
-   `Files`: `file_id`, `owner_id`, `filename`, `is_directory`, `parent_id`, `...`
-   `FileVersions`: `version_id`, `file_id`, `created_at`, `...`
-   `FileVersionChunks`: `version_id`, `chunk_hash`, `chunk_order` (The join table that defines a file as an ordered list of chunks).
-   `Chunks`: `chunk_hash`, `storage_path`, `ref_count` (for deduplication).

The database would be sharded by `owner_id` or `file_id` to distribute the load.

---

## 12. Summary and Mastery Checklist

-   [ ] I have separated the storage of **file data (Block Store)** from **file metadata (Database)**.
-   [ ] I have designed an upload process that breaks files into **chunks** to enable deduplication and efficient parallel uploads.
-   [ ] I have designed a synchronization system that uses a **persistent connection** for real-time updates for online clients.
-   [ ] I have incorporated **long polling** for clients that are coming online to catch up on missed changes.
-   [ ] I have used a **Message Queue** to decouple the file upload process from the fan-out notification process.
-   [ ] I have proposed a scalable, sharded data model for the file metadata.
