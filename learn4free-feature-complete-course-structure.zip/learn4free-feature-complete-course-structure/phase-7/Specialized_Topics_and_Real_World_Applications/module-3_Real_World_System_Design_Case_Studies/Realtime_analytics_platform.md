# Case Study: Designing a Real-Time Analytics Platform

## 1. Clear Learning Objectives

By the end of this case study, you will be able to:

-   **Apply** system design principles to a high-throughput, data-intensive streaming application.
-   **Analyze** the requirements for a system that must provide low-latency analytics on fresh data.
-   **Design** a scalable event ingestion pipeline using a distributed log like Apache Kafka.
-   **Incorporate** a stream processing engine (like ksqlDB or Spark Streaming) to transform and aggregate data in real-time.
-   **Propose** a suitable OLAP database (e.g., Druid, ClickHouse) as the serving layer for analytical queries.
-   **Contrast** this streaming architecture with a traditional batch-based ETL/Data Warehouse architecture.

---

## 2. Step 1: Establish Requirements

### Functional Requirements:

1.  **Event Ingestion**: The system must be able to ingest a high volume of events from various sources (e.g., website clicks, mobile app usage, server logs).
2.  **Real-time Dashboard**: Provide a dashboard that allows users to query and visualize the event data with low latency.
3.  **Flexible Queries**: Users should be able to "slice and dice" the data, filtering and grouping by various dimensions (e.g., event type, user country, device type).

### Non-Functional Requirements:

1.  **High Throughput**: The ingestion layer must handle hundreds of thousands of events per second.
2.  **Low Query Latency**: 95% of analytical queries on the dashboard should return in under one second.
3.  **Data Freshness**: Data should be available for querying within seconds of the event occurring. This is a "near real-time" requirement.
4.  **Scalability**: The system should be able to scale to handle petabytes of event data.
5.  **Reliability**: The ingestion pipeline should be fault-tolerant with no data loss.

---

## 3. Step 2: High-Level Architecture (The Lambda Architecture, Simplified)

The core of this design is a **streaming pipeline**. We are not building a traditional request-response service. Instead, we are building a one-way flow of data from ingestion to processing to querying.

![Real-time Analytics Architecture](https://miro.medium.com/max/1400/1*b-8a-3F-g-3z-1E-2B-5f-9A.png)

-   **Event Sources**: The clients (web, mobile) and servers that generate the raw events.
-   **Collection/Ingestion Layer**: A highly scalable and durable system to act as the front door for all incoming events. **Apache Kafka** is the de facto standard for this.
-   **Stream Processing Layer**: A component that reads from Kafka, performs transformations (enrichment, aggregation) in real-time, and writes the results to the serving layer.
-   **Serving Layer (OLAP Database)**: A specialized, high-performance analytical database that ingests the processed data and serves the fast queries from the dashboard. **Apache Druid** or **ClickHouse** are excellent choices.
-   **Query/Visualization Layer**: The user-facing dashboard application (e.g., a web app using a tool like Apache Superset or a custom React frontend).

---

## 4. Step 3: Deep Dive into the Data Flow

### 1. Ingestion

1.  Clients send events via HTTP to a stateless **Collector Service**. This service's only job is to do minimal validation/sanitization and then write the event to a **Kafka Topic**.
2.  Using Kafka as the entry point provides several key benefits:
    -   **Durability**: Kafka durably stores the events on disk, acting as a massive, persistent buffer. If downstream components fail, the data is safe in Kafka.
    -   **Scalability**: Kafka is designed for extreme horizontal scalability and can handle millions of writes per second.
    -   **Decoupling**: It decouples the event producers from the event consumers.

### 2. Stream Processing

1.  A **Stream Processor** (e.g., a ksqlDB application, a Spark Streaming job, or a Flink job) subscribes to the raw events topic in Kafka.
2.  For each event, it can perform transformations:
    -   **Enrichment**: Look up the user's country based on their IP address.
    -   **Parsing**: Parse the user-agent string to identify the device type.
    -   **Real-time Aggregation**: It can maintain running counters in memory (e.g., number of clicks per minute) and emit these aggregates to a different Kafka topic.
3.  The processor then writes the final, enriched, and structured data to another Kafka topic, which will be the source for the serving layer.

### 3. Serving

1.  The **OLAP Database** (e.g., Apache Druid) has a built-in Kafka consumer. It ingests the structured data from the processed Kafka topic in near real-time.
2.  Druid is a **columnar, time-series-optimized database**. It is specifically designed to provide sub-second query latency on massive datasets by heavily pre-aggregating and indexing the data upon ingestion.
3.  When a user interacts with the **Dashboard UI**, the UI constructs a native JSON-based or SQL query and sends it to the Druid query brokers.
4.  Druid executes the query across its distributed cluster and returns the result, typically in a few hundred milliseconds.

---

## 5. Step 4: Why Not a Traditional Database?

Why can't we just use PostgreSQL or MySQL for this?
-   **Write Throughput**: A traditional relational database cannot handle the write load of hundreds of thousands of events per second.
-   **Query Performance**: An analytical query in PostgreSQL that performs a `GROUP BY` on a billion-row table would take many minutes or even hours to complete, not the sub-second latency required by an interactive dashboard. OLAP databases like Druid and ClickHouse are architecturally different (columnar storage, inverted indexes, etc.) and are specifically optimized for this workload.

This case study is a prime example of **Polyglot Persistence**: using the right database for the right job. We use Kafka for a durable log, and Druid/ClickHouse for analytical serving.

---

## 12. Summary and Mastery Checklist

-   [ ] I have designed an end-to-end **streaming architecture** for a real-time analytics workload.
-   [ ] I have chosen **Apache Kafka** as the scalable and durable ingestion layer to act as a central buffer for events.
-   [ ] I have incorporated a **stream processing** layer to perform real-time enrichment and aggregation of the data.
-   [ ] I have chosen a specialized **OLAP database** (like Druid or ClickHouse) as the serving layer to meet the low-latency query requirements.
-   [ ] I can clearly articulate why a traditional OLTP database is not suitable for this high-throughput, analytical use case.
