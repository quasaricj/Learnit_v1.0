# Case Study: Designing a Scalable Video Streaming Service

## 1. Clear Learning Objectives

By the end of this case study, you will be able to:

-   **Apply** system design principles to a media-heavy, high-throughput application.
-   **Analyze** the unique challenges of video streaming, particularly the video processing pipeline and global content delivery.
-   **Design** an asynchronous, message-driven workflow for video transcoding.
-   **Explain** the critical role of a Content Delivery Network (CDN) in providing a low-latency, high-quality viewing experience.
-   **Describe** the concept of Adaptive Bitrate Streaming and the protocols (like HLS or DASH) that enable it.
-   **Propose** a data model for storing video metadata and user information.

---

## 2. Step 1: Establish Requirements

### Functional Requirements:

1.  **Video Upload**: Users can upload videos.
2.  **Video Streaming**: Users can stream videos from any device.
3.  **Playback Controls**: Users can play, pause, and seek within a video.
4.  **Variable Quality**: The video player should automatically adjust the quality of the stream based on the user's network conditions.

### Non-Functional Requirements:

1.  **High Durability**: Uploaded videos must never be lost.
2.  **High Availability**: The service must be highly available for streaming.
3.  **Low Latency**: Video playback should start quickly (low time-to-first-frame), and buffering should be minimal.
4.  **Scalability**: The system must support millions of concurrent viewers and petabytes of video storage.

---

## 3. Step 2: High-Level Architecture

The system can be conceptually divided into two distinct parts:
1.  **The Video Processing Pipeline (The Write Path)**: Everything that happens after a user uploads a video.
2.  **The Video Streaming Pipeline (The Read Path)**: Everything that happens when a user clicks "play."

![Video Streaming Architecture](https://miro.medium.com/max/1400/1*d-e_P-D32-u_1-a-1qAFgA.png)

-   **API Gateway/Backend Services**: The standard stateless application layer for handling user requests (uploads, metadata, etc.).
-   **Message Queue**: To orchestrate the asynchronous transcoding pipeline.
-   **Transcoding Service**: A fleet of specialized workers (often GPU-enabled) that process the videos.
-   **Object Storage**: Two buckets—one for the original, raw uploads, and one for the processed, streamable video segments.
-   **Metadata Database**: To store information about the videos, users, and encoding formats.
-   **CDN**: The most critical component for the read path.

---

## 4. Step 3: Deep Dive - The Video Processing Pipeline (Offline)

When a user uploads a 1GB video file, we can't just serve that same file to other users. It needs to be processed for different devices and network speeds. This is a complex, asynchronous workflow.

1.  **Upload**: The user uploads the raw video file (e.g., `movie.mp4`) via the **API Gateway** to a dedicated **Upload Service**.
2.  **Store Original**: The Upload Service saves the original, high-quality file directly to a private **"Originals" Object Storage bucket**. This ensures durability.
3.  **Trigger Processing**: The Upload Service then writes the video metadata (title, user ID, path to the original file) to the **Metadata Database** and publishes a `VideoUploaded` message to the **Message Queue**.
4.  **Transcoding**:
    -   The **Transcoding Service** is a group of worker services that subscribe to the `VideoUploaded` message.
    -   When a worker receives a message, it downloads the original video file.
    -   It then performs **transcoding**: the process of converting the video into multiple different formats and bitrates. For a single video, it might generate:
        -   `1080p_high_bitrate.ts`
        -   `720p_medium_bitrate.ts`
        -   `480p_low_bitrate.ts`
    -   Crucially, it also breaks each of these versions into small, 10-second segments (e.g., `1080p_segment_001.ts`, `1080p_segment_002.ts`, etc.).
    -   It also creates a **manifest file** (e.g., `manifest.m3u8` for HLS), which is a simple text file that lists all the available quality levels and the URLs to their corresponding segments.
5.  **Store Processed Segments**: The transcoder uploads all the generated segments and the manifest file to a public **"Streamable" Object Storage bucket**.
6.  **Update Metadata**: Finally, the transcoder updates the video's record in the **Metadata Database** to mark it as "Ready" and stores the path to the manifest file.

---

## 5. Step 4: Deep Dive - The Video Streaming Pipeline (Real-Time)

This path must be extremely fast and scalable.

1.  **Request Video**: A user clicks "play" in their client (web or mobile player).
2.  **Fetch Metadata**: The client calls the backend API to get the video's metadata, which includes the URL to the **manifest file**.
3.  **Fetch from CDN**: The client requests the manifest file. This request, and all subsequent requests, are sent to the **CDN**.
    -   The CDN, if it doesn't have the file cached, will fetch it from the **"Streamable" Object Storage bucket** and cache it at the edge location closest to the user.
4.  **Adaptive Bitrate Streaming**:
    -   The video player inspects the manifest file and sees the list of available quality levels (1080p, 720p, etc.).
    -   It detects the user's current network speed and starts by requesting the first few segments of the appropriate quality level (e.g., the 720p segments).
    -   As playback continues, the player constantly monitors the network bandwidth.
        -   If the network gets faster, it will seamlessly switch to requesting the 1080p segments.
        -   If the network gets slower, it will switch down to the 480p segments to avoid buffering.
    -   This entire process is handled automatically by modern video players (like `video.js` or native mobile players) and is transparent to the user.

### Why is the CDN so critical?

Streaming video generates a massive amount of traffic. It would be prohibitively expensive and slow to serve all this data from a single origin server. The CDN distributes the load globally, providing low-latency, high-throughput delivery of the video segments directly from an edge server close to the user.

---

## 12. Summary and Mastery Checklist

-   [ ] I have designed two separate flows: an **asynchronous processing pipeline** for uploads and a **highly optimized streaming pipeline** for viewing.
-   [ ] I have used a **Message Queue** to manage the complex, multi-step **transcoding** process.
-   [ ] I have chosen **Object Storage** as the appropriate technology for storing large binary files.
-   [ ] I can explain **Adaptive Bitrate Streaming** and the role of the **manifest file** and segmented video files.
-   [ ] I understand that the **CDN** is the most critical component for achieving a scalable, low-latency video streaming experience.
