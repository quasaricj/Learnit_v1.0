# Capstone Project: Step 1 - Problem Identification and Scoping

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Select** a suitable, complex system to design for your capstone project.
-   **Apply** a structured approach to defining the problem and its boundaries.
-   **Elicit and document** a clear, concise set of functional and non-functional requirements.
-   **Perform** a "back-of-the-envelope" calculation to estimate the scale of the system.
-   **Justify** the scope of your Minimum Viable Product (MVP) and identify features that are out of scope.
-   **Create** a solid requirements document that will serve as the foundation for your High-Level Design.

---

## 2. Introduction: The Final Challenge

This capstone project is the culmination of the entire course. Your task is to bring together everything you have learned—from foundational programming concepts to advanced distributed systems patterns—to create a comprehensive High-Level Design for a complex, large-scale system of your own choosing.

This is not a coding project; it is a **design project**. The final output will be a detailed HLD document, similar to the case studies you have completed.

The most critical step in this entire process is the first one: clearly defining the problem you are going to solve. A brilliant design for the wrong problem is a useless design.

---

## 3. Step 1: Choose Your System

Select a well-known, large-scale application that you are familiar with as a user. This will give you a good starting point for understanding its core features.

### Good Project Choices:
-   Design a Ride-Sharing App (like Uber or Lyft)
-   Design a Food Delivery App (like DoorDash or Uber Eats)
-   Design a Ticket Booking System (like Ticketmaster)
-   Design a Web Crawler
-   Design a Distributed Job Scheduler
-   Design a "Pastebin" like service
-   Design an Instagram-like photo sharing service
-   Design a YouTube-like video streaming service
-   Design a "TinyURL" URL shortener
-   Design a real-time chat application (like WhatsApp)

Choose **one** of these or a similarly complex system.

---

## 4. Step 2: Define the Scope (MVP)

You cannot design all of Instagram or Uber in one HLD. You must aggressively **scope down** the problem to a manageable set of core features for a Minimum Viable Product (MVP).

-   **Example: Designing Uber**
    -   **Core Features (In Scope)**:
        -   A rider can request a ride from their location to a destination.
        -   A nearby driver can see and accept the ride request.
        -   The system tracks the driver's location in real-time.
        -   The system handles payment upon ride completion.
    -   **Extended Features (Out of Scope for this project)**:
        -   Surge pricing
        -   Driver ratings and reviews
        -   Uber Eats or other sub-brands
        -   Pre-scheduled rides

---

## 5. Step 3: Elicit and Document Requirements

This is the most important part of this module. You must create a formal requirements document.

### Functional Requirements

List the 3-5 core user stories that your design will support. Be specific.
-   *Bad*: "Users can get a ride."
-   *Good*: "A logged-in Rider must be able to request a ride by specifying their pickup location and destination. The system shall match them with the nearest available Driver."

### Non-Functional Requirements (NFRs)

This is what will drive your architecture. You must make reasonable, quantified assumptions.
-   **Scalability**:
    -   *How many active users?* (e.g., "10 million daily active users").
    -   *How many concurrent requests?* (e.g., "The system should handle 5,000 ride requests per second during peak hours.").
-   **Availability**:
    -   *What is the uptime target?* (e.g., "The core ride-booking service must have 99.99% availability.").
-   **Latency**:
    -   *What are the performance targets for critical operations?* (e.g., "A driver's location must be updated on the rider's map within 500ms.").
-   **Consistency**:
    -   *What level of consistency is needed?* (e.g., "It is acceptable for a driver's location to be a few seconds out of date (eventual consistency), but the final payment transaction must be strongly consistent.").

---

## 6. Step 4: Back-of-the-Envelope Estimation

Perform a quick, rough calculation to understand the scale of your NFRs. This helps to ground your design in reality.

-   **Example: Designing a Twitter-like Service**
    -   *Assumption*: 100 million daily active users.
    -   *Assumption*: 10% of users post one tweet per day.
        -   `100M users * 0.1 = 10M tweets/day`
        -   `10M / (24 hours * 3600 sec/hr) ≈ 115 tweets/sec (average write TPS)`
    -   *Assumption*: Each user reads 20 tweets per day.
        -   `100M users * 20 = 2 Billion tweet reads/day`
        -   `2B / (24 * 3600) ≈ 23,000 reads/sec (average read QPS)`
    -   **Conclusion**: The system is **extremely read-heavy**. This immediately tells you that your architecture must be optimized for fast reads (e.g., heavy caching, fan-out on write).

---

## 7. Deliverable for this Module

The output of this first stage of the capstone is a **Requirements and Scoping Document**. It should be a clear, concise document containing:
1.  Your chosen system.
2.  The defined MVP scope (in-scope and out-of-scope features).
3.  A detailed list of Functional Requirements.
4.  A detailed list of quantified Non-Functional Requirements.
5.  Your back-of-the-envelope estimation of the system's scale.

This document will be the foundation upon which you build your HLD in the next module.

---

## 12. Summary and Mastery Checklist

-   [ ] I have selected a suitable, large-scale system for my capstone project.
-   [ ] I have clearly defined the scope of my MVP, identifying what is in and out of scope.
-   [ ] I have written a clear set of specific, actionable Functional Requirements.
-   [ ] I have written a clear set of specific, **quantified** Non-Functional Requirements.
-   [ ] I have performed a back-of-the-envelope calculation to estimate the read/write load of my system.
-   [ ] I have a solid foundational document that I can now use to start my High-Level Design.
