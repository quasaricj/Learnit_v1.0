# Capstone Project: Step 2 - System Design and Implementation

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Synthesize** the various principles and patterns from the entire course into a single, cohesive design.
-   **Create** a comprehensive High-Level Design (HLD) document for your chosen system.
-   **Draw** clear and effective component and data flow diagrams.
-   **Define** the API contracts for the core services in your design.
-   **Justify** your architectural and technological choices based on the requirements you defined in the previous step.
-   **Analyze** and articulate the trade-offs you made in your design.

---

## 2. Introduction: Building the Blueprint

This is the heart of the capstone project. In the previous step, you created a detailed **Requirements and Scoping Document**. Now, you will use that document as your guide to create a complete **High-Level Design (HLD)** for your chosen system.

Your goal is to apply the knowledge you've gained from all the previous phases. You will be acting as the lead architect for this project, making the key decisions that will shape the system. The final deliverable for this step is a formal HLD document.

---

## 3. Your Task: Create the HLD Document

You must now create your HLD document. You should follow the structure and checklist provided in **Phase 6, Module 2: "Creating a High-Level Design (HLD) Document: A Checklist"**.

Your document must include, at a minimum, the following sections:

### 1. Overview and Goals
-   Briefly restate the problem and the goals of your design.

### 2. Requirements
-   Copy the detailed Functional and Non-Functional Requirements from your scoping document. These are the foundation of your design.

### 3. High-Level Architecture
-   Create a **Component Diagram**. This is the most important visual artifact. It should show the major services, databases, caches, load balancers, and other components of your system and how they interact.
-   State the architectural style you have chosen (e.g., Microservices) and briefly justify it.

### 4. Component Deep Dive
-   For each key component in your diagram (e.g., `RideMatchingService`, `GeoLocationService`), write a short paragraph describing its responsibilities.

### 5. Data Model and Storage
-   Propose a high-level database schema.
-   Choose the appropriate database technology (or technologies) for your components (**Polyglot Persistence**).
-   **Justify your choice**. For example, "We will use Cassandra for the GeoLocation service because its wide-column store is optimized for the high-throughput writes of location data. The user service, however, will use a relational database for its transactional nature."

### 6. API Contracts
-   Define the API contracts for 1-2 of the most critical interactions in your system (e.g., the API for requesting a ride, or the API for updating a driver's location).

### 7. Scalability, Reliability, and Security Plan
-   **Scalability**: How will your system handle the load defined in your NFRs? Discuss your strategy (e.g., stateless services, database sharding, caching).
-   **Reliability**: How will you meet your availability target? Discuss your use of redundancy, replication, failover, and resilience patterns (e.g., circuit breakers).
-   **Security**: Outline your security strategy (e.g., authentication at the API Gateway, mTLS between services).

### 8. Technology Stack
-   List and justify the key technologies you have chosen (language, frameworks, etc.).

### 9. Alternatives Considered
-   Briefly discuss a major design trade-off you made. For example, if you designed a "fan-out-on-write" feed system, briefly explain the "fan-out-on-read" alternative and why you rejected it.

---

## 4. Key Concepts to Apply

This is your chance to show what you've learned. As you create your design, think about how to incorporate the following concepts where appropriate:

-   **Phase 1-3 Foundations**: SOLID principles, Data Structures, OOP.
-   **Phase 4 Cloud/Containers**: How would you containerize your services? How does your design leverage cloud infrastructure?
-   **Phase 5 System Design Fundamentals**:
    -   Load Balancing
    -   Caching Strategies
    -   Stateless vs. Stateful Tiers
    -   Message Queues for asynchronous communication
    -   CDNs for static content
-   **Phase 6 Advanced Design**:
    -   API Gateway Pattern / BFF
    -   Resilience Patterns (Circuit Breaker, Bulkhead)
    -   Distributed Transactions (Saga Pattern)
    -   Security principles (mTLS, Zero Trust)
-   **Phase 7 Specialized Topics**:
    -   Performance analysis and optimization
    -   Advanced database choices (OLTP vs. OLAP)

---

## 5. Deliverable for this Module

The output of this stage is a **complete High-Level Design (HLD) Document**. This should be a polished, professional document that clearly and comprehensively describes your proposed architecture and the reasoning behind it. It should be detailed enough that a team of engineers could use it as their guide to begin the low-level design and implementation of the system.
