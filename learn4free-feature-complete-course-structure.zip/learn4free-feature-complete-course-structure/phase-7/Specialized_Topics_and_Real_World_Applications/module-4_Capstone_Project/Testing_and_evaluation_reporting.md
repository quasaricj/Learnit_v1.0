# Capstone Project: Step 3 - Testing, Evaluation, and Reporting

## 1. Clear Learning Objectives

By the end of this module, you will be able to:

-   **Develop** a comprehensive testing strategy for a complex, distributed system.
-   **Define** a performance testing plan to validate that your design meets its non-functional requirements.
-   **Identify** the key Service Level Indicators (SLIs) for your system and set realistic Service Level Objectives (SLOs).
-   **Structure** a final project report that professionally communicates your design and the reasoning behind it.
-   **Reflect** on the design process and the trade-offs made.

---

## 2. Introduction: Validating Your Design

A design on paper is a hypothesis. The final step in any design process is to define how you will test and validate that hypothesis. How will you prove that your design is correct, resilient, and performant?

This final step of the capstone project asks you to step into the role of a test or SRE architect. You will not actually *run* these tests, but you must create a clear and thorough plan for how you *would* test and evaluate the system you've designed.

---

## 3. Your Task: Create a Testing and Evaluation Plan

Add the following sections to your HLD document.

### 1. Overall Testing Strategy

Outline your approach to ensuring the quality of the system. This should cover the different levels of the testing pyramid.
-   **Unit Testing**: What is your strategy for unit testing? (e.g., "All business logic in the domain layer will have 100% unit test coverage. Dependencies will be mocked using Dependency Injection.").
-   **Integration Testing**: How will you test the "contracts" between your microservices? (e.g., "We will use consumer-driven contract testing with a tool like Pact to ensure the `OrderService` and `PaymentService` can communicate correctly.").
-   **End-to-End Testing**: How will you validate a full user journey? (e.g., "A small suite of automated E2E tests will run in a staging environment to validate the critical 'request a ride' flow.").

### 2. Performance Testing Plan

This is the most critical part of the evaluation. It directly validates your non-functional requirements.
-   **Goal**: State the specific NFR you are testing (e.g., "Verify the system can handle 5,000 ride requests per second with a p99 latency of < 500ms.").
-   **Tooling**: What tool would you use? (e.g., "We will use JMeter or k6.").
-   **Methodology**: Describe the load test.
    -   What specific API endpoints will you target?
    -   What will the load profile look like? (e.g., "Ramp up from 0 to 10,000 virtual users over 10 minutes and hold the load for 1 hour.").
-   **Success Criteria**: What are the pass/fail criteria for the test? (e.g., "The test will be considered successful if the p99 latency remains below 500ms and the error rate is less than 0.1%.").

### 3. Monitoring and SLOs

How will you monitor the system in production to ensure it continues to meet its goals?
-   **Key SLIs**: List the top 3-4 Service Level Indicators for your system. These should be the "Four Golden Signals" applied to your specific design.
    -   *Example (for Uber)*:
        -   **Latency**: The p99 latency of the `request_ride` API endpoint.
        -   **Traffic**: The number of active drivers online.
        -   **Errors**: The error rate for the payment processing service.
        -   **Saturation**: The depth of the ride request message queue.
-   **SLOs**: For each SLI, define a precise Service Level Objective.
    -   *Example*: "The `request_ride` API endpoint will have a 99.9% success rate, measured over a 28-day window."

---

## 4. Final Deliverable: The Capstone Report

Your final task is to assemble your work into a single, polished **Capstone Project Report**. This document should contain:

1.  **Part 1: Problem Identification and Scoping**
    -   Your complete requirements document from the first step of the project.

2.  **Part 2: High-Level Design**
    -   Your complete HLD document from the second step of the project, including all diagrams, justifications, and API contracts.

3.  **Part 3: Testing and Evaluation Plan**
    -   The testing strategy and SLO definitions you created in this final step.

This report is a comprehensive demonstration of your ability to lead a system design project from conception to a detailed, actionable architectural plan.

---

## 5. Course Reflection

Take a moment to reflect on your design.
-   What was the most difficult trade-off you had to make?
-   Which part of your design are you least confident in, and how would you seek to improve it?
-   How has your understanding of system design changed from the beginning of this course to the end?

Congratulations on completing the "Mastery in Software Development and System Design" course!

---

## 12. Summary and Mastery Checklist

-   [ ] I have defined a multi-layered testing strategy, including unit, integration, and end-to-end testing.
-   [ ] I have created a specific, actionable **performance testing plan** designed to validate the NFRs of my system.
-   [ ] I have identified the key **SLIs** for my system and defined a set of precise **SLOs**.
-   [ ] I have assembled all the parts of the capstone project into a final, comprehensive report.
-   [ ] I have successfully completed the capstone project and the course.
